var HtmlWebpackPlugin = require('html-webpack-plugin');

module.exports = {
    mode: 'stage',
    resolve: {
        extensions: ['.js', '.jsx']
    },
    module: {
        rules: [
            {
                test: /\.jsx?$/,
                loader: 'babel-loader'
            }, {
                test: /\.(png|jpe?g|gif|svg|ttf|woff|woff2|eot)$/i,
                loader: 'file-loader',
                options: {
                    name: '[path][name].[ext]'
                }
            },
            {
                test: /\.s[ac]ss$/i,
                use: [
                    // Creates `style` nodes from JS strings
                    'style-loader',
                    // Translates CSS into CommonJS
                    'css-loader',
                    // Compiles Sass to CSS
                    'sass-loader'
                ]
            },
            {
                test: /\.css$/i,
                use: [
                    // Creates `style` nodes from JS strings
                    'style-loader',
                    // Translates CSS into CommonJS
                    'css-loader'
                ]
            }
        ]
    },
    output: {
        publicPath: '',
    },
    plugins: [
        new HtmlWebpackPlugin({
            template: './src/index.html'
        })],
    devServer: {
        historyApiFallback: {disableDotRule: true}
    },
    externals: {
        // global app config object
        config: JSON.stringify({
           // apiUrl: 'http://mtznjv1guvm71.kvm.cip.att.com:7001/Dragon2Rest/resources',//for  stage server
            logoutUrl:'https://oidc.stage.elogin.att.com'

        })
    }
};