import React, {Component} from "react";
import PropTypes from "prop-types";
import {acctDelegationActions, alertActions, delegateNameserverActions, delegationActions} from "../../../_actions";
import {withRouter} from "react-router-dom";
import {connect} from "react-redux";
import {accountService, delegationNSService, delegationService, zoneService} from "../../../_services";
import _ from "lodash";
import {DELEGATIONNS_RESPONSE_TO_REQUEST_MAP, removeEmptyValues} from "../../../_helpers";
import {Button, Card, CardContent, Dialog, DialogActions, DialogTitle} from "@material-ui/core";
import Form from "react-bootstrap/Form";
import {Col, Row} from "react-bootstrap";
import {Helmet} from "react-helmet";
import Container from "@material-ui/core/Container";
import {Alert} from "@material-ui/lab";

class AccountDelegationNS extends Component {
    constructor(props) {
        super(props);
        this.state = {
            zoneData: {},
            delegation: {},
            loading: true,
            alert: '',
            showDeleteConfirm: false,
            nameserver: {
                zoneNum: this.props.match.params.zoneNum,
                delegationId: this.props.match.params.id,
                accountId: '',
                recId: this.props.match.params.recId,
                delegationName: '',
                ns1: '',
                DType: '',
                ttl: '',
                comments: '',
                cut_ns_fqdn: ''
            },


        }
        this.isComponentMounted = false
        this.saveDelegationNS = this.saveDelegationNS.bind(this);
        this.deleteDelegationNS = this.deleteDelegationNS.bind(this);
        this.getDeleteConfirmDialog = this.getDeleteConfirmDialog.bind(this);
        this.updateDelegationNSObj = this.updateDelegationNSObj.bind(this);

        if ((this.props.location.state === null || this.props.location.state === undefined || !this.props.location.state.showAlerts) && !_.isEmpty(this.props.alert)) {
            this.props.alertClear()
        }
    }


    async componentDidMount() {


        this.isComponentMounted = true;
        const accountResponse = await accountService.getAccountById(this.props.match.params.accountId)
        // const resp = await zoneService.getZoneById(this.props.match.params.zoneNum)

        /* if (this.props.match.path = "/dns/accounts/details/:accountId/acctDelg/:id/nameServers/acctDelgNS") {

         }*/
        if (this.isComponentMounted) {
            if (!this.props.isEmptyForm) {
                const response = await delegationNSService.getByDelegationId(this.props.match.params.id);
                if (!_.isEmpty(response)) {
                    this.setState({loading: false, account: accountResponse, nameserver: response.nameserver});
                }
            } else {
                const response = await delegationService.getByDelegationId(this.props.match.params.delegationId);
                if (!_.isEmpty(response)) {
                    this.setState({
                        loading: false,
                        account: accountResponse,
                        nameserver: {zoneNum: response.delegation.zoneNum, delegationId: response.delegation.recId}
                    });
                }
            }
        }
        /*
                else {
                    console.log(123)
                    this.props.history.push({
                        pathname: `/dns/accounts/details/${this.props.match.params.accountId}/acctDelg/${this.props.match.params.delegationId}/acctDelgNS`,
                        state: {showAlerts: true}
                    })
                }
        */


    }


    saveDelegationNS(e) {
        e.preventDefault()
        console.log(this.state.delegation, "account delegation");

        if (this.isComponentMounted) {
            this.setState({loading: !this.props.isEmptyForm})//changed it so that it supports loading on create page

        }

        if (this.props.isEmptyForm && this.props.isEditable) {
            const nameservers = removeEmptyValues({
                zoneName: this.state.zoneData.zoneName,
                //zoneNum:this.state.nameserver.zoneNum,
                ...this.state.nameserver
            })

            this.props.create(nameservers,this.props.match.params.accountId);


        } else {

            const updatedNameservers = removeEmptyValues({
                zoneName: this.state.zoneData.zoneName,
                ns1: this.state.nameserver.ns1,
                comments: this.state.nameserver.comments,
                ttl: this.state.nameserver.ttl,
                //...this.state.nameserver
            })

            this.props.update(this.props.match.params.id, this.props.match.params.accountId, updatedNameservers);
        }
    }

    componentWillUnmount() {
        this.isComponentMounted = false;
    }

    updateDelegationNSObj(e) {
        let {name, value} = e.target;
        const {nameserver} = this.state;
        if (DELEGATIONNS_RESPONSE_TO_REQUEST_MAP.hasOwnProperty(name)) {
            delete nameserver[name];
            name = DELEGATIONNS_RESPONSE_TO_REQUEST_MAP[name];
        }

        this.setState({nameserver: {...nameserver, [name]: value}})
    }


    deleteDelegationNS() {
        this.setState({showDeleteConfirm: false, loading: true})
        this.props.delete(this.props.match.params.id, this.props.match.params.accountId, this.props.match.params.delegationId);


    }

    getDeleteConfirmDialog() {
        return !this.props.isEditable && <Dialog
            onClose={(event, reason) => {
                if (reason === 'backdropClick' || reason === 'escapeKeyDown') {
                    return false;
                }
            }}
            maxWidth="xs"
            aria-labelledby="confirmation-dialog-title"
            open={this.state.showDeleteConfirm}
        >
            <DialogTitle id="confirmation_dialog_title">Are you sure you want to delete this
                delegation?</DialogTitle>
            <DialogActions>
                <Button autoFocus onClick={this.deleteDelegationNS} className={"dns-blue-button text-white"}>
                    Delete
                </Button>
                <Button onClick={() => this.setState({showDeleteConfirm: false})}
                        className={"dns-blue-button text-white"}>
                    Cancel
                </Button>
            </DialogActions>
        </Dialog>
    }

    getDelegationNSPageButtons() {
        let pageElements = {
            pageTitle: '',
            pageButtons: [],
        }
        if (this.props.isEditable && this.props.isEmptyForm) {
            pageElements.pageTitle = "DNS Delegations NameServers Insert Page"
            pageElements.pageButtons.push(<Button className={"dns-blue-button text-white mr-2"}
                                                  type={"submit"} key={"insert_dlgNS"}>Insert</Button>)
            pageElements.pageButtons.push(<Button className={"dns-blue-button text-white mr-2 col-md-1"}
                                                  onClick={() => this.props.history.goBack()}
                                                  key={"cancel_update"}>Cancel</Button>)


        } else if (this.props.isEditable) {
            pageElements.pageTitle = "DNS Delegation Name Servers Update Page"
            pageElements.pageButtons.push(<Button className={"dns-blue-button text-white mr-2 col-md-1"}
                                                  type={"submit"}
                                                  key={"update_dlgNS"}>Update</Button>)
            pageElements.pageButtons.push(<Button className={"dns-blue-button text-white mr-2 col-md-1"}
                                                  onClick={() => this.props.history.goBack()}
                                                  key={"cancel_update"}>Cancel</Button>)


        } else {
            pageElements.pageTitle = "DNS Delegate NameServer Details Page"
            pageElements.pageButtons.push(<Button className={"dns-blue-button text-white mt-2 mr-4 mb-4"}
                                                  onClick={() => {
                                                      this.props.history.push(`/dns/accounts/details/${this.props.match.params.accountId}/acctDelg/${this.props.match.params.delegationId}/nameServers/acctDelgNS/edit/${this.props.match.params.id}`)
                                                  }}
                                                  key={"edit_dlgNS"}>Go To Update</Button>)
            pageElements.pageButtons.push(<Button className={"dns-blue-button text-white mt-2 mr-4 mb-4"}
                                                  onClick={() => {
                                                      this.setState({showDeleteConfirm: true})
                                                  }} key={"delete_dlgNS"}>Delete</Button>)
            pageElements.pageButtons.push(<Button className={"dns-blue-button text-white ml-2 mt-2 mb-4"}
                                                  onClick={() => {
                                                      this.props.history.push(`/dns/accounts/details/${this.props.match.params.accountId}/acctDelg/${this.props.match.params.delegationId}/nameServers/acctDelgNS`)


                                                  }}
                                                  key={"dlgNS_List"}>List Delegation NameServers</Button>)


        }

        return pageElements;
    }

    getDelegationNSForm() {
        let {nameserver} = this.state;
        let {pageButtons} = this.getDelegationNSPageButtons();
        return <form onSubmit={this.saveDelegationNS}>
            {!this.props.isEmptyForm && <> <Form.Group as={Row} className={"align-items-center"}>

                <Form.Label column sm="2" className={"font-weight-bold"}>
                    Record ID
                </Form.Label>

                <Col sm={4}>
                    {nameserver.recId}
                </Col>


                {(this.props.isEditable || !this.props.isEmptyForm) && <>    <Form.Label column sm="2"
                                                                                         className={"font-weight-bold"}>
                    Delegation RecID
                </Form.Label>
                    <Col sm={4}>
                        {nameserver.delegationId}
                    </Col></>}

            </Form.Group>                </>}


            <Form.Group as={Row} className={"align-items-center"}>
                <Form.Label column sm="2"
                            className={"font-weight-bold"}>
                    Zone ID
                </Form.Label>
                <Col sm={4}>
                    {nameserver.zoneNum}
                </Col>
                {this.props.isEmptyForm && <>     <Form.Label column sm="2"
                                                              className={"font-weight-bold"}>
                    Sub Zone ID
                </Form.Label>
                    <Col sm={2}>
                        {nameserver.delegationId}
                    </Col></>}
            </Form.Group>

            {
                !this.props.isEditable && <Form.Group as={Row} className={"align-items-center mb-2"}>
                    <Form.Label column sm="2" className={"font-weight-bold"}>
                        Created
                    </Form.Label>
                    <Col sm="4">
                        {nameserver.createTime}
                    </Col>
                    <Form.Label column sm="2" className={"font-weight-bold"}>
                        Last Modified
                    </Form.Label>
                    <Col sm="4">
                        {nameserver.modTime}
                    </Col>

                </Form.Group>
            }

            <Form.Group as={Row}
                        className={"align-items-center"}>
                <Form.Label column sm="2"
                            className={"font-weight-bold"}>
                    Server's Full Name
                </Form.Label>
                <Col sm={4}>
                    {(this.props.isEmptyForm || this.props.isEditable) ?

                        <Form.Control name={"cut_ns_fqdn"}
                                      onChange={this.updateDelegationNSObj}
                                      defaultValue={nameserver.cut_ns_fqdn ? nameserver.cut_ns_fqdn : ''}/> : nameserver.cut_ns_fqdn}
                </Col>
            </Form.Group>


            <Form.Group as={Row}
                        className={"align-items-center"}>
                <Form.Label column sm="2" className={"font-weight-bold"}>
                    Time To Live
                </Form.Label>
                <Col sm={4}>
                    {this.props.isEditable ?

                        <Form.Control name={"ttl"}
                                      onChange={this.updateDelegationNSObj}
                                      defaultValue={nameserver.ttl ? nameserver.ttl : ''}/> : nameserver.ttl}
                </Col>
            </Form.Group>


            <Form.Group as={Row} className={"align-items-center"}>
                <Form.Label column sm="2"
                            className={"font-weight-bold"}>
                    Comment
                </Form.Label>
                <Col sm={4}>
                    {this.props.isEditable ?

                        <Form.Control name={"comment"}
                                      onChange={this.updateDelegationNSObj}
                                      defaultValue={nameserver.comment ? nameserver.comment : ''}/> : nameserver.comment}
                </Col>


                {!this.props.isEditable && <>  <Form.Label column sm="2" className={"font-weight-bold"}>
                    Modified By
                </Form.Label>
                    <Col sm="4">
                        {this.props.isEditable ?
                            <Form.Control name={"modBy"} onChange={this.updateDelegationNSObj}
                                          defaultValue={nameserver.modBy ? nameserver.modBy : ''}/> : nameserver.modBy}
                    </Col></>}

            </Form.Group>


            <div className={"text-center"}>
                {pageButtons.map(buttonComp => buttonComp)}
            </div>
        </form>

    }


    render() {
        let {pageTitle} = this.getDelegationNSPageButtons();
        return (
            <>
                {this.getDeleteConfirmDialog()}
                <div>
                    <Helmet>
                        <title>DNS Admin | DNS Delegate NameServer Details Page
                        </title>
                    </Helmet>
                    <Container maxWidth={false} className={"px-2"}>
                        <Card>
                            <CardContent>
                                <h5 className="font-weight-bold  text-capitalize text-left pt-3 pb-1 pl-4">{pageTitle}</h5>
                                <div className={"pb-2 pl-4"}>
                                    <div className={"pb-2"}>
                                        {this.props.alert.message && <Alert
                                            severity={this.props.alert.type}>{this.props.alert.message}</Alert>}</div>
                                    {this.getDelegationNSForm()}
                                </div>
                            </CardContent>
                        </Card>
                    </Container>
                </div>
            </>)
    }


}


AccountDelegationNS.defaultProps =
    {
        isEditable: false,
    };

AccountDelegationNS.propTypes =
    {
        isEditable: PropTypes.bool.isRequired,
        isEmptyForm: PropTypes.bool

    };

function mapState(state) {
    const {saving, loading, saved, deleted} = state.delegationServers

    const {alert} = state
    return {saving, loading, saved, deleted, alert}
}

const actionCreators = {
    alertClear: alertActions.clear,
    create: acctDelegationActions.createNS,
    update: acctDelegationActions.updateNS,
    delete: acctDelegationActions.deleteNS,
};

const connectedAccountDelegationNS = withRouter(connect(mapState, actionCreators)(AccountDelegationNS));
export {connectedAccountDelegationNS as AccountDelegationNS};