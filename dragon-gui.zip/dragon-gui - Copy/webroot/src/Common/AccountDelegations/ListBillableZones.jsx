import React, {Component} from "react";
import {withRouter} from "react-router-dom";
import {connect} from "react-redux";
import {alertActions} from "../../_actions";
import {Helmet} from "react-helmet";
import Container from "@material-ui/core/Container";
import {Card, CardContent} from "@material-ui/core";
import {Alert} from "@material-ui/lab";
import BootstrapTable from "react-bootstrap-table-next";
import {accountService, resourceRecordService, zoneService} from "../../_services";

class ListBillableZones extends Component {
    constructor(props) {
        super(props);
        this.state = {
            data: [],

        }
        this.isComponentMounted = false;
    }

/*
    async componentDidMount() {
        this.isComponentMounted = true;
        const res = await zoneService.getZoneById(this.props.match.params.zoneNum)
/!*
        if (this.isComponentMounted) {

            this.setState({zoneData: res.zone});
        }
*!/

        if (this.isComponentMounted) {
            this.setState({submitted: true, loading: true})
        }

        zoneService.getAll(data).then(res => {
            if (this.isComponentMounted) {
                console.log(data, "data")
                this.setState({
                    loading: false,
                    data: res.zones,
                    totalSize: res.totalRecords,

                });
            }
        });
        await this.loadTableData({zoneNum: this.props.match.params.zoneNum, rrType: this.props.match.params.type});
    }
*/
    async  componentDidMount() {
        this.isComponentMounted = true;
        setTimeout(() => {
            this.props.alertClear()
        }, 10000)//this clears alert message on listing or search page after 10 seconds
        await this.loadTableData({zoneNum: this.props.match.params.zoneNum});

    }

    async loadTableData(data) {
        if (this.isComponentMounted) {
            this.setState({loading: true})
        }
        const res = await resourceRecordService.getAllRecords(data);
        if (this.isComponentMounted) {
            this.setState({loading: false, data: res.rr, error: res.error});


        }
    }


    componentWillUnmount() {
        this.isComponentMounted = false;
    }

    getBillableZonesTableColumns() {
        return [
            {
                dataField: 'zoneName',
                text: 'Zone Name',
                headerAlign: 'center',
                classes: 'text-left p-0',
                headerStyle: {
                    width: '20%'
                },
                style: {
                    wordWrap: 'break-word'
                },


            },
            {
                dataField: 'zoneNum',
                text: 'Zone Id',
                headerAlign: 'center',
                classes: 'text-left p-0',
                headerStyle: {
                    width: '20%'
                },
                style: {
                    wordWrap: 'break-word'
                },

            },
            {
                dataField: 'createTime',
                text: 'Zone Create Time',
                headerAlign: 'center',
                classes: 'text-left p-0',
                headerStyle: {
                    width: '20%'
                },
                style: {
                    wordWrap: 'break-word'
                },
            },
        ];

    }


    render() {
        const {data} = this.state;
        let columns = this.getBillableZonesTableColumns();
        return <div>
            <Helmet><title>
                DNS Zone Transfers ACLs
            </title></Helmet>

            <Container maxWidth={false} className={"px-2"}>
                <Card>
                    <CardContent>
                        <div className="mt-2 ml-2 mr-3 mb-2  pb-5">
                            <h5 className={"font-weight-bold mt-4 mb-4"}>List Of Billable Zones</h5>

                            <div>
                                {this.props.alert.message &&
                                <Alert severity={this.props.alert.type}>{this.props.alert.message}</Alert>}
                                <div className="pl-2 pr-2">
                                    <BootstrapTable bootstrap4
                                                    keyField={"zoneNum"}
                                                    data={data}
                                                    columns={columns}
                                                    noDataIndication="Table is Empty"
                                                    remote
                                                    condensed
                                                    striped
                                                    hover
                                                    loading={true}
                                    />

                                </div>
                            </div>
                        </div>
                    </CardContent>
                </Card>
            </Container>
        </div>

    }
}

function mapState(state) {
    const {alert} = state
    return {alert}
}

const actionCreators = {
    alertClear: alertActions.clear,
};

const connectedListBillableZones = withRouter(connect(mapState, actionCreators)(ListBillableZones));
export {connectedListBillableZones as ListBillableZones};
