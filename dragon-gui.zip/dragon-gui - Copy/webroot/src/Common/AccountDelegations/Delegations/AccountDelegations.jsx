import {Helmet} from "react-helmet";
import Container from "@material-ui/core/Container";
import {
    Button,
    Card,
    CardContent,
    Dialog,
    DialogActions,
    DialogTitle, FormControlLabel, Radio, RadioGroup
} from "@material-ui/core";
import {Alert} from "@material-ui/lab";
import {acctDelegationActions, alertActions, delegationActions} from "../../../_actions";
import {withRouter} from "react-router-dom";
import {connect} from "react-redux";
import React, {Component} from "react";
import {accountService, delegationService} from "../../../_services";
import _ from "lodash";
import Form from "react-bootstrap/Form";
import {Col, Row} from "react-bootstrap";
import {removeEmptyValues} from "../../../_helpers";
import PropTypes from "prop-types";

class AccountDelegations extends Component {
    constructor(props) {
        super(props);
        this.state = {
            zoneData: {},
            zone: this.props.isEmptyForm ? {
                zoneSubType: "IP4",
            } : {},
            /*   zone: {
                   zoneSubType: "IP4",
               },*/
            loading: false,
            account: {},
            alert: '',
            showDeleteConfirm: false,
            delegation: {
                accountId: this.props.match.params.accountId,
                recId: this.props.match.params.recId,
                //zoneNum: '',
                zoneNum: this.props.match.params.zoneNum,
                delegationName: '',
                ns1: '',
                ns2: '',
                zoneName: '',
                DType: '',

            },
        }
        console.log(this.state.delegation, "delegation")

        this.isComponentMounted = false
        this.saveAccountDelegation = this.saveAccountDelegation.bind(this);
        this.deleteDelegation = this.deleteDelegation.bind(this);
        this.updateDelegationObj = this.updateDelegationObj.bind(this);
        this.getDeleteConfirmDialog = this.getDeleteConfirmDialog.bind(this);

        if ((this.props.location.state === null || this.props.location.state === undefined || !this.props.location.state.showAlerts) && !_.isEmpty(this.props.alert)) {
            this.props.alertClear()
        }

    }

    saveAccountDelegation(e) {
        e.preventDefault()
        console.log(this.state.delegation, "account delegation");
        //const res = zoneService.getZoneById(this.props.match.params.zoneNum)


        if (this.isComponentMounted) {
            this.setState({loading: !this.props.isEmptyForm})//changed it so that it supports loading on create page

        }


        if (this.props.isEmptyForm && this.props.isEditable) {
            const delegations = removeEmptyValues({
                accountId: this.state.account.accountId,
                zoneName: this.state.delegation.zoneName,
                zoneNum: this.state.delegation.zoneNum,
                ns1: this.state.delegation.ns1,

                ...this.state.delegation
            })
            delegations.delegationName= _.trimEnd(delegations.delegationName,'.')+'.'

            //this.props.create(delegations,this.state.account.serviceName);
           this.props.create(delegations);


        } else {
            this.props.update(this.props.match.params.id, {
                accountId: this.state.account.accountId, ...this.state.delegation
            });
        }


    }

    updateDelegationObj(e) {
        let {name, value} = e.target;
        const {delegation} = this.state;
        value = value.trim();
        if (this.isComponentMounted) {
            this.setState({delegation: {...delegation, [name]: value}})
        }
    }


    async componentDidMount() {
        this.isComponentMounted = true;
        const accountResponse = await accountService.getAccountById(this.props.match.params.accountId)

        if (this.isComponentMounted) {
            this.setState({loading: !this.props.isEmptyForm, account: accountResponse});
        }

        if (!this.props.isEmptyForm && this.isComponentMounted) {
            const response = await delegationService.getByDelegationId(this.props.match.params.id);
            if (!_.isEmpty(response) && this.isComponentMounted) {

                this.setState({loading: false, delegation: response.delegation});

            } else {
                console.log(123)
                this.props.history.push({
                    pathname: `/dns/account/details/${this.props.match.params.accountId}/acctDelg`,
                    state: {showAlerts: true}
                })
            }

        }

    }


    deleteDelegation() {
        if (this.isComponentMounted) {
            this.setState({showDeleteConfirm: false, loading: true})
        }
        this.props.delete(this.props.match.params.id, this.props.match.params.accountId);

    }

    componentWillUnmount() {
        this.isComponentMounted = false;
    }


    getPageButtons() {
        let pageElements = {
            pageTitle: '',
            pageButtons: [],
        }
        if (this.props.isEditable && this.props.isEmptyForm) {
            pageElements.pageTitle = "Create New Delegation"
            pageElements.pageButtons.push(<Button className={"dns-blue-button text-white mr-2"}
                // onClick={this.saveAccountDelegation}
                                                  type={"submit"}
                                                  key={"insert"}>Insert</Button>)
            pageElements.pageButtons.push(<Button className={"dns-blue-button text-white mr-2 col-md-1"}
                                                  onClick={() => this.props.history.goBack()}
                                                  key={"cancel_update"}>Cancel</Button>)


        } else if (this.props.isEditable) {
            pageElements.pageTitle = "DNS Delegation Update"
            pageElements.pageButtons.push(<Button className={"dns-blue-button text-white mr-2 col-md-1"}
                                                  type={"submit"}
                                                  key={"update"}>Update</Button>)
            pageElements.pageButtons.push(<Button className={"dns-blue-button text-white mr-2 col-md-1"}
                                                  onClick={() => this.props.history.goBack()}
                                                  key={"cancel_update"}>Cancel</Button>)


        } else {
            pageElements.pageTitle = "DNS Delegation Details"
            pageElements.pageButtons.push(<Button className={"dns-blue-button text-white mt-2 mr-4 mb-4"}
                                                  onClick={() => this.props.history.push(`/dns/accounts/details/${this.props.match.params.accountId}/acctDelg/edit/${this.props.match.params.id}`)}
                                                  key={"edit"}>Go To Update</Button>)
            pageElements.pageButtons.push(<Button className={"dns-blue-button text-white mt-2 mr-4 mb-4"}
                                                  onClick={() => {
                                                      this.setState({showDeleteConfirm: true})
                                                  }} key={"delete"}>Delete</Button>)
            pageElements.pageButtons.push(<Button className={"dns-blue-button text-white mt-2 mb-4"}
                                                  onClick={() => this.props.history.push(`/dns/accounts/details/${this.props.match.params.accountId}/acctDelg`)}
                                                  key={"acctDel_List"}>List Delegations</Button>)
            pageElements.pageButtons.push(<Button className={"dns-blue-button text-white ml-2 mt-2 mb-4"}
                                                  onClick={() => {
                                                      this.props.history.push(`/dns/accounts/details/${this.props.match.params.accountId}/acctDelg/${this.props.match.params.id}/nameServers/acctDelgNS`)
                                                  }}
                                                  key={"naptr"}>List Delegation NameServers</Button>)


        }

        return pageElements;
    }

    getDeleteConfirmDialog() {
        return !this.props.isEditable && <Dialog
            onClose={(event, reason) => {
                if (reason === 'backdropClick' || reason === 'escapeKeyDown') {
                    return false;
                }
            }}
            maxWidth="xs"
            aria-labelledby="confirmation-dialog-title"
            open={this.state.showDeleteConfirm}
        >
            <DialogTitle id="confirmation_dialog_title">Are you sure you want to delete this
                delegation?</DialogTitle>
            <DialogActions>
                <Button autoFocus onClick={this.deleteDelegation} className={"dns-blue-button text-white"}>
                    Delete
                </Button>
                <Button onClick={() => this.setState({showDeleteConfirm: false})}
                        className={"dns-blue-button text-white"}>
                    Cancel
                </Button>
            </DialogActions>
        </Dialog>
    }

    getAccountDelegationForm() {
        let {zoneData, account, delegation} = this.state;
        let {pageButtons} = this.getPageButtons();
        console.log(zoneData)
        return <form onSubmit={this.saveAccountDelegation}>
            {/*            {this.props.alert.message &&
                <Alert severity={this.props.alert.type} className={"mb-3"}>{this.props.alert.message}</Alert>}*/}
            <Form.Group as={Row} className={"align-items-center"}>
                {(!this.props.isEmptyForm && this.props.isEditable) && <>
                    <Form.Label column sm="2"
                                className={"font-weight-bold"}>
                        Zone ID
                    </Form.Label>
                    <Col sm={4}>
                        {delegation.zoneNum}

                    </Col></>}


            </Form.Group>
            <Form.Group as={Row} className={"align-items-center"}>
                {!this.props.isEmptyForm && <> <Form.Label column sm="2"
                                                           className={"font-weight-bold"}>
                    Delegation RecId
                </Form.Label>
                    <Col sm={4}>
                        {delegation.recId}
                    </Col></>}

                {(this.props.isEditable || !this.props.isEmptyForm) && <>      <Form.Label column sm="2"
                                                                                           className={"font-weight-bold"}>
                    Account Id

                </Form.Label>
                    <Col sm={4}>
                        {account.accountId}


                    </Col></>}

            </Form.Group>
            <Form.Group as={Row} className={"align-items-center"}>
                {(this.props.isEditable || !this.props.isEmptyForm) && <> <Form.Label column sm="2"
                                                                                      className={"font-weight-bold"}>
                    Organization
                </Form.Label>

                    <Col sm="4">
                        {account.company}

                    </Col></>}
            </Form.Group>


            {this.props.isEmptyForm && <> <Form.Group as={Row} className={'align-items-center'}>

                <p>
                    There are different formats that can be used here for Zone Name and Delegation Name.
                    Please select the appropriate format before filling the fields.</p>

                <RadioGroup value={this.state.zone.zoneSubType} onChange={this.updateDelegationObj}
                            name={"zoneSubType"}>

                    <FormControlLabel value="IP4"
                                      control={<Radio color="primary"/>}
                                      label="Forward Zones (i.e. zone.com.) and Delegations (delegation.) or IP4 Arpa Zones (i.e. 10.12.in-addr.arpa.) and Delegations (25.)"/>
                    <FormControlLabel value="IP6" control={<Radio color="primary"/>}
                                      label="IP6 Arpa Zones (i.e. 2001:1890:1111::/48 or 1.1.1.1.0.8.9.1.1.0.0.2.ip6.arpa.) and delegations (i.e. 00:11 or 1.1.0.0)"/>

                </RadioGroup>

            </Form.Group></>}


            <Form.Group as={Row} className={"align-items-center"}>

                <Form.Label column sm="2"
                            className={"font-weight-bold"}>
                    {this.props.isEmptyForm ? "*" : ""}Delegation Name
                </Form.Label>
                <Col sm={4}>

                    {this.props.isEditable ?
                        <Form.Control name={"delegationName"}
                            //  name={ `${this.state.delegation.delegationName}.`}
                                      onChange={this.updateDelegationObj}
                                      className={"w-50 d-inline"}

                                      defaultValue={delegation.cutDnameHpart ? delegation.cutDnameHpart : ''}/> : delegation.cutDnameHpart}

                    {/*
                    <span className={"d-inline"}>{`${zoneData.zoneName}`}</span>
*/}

                </Col>

                {(this.props.isEmptyForm || !this.props.isEditable) && <><Form.Label column sm="2"
                                                                                     className={"font-weight-bold"}>
                    {this.props.isEmptyForm ? "*" : ""}Zone Name
                </Form.Label>
                    <Col sm={4}>

                        {this.props.isEditable ?
                            <Form.Control name={"zoneName"}
                                          onChange={this.updateDelegationObj}
                                          className={"w-50 d-inline"}

                                          defaultValue={delegation.zoneName ? delegation.zoneName : ''}/> : delegation.zoneName}

                    </Col>

                </>}
            </Form.Group>


            <Form.Group as={Row} className={"align-items-center"}>

                <Form.Label column sm="2"
                            className={"font-weight-bold"}>
                    Comment
                </Form.Label>
                <Col sm="4">
                    {this.props.isEditable ?

                        <Form.Control name={"comments"}
                                      onChange={this.updateDelegationObj}
                                      defaultValue={delegation.comments ? delegation.comments : ''}/> : delegation.comments}
                </Col>

                {!this.props.isEditable && <>  <Form.Label column sm="2" className={"font-weight-bold"}>
                    Modified By
                </Form.Label>
                    <Col sm="4">
                        {this.props.isEditable ?
                            <Form.Control name={"modBy"} onChange={this.updateDelegationObj}
                                          defaultValue={delegation.modBy ? delegation.modBy : ''}/> : delegation.modBy}
                    </Col></>}

            </Form.Group>
            <Form.Group as={Row} className={"align-items-center"}>


                {!this.props.isEditable && <><Form.Label column sm="2"
                                                         className={"font-weight-bold"}>
                    Delegation Type
                </Form.Label>
                    <Col sm={4}>
                        {delegation.DType}

                    </Col></>}
            </Form.Group>
            <Form.Group as={Row} className={"align-items-center"}>


                {(!this.props.isEmptyForm && this.props.isEditable) && <><Form.Label column sm="2"
                                                                                     className={"font-weight-bold"}>
                    Status </Form.Label>
                    <Col sm="4">
                        {this.props.isEditable ?
                            <Form.Control name={"status"}
                                          className={"w-25 d-inline"}
                                          onChange={this.updateDelegationObj}
                                          defaultValue={delegation.status ? delegation.status : ''}/> : delegation.status}

                        {this.props.isEditable && <> <p className={"d-inline"}>Either A for active or S for
                            suspended</p></>}
                    </Col></>}

            </Form.Group>
            <Form.Group as={Row} className={"align-items-center"}>

                {!this.props.isEditable && <> <Form.Label column sm="2"
                                                          className={"font-weight-bold"}>
                    First Name
                </Form.Label>
                    <Col sm="4">
                        {delegation.FName}

                    </Col></>}


                {!this.props.isEditable && <> <Form.Label column sm="2"
                                                          className={"font-weight-bold"}>
                    Middle Name
                </Form.Label>
                    <Col sm="4">

                        {delegation.MName}

                    </Col></>}


            </Form.Group>
            <Form.Group as={Row} className={"align-items-center"}>
                {!this.props.isEditable && <>
                    <Form.Label column sm="2" className={"font-weight-bold"}>
                        Last Name
                    </Form.Label>
                    <Col sm="4">
                        {delegation.LName}
                    </Col></>}

                {!this.props.isEditable && <>    <Form.Label column sm="2"
                                                             className={"font-weight-bold"}>
                    Option
                </Form.Label>
                    <Col sm="4">
                        {delegation.option}
                    </Col></>}
            </Form.Group>


            {(this.props.isEmptyForm) && <>  <p>You must provide at least one name server
                below to complete the creation of a Delegation. If you need
                to
                provide more than two servers , you can add them via the Delegations Detail Display Page after you
                finish the creation.
            </p></>}
            {(this.props.isEmptyForm) && <> <Form.Group as={Row}
                                                        className={"align-items-center"}>
                <Form.Label column sm="6"
                            className={"font-weight-bold"}>
                    Domains Name Servers:
                </Form.Label>
                <Col>
                    {}
                </Col>
            </Form.Group></>}
            {this.props.isEmptyForm && <>  <Form.Group as={Row}
                                                       className={"align-items-center"}>
                <Form.Label column sm="2"
                            className={"font-weight-bold"}>
                    {this.props.isEmptyForm ? "*" : ""}1.Server's Full Name:
                </Form.Label>
                <Col sm={4}>
                    {this.props.isEmptyForm ?

                        <Form.Control name={"ns1"}
                                      onChange={this.updateDelegationObj}
                                      defaultValue={delegation.ns1 ? delegation.ns1 : ''}/> : delegation.ns1}
                </Col>
                <Form.Label column sm="2"
                            className={"font-weight-bold"}>
                    Time To Live
                </Form.Label>
                <Col sm={4}>
                    {this.props.isEmptyForm ?

                        <Form.Control name={"ttl1"}
                                      onChange={this.updateDelegationObj}
                                      defaultValue={delegation.ttl1 ? delegation.ttl1 : ''}/> : delegation.ttl1}
                </Col>
            </Form.Group></>}
            {this.props.isEmptyForm && <>   <Form.Group as={Row}
                                                        className={"align-items-center"}>
                <Form.Label column sm="2"
                            className={"font-weight-bold"}>
                    2.Server's Full Name:
                </Form.Label>
                <Col sm={4}>
                    {this.props.isEmptyForm ?

                        <Form.Control name={"ns2"}
                                      onChange={this.updateDelegationObj}
                                      defaultValue={delegation.ns2 ? delegation.ns2 : ''}/> : delegation.ns2}
                </Col>
                <Form.Label column sm="2"
                            className={"font-weight-bold"}>
                    Time To Live
                </Form.Label>
                <Col sm={4}>
                    {this.props.isEmptyForm ?

                        <Form.Control name={"ttl2"}
                                      onChange={this.updateDelegationObj}
                                      defaultValue={delegation.ttl2 ? delegation.ttl2 : ''}/> : delegation.ttl2}

                </Col>

            </Form.Group></>}
            {this.props.isEmptyForm && <>
                <p>Those entries marked with * must be provided
                </p></>}
            <Form.Group as={Row} className={"align-items-center"}>
                {!this.props.isEditable && <> <Form.Label column sm="2" className={"font-weight-bold"}>
                    Address </Form.Label>
                    <Col sm="4">
                        {delegation.stAddr}

                    </Col></>}

                {!this.props.isEditable && <> <Form.Label column sm="2"
                                                          className={"font-weight-bold"}>
                    City </Form.Label>
                    <Col sm="4">
                        {delegation.city}

                    </Col></>}
            </Form.Group>
            <Form.Group as={Row} className={"align-items-center"}>


                {!this.props.isEditable && <> <Form.Label column sm="2"
                                                          className={"font-weight-bold"}>
                    State </Form.Label>
                    <Col sm="4">
                        {delegation.stateCode}

                    </Col></>}

                {!this.props.isEditable && <> <Form.Label column sm="2"
                                                          className={"font-weight-bold"}>
                    Country Code </Form.Label>
                    <Col sm="4">
                        {delegation.countryCode}

                    </Col></>}

            </Form.Group>
            <Form.Group as={Row} className={"align-items-center"}>
                {!this.props.isEditable && <> <Form.Label column sm="2"
                                                          className={"font-weight-bold"}>
                    Zip Code </Form.Label>
                    <Col sm="4">
                        {delegation.zip}

                    </Col></>}
                {!this.props.isEditable && <> <Form.Label column sm="2"
                                                          className={"font-weight-bold"}>
                    Phone Country Code </Form.Label>
                    <Col sm="4">
                        {delegation.phoneCountryCode}

                    </Col></>}

            </Form.Group>
            <Form.Group as={Row} className={"align-items-center"}>


                {!this.props.isEditable && <> <Form.Label column sm="2"
                                                          className={"font-weight-bold"}>
                    Phone Number </Form.Label>
                    <Col sm="4">
                        {delegation.phoneNum}

                    </Col></>}


                {!this.props.isEditable && <> <Form.Label column sm="2"
                                                          className={"font-weight-bold"}>
                    Extension </Form.Label>
                    <Col sm="4">
                        {delegation.ext}

                    </Col></>}

            </Form.Group>

            <Form.Group as={Row} className={"align-items-center"}>


                {!this.props.isEditable && <> <Form.Label column sm="2"
                                                          className={"font-weight-bold"}>
                    Fax Country Code </Form.Label>
                    <Col sm="4">
                        {this.state.account.faxCountryCode}

                    </Col></>}


                {!this.props.isEditable && <> <Form.Label column sm="2"
                                                          className={"font-weight-bold"}>
                    Fax Number </Form.Label>
                    <Col sm={4}>
                        {this.state.account.faxNum}

                    </Col></>}
            </Form.Group>
            <Form.Group as={Row} className={"align-items-center"}>


                {!this.props.isEditable && <> <Form.Label column sm="2"
                                                          className={"font-weight-bold"}>
                    Email </Form.Label>
                    <Col sm={4}>
                        {this.state.account.emailAddr1}

                    </Col></>}


                {!this.props.isEditable && <> <Form.Label column sm="2"
                                                          className={"font-weight-bold"}>
                    Order Id </Form.Label>
                    <Col sm={4}>
                        {delegation.orderId}

                    </Col></>}
            </Form.Group>


            {
                !this.props.isEditable && <Form.Group as={Row} className={"align-items-center mb-2"}>
                    <Form.Label column sm="2" className={"font-weight-bold"}>
                        Created
                    </Form.Label>
                    <Col sm="4">
                        {delegation.createTime}
                    </Col>
                    <Form.Label column sm="2" className={"font-weight-bold"}>
                        Last Modified
                    </Form.Label>
                    <Col sm="4">
                        {delegation.updateTime}
                    </Col>
                </Form.Group>
            }


            <div className={"text-center"}>
                {pageButtons.map(buttonComp => buttonComp)}
            </div>
        </form>
    }


    render() {
        let {pageTitle} = this.getPageButtons();
        console.log(this.state.account,"this.state")
        return (
            <>
                {this.getDeleteConfirmDialog()}
                {/*  <Backdrop className={"page-loading"} style={{'zIndex': '10000', 'color': '#fff'}}
                          open={this.state.loading && this.props.loading}>
                    <CircularProgress color="inherit"/>
                </Backdrop>*/}
                <div>
                    <Helmet>
                        <title>DNS Admin | DNS Delegation Details Page</title>
                    </Helmet>
                    <Container maxWidth={false} className={"px-2"}>
                        <Card>
                            <CardContent>
                                <h5 className="font-weight-bold  text-capitalize text-left pt-3 pb-1 pl-4">{pageTitle}</h5>
                                <div className={"pb-2 pl-4"}>
                                    <div className={"pb-2"}>
                                        {this.props.alert.message && <Alert
                                            severity={this.props.alert.type}>{this.props.alert.message}</Alert>}</div>
                                    {this.getAccountDelegationForm()}
                                </div>
                            </CardContent>
                        </Card>
                    </Container>
                </div>
            </>)
    }
}

AccountDelegations.defaultProps =
    {
        isEditable: false,
    };

AccountDelegations.propTypes =
    {
        isEditable: PropTypes.bool.isRequired,
        isEmptyForm: PropTypes.bool

    };

function mapState(state) {
    // const {saving, loading, saved, deleted} = state.delegations
    const {saving, loading, saved, deleted} = state.acctDelegations


    const {alert} = state
    return {saving, loading, saved, deleted, alert}
}

const actionCreators = {
    alertClear: alertActions.clear,
    create: acctDelegationActions.create,
    update: acctDelegationActions.update,
    delete: acctDelegationActions.delete,
};

const connectedAccountDelegations = withRouter(connect(mapState, actionCreators)(AccountDelegations));
export {connectedAccountDelegations as AccountDelegations};
