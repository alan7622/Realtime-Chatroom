import {Helmet} from "react-helmet";
import Container from "@material-ui/core/Container";
import {
    Button,
    Card,
    CardContent,
    Dialog, DialogActions,
    DialogContent,
    DialogTitle,
    FormControl, FormControlLabel,
    InputLabel, MenuItem, Radio, RadioGroup,
    Select
} from "@material-ui/core";
import {Alert} from "@material-ui/lab";
import BootstrapTable from "react-bootstrap-table-next";
import {alertActions} from "../../../_actions";
import {Link, withRouter} from "react-router-dom";
import {connect} from "react-redux";
import React, {Component} from "react";
import {accountService, delegationService, resourceRecordService, zoneService} from "../../../_services";
import paginationFactory from "react-bootstrap-table2-paginator";
import {pageRenderer, SizePerPageRenderer} from "../../../_components";
import Form from "react-bootstrap/Form";
import {Col, Row} from "react-bootstrap";
import {ComparatorHelper} from "../../../_helpers";
import _ from "lodash";


const defaultFilters = {
    delegationName: {comparator: 'Eq', value: ''},
    zoneName: {comparator: '', value: ''},
    zoneSubType: {comparator: '', value: 'DOM'},
    orderBy: {comparator: '', value: 'delegationNum'},
    orderDir: {comparator: '', value: 'asc'},
}

class Search extends Component {
    constructor(props) {
        super(props);
        this.state = {
            data: [],
            zoneData: {},
            advanceSearchApplied: false,
            filters: _.cloneDeep(defaultFilters),
            acctDelgSearchParams: {},

            /* filters: {
                 companyName: {comparator: 'Eq', value: ''},
                 delegationName: {comparator: 'Eq', value: ''},

             },*/
            showDeleteConfirm: false,
            showAdvanceSearch: false,
            page: 1,
            sizePerPage: 10,
            totalSize: 0,


        }
        this.isComponentMounted = false;
        this.getAdvanceSearchDialog = this.getAdvanceSearchDialog.bind(this)
        this.handleFilterChange = this.handleFilterChange.bind(this)
        this.handleTableChange = this.handleTableChange.bind(this);

        if ((this.props.location.state === null || this.props.location.state === undefined || !this.props.location.state.showAlerts) && !_.isEmpty(this.props.alert)) {
            this.props.alertClear()
        }

    }

    async componentDidMount() {
        this.isComponentMounted = true;
        setTimeout(() => {
            this.props.alertClear()
        }, 10000)
        await this.loadTableData({numberOfRows: this.state.sizePerPage, pageNumber: this.state.page});
        const res = await accountService.getAccountById(this.props.match.params.accountId)
        if (this.isComponentMounted) {
            this.setState({account: res.data});
        }
    }

    async loadTableData(data) {
        if (this.isComponentMounted) {
            this.setState({loading: true})
        }

        for (var key in this.state.filters) {
            if (this.state.filters.hasOwnProperty(key) &&
                this.state.filters[key].value && this.state.filters[key].value != "...") {
                data[key +
                this.state.filters[key].comparator] = this.state.filters[key].value;
            }
        }

        data = {
            ...data,
            accountId: this.props.match.params.accountId,
        }
        const res = await delegationService.getAllDelegations(data);
        if (this.isComponentMounted) {
            this.setState({
                loading: false, data: res.delegation, error: res.error, totalSize: res.totalRecords,
                page: data.pageNumber ? data.pageNumber : this.state.page,
                sizePerPage: data.numberOfRows ?
                    data.numberOfRows :
                    this.state.sizePerPage,
            });
        }
    }


    componentWillUnmount() {
        this.isComponentMounted = false;
    }

    handleFilterChange(e) {
        const {name, value} = e.target;
        const {filters} = this.state;
        const filterInfo = name.split('.');
        filters[filterInfo[0]][filterInfo[1]] = value;
        this.setState({filters: filters});
    }


    getAccountDelegationsTableColumns() {
        return [
            {
                dataField: 'accountId',
                text: 'Account ID',
                headerAlign: 'center',
                classes: 'text-left p-0',
                headerStyle: {
                    width: '10%'
                },
                style: {
                    wordWrap: 'break-word'
                },


            },
            {
                dataField: 'cutDnameHpart',
                text: 'Delegation Name',
                headerAlign: 'center',
                classes: 'text-left p-0',
                headerStyle: {
                    width: '20%'
                },
                style: {
                    wordWrap: 'break-word'
                },


            },
            {
                dataField: 'recId',
                text: 'DelegationRecID',
                headerAlign: 'center',
                classes: 'text-left p-0',
                headerStyle: {
                    width: '20%'
                },
                style: {
                    wordWrap: 'break-word'
                },
            },


            {
                dataField: 'zoneName',
                text: 'Zone Name',
                headerAlign: 'center',
                classes: 'text-left p-0',
                headerStyle: {
                    width: '20%'
                },
                style: {
                    wordWrap: 'break-word'
                },


            },

            {
                dataField: 'zoneNum',
                text: 'Zone Id',
                headerAlign: 'center',
                classes: 'text-left p-0',
                headerStyle: {
                    width: '20%'
                },
                style: {
                    wordWrap: 'break-word'
                },

            },
            {
                text: "Action",
                dataField: "",
                headerAlign: 'center',
                headerStyle: {
                    width: "10%"
                },

                formatter: (cell, row, rowIndex) => <>
                    <Link
                        to={`/dns/accounts/details/${this.props.match.params.accountId}/acctDelg/${row.recId}`}

                        key={"details_account_delegation"}
                        className={"color-dragon-blue mr-2"}
                    >Details</Link>
                </>
            },

        ];

    }

    getAdvanceSearchDialog() {
        return <Dialog
            fullWidth={true}
            onClose={(event, reason) => {
                if (reason === 'backdropClick' || reason === 'escapeKeyDown') {
                    return false;
                }
            }}
            maxWidth="md"
            open={this.state.showAdvanceSearch}
        >
            <DialogTitle id="form-dialog-title"><h5 className={"font-weight-bold"}>DNS
                Search Delegations</h5></DialogTitle>

            <DialogContent>
                <Form>

                    <Form.Group as={Row} className={'align-items-center'}>

                        <p className={"pl-2"}>
                            There are different formats that can be used here for Zone Name and Delegation Name.
                            Please select the appropriate format before filling the fields.</p>

                        <RadioGroup value={this.state.filters.zoneSubType.value} onChange={this.handleFilterChange}
                                    name={"zoneSubType"}>
                            <FormControlLabel value="DOM"
                                              control={<Radio color="primary"/>}
                                              className={"pl-4"}
                                              label="Forward and IP4 Arpa Zones (i.e. expressojoes.com. or 128/27.114.0.12.in-addr.arpa.)"/>
                            <FormControlLabel value="IP4" control={<Radio color="primary"/>}
                                              className={"pl-4"}
                                              label="IP4 Arpa Zones (i.e. 128/27.114.0.12.in-addr.arpa.) Please note that the IP4 arpa search is always on the IP address of the arpa zone(i.e. 12.0.114.128/27 or 12.0.114 or 0.114).The exceptions are an ' Equals' or a ' Contains' search where the search string ends with '.in-addr.arpa.'.In this case the search is on the Arpa Address(i.e 128/27.114.0.12.in-addr.arpa. or 12.in-addr.arpa.)."/>
                            <FormControlLabel value="IP6" control={<Radio color="primary"/>}
                                              className={"pl-4"}
                                              label="IP6 Arpa Zones (i.e. 2001:1890:1111 or 1.1.1.1.0.9.8.1.1.0.0.2.ip6.arpa.)  Please make sure your search argument includes one of the delimiters ('.' or ':') to indicate what IP6 format you are using.If you don't, the search will assume the input is an address (i.e. 2001:1890:1111)."/>

                        </RadioGroup>

                    </Form.Group>


                    <Form.Group as={Row} className={'align-items-center'}>
                        <Form.Label column sm="2" className={'font-weight-bold'}>
                            Delegation Name
                        </Form.Label>
                        <Col sm={2}>
                            <FormControl variant="outlined">
                                <InputLabel htmlFor="wildcard-company-search"> Delegation Name</InputLabel>
                                <Select
                                    autoWidth={true}
                                    className={'w-100'}
                                    name={'delegationName.comparator'}
                                    value={this.state.filters.delegationName.comparator}
                                    onChange={this.handleFilterChange}
                                    label="Delegation Name"
                                >
                                    {ComparatorHelper.getComparators.map(obj => (
                                        <MenuItem value={obj.value}
                                                  key={obj.value}>{obj.label}</MenuItem>
                                    ))}

                                </Select>
                            </FormControl>
                        </Col>
                        <Col sm={4}>
                            <Form.Control name={'delegationName.value'}
                                          defaultValue={this.state.filters.delegationName.value}
                                          onChange={this.handleFilterChange}
                            />
                        </Col>

                    </Form.Group>

                    <Form.Group as={Row} className={"align-items-center"}>

                        <Form.Label column sm="2" className={"font-weight-bold"}>
                            Zone Name
                        </Form.Label>
                        <Col sm={2}>
                            <FormControl variant="outlined">
                                <InputLabel htmlFor="wildcard-zoneName-search">
                                    zoneName</InputLabel>
                                <Select
                                    autoWidth={true}
                                    className={'w-100'}
                                    name={'zoneName.comparator'}
                                    value={this.state.filters.zoneName.comparator}
                                    onChange={this.handleFilterChange}
                                    label="ZoneName"
                                >
                                    {ComparatorHelper.getComparators.map(obj => (
                                        <MenuItem value={obj.value}
                                                  key={obj.value}>{obj.label}</MenuItem>
                                    ))}

                                </Select>
                            </FormControl>
                        </Col>
                        <Col sm={4}>
                            <Form.Control name={'zoneName.value'}
                                          defaultValue={this.state.filters.zoneName.value}
                                          onChange={this.handleFilterChange}
                            />
                        </Col>

                    </Form.Group>
                </Form>

            </DialogContent>

            <DialogActions>
                <Button onClick={async (e) => {
                    await this.loadTableData({numberOfRows: this.state.sizePerPage, pageNumber: this.state.page});
                    this.setState(
                        {showAdvanceSearch: false});
                }
                } color="primary" className={'dns-blue-button text-white'}
                >
                    Search
                </Button>
                <Button onClick={() => this.setState(
                    {showAdvanceSearch: false})}
                        color="primary" className={'dns-blue-button text-white'}>
                    Cancel
                </Button>
            </DialogActions>

        </Dialog>
    }

    async handleTableChange(type, {filters, page, sortOrder, sortField, sizePerPage, totalSize}) {
        const currentIndex = (page - 1) * sizePerPage;
        let acctDelgSearchParams = {};
        if (sortField && sortOrder) {
            acctDelgSearchParams.orderDir = sortOrder;
            acctDelgSearchParams.orderBy = sortField;
        }

        acctDelgSearchParams.numberOfRows = sizePerPage;
        acctDelgSearchParams.pageNumber = page;
        await this.loadTableData(acctDelgSearchParams);

    }


    paginationOptions() {
        return {
            sizePerPage: this.state.sizePerPage,
            page: this.state.page,
            totalSize: this.state.totalSize,
            alwaysShowAllBtns: true,
            withFirstAndLast: true,
            firstPageText: 'First',
            prePageText: 'Back',
            nextPageText: 'Next',
            lastPageText: 'Last',
            nextPageTitle: 'First page',
            prePageTitle: 'Pre page',
            firstPageTitle: 'Next page',
            lastPageTitle: 'Last page',
            showTotal: false,
            sizePerPageList: [
                {
                    text: '10', value: 10
                }, {
                    text: '20', value: 20
                },
                {
                    text: '50', value: 50
                },],
            pageButtonRenderer: pageRenderer,
            sizePerPageRenderer: ({
                                      options,
                                      currSizePerPage,
                                      onSizePerPageChange
                                  }) => <SizePerPageRenderer options={options}
                                                             currSizePerPage={currSizePerPage}
                                                             onSizePerPageChange={onSizePerPageChange}/>,

            disablePageTitle: true,
        };
    }


    render() {
        const {data} = this.state;
        let columns = this.getAccountDelegationsTableColumns();
        const paginationOptions = this.paginationOptions();

        return <div>
            <Helmet><title>
                DNS Account Delegations </title></Helmet>

            <Container maxWidth={false} className={"px-2"}>
                <Card>
                    <CardContent>
                        <div className="mt-2 ml-2 mr-3 mb-2  pb-5">
                            <h5 className={"font-weight-bold mt-4 mb-4"}>
                                DNS Account Delegations</h5>

                            <div>
                                {this.props.alert.message &&
                                    <Alert severity={this.props.alert.type}>{this.props.alert.message}</Alert>}
                                <div className="pl-2 pr-2">
                                    {this.getAdvanceSearchDialog()}


                                    <div className={'col text-right pt-4 pb-4'}>
                                        <Link
                                            className={"d-inline-block btn btn-primary dns-blue-button mr-1"}
                                            to={"/dns/accounts/details/" + this.props.match.params.accountId + "/acctDelg/create"}
                                        >Insert</Link>
                                        <Button aria-controls="simple-menu"
                                                aria-haspopup="true"
                                                color="primary"
                                                className={'dns-blue-button'}
                                                variant={'contained'}
                                                onClick={() => {
                                                    this.setState(
                                                        {showAdvanceSearch: true});
                                                }} key={'advance_search'}>Search</Button>
                                        {(JSON.stringify(this.state.filters) !== JSON.stringify(defaultFilters)) &&
                                            <Button type={"reset"} onClick={() => {
                                                this.props.alertClear();
                                                this.setState({filters: _.cloneDeep(defaultFilters), error: ''}, () => {
                                                    this.loadTableData({numberOfRows: 10, pageNumber: 1})
                                                });
                                            }} variant="contained"
                                                    className={"dns-blue-button text-white ml-2"}


                                            >clear</Button>}
                                    </div>

                                    <BootstrapTable bootstrap4
                                                    keyField={"recId"}
                                                    data={data}
                                                    columns={columns}
                                                    noDataIndication="No matching records found"
                                                    onTableChange={this.handleTableChange}
                                                    pagination={paginationFactory(paginationOptions)}
                                                    id={"zoneDelegation_table"}
                                                    remote={{
                                                        pagination: true,
                                                    }} condensed
                                                    striped
                                                    hover
                                                    loading={true}
                                                    condensed
                                    />

                                </div>
                            </div>
                        </div>
                    </CardContent>
                </Card>
            </Container>
        </div>

    }
}

function mapState(state) {
    const {alert} = state
    return {alert}
}

const actionCreators = {
    alertClear: alertActions.clear,
};

const connectedAccountDelegations = withRouter(connect(mapState, actionCreators)(Search));
export {connectedAccountDelegations as Search};


