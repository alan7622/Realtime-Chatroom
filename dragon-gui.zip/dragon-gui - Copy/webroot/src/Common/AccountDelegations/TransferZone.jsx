import {alertActions} from "../../_actions";
import {withRouter} from "react-router-dom";
import {connect} from "react-redux";
import React, {Component} from "react";
import Form from "react-bootstrap/Form";
import {Col, Row} from "react-bootstrap";
import {
    Backdrop,
    Button,
    Card,
    CardContent,
    CircularProgress,
    FormControlLabel,
    Radio,
    RadioGroup
} from "@material-ui/core";
import {Helmet} from "react-helmet";
import Container from "@material-ui/core/Container";
import {accountService, zoneService} from "../../_services";
import _ from "lodash";

class TransferZone extends Component {
    constructor(props) {
        super(props);
        this.state = {
            date: [],
            loading: false,
            zoneData: {},
            zone: {
                accountId: '',
                serviceName: '',
                zoneSubType: "IP4"

            }
        }
        this.isComponentMounted = false;
        this.updateZoneObj = this.updateZoneObj.bind(this);

        if ((this.props.location.state === undefined || !this.props.location.state.showAlerts) && !_.isEmpty(this.props.alert)) {
            this.props.alertClear()
        }


    }


    async componentDidMount() {
        this.isComponentMounted = true;
        let accountId, serviceName;

        const resp = await accountService.getAccountById(this.props.match.params.id)
        console.log(resp, "resp")
        accountId = resp.accountId;
        serviceName = resp.serviceName;
        if (this.isComponentMounted) {
            this.setState({
                gettingZone: false,
                zone: {accountId: accountId, serviceName: serviceName},
                loading: false

            })
        }
    }


    /*
        async componentDidMount() {
            await this.getZone();
        }

        async getZone() {
            this.isComponentMounted = true;
            let resp;

            if (this.isComponentMounted) {
                this.setState({gettingZone: true});
                let accountId, serviceName;
                if (this.props.match.path == '/dns/accounts/details/:id/create/:zoneType') {
                    resp = await accountService.getAccountById(this.props.match.params.id)
                    accountId = resp.accountId;
                    serviceName = resp.serviceName;
                } else {
                    resp = await zoneService.getZoneById(this.props.match.params.id)
                    if (resp.success) {
                        accountId = resp.zone.accountId;
                        serviceName = resp.zone.serviceName;
                    }
                }
                //   const resp = await zoneService.getZoneById(this.props.match.params.id)
                const zone = this.state.zone
                if (this.isComponentMounted) {
                    if (this.props.match.params.zoneType) {
                        zone.accountId = accountId
                        zone.serviceName = serviceName
                        this.setState({
                            gettingZone: false,
                            zone,
                            loading: false

                        })
                    } else {
                        this.setState({loading: false, zone: resp.zone, gettingZone: false});

                    }
                }


            }
        }
        componentWillUnmount() {
            this.isComponentMounted = false;
        }
    */


    updateZoneObj(e) {

        let {name, value} = e.target;

        const {zone} = this.state;


        this.setState({zone: {...zone, [name]: value}})
    }

    getTransferZoneForm() {
        const {zone, zoneData} = this.state
        return (<>
            <Form>
                <Form.Group as={Row} className={"align-items-center"}>
                    <Form.Label column sm="2" className={"font-weight-bold"}>
                        Service Id
                    </Form.Label>
                    <Col sm="4">
                        {zone.serviceName}
                    </Col>
                    <Form.Label column sm="2" className={"font-weight-bold"}>
                        Account Id
                    </Form.Label>
                    <Col sm="4">
                        {zone.accountId}
                        {console.log(zone.accountId, "zoneData.serviceName")}
                    </Col>
                </Form.Group>
                <Form.Group as={Row} className={"align-items-center"}>


                    <RadioGroup value={this.state.zone.zoneSubType} name={"zoneSubType"}
                                onChange={this.updateZoneObj}
                                className={"ml-4"}
                                row={true}>

                        <FormControlLabel value={this.state.zone.zoneSubType}
                                          control={<Radio color="primary"/>}
                                          label="IP4 Zone"/>
                        <FormControlLabel value="IP6" control={<Radio color="primary"/>}
                                          label="IP6 Zone"/>


                    </RadioGroup>

                </Form.Group>

                <Form.Group as={Row} className={"align-items-center"}>

                    <Form.Label column sm="2" className={"font-weight-bold"}>
                        Zone Name
                    </Form.Label>

                    <Col sm="4">
                        <Form.Control name={"zoneName"}
                                      defaultValue={zone.zoneName ? zone.zoneName : ''}/>

                    </Col>
                </Form.Group>
                <Form.Group as={Row} className={"align-items-center"}>
                    <Form.Label column sm="2" className={"font-weight-bold"}>
                        Current Name Server IP
                    </Form.Label>
                    <Col sm="4">
                        <Form.Control name={"ipAddress"}
                                      defaultValue={zone.ipAddress ? zone.ipAddress : ''}/>

                    </Col>
                </Form.Group>
                <Form.Group as={Row} className={"align-items-center"}>
                    <Form.Label column sm="2" className={"font-weight-bold"}>
                        Check Host Name
                    </Form.Label>
                    <Col sm="4">
                        <Form.Control as="select"
                        >
                            <option value={"Y"}>Y</option>
                            <option value={"N"}>N</option>
                        </Form.Control>
                    </Col>

                </Form.Group>

                <div className={"text-center"}>
                    {/*  {pageButtons.map(buttonComp => buttonComp)}*/}
                    <Button className={"dns-blue-button text-white "}
                            onClick={this.saveZone}
                            key={"update"}>Transfer</Button>
                </div>
            </Form>
        </>)
    }

    render() {
        /*   if ((!this.state.loading) && _.isEmpty(this.state.zone)) {
               return <div>Loading....</div>
           }*/
        return (
            <>

                <Backdrop className={"page-loading"} style={{'zIndex': '10000', 'color': '#fff'}}
                    //  open={this.state.loading && (this.props.saving == true)}>
                          open={this.state.loading}>

                    <CircularProgress color="inherit"/>
                </Backdrop>
                <div>
                    <Helmet>
                        <title>DNS zones | zones</title>
                    </Helmet>

                    <Container maxWidth={false} className={"px-2"}>
                        <Card>
                            <CardContent>
                                <div className="pt-3 pl-4 pr-5">
                                    <h6 className={"font-weight-bold  text-capitalize text-left pt-3 pb-4"}>
                                        Transfer a Zone from Other Internet Service Provider</h6>

                                    {this.getTransferZoneForm()}

                                </div>
                            </CardContent>
                        </Card>
                    </Container>
                </div>
            </>
        )
    }

}

function mapState(state) {
    const {alert} = state
    return {alert}
}

const actionCreators = {
    alertClear: alertActions.clear,

}
const
    connectedTransferZone = withRouter(connect(mapState, actionCreators)(TransferZone));
export {
    connectedTransferZone
        as
            TransferZone
};
