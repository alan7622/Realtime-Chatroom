import React from "react";
import {alertActions} from "../../_actions";
import {connect} from "react-redux";
import {
    CardContent,
    Card,
    TextField,
    FormControl,
    Select,
    DialogTitle,
    DialogActions,
    Dialog,
    DialogContent,
    MenuItem,
    Button, InputLabel, Grid
} from "@material-ui/core";
import {Helmet} from "react-helmet";
import Container from "@material-ui/core/Container";
import BootstrapTable from 'react-bootstrap-table-next';
import paginationFactory from 'react-bootstrap-table2-paginator';
import {historyLogService} from "../../_services/historyLog.service";
import _ from "lodash";
import {HistoryLogHelper} from "../../_helpers";
import {Alert} from "@material-ui/lab";
import {MDBTooltip} from "mdbreact";
import {pageRenderer, SizePerPageRenderer} from "../../_components";
import Form from "react-bootstrap/Form";
import {Col, Row} from "react-bootstrap";

const defaultFilters = {
    // mtf: {comparator: 'Eq', value: ''},
    lastModTime: {comparator: 'GtEq', value: ''},
    zoneNum: {comparator: '', value: ''},
    zoneName: {comparator: 'Eq', value: ''},
    recId: {comparator: '', value: ''},
    domainName: {comparator: 'Eq', value: ''},
    typeCode: {comparator: '', value: ''},
    action: {comparator: '', value: ''},
    modBy: {comparator: '', value: ''},
}

class Search extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            advanceSearchApplied: false,
            filters: _.cloneDeep(defaultFilters),
            // modTimeFilter: {operation: "lastModTimeGtEq", value: ""},
            data: [],
            alert: '',
            loading: true,
            openPgMenu: null,
            page: 1,
            sizePerPage: 10,
            totalSize: 0,
            historyLogSearchParams: {},
            showDeleteConfirm: false,
            showAdvanceSearch: false,

        }
        this.isComponentMounted = false;
        this.handleHistoryTableChange = this.handleHistoryTableChange.bind(this)
        this.getAdvanceSearchDialog = this.getAdvanceSearchDialog.bind(this)
        this.handleFilterChange = this.handleFilterChange.bind(this);
        //  this.setTableRecords = this.setTableRecords.bind(this);


        if ((this.props.location.state === null || this.props.location.state === undefined || !this.props.location.state.showAlerts) && !_.isEmpty(this.props.alert)) {
            this.props.alertClear()
        }
    }

    async componentDidMount() {
        this.isComponentMounted = true;
        await this.loadTableData({numberOfRows: this.state.sizePerPage, pageNumber: this.state.page});


    }

    async loadTableData(params) {
        this.setState({loading: true})
        for (var key in this.state.filters) {
            if (this.state.filters.hasOwnProperty(key) &&
                this.state.filters[key].value) {
                var value = this.state.filters[key].value
                if (key == 'lastModTime') {
                    value = this.getFormattedModTime(value);
                }
                params[key +
                this.state.filters[key].comparator] = value;
            }
        }
        const res = await historyLogService.getHistoryLogs(params);
        if (this.isComponentMounted) {
            this.setState({
                alert: res.error,
                data: res.historyLogs,
                loading: false,
                page: params.pageNumber ? params.pageNumber : this.state.page,
                sizePerPage: params.numberOfRows ?
                    params.numberOfRows :
                    this.state.sizePerPage,
                totalSize: res.totalRecords
            });
        }
    }

    componentWillUnmount() {
        this.isComponentMounted = false;
    }

    handleFilterChange(e) {
        let {name, value} = e.target;

        const {filters} = this.state;
        const filterInfo = name.split('.');
        filters[filterInfo[0]][filterInfo[1]] = value;
        this.setState({filters: filters});
    }

    getHistoryLogTableColumns() {
        return [
            {
                dataField: 'sequence',
                text: 'Seq',
                headerAlign: 'center',
                headerClasses: 'p-1',
                classes: 'text-center p-0',

                headerStyle: {
                    width: "7%",
                },
                headerFormatter: (column, colIndex) => <MDBTooltip
                    domElement
                    tag="span"
                    placement="top"
                >
                    <span className="blue-text"> {column.text} </span>
                    <span>Sequence</span>
                </MDBTooltip>


            },
            {
                dataField: 'createTime',
                text: 'Time',
                headerAlign: 'center',
                headerClasses: 'p-1',
                classes: 'text-center p-0',
                headerStyle: {
                    width: '13%'
                },
            },
            {
                dataField: 'modBy',
                text: 'Last Modified By',
                headerAlign: 'center',
                headerClasses: 'p-1',
                classes: 'text-center p-0',
                headerStyle: {
                    width: '9%'
                },
            },

            {
                dataField: 'actionCode',
                text: 'Action',
                /* formatter: cell => {
                     return selectOptions[cell]
                 },*/
                headerAlign: 'center',
                headerClasses: 'p-1',
                classes: 'text-center p-0',
                headerStyle: {
                    width: '5%'
                },
                cellStyle: {

                    width: '3%'

                },

                style: {'wordWrap': 'break-word'},
            },
            {
                dataField: 'zoneNum',
                text: 'Zone ID',
                headerAlign: 'center',
                headerClasses: 'p-1',
                classes: 'text-center p-0',
                headerStyle: {
                    width: '7%'
                },
                style: {'wordWrap': 'break-word'}

            },
            {
                text: 'Zone Name',
                dataField: 'zoneName',
                sort: false,
                headerAlign: 'center',
                headerClasses: 'p-1',
                classes: 'p-0',
                headerStyle: {
                    width: '22%'
                },

                style: {'wordWrap': 'break-word'},
                headerEvents: {
                    onClick: (e, column, columnIndex) => {
                        e.preventDefault();
                    }
                }
            },
            {
                dataField: 'typeCode',
                text: 'Record Type',
                headerAlign: 'center',
                headerClasses: 'p-1',
                classes: 'text-center p-0',
                headerStyle: {
                    width: '7%'
                },
                style: {
                    'wordWrap': 'break-word'
                },
            },
            {
                dataField: 'recId',
                text: 'Record ID',
                headerAlign: 'center',
                headerClasses: 'p-1',
                classes: 'text-center p-0',
                headerStyle:
                    {
                        width: '8%'
                    },

                style: {
                    'wordWrap': 'break-word'
                },
            },
            {
                dataField: 'domainName',
                text: 'Record Name',
                headerAlign: 'center',
                headerClasses: 'p-1',
                classes: 'text-center p-0',
                headerStyle:
                    {
                        width: '15%'
                    },
                style: {
                    'wordWrap': 'break-word'
                },
                headerEvents: {
                    onClick: (e, column, columnIndex) => {
                        e.preventDefault();
                    }
                }
            },


            {
                dataField: 'comment',
                text: 'Comments',
                headerAlign: 'center',
                headerClasses: 'p-1',
                classes: 'text-center p-0',
                headerStyle:
                    {
                        width: '7%'
                    },

                style: {
                    'wordWrap': 'break-word'
                },
            },

        ];
    }

    clearButton() {

    }

    getAdvanceSearchDialog() {
        return <Dialog
            fullWidth={true}
            onClose={(event, reason) => {
                if (reason === 'backdropClick' || reason === 'escapeKeyDown') {
                    return false;
                }
            }}
            maxWidth="lg"
            open={this.state.showAdvanceSearch}
        >
            <DialogTitle id="form-dialog-title">DNS Resource Record
                Search</DialogTitle>

            <DialogContent>
                <Form>
                    <Form.Group as={Row} className={'align-items-center'}>
                        <Form.Label column sm="2" className={'font-weight-bold'}>
                            Last Modified Time:

                        </Form.Label>
                        <Col sm="2">
                            <FormControl variant="outlined">
                                <Select
                                    id="mod_time_operation_filter"
                                    value={this.state.filters.lastModTime.comparator}
                                    onChange={this.handleFilterChange}
                                    name={'lastModTime.comparator'}>
                                    <MenuItem value={'GtEq'}
                                              key={0}> {'>='} </MenuItem>
                                    <MenuItem value={'Lt'} key={1}> {'<'} </MenuItem>
                                </Select>
                            </FormControl>
                        </Col>
                        <Col sm={4}>
                            <TextField
                                id="mod_time"
                                type="datetime-local"
                                variant="outlined"
                                name={'lastModTime.value'}
                                onChange={this.handleFilterChange}
                                value={this.state.filters.lastModTime.value}
                            />
                        </Col>
                    </Form.Group>
                    <Form.Group as={Row} className={'align-items-center'}>
                        <Form.Label column sm="2" className={'font-weight-bold'}>
                            Zone Id
                        </Form.Label>
                        <Col sm={6}>
                            <Form.Control name={'zoneNum.value'}
                                /*
                                                                          defaultValue={this.state.filters.zoneNum.value}
                                */
                                          value={this.state.filters.zoneNum.value}
                                          onChange={this.handleFilterChange}
                            />
                        </Col>
                    </Form.Group>
                    <Form.Group as={Row} className={'align-items-center'}>
                        <Form.Label column sm="2" className={'font-weight-bold'}>
                            Zone Name
                        </Form.Label>
                        <Col sm={2}>
                            <FormControl variant="outlined">
                                <InputLabel htmlFor="wildcard-company-search">Zone
                                    Name</InputLabel>
                                <Select
                                    autoWidth={true}
                                    className={'w-100'}
                                    name={'zoneName.comparator'}
                                    value={this.state.filters.zoneName.comparator}
                                    onChange={this.handleFilterChange}
                                    label="Zone Name"
                                >
                                    {HistoryLogHelper.getZoneNameComparators.map(obj => (
                                        <MenuItem value={obj.value}
                                                  key={obj.value}>{obj.label}</MenuItem>
                                    ))}

                                </Select>
                            </FormControl>
                        </Col>
                        <Col sm={4}>
                            <Form.Control name={'zoneName.value'}
                                          value={this.state.filters.zoneName.value}
                                          onChange={this.handleFilterChange}
                            />
                        </Col>

                    </Form.Group>


                    <Form.Group as={Row} className={'align-items-center'}>
                        <Form.Label column sm="2" className={'font-weight-bold'}>
                            Record Id
                        </Form.Label>
                        <Col sm={6}>
                            <Form.Control name={'recId.value'} value={this.state.filters.recId.value}
                                          onChange={this.handleFilterChange}
                            />
                        </Col>
                    </Form.Group>
                    <Form.Group as={Row} className={"align-items-center"}>

                        <Form.Label column sm="2" className={"font-weight-bold"}>
                            Record Name
                        </Form.Label>
                        <Col sm={2}>
                            <FormControl variant="outlined">
                                <InputLabel htmlFor="wildcard-recordName-search">
                                    Record Name</InputLabel>
                                <Select
                                    autoWidth={true}
                                    className={'w-100'}
                                    name={'domainName.comparator'}
                                    value={this.state.filters.domainName.comparator}
                                    onChange={this.handleFilterChange}
                                    label="Record Name"
                                >
                                    {HistoryLogHelper.getZoneNameComparators.map(obj => (
                                        <MenuItem value={obj.value}
                                                  key={obj.value}>{obj.label}</MenuItem>
                                    ))}

                                </Select>
                            </FormControl>
                        </Col>
                        <Col sm={4}>
                            <Form.Control name={'domainName.value'}
                                          value={this.state.filters.domainName.value}
                                          onChange={this.handleFilterChange}
                            />
                        </Col>

                    </Form.Group>
                    <Form.Group as={Row} className={"align-items-center"}>
                        <Form.Label column sm="2" className={"font-weight-bold"}>
                            Record Type </Form.Label>
                        <Col sm={6}>
                            <Form.Control name={"typeCode.value"} value={this.state.filters.typeCode.value}
                                          onChange={this.handleFilterChange}
                            />
                        </Col>

                    </Form.Group>
                    <Form.Group as={Row} className={"align-items-center"}>

                        <Form.Label column sm="2" className={"font-weight-bold"}>
                            Action
                        </Form.Label>
                        <Col sm={4}>
                            <Form.Control name={"action.value"} value={this.state.filters.action.value}
                                          onChange={this.handleFilterChange}
                            />

                        </Col>

                    </Form.Group>
                    <Form.Group as={Row} className={"align-items-center"}>
                        <Form.Label column sm="2" className={"font-weight-bold"}>
                            Modified By </Form.Label>
                        <Col sm={4}>
                            <Form.Control name={"modBy.value"} value={this.state.filters.modBy.value}
                                          onChange={this.handleFilterChange}
                            />
                        </Col>
                    </Form.Group>
                    <div className={"pt-5"}>
                        {/*
                        <WbIncandescentIcon className={" mr-1 color-dragon-blue"}></WbIncandescentIcon>
*/}
                        <h6 className={"font-weight-bold mr-1 color-dragon-blue d-inline-block"}>Note</h6>

                        <h6 className={"ml-1 d-inline-block"}>Search of zonename and rectype is not case-sensitive
                            anymore</h6>
                    </div>
                </Form>
            </DialogContent>

            <DialogActions>
                <Button onClick={async (e) => {
                    await this.loadTableData({numberOfRows: 10, pageNumber: 1});
                    this.setState(
                        {showAdvanceSearch: false});
                }
                } color="primary" className={'dns-blue-button text-white'}
                >
                    Search
                </Button>
                <Button onClick={() => this.setState(
                    {showAdvanceSearch: false})}
                        color="primary" className={'dns-blue-button text-white'}>
                    Close
                </Button>
                <Button type={"reset"} onClick={() => {
                    this.setState({filters: _.cloneDeep(defaultFilters)}, () => {
                        console.log(defaultFilters, "defaultFilters");
                        console.log(this.state, "STATE");
                        this.loadTableData({numberOfRows: 10, pageNumber: 1})
                    });
                }} variant="contained"
                        className={"dns-blue-button text-white ml-2"}
                        disabled={JSON.stringify(this.state.filters) === JSON.stringify(defaultFilters)}>clear</Button>
            </DialogActions>

        </Dialog>
    }

    paginationOptions() {
        return {
            sizePerPage: this.state.sizePerPage,
            page: this.state.page,
            totalSize: this.state.totalSize,
            alwaysShowAllBtns: true,
            withFirstAndLast: true,
            firstPageText: 'First',
            prePageText: 'Back',
            nextPageText: 'Next',
            lastPageText: 'Last',
            nextPageTitle: 'First page',
            prePageTitle: 'Pre page',
            firstPageTitle: 'Next page',
            lastPageTitle: 'Last page',
            showTotal: false,
            sizePerPageList: [
                {
                    text: '10', value: 10
                }, {
                    text: '20', value: 20
                },
                {
                    text: '50', value: 50
                },],
            pageButtonRenderer: pageRenderer,
            sizePerPageRenderer: ({
                                      options,
                                      currSizePerPage,
                                      onSizePerPageChange
                                  }) => <SizePerPageRenderer options={options}
                                                             currSizePerPage={currSizePerPage}
                                                             onSizePerPageChange={onSizePerPageChange}/>,
            disablePageTitle: true,
        };
    }


    async handleHistoryTableChange(type, {filters, page, sizePerPage, totalSize, sortOrder, sortField}) {
        const currentIndex = (page - 1) * sizePerPage;
        let historyLogSearchParams = {};
        if (sortField && sortOrder) {
            historyLogSearchParams.orderDir = sortOrder;
            historyLogSearchParams.orderBy = sortField;
        }

        historyLogSearchParams.numberOfRows = sizePerPage;
        historyLogSearchParams.pageNumber = page;
        await this.loadTableData(historyLogSearchParams);


    }

    getFormattedModTime(dateTime) {
        let modDate = new Date(dateTime)
        console.log(modDate, "modDate")
        const [year, month, date, hour, minutes, seconds] = [modDate.getFullYear(), modDate.getMonth() + 1, modDate.getDate(), modDate.getHours(), modDate.getMinutes(), modDate.getSeconds()];
        return `${year}-${month}-${date} ${hour}:${minutes}:${seconds}`
    }

    render() {
        const paginationOptions = this.paginationOptions();
        const {data} = this.state;
        const columns = this.getHistoryLogTableColumns();
        return (

            <div>
                <Helmet>
                    <title>DNS History Logs | Sys Admin</title>
                </Helmet>
                <Container maxWidth={false} className={"px-2"}>
                    <Card>
                        <CardContent className={"px-0"}>
                            <div className={'mt-3 ml-3 mr-3 mb-3'}>
                                <h5 className="font-weight-bold  text-capitalize text-left pt-1 pl-2">DNS
                                    Resource Record List
                                </h5>
                                <div>

                                    {this.getAdvanceSearchDialog()}

                                    <div className={'col text-right mt-2 mb-2'}>
                                        <Button aria-controls="simple-menu"
                                                aria-haspopup="true"
                                                color="primary"
                                                className={'d-inline-block dns-blue-button mt-3 mr-1'}
                                                variant={'contained'}
                                                onClick={() => {
                                                    this.setState(
                                                        {showAdvanceSearch: true});
                                                }} key={'advance_search'}>Search</Button>
                                        {(JSON.stringify(this.state.filters) !== JSON.stringify(defaultFilters)) &&
                                        <Button type={"reset"} onClick={() => {
                                            this.setState({filters: _.cloneDeep(defaultFilters)}, () => {
                                                this.loadTableData({numberOfRows: 10, pageNumber: 1})
                                            });
                                        }} variant="contained"
                                                className={'d-inline-block text-white dns-blue-button mt-3 mr-1'}
                                        >clear</Button>}
                                    </div>
                                    {this.state.alert &&
                                    <Alert severity={'error'}>{this.state.alert.text}</Alert>}

                                    <div className="pl-2 pr-2 mt-2">

                                        <BootstrapTable bootstrap4
                                                        keyField="sequence"
                                                        data={data}
                                                        remote={{
                                                            pagination: true,
                                                        }}
                                                        onTableChange={this.handleHistoryTableChange}
                                                        columns={columns}
                                                        pagination={paginationFactory(
                                                            paginationOptions)}
                                                        id={'historyLog_table'}
                                                        loading={this.state.loading}
                                                        noDataIndication="Table is Empty"//need to fix here while loading data it displays as table empty during loading time
                                                        striped
                                                        hover
                                                        condensed
                                        />

                                    </div>


                                </div>

                            </div>
                        </CardContent>
                    </Card>
                </Container>
            </div>

        );
    }
}

function mapState(state) {
    const {alert} = state
    return {alert}
}

const actionCreators =
    {
        alertClear: alertActions.clear,
    }

const connectedHistoryLog = connect(mapState, actionCreators)(Search);
export {
    connectedHistoryLog as Search
}
    ;