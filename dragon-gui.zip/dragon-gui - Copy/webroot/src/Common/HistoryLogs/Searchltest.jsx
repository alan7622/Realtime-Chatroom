import React from 'react';
import {alertActions} from '../../_actions';
import {connect} from 'react-redux';
import {
  CardContent,
  Card,
  TextField,
  FormControl,
  Select,
  DialogTitle,
  DialogActions,
  Dialog,
  DialogContent,
  MenuItem,
  Button, InputLabel, Grid
} from '@material-ui/core';
import {Helmet} from 'react-helmet';
import Container from '@material-ui/core/Container';
import Box from '@material-ui/core/Box';
import BootstrapTable from 'react-bootstrap-table-next';
import filterFactory, {
  Comparator,
  customFilter,
  selectFilter,
  textFilter
} from 'react-bootstrap-table2-filter';
import paginationFactory from 'react-bootstrap-table2-paginator';
import overlayFactory from 'react-bootstrap-table2-overlay';
import {historyLogService} from '../../_services/historyLog.service';
import _ from 'lodash';
import {HistoryLogHelper, Utility} from '../../_helpers';
import {Alert} from '@material-ui/lab';
import {MDBTooltip} from 'mdbreact';
import {
  pageRenderer,
  ShowHideButton,
  ShowHideHistoryLogButton,
  SizePerPageRenderer
} from '../../_components';
import ToolkitProvider from 'react-bootstrap-table2-toolkit';
import Form from 'react-bootstrap/Form';
import {Col, Row} from 'react-bootstrap';

import './history-logs.scss';

const useStyles = theme => ({
  visibilityButton: {

    backgroundColor: '#4789b6',
    paddingRight: 2,
    '&:hover': {
      backgroundColor: '#3f75b5'

    }

  },
  actionContainer: {
    textAlign: 'left'
  }
});

class Search extends React.Component {

  constructor(props) {
    super(props);
    this.state = {
      filters: {
        mtf: {comparator: 'Eq', value: ''},
        zif: {comparator: 'Eq', value: ''},
        znf: {comparator: 'Eq', value: ''}
      },
      modTimeFilter: {operation: 'lastModTimeGtEq', value: ''},
      data: [],
      alert: '',
      loading: true,
      openPgMenu: null,
      page: 1,
      sizePerPage: 10,
      totalSize: 0,
      historyLogSearchParams: {},
      showDeleteConfirm: false,
      showAdvanceSearch: false

    };
    this.isComponentMounted = false;
    this.handleHistoryTableChange = this.handleHistoryTableChange.bind(this);
    this.getAdvanceSearchDialog = this.getAdvanceSearchDialog.bind(this);
    this.handleFilterChange = this.handleFilterChange.bind(this);
    if ((this.props.location.state === null || this.props.location.state ===
            undefined || !this.props.location.state.showAlerts) &&
        !_.isEmpty(this.props.alert)) {
      this.props.alertClear();
    }
  }

  async componentDidMount() {
    this.isComponentMounted = true;
    await this.loadTableData({});
  }

  async loadTableData(params) {
    this.setState({loading: true});
    for (var key in this.state.filters) {
      if (this.state.filters.hasOwnProperty(key) &&
          this.state.filters[key].value) {
        params[HistoryLogHelper.getFilterNameToApiFilter(key,
            this.state.filters[key].comparator)] = this.state.filters[key].value;
      }
    }

    console.log(params);

    const res = await historyLogService.getHistoryLogs(params);
    if (this.isComponentMounted) {
      this.setState({
        alert: res.error,
        data: res.historyLogs,
        loading: false,
        page: params.pageNumber ? params.pageNumber : this.state.page,
        sizePerPage: params.numberOfRows ?
            params.numberOfRows :
            this.state.sizePerPage,
        totalSize: res.totalRecords
      });
    }
  }

  componentWillUnmount() {
    this.isComponentMounted = false;
  }

  handleFilterChange(e) {
    const {name, value} = e.target;
    const {filters} = this.state;
    const filterInfo = name.split('.');
    filters[filterInfo[0]][filterInfo[1]] = value;
    this.setState({filters: filters});
  }

  getHistoryLogTableColumns() {
    const selectOptions = {
      A: 'A',
      C: 'C',
      D: 'D',
      M: 'M',
      U: 'U',
      S: 'S'

    };
    return [
      {
        dataField: 'sequence',
        text: 'Seq',
        headerAlign: 'center',
        headerClasses: 'p-1',
        classes: 'text-center p-0',

        headerStyle: {
          width: '5%'
        },
        headerFormatter: (column, colIndex) => <MDBTooltip
            domElement
            tag="span"
            placement="top"
        >
          <span className="blue-text"> {column.text} </span>
          <span>Sequence</span>
        </MDBTooltip>

      },
      {
        dataField: 'createTime',
        text: 'Time',
        headerAlign: 'center',
        headerClasses: 'p-1',
        classes: 'text-center p-0',
        headerStyle: {
          width: '15%'
        }
      },
      {
        dataField: 'modBy',
        text: 'Last Modified By',
        headerAlign: 'center',
        headerClasses: 'p-1',
        classes: 'text-center p-0',
        headerStyle: {
          width: '9%'
        }
      },

      {
        dataField: 'actionCode',
        text: 'Action',
        formatter: cell => {
          return selectOptions[cell];
        },
        headerAlign: 'center',
        headerClasses: 'p-1',
        classes: 'text-center p-0',
        headerStyle: {
          width: '5%'
        },
        cellStyle: {

          width: '3%'

        },
        style: {'wordWrap': 'break-word'}
      },
      {
        dataField: 'zoneNum',
        text: 'Zone ID',
        headerAlign: 'center',
        headerClasses: 'p-1',
        classes: 'text-center p-0',
        headerStyle: {
          width: '6%'
        },
        style: {'wordWrap': 'break-word'}

      },
      {
        text: 'Zone Name',
        dataField: 'zoneName',
        sort: false,
        headerAlign: 'center',
        headerClasses: 'p-1',
        classes: 'p-0',
        headerStyle: {
          width: '22%'
        },

        style: {'wordWrap': 'break-word'},
        headerEvents: {
          onClick: (e, column, columnIndex) => {
            e.preventDefault();
          }
        }
      },
      {
        dataField: 'typeCode',
        text: 'Record Type',
        headerAlign: 'center',
        headerClasses: 'p-1',
        classes: 'text-center p-0',
        headerStyle: {
          width: '8%'
        },
        style: {
          'wordWrap': 'break-word'
        }
      },
      {
        dataField: 'recId',
        text: 'Record ID',
        headerAlign: 'center',
        headerClasses: 'p-1',
        classes: 'text-center p-0',
        headerStyle:
            {
              width: '8%'
            },

        style: {
          'wordWrap': 'break-word'
        }
      },
      {
        dataField: 'domainName',
        text: 'Record Name',
        headerEvents: {
          onClick: (e, column, columnIndex) => {
            e.preventDefault();
          }
        },
        headerAlign: 'center',
        headerClasses: 'p-1',
        classes: 'text-center p-0',
        headerStyle:
            {
              width: '15%'
            },
        style: {
          'wordWrap': 'break-word'
        }
      },

      {
        dataField: 'comment',
        text: 'Comments',
        headerAlign: 'center',
        headerClasses: 'p-1',
        classes: 'text-center p-0',
        headerStyle:
            {
              width: '7%'
            },

        style: {
          'wordWrap': 'break-word'
        }
      }

    ];
  }

  getAdvanceSearchDialog() {
    return <Dialog
        fullWidth={true}
        onClose={(event, reason) => {
          if (reason === 'backdropClick' || reason === 'escapeKeyDown') {
            return false;
          }
        }}
        maxWidth="lg"
        open={this.state.showAdvanceSearch}
    >
      <DialogTitle id="form-dialog-title">DNS Resource Record
        Search</DialogTitle>

      <DialogContent>.
        <Form>
          <Form.Group as={Row} className={'align-items-center'}>
            <Form.Label column sm="2" className={'font-weight-bold'}>
              Last Modified Time:

            </Form.Label>
            <Col sm="2">
              <FormControl variant="outlined">
                <Select
                    id="mod_time_operation_filter"
                    value={this.state.filters.mtf.comparator}
                    onChange={this.handleFilterChange}
                    name={'mtf.comparator'}>
                  <MenuItem value={'lastModTimeGtEq'}
                            key={0}> {'>='} </MenuItem>
                  <MenuItem value={'lastModTimeLt'} key={1}> {'<'} </MenuItem>
                </Select>
              </FormControl>
            </Col>
            <Col sm={4}>
              <TextField
                  id="mod_time"
                  type="datetime-local"
                  variant="outlined"
                  name={'mtf.value'}
                  onChange={this.handleFilterChange}
                  value={this.state.filters.mtf.value}
              />
            </Col>
          </Form.Group>
          <Form.Group as={Row} className={'align-items-center'}>
            <Form.Label column sm="2" className={'font-weight-bold'}>
              Zone Id
            </Form.Label>
            <Col sm={6}>
              <Form.Control name={'zif.value'}
                            defaultValue={this.state.filters.zif.value}
                            onChange={this.handleFilterChange}
              />
            </Col>
          </Form.Group>
          <Form.Group as={Row} className={'align-items-center'}>
            <Form.Label column sm="2" className={'font-weight-bold'}>
              Zone Name
            </Form.Label>
            <Col sm={2}>
              <FormControl variant="outlined">
                <InputLabel htmlFor="wildcard-company-search">Zone
                  Name</InputLabel>
                <Select
                    autoWidth={true}
                    className={'w-100'}
                    name={'znf.comparator'}
                    value={this.state.filters.znf.comparator}
                    onChange={this.handleFilterChange}
                    label="Zone Name"
                >
                  {HistoryLogHelper.getZoneNameComparators.map(obj => (
                      <MenuItem value={obj.value}
                                key={obj.value}>{obj.label}</MenuItem>
                  ))}

                </Select>
              </FormControl>
            </Col>
            <Col sm={4}>
              <Form.Control name={'znf.value'}
                            defaultValue={this.state.filters.znf.value}
                            onChange={this.handleFilterChange}
              />
            </Col>

          </Form.Group>
        </Form>
      </DialogContent>

      <DialogActions>
        <Button onClick={async (e) => {
          await this.loadTableData({});
          e.preventDefault();
        }
        } color="primary" className={'dns-blue-button text-white'}
        >
          Search
        </Button>
        <Button onClick={() => this.setState(
            {showAdvanceSearch: false})}
                color="primary" className={'dns-blue-button text-white'}>
          Cancel
        </Button>
      </DialogActions>

    </Dialog>;
  }

  paginationOptions() {
    return {
      sizePerPage: this.state.sizePerPage,
      page: this.state.page,
      totalSize: this.state.totalSize,
      alwaysShowAllBtns: true,
      withFirstAndLast: false,
      firstPageText: 'First',
      prePageText: 'Back',
      nextPageText: 'Next',
      lastPageText: 'Last',
      nextPageTitle: 'First page',
      prePageTitle: 'Pre page',
      firstPageTitle: 'Next page',
      lastPageTitle: 'Last page',
      showTotal: false,
      sizePerPageList: [
        {
          text: '10', value: 10
        }, {
          text: '20', value: 20
        },
        {
          text: '50', value: 50
        }],
      pageButtonRenderer: pageRenderer,
      sizePerPageRenderer: ({
                              options,
                              currSizePerPage,
                              onSizePerPageChange
                            }) => <SizePerPageRenderer options={options}
                                                       currSizePerPage={currSizePerPage}
                                                       onSizePerPageChange={onSizePerPageChange}/>,
      disablePageTitle: true
    };
  }

  async handleHistoryTableChange(
      type, {
        filters,
        page,
        sizePerPage,
        totalSize,
        sortOrder,
        sortField
      }) {
    const currentIndex = (page - 1) * sizePerPage;
    let historyLogSearchParams = {};
    if (sortField && sortOrder) {
      historyLogSearchParams.orderDir = sortOrder;
      historyLogSearchParams.orderBy = sortField;
    }

    historyLogSearchParams.numberOfRows = sizePerPage;
    historyLogSearchParams.pageNumber = page;
    await this.loadTableData(historyLogSearchParams);
  }

  getFormattedModTime(dateTime) {
    let modDate = new Date(dateTime);
    const [year, month, date, hour, minutes, seconds] = [
      modDate.getFullYear(),
      modDate.getMonth() + 1,
      modDate.getDate(),
      modDate.getHours(),
      modDate.getMinutes(),
      modDate.getSeconds()];
    return `${year}-${month}-${date} ${hour}:${minutes}:${seconds}`;
  }

  render() {
    const paginationOptions = this.paginationOptions();
    const {data} = this.state;
    const columns = this.getHistoryLogTableColumns();
    return (

        <div>
          <Helmet>
            <title>DNS History Logs | Sys Admin</title>
          </Helmet>
          <Box>
            <Container maxWidth={false}>
              <Card>
                <CardContent>
                  <div className={'mt-3 ml-3 mr-3 mb-3'}>

                    <h5 className="font-weight-bold  text-capitalize text-left pt-1 pb-1 pl-2">DNS
                      Resource Record List
                    </h5>
                    <div>
                      {this.getAdvanceSearchDialog()}

                      <div className={'col text-right mt-2 mb-2'}>
                        <Button aria-controls="simple-menu"
                                aria-haspopup="true"
                                color="primary"
                                className={'dns-blue-button'}
                                variant={'contained'}
                                onClick={() => {
                                  this.setState(
                                      {showAdvanceSearch: true});
                                }} key={'advance_search'}>Advance
                          Search</Button>
                        {/*  <ShowHideHistoryLogButton columnToggleProps={this.props.columnToggleProps}
                                                            className={"d-inline-block"}></ShowHideHistoryLogButton>*/}
                      </div>
                      {this.state.alert &&
                      <Alert severity={'error'}>{this.state.alert.text}</Alert>}

                      <div className="pl-2 pr-2 mt-2">

                        <BootstrapTable bootstrap4
                                        keyField="sequence"
                                        remote
                                        onTableChange={this.handleHistoryTableChange}
                                        columns={columns}
                                        data={data}
                                        pagination={paginationFactory(
                                            paginationOptions)}
                                        id={'historyLog_table'}
                                        loading={this.state.loading}
                                        noDataIndication="Table is Empty"//need to fix here while loading data it displays as table empty during loading time
                                        striped
                                        hover
                                        condensed
                        />

                      </div>


                    </div>
                  </div>
                </CardContent>
              </Card>
            </Container>
          </Box>
        </div>

    );
  }
}

//const styledSearch = withStyles(useStyles)(Search);

function mapState(state) {
  const {alert} = state;
  return {alert};
}

const actionCreators =
    {
      alertClear: alertActions.clear
    };

const connectedHistoryLog = connect(mapState, actionCreators)(Search);
export {
  connectedHistoryLog as Search
}
  ;