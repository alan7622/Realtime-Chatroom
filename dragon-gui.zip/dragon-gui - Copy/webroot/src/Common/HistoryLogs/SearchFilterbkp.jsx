import React from "react";
import {alertActions} from "../../_actions";
import {connect} from "react-redux";
import {
    CardContent,
    Card,
    TextField,
    FormControl,
    Select,
    DialogTitle,
    DialogActions,
    Dialog,
    DialogContent,
    MenuItem,
    Button, InputLabel, Grid
} from "@material-ui/core";
import {Helmet} from "react-helmet";
import Container from "@material-ui/core/Container";
import Box from "@material-ui/core/Box";
import BootstrapTable from 'react-bootstrap-table-next';
import filterFactory, {Comparator, customFilter, selectFilter, textFilter} from 'react-bootstrap-table2-filter';
import paginationFactory from 'react-bootstrap-table2-paginator';
import overlayFactory from 'react-bootstrap-table2-overlay';
import {historyLogService} from "../../_services/historyLog.service";
import _ from "lodash";
import {HistoryLogHelper, Utility} from "../../_helpers";
import {Alert} from "@material-ui/lab";
import {MDBTooltip} from "mdbreact";
import {pageRenderer, ShowHideButton, ShowHideHistoryLogButton, SizePerPageRenderer} from "../../_components";
import ToolkitProvider from "react-bootstrap-table2-toolkit";
import Form from "react-bootstrap/Form";
import {Col, Row} from "react-bootstrap";


const useStyles = theme => ({
    visibilityButton: {

        backgroundColor: '#4789b6',
        paddingRight: 2,
        '&:hover': {
            backgroundColor: '#3f75b5',

        },


    },
    actionContainer: {
        textAlign: 'left'
    }
});

class Search extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            advanceSearchApplied: false,
            filters: {
                zif: '',
                znf: '',
                rif:''
            },
            modTimeFilter: {operation: "lastModTimeGtEq", value: ""},
            data: [],
            alert: '',
            loading: true,
            openPgMenu: null,
            page: 1,
            sizePerPage: 10,
            totalSize: 0,
            comparator: Comparator.EQ,
            historyLogSearchParams: {},
            showDeleteConfirm: false,
            showAdvanceSearchConfirm: false,

        }
        this.zf = null;
        this.znamefr = [{value: Comparator['EQ'], label: "Equals to"}, {
            value: 'Contains',
            label: "Contains"
        }, {value: 'Beg', label: "Begins With"}]


        this.isComponentMounted = false;
        this.handleHistoryTableChange = this.handleHistoryTableChange.bind(this)
        this.getAdvanceSearchDialog = this.getAdvanceSearchDialog.bind(this)
        this.handleChange = this.handleChange.bind(this);
        this.handleFilterChange = this.handleFilterChange.bind(this);


        if ((this.props.location.state === null || this.props.location.state === undefined || !this.props.location.state.showAlerts) && !_.isEmpty(this.props.alert)) {
            this.props.alertClear()
        }
    }

    async componentDidMount() {
        this.isComponentMounted = true;
        await this.loadTableData({});
    }

    async loadTableData(params) {
        this.setState({loading: true})
        params.numberOfRows = this.state.sizePerPage;
        params.pageNumber = this.state.page;
        const res = await historyLogService.getHistoryLogs(params);
        if (this.isComponentMounted) {
            this.setState({loading: false, data: res.historyLogs, alert: res.error, totalSize: res.totalRecords});

        }
    }

    componentWillUnmount() {
        this.isComponentMounted = false;
    }

    handleChange(e) {
        const {name, value} = e.target;
        const {modTimeFilter} = this.state;
        this.setState({modTimeFilter: {...modTimeFilter, [name]: value}})
    }

    handleFilterChange(e) {
        const {name, value} = e.target;
        const {filters} = this.state;
        this.setState({filters: {...filters, [name]: value}})
    }

    getHistoryLogTableColumns() {
        const selectOptions = {
            A: 'A',
            C: 'C',
            D: 'D',
            M: 'M',
            U: 'U',
            S: 'S',

        };
        return [
            {
                dataField: 'sequence',
                text: 'Seq',
                headerAlign: 'center',
                headerClasses: 'p-1',
                classes: 'text-center p-0',

                headerStyle: {
                    width: "5%",
                },
                headerFormatter: (column, colIndex) => <MDBTooltip
                    domElement
                    tag="span"
                    placement="top"
                >
                    <span className="blue-text"> {column.text} </span>
                    <span>Sequence</span>
                </MDBTooltip>


            },
            {
                dataField: 'createTime',
                text: 'Time',
                headerAlign: 'center',
                headerClasses: 'p-1',
                classes: 'text-center p-0',
                headerStyle: {
                    width: '15%'
                },
            },
            {
                dataField: 'modBy',
                text: 'Last Modified By',
                filter: textFilter({placeholder: 'Search', comparator: Comparator.EQ}),
                headerAlign: 'center',
                headerClasses: 'p-1',
                classes: 'text-center p-0',
                headerStyle: {
                    width: '9%'
                },
            },

            {
                dataField: 'actionCode',
                text: 'Action',
                formatter: cell => {
                    return selectOptions[cell]
                },
                filter: selectFilter({
                    options: selectOptions,
                    placeholder: "Select",
                }),
                headerAlign: 'center',
                headerClasses: 'p-1',
                classes: 'text-center p-0',
                headerStyle: {
                    width: '5%'
                },
                cellStyle: {

                    width: '3%'

                },

                style: {'wordWrap': 'break-word'},
            },
            {
                dataField: 'zoneNum',
                text: 'Zone ID',
                filter: textFilter({
                    placeholder: 'Search', comparator: Comparator.EQ, getFilter: (f) => {
                        this.zf = f
                    }
                }),
                headerAlign: 'center',
                headerClasses: 'p-1',
                classes: 'text-center p-0',
                headerStyle: {
                    width: '6%'
                },

                style: {'wordWrap': 'break-word'},

            },
            {
                text: 'Zone Name',
                dataField: 'zoneName',
                sort: false,
                headerAlign: 'center',
                headerClasses: 'p-1',
                classes: 'p-0',
                headerStyle: {
                    width: '22%'
                },

                style: {'wordWrap': 'break-word'},
                filter: customFilter({
                    comparator: this.state.comparator, getFilter: (f) => {
                        this.znf = f
                    }
                }),
                headerEvents: {
                    onClick: (e, column, columnIndex) => {
                        e.preventDefault()
                    }
                },
                filterRenderer: (onFilter, ...column) => {
                    return (<> <select
                        key="select"
                        ref={node => this.select = node}
                        className="form-control"
                        value={this.state.comparator}
                        onClick={(e) => e.preventDefault()}
                        onChange={(e) => this.setState({comparator: e.target.value})}
                    >{this.znamefr.map(obj => (
                        <option value={obj.value}>{obj.label}</option>
                    ))}
                    </select>
                        <input
                            className={"form-control"}
                            placeholder={"Search"}
                            name={"zoneName"}
                            onChange={(e) => {
                                e.preventDefault();
                                onFilter({value: e.target.value, comparator: this.state.comparator});
                                this.setState({filters: {...this.state.filters, znf: e.target.value}})
                            }}
                            value={this.state.filters.znf}
                        /></>)
                }
            },
            {
                dataField: 'typeCode',
                text: 'Record Type',
                filter: textFilter({placeholder: 'Search', comparator: Comparator.EQ}),
                headerAlign: 'center',
                headerClasses: 'p-1',
                classes: 'text-center p-0',
                headerStyle: {
                    width: '8%'
                },
                style: {
                    'wordWrap': 'break-word'
                },
            },
            {
                dataField: 'recId',
                text: 'Record ID',
                filter: textFilter({placeholder: 'Search', comparator: Comparator.EQ,getFilter: (f) => {
                        this.rf = f
                    }}),//give empty string when on;ly column name is required
                headerAlign: 'center',
                headerClasses: 'p-1',
                classes: 'text-center p-0',
                headerStyle:
                    {
                        width: '8%'
                    },

                style: {
                    'wordWrap': 'break-word'
                },
            },
            {
                dataField: 'domainName',
                text: 'Record Name',
                filter: customFilter({comparator: this.state.comparator}),
                headerEvents: {
                    onClick: (e, column, columnIndex) => {
                        e.preventDefault()
                    }
                },
                filterRenderer: (onFilter, column) => {
                    return (<> <select
                        key="select"
                        ref={node => this.select = node}
                        className="form-control"
                        onClick={(e) => e.preventDefault()}
                        onChange={(e) => this.setState({comparator: e.target.value})}
                    >
                        <option value={Comparator.EQ}>Equals to</option>
                        <option value={"Contains"}>Contains</option>
                        <option value={"Beg"}>Begins with</option>
                    </select>
                        <input
                            className={"form-control"}
                            placeholder={"Search"}
                            onChange={(e) => onFilter({value: e.target.value, comparator: this.state.comparator})}
                        /></>)
                },
                headerAlign: 'center',
                headerClasses: 'p-1',
                classes: 'text-center p-0',
                headerStyle:
                    {
                        width: '15%'
                    },
                style: {
                    'wordWrap': 'break-word'
                },
            },


            {
                dataField: 'comment',
                text: 'Comments',
                headerAlign: 'center',
                headerClasses: 'p-1',
                classes: 'text-center p-0',
                headerStyle:
                    {
                        width: '7%'
                    },

                style: {
                    'wordWrap': 'break-word'
                },
            },

        ];
    }

    getAdvanceSearchDialog() {
        return <Dialog
            onClose={(event, reason) => {
                if (reason === 'backdropClick' || reason === 'escapeKeyDown') {
                    return false;
                }
            }}
            maxWidth="lg"
            open={this.state.showAdvanceSearchConfirm}
        >
            <DialogTitle id="form-dialog-title">DNS Resource Record Search</DialogTitle>

            <DialogContent>.
                <Form>
                    <Form.Group as={Row} className={"align-items-center"}>
                        <Form.Label column sm="2" className={"font-weight-bold"}>
                            Last Modified Time:

                        </Form.Label> <FormControl variant="outlined">
                        <Select
                            id="mod_time_operation_filter"
                            value={this.state.modTimeFilter.operation}
                            onChange={this.handleChange}
                            name={"operation"}>
                            <MenuItem value={'lastModTimeGtEq'}> {'>='} </MenuItem>
                            <MenuItem value={'lastModTimeLt'}> {'<'} </MenuItem>
                        </Select>
                    </FormControl>
                        <TextField
                            id="mod_time"
                            type="datetime-local"
                            variant="outlined"
                            name={"value"}
                            onChange={this.handleChange}
                            value={this.state.modTimeFilter.value}
                        />
                    </Form.Group>
                    <Form.Group as={Row} className={"align-items-center"}>
                        <Form.Label column sm="2" className={"font-weight-bold"}>
                            Zone Id
                        </Form.Label>
                        <Col sm="4">

                            <Form.Control name={"zif"} defaultValue={this.state.filters.zif}
                                          onChange={this.handleFilterChange}
                            />
                        </Col>
                    </Form.Group>
                    <Form.Group as={Row} className={"align-items-center"}>
                        <Form.Label column sm="2" className={"font-weight-bold"}>
                            Zone Name
                        </Form.Label>
                        <Col sm="4">
                            <FormControl variant="outlined">
                                <InputLabel htmlFor="wildcard-company-search">Zone Name</InputLabel>
                                <Select
                                    onChange={(e) => this.setState({comparator: e.target.value})}
                                    label="Zone Name"

                                >
                                    {this.znamefr.map(obj => (
                                        <MenuItem value={obj.value}>{obj.label}</MenuItem>
                                    ))}

                                </Select>
                            </FormControl>
                            <TextField
                                id="outlined-helperText"
                                label="Zone Name"
                                variant="outlined"
                                name={"znf"}
                                value={this.state.filters.znf}
                                onChange={this.handleFilterChange}
                            />
                        </Col>

                    </Form.Group>


                    <Form.Group as={Row} className={"align-items-center"}>
                        <Form.Label column sm="2" className={"font-weight-bold"}>
                            Record Id
                        </Form.Label>
                        <Col sm="4">
                            <Form.Control name={"rif"} defaultValue={this.state.filters.rif}
                                          onChange={this.handleFilterChange}
                            />
                        </Col>
                    </Form.Group>
                    <Form.Group as={Row} className={"align-items-center"}>

                        <Form.Label column sm="2" className={"font-weight-bold"}>
                            Record Name
                        </Form.Label>
                        <Col sm="4">
                            <Form.Control name={"domainName"} onChange={""}
                            />
                        </Col>

                    </Form.Group>
                    <Form.Group as={Row} className={"align-items-center"}>
                        <Form.Label column sm="2" className={"font-weight-bold"}>
                            Record Type </Form.Label>
                        <Col sm="4">
                            <Form.Control name={"typeCode"} onChange={""}
                            />
                        </Col>

                    </Form.Group>

                    <Form.Group as={Row} className={"align-items-center"}>

                        <Form.Label column sm="2" className={"font-weight-bold"}>
                            Action
                        </Form.Label>
                        <Col sm="4">
                            <Form.Control name={"actionCode"} onChange={""}
                            />
                        </Col>

                    </Form.Group>
                    <Form.Group as={Row} className={"align-items-center"}>
                        <Form.Label column sm="2" className={"font-weight-bold"}>
                            Modified By </Form.Label>
                        <Col sm="4">
                            <Form.Control name={"modBy"} onChange={""}
                            />
                        </Col>
                    </Form.Group>
                </Form>
            </DialogContent>

            <DialogActions>
                {/*   <Button onClick={async () => {
                    await this.loadTableData({[this.state.modTimeFilter.operation]: this.getFormattedModTime(this.state.modTimeFilter.value)});
                    this.setState({showAdvanceSearchConfirm: false, advanceSearchApplied: true})
                }} color="primary" className={"dns-blue-button text-white"}>
                    Search
                </Button>*/}
                <Button onClick={() => {
                    this.zf(this.state.filters.zif),
                        this.znf(this.state.filters.znf),
                        this.rf(this.state.filters.rif),

                        this.setState({showAdvanceSearchConfirm: false})
                }
                } color="primary" className={"dns-blue-button text-white"}
                >
                    Search
                </Button>
                <Button onClick={() => this.setState({showAdvanceSearchConfirm: false, advanceSearchApplied: false})}
                        color="primary" className={"dns-blue-button text-white"}>
                    Cancel
                </Button>
            </DialogActions>

        </Dialog>
    }


    paginationOptions() {
        return {
            sizePerPage: this.state.sizePerPage,
            page: this.state.page,
            totalSize: this.state.totalSize,
            alwaysShowAllBtns: true,
            withFirstAndLast: false,
            firstPageText: 'First',
            prePageText: 'Back',
            nextPageText: 'Next',
            lastPageText: 'Last',
            nextPageTitle: 'First page',
            prePageTitle: 'Pre page',
            firstPageTitle: 'Next page',
            lastPageTitle: 'Last page',
            showTotal: false,
            sizePerPageList: [
                {
                    text: '10', value: 10
                }, {
                    text: '20', value: 20
                },
                {
                    text: '50', value: 50
                },],
            pageButtonRenderer: pageRenderer,
            sizePerPageRenderer: ({
                                      options,
                                      currSizePerPage,
                                      onSizePerPageChange
                                  }) => <SizePerPageRenderer options={options}
                                                             currSizePerPage={currSizePerPage}
                                                             onSizePerPageChange={onSizePerPageChange}/>,
            disablePageTitle: true,
        };
    }


    async handleHistoryTableChange(type, {filters, page, sizePerPage, totalSize, sortOrder, sortField}) {
        const currentIndex = (page - 1) * sizePerPage;
        let historyLogSearchParams = {}
        /*
                if (type === 'sort') {
        */
        if (sortField && sortOrder) {
            historyLogSearchParams.orderDir = sortOrder;
            historyLogSearchParams.orderBy = sortField;
        }


        // }else if (type === 'filter') {
        if (_.isEmpty(filters)) {
            historyLogSearchParams = {}
        }

        for (const [columnField, colFilterInfo] of Object.entries(filters)) {
            let comparator = colFilterInfo.comparator
            let value = colFilterInfo.filterVal
            if (_.isObject(value) && value.hasOwnProperty('comparator')) {
                value = colFilterInfo.filterVal.value
                comparator = colFilterInfo.filterVal.comparator

            }
            if (value == "") {
                continue;
            }
            switch (comparator) {
                case Comparator.EQ:
                    historyLogSearchParams[`${HistoryLogHelper.getDataFieldToFilterMap(columnField, 'Eq')}`] = value
                    break;
                case Comparator.LIKE:
                    historyLogSearchParams[`${HistoryLogHelper.getDataFieldToFilterMap(columnField)}Contains`] = value
                    break;
                case Comparator.GT:
                    historyLogSearchParams[`${HistoryLogHelper.getDataFieldToFilterMap(columnField)}Beg`] = value
                    break;
                default:
                    historyLogSearchParams[`${HistoryLogHelper.getDataFieldToFilterMap(columnField)}${Utility.ucFirst(comparator)}`] = value
                    break;

            }


        }
        //}
        /*else {
            this.setState({com: false})
            return;
        }*/ //add else if == pagination  code breaks
        historyLogSearchParams.numberOfRows = sizePerPage;
        historyLogSearchParams.pageNumber = page;
        this.setState({loading: true});
        const res = await historyLogService.getHistoryLogs(historyLogSearchParams);
        this.setState({
            data: res.historyLogs,
            loading: false,
            page: page,
            sizePerPage: sizePerPage,
            totalSize: res.totalRecords
        });


        if (this.state.advanceSearchApplied) {
            historyLogSearchParams[this.state.modTimeFilter.operation] = this.getFormattedModTime(this.state.modTimeFilter.value);
        }

        /* this.setState({data: res.historyBOs, loading: false, page: page, sizePerPage: sizePerPage});*/

    }


    getFormattedModTime(dateTime) {
        let modDate = new Date(dateTime)
        const [year, month, date, hour, minutes, seconds] = [modDate.getFullYear(), modDate.getMonth() + 1, modDate.getDate(), modDate.getHours(), modDate.getMinutes(), modDate.getSeconds()];
        return `${year}-${month}-${date} ${hour}:${minutes}:${seconds}`
    }

    render() {
        const paginationOptions = this.paginationOptions();
        const {data} = this.state;
        const columns = this.getHistoryLogTableColumns();
        return (

            <div>
                <Helmet>
                    <title>DNS History Logs | Sys Admin</title>
                </Helmet>
                <Box>
                    <Container maxWidth="lg">
                        <Card>
                            <CardContent>
                                <div className={"mt-3 ml-3 mr-3 mb-3"}>

                                    <h5 className="font-weight-bold  text-capitalize text-left pt-1 pb-1 pl-2">DNS
                                        Resource Record List
                                    </h5>
                                    <div>
                                        {this.getAdvanceSearchDialog()}

                                        <div className={"col text-right mt-2 mb-2"}>
                                            <Button className={"dns-blue-button text-white mt-2 mr-4 mb-4"}
                                                    onClick={() => {
                                                        this.setState({showAdvanceSearchConfirm: true})
                                                    }} key={"advance_search"}>Advance Search</Button>
                                            <Button className={"dns-blue-button text-white mt-2 mr-4 mb-4"}
                                                    key={"search"}>Search</Button>
                                            {/*  <ShowHideHistoryLogButton columnToggleProps={this.props.columnToggleProps}
                                                            className={"d-inline-block"}></ShowHideHistoryLogButton>*/}
                                        </div>
                                        {this.state.alert &&
                                        <Alert severity={"error"}>{this.state.alert.text} <a href={"#"}
                                                                                             onClick={async (e) => {
                                                                                                 e.preventDefault();
                                                                                                 this.setState({
                                                                                                     modTimeFilter: {
                                                                                                         ...this.state.modTimeFilter,
                                                                                                         value: ""
                                                                                                     }
                                                                                                 });
                                                                                                 await this.loadTableData({})
                                                                                             }}>Clear</a></Alert>}

                                        <div className="pl-2 pr-2">

                                            <BootstrapTable bootstrap4
                                                            keyField="sequence"
                                                            data={data}
                                                            remote
                                                            onTableChange={this.handleHistoryTableChange}
                                                            columns={columns}
                                                            filter={filterFactory()}
                                                            filterPosition={"top"}
                                                            pagination={paginationFactory(paginationOptions)}
                                                            id={"historyLog_table"}
                                                            loading={this.state.loading}  //only loading is true, react-bootstrap-table will render overlay
                                                /*
                                                                                                            overlay={ overlayFactory({spinner:true,styles:{overlay:(b)=>({...b})}}) }
                                                */
                                                /*
                                                                                                            overlay={overlayFactory()}
                                                */
                                                            noDataIndication="Table is Empty"//need to fix here while loading data it displays as table empty during loading time
                                                            striped
                                                            hover
                                                            condensed
                                            />

                                        </div>


                                    </div>
                                </div>
                            </CardContent>
                        </Card>
                    </Container>
                </Box>
            </div>

        );
    }
}

//const styledSearch = withStyles(useStyles)(Search);

function mapState(state) {
    const {alert} = state
    return {alert}
}

const actionCreators =
    {
        alertClear: alertActions.clear,
    }

const connectedHistoryLog = connect(mapState, actionCreators)(Search);
export {
    connectedHistoryLog as Search
}
    ;