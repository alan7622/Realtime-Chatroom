import React, {Component} from "react";
import {
    Backdrop,
    Button,
    Card,
    CardContent,
    CircularProgress,
    Dialog,
    DialogActions,
    DialogTitle
} from "@material-ui/core";
import Form from "react-bootstrap/Form";
import {Col, Row} from "react-bootstrap";
import PropTypes from "prop-types";
import {alertActions, delegateNameserverActions, delegationActions} from "../../../_actions";
import {withRouter} from "react-router-dom";
import {connect} from "react-redux";
import {Helmet} from "react-helmet";
import Container from "@material-ui/core/Container";
import {Alert} from "@material-ui/lab";
import {delegationNSService, delegationService, zoneService} from "../../../_services";
import _ from "lodash";
import {DELEGATIONNS_RESPONSE_TO_REQUEST_MAP, removeEmptyValues} from "../../../_helpers";

class DelegationNameserver extends Component {
    constructor(props) {
        super(props);
        this.state = {
            zoneData: {},
            delegation: {},
            loading: true,
            alert: '',
            showDeleteConfirm: false,
            nameserver: {
                zoneNum: this.props.match.params.zoneNum,
                delegationId: this.props.match.params.id,
                accountId: '',
                recId: this.props.match.params.recId,
                delegationName: '',
                ns1: '',
                DType: '',
                ttl: '',
                comments: '',
                cut_ns_fqdn: ''
            },


        }
        this.isComponentMounted = false
        this.saveDelegationNameServer = this.saveDelegationNameServer.bind(this);
        this.deleteDelegationNameServer = this.deleteDelegationNameServer.bind(this);
        this.getDeleteConfirmDialog = this.getDeleteConfirmDialog.bind(this);
        this.updateDelegationNSObj = this.updateDelegationNSObj.bind(this);
    }

    async componentDidMount() {
        this.isComponentMounted = true;
        const res = await zoneService.getZoneById(this.props.match.params.zoneNum)

        if (this.isComponentMounted) {
            this.setState({loading: !this.props.isEmptyForm, zoneData: res.zone});
        }
        if (!this.props.isEmptyForm && this.isComponentMounted) {
            const res2 = await delegationNSService.getByDelegationId(this.props.match.params.id);
            if (!_.isEmpty(res2) && this.isComponentMounted) {

                console.log(res2.delegation, "res2.delegation")
                this.setState({loading: false, nameserver: res2.nameserver});

            }
        }


    }


    saveDelegationNameServer(e) {
        e.preventDefault()
        console.log(this.state.nameserver, "nameserver");

        if (this.isComponentMounted) {
            this.setState({loading: !this.props.isEmptyForm})//changed it so that it supports loading on create page

        }
        if (this.props.isEmptyForm && this.props.isEditable) {
            const nameservers = removeEmptyValues({
                zoneName: this.state.zoneData.zoneName,
                ...this.state.nameserver
            })

            this.props.create(nameservers,this.props.match.params.zoneNum);


        } else {

            const updatedNameservers = removeEmptyValues({
                //zoneName: this.state.zoneData.zoneName,
                //ns1: this.state.nameserver.ns1,
                comments: this.state.nameserver.comments,
                ttl: this.state.nameserver.ttl,
                //...this.state.nameserver
            })

            this.props.update(this.props.match.params.id, this.props.match.params.zoneNum, updatedNameservers);
        }
    }

    componentWillUnmount() {
        this.isComponentMounted = false;
    }

    updateDelegationNSObj(e) {
        let {name, value} = e.target;
        const {nameserver} = this.state;
        if (DELEGATIONNS_RESPONSE_TO_REQUEST_MAP.hasOwnProperty(name)) {
            delete nameserver[name];
            name = DELEGATIONNS_RESPONSE_TO_REQUEST_MAP[name];
        }

        this.setState({nameserver: {...nameserver, [name]: value}})
    }


    deleteDelegationNameServer() {
        this.setState({showDeleteConfirm: false, loading: true})
        this.props.delete(this.props.match.params.id,this.props.match.params.zoneNum,this.props.match.params.delegationId);


    }

    getDeleteConfirmDialog() {
        return !this.props.isEditable && <Dialog
            onClose={(event, reason) => {
                if (reason === 'backdropClick' || reason === 'escapeKeyDown') {
                    return false;
                }
            }}
            maxWidth="xs"
            aria-labelledby="confirmation-dialog-title"
            open={this.state.showDeleteConfirm}
        >
            <DialogTitle id="confirmation_dialog_title">Are you sure you want to delete this
                delegation?</DialogTitle>
            <DialogActions>
                <Button autoFocus onClick={this.deleteDelegationNameServer} className={"dns-blue-button text-white"}>
                    Delete
                </Button>
                <Button onClick={() => this.setState({showDeleteConfirm: false})}
                        className={"dns-blue-button text-white"}>
                    Cancel
                </Button>
            </DialogActions>
        </Dialog>
    }

    getDelegationNameserverPageButtons() {
        let pageElements = {
            pageTitle: '',
            pageButtons: [],
        }
        if (this.props.isEditable && this.props.isEmptyForm) {
            pageElements.pageTitle = "DNS Delegations NameServers Insert Page"
            pageElements.pageButtons.push(<Button className={"dns-blue-button text-white mr-2"}
                                                  type={"submit"} key={"insert_dlgNS"}>Insert</Button>)
            pageElements.pageButtons.push(<Button className={"dns-blue-button text-white mr-2 col-md-1"}
                                                  onClick={() => this.props.history.goBack()}
                                                  key={"cancel_update"}>Cancel</Button>)


        } else if (this.props.isEditable) {
            pageElements.pageTitle = "DNS Delegation Name Servers Update Page"
            pageElements.pageButtons.push(<Button className={"dns-blue-button text-white mr-2 col-md-1"}
                                                  type={"submit"}
                                                  key={"update_dlgNS"}>Update</Button>)
            pageElements.pageButtons.push(<Button className={"dns-blue-button text-white mr-2 col-md-1"}
                                                  onClick={() => this.props.history.goBack()}
                                                  key={"cancel_update"}>Cancel</Button>)


        } else {
            pageElements.pageTitle = "DNS Delegate NameServer Details Page"
            pageElements.pageButtons.push(<Button className={"dns-blue-button text-white mt-2 mr-4 mb-4"}
                                                  onClick={() => {
                                                      this.props.alertClear();

                                                      this.props.history.push(`/dns/zones/details/${this.props.match.params.zoneNum}/zoneDelegation/${this.props.match.params.delegationId}/delg/nameserver/edit/${this.props.match.params.id}`)
                                                  }}
                                                  key={"edit_dlgNS"}>Go To Update</Button>)
            pageElements.pageButtons.push(<Button className={"dns-blue-button text-white mt-2 mr-4 mb-4"}
                                                  onClick={() => {
                                                      this.setState({showDeleteConfirm: true})
                                                  }} key={"delete_dlgNS"}>Delete</Button>)
            pageElements.pageButtons.push(<Button className={"dns-blue-button text-white ml-2 mt-2 mb-4"}
                                                  onClick={() => {
                                                      this.props.history.push(`/dns/zones/details/${this.props.match.params.zoneNum}/zoneDelegation/${this.props.match.params.delegationId}/delg/nameserver`)


                                                  }}
                                                  key={"dlgNS_List"}>List Delegation NameServers</Button>)


        }

        return pageElements;
    }

    getDelegationNameServerForm() {
        let {zoneData, delegation, nameserver} = this.state;
        let {pageButtons} = this.getDelegationNameserverPageButtons();
        return <form onSubmit={this.saveDelegationNameServer}>
            {!this.props.isEmptyForm && <> <Form.Group as={Row} className={"align-items-center"}>

                <Form.Label column sm="2" className={"font-weight-bold"}>
                    Record ID
                </Form.Label>

                <Col sm={4}>
                    {nameserver.recId}
                </Col>


                {!this.props.isEditable && <>    <Form.Label column sm="2" className={"font-weight-bold"}>
                    Delegation RecID
                </Form.Label>
                    <Col sm={4}>
                        {nameserver.delegationId}
                    </Col></>}

            </Form.Group>                </>}


            <Form.Group as={Row} className={"align-items-center"}>
                {(this.props.isEmptyForm || !this.props.isEditable) && <> <Form.Label column sm="2"
                                                                                      className={"font-weight-bold"}>
                    Zone ID
                </Form.Label>
                    <Col sm={4}>
                        {zoneData.zoneNum}
                    </Col></>}
                {this.props.isEmptyForm && <>     <Form.Label column sm="2"
                                                              className={"font-weight-bold"}>
                    Sub Zone ID
                </Form.Label>
                    <Col sm={2}>
                        {nameserver.delegationId}
                    </Col></>}
            </Form.Group>

            <Form.Group as={Row}
                        className={"align-items-center"}>
                <Form.Label column sm="2"
                            className={"font-weight-bold"}>
                    Server's Full Name
                </Form.Label>
                <Col sm={4}>
                    {(this.props.isEmptyForm || this.props.isEditable) ?

                        <Form.Control name={"cut_ns_fqdn"}
                                      onChange={this.updateDelegationNSObj}
                                      defaultValue={nameserver.cut_ns_fqdn ? nameserver.cut_ns_fqdn : ''}/> : nameserver.cut_ns_fqdn}
                </Col>
            </Form.Group>


            <Form.Group as={Row}
                        className={"align-items-center"}>
                <Form.Label column sm="2" className={"font-weight-bold"}>
                    Time To Live
                </Form.Label>
                <Col sm={4}>
                    {this.props.isEditable ?

                        <Form.Control name={"ttl"}
                                      onChange={this.updateDelegationNSObj}
                                      defaultValue={nameserver.ttl ? nameserver.ttl : ''}/> : nameserver.ttl}
                </Col>
            </Form.Group>


            <Form.Group as={Row} className={"align-items-center"}>
                <Form.Label column sm="2"
                            className={"font-weight-bold"}>
                    Comment
                </Form.Label>
                <Col sm={4}>
                    {this.props.isEditable ?

                        <Form.Control name={"comment"}
                                      onChange={this.updateDelegationNSObj}
                                      defaultValue={nameserver.comment ? nameserver.comment : ''}/> : nameserver.comment}
                </Col>


                {!this.props.isEditable && <>  <Form.Label column sm="2" className={"font-weight-bold"}>
                    Modified By
                </Form.Label>
                    <Col sm="4">
                        {this.props.isEditable ?
                            <Form.Control name={"modBy"} onChange={this.updateDelegationNSObj}
                                          defaultValue={nameserver.modBy ? nameserver.modBy : ''}/> : nameserver.modBy}
                    </Col></>}

            </Form.Group>

            {
                !this.props.isEditable && <Form.Group as={Row} className={"align-items-center mb-2"}>
                    <Form.Label column sm="2" className={"font-weight-bold"}>
                        Created
                    </Form.Label>
                    <Col sm="4">
                        {nameserver.createTime}
                    </Col>
                    <Form.Label column sm="2" className={"font-weight-bold"}>
                        Last Modified
                    </Form.Label>
                    <Col sm="4">
                        {nameserver.modTime}
                    </Col>

                </Form.Group>
            }

            <div className={"text-center"}>
                {pageButtons.map(buttonComp => buttonComp)}
            </div>
        </form>
    }

    render() {
        let {pageTitle} = this.getDelegationNameserverPageButtons();
        return (
            <>
                {this.getDeleteConfirmDialog()}
                {/*  <Backdrop className={"page-loading"} style={{'zIndex': '10000', 'color': '#fff'}}
                          open={this.state.loading && this.props.loading}>
                    <CircularProgress color="inherit"/>
                </Backdrop>*/}
                <div>
                    <Helmet>
                        <title>DNS Admin | DNS Delegate NameServer Details Page
                        </title>
                    </Helmet>
                    <Container maxWidth={false} className={"px-2"}>
                        <Card>
                            <CardContent>
                                <h5 className="font-weight-bold  text-capitalize text-left pt-3 pb-1 pl-4">{pageTitle}</h5>
                                <div className={"pb-2 pl-4"}>

                                    <div className={"pb-2"}>
                                        {this.props.alert.message && <Alert
                                            severity={this.props.alert.type}>{this.props.alert.message}</Alert>}</div>
                                    {this.getDelegationNameServerForm()}
                                </div>
                            </CardContent>
                        </Card>
                    </Container>
                </div>
            </>)
    }


}

DelegationNameserver.defaultProps = {
    isEditable: false,
};

DelegationNameserver.propTypes = {
    isEditable: PropTypes.bool,
    isEmptyForm: PropTypes.bool
};

function mapState(state) {
    const {saving, loading, saved, deleted} = state.delegationServers

    const {alert} = state
    return {saving, loading, saved, deleted, alert}
}

const actionCreators = {
    alertClear: alertActions.clear,
    create: delegateNameserverActions.create,
    update: delegateNameserverActions.update,
    delete: delegateNameserverActions.delete


};
const connectedDelegationNameserver = withRouter(connect(mapState,
    actionCreators)(DelegationNameserver));
export {connectedDelegationNameserver as DelegationNameserver}