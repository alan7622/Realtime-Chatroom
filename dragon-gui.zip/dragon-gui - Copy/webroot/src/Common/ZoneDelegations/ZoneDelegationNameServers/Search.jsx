import {Link, withRouter} from "react-router-dom";
import {connect} from "react-redux";
import {Helmet} from "react-helmet";
import Container from "@material-ui/core/Container";
import {
    Button,
    Card,
    Dialog, DialogActions,
    DialogContent,
    DialogTitle,
    CardContent,
    FormControl, InputLabel,
    MenuItem,
    Select, RadioGroup, FormControlLabel, Radio,
} from "@material-ui/core";
import {Alert} from "@material-ui/lab";
import BootstrapTable from "react-bootstrap-table-next";
import React, {Component} from "react";
import Form from "react-bootstrap/Form";
import {Col, Row} from "react-bootstrap";
import {alertActions} from "../../../_actions";
import {ComparatorHelper} from "../../../_helpers";
import {delegationNSService, delegationService} from "../../../_services";
import paginationFactory from "react-bootstrap-table2-paginator";
import {pageRenderer, SizePerPageRenderer} from "../../../_components";
import PropTypes from "prop-types";


class Search extends Component {
    constructor(props) {
        super(props);
        this.state = {
            data: [],
            zoneData: {},
            delegationNSSearchParams:{},
            advanceSearchApplied: false,
            filters: {
                companyName: {comparator: 'Eq', value: ''},
                delegationName: {comparator: 'Eq', value: ''},

            },
            showDeleteConfirm: false,
            showAdvanceSearch: false,
            page: 1,
            sizePerPage: 10,
            totalSize: 0,


        }
        this.isComponentMounted = false;
        this.handleFilterChange = this.handleFilterChange.bind(this)
        this.handleTableChange = this.handleTableChange.bind(this);
        this.getAdvanceSearchDialog = this.getAdvanceSearchDialog.bind(this)



    }

    async componentDidMount() {
        this.isComponentMounted = true;
        setTimeout(() => {
            this.props.alertClear()
        }, 10000)
        await this.loadTableData({numberOfRows: this.state.sizePerPage, pageNumber: this.state.page});


    }

    async loadTableData(data) {

        if (this.isComponentMounted) {
            this.setState({loading: true})
        }
        data = {
            ...data,
            delegationNum: this.props.match.params.id,
            //   zoneNum: this.props.match.params.zoneNum,

        }
        const res = await delegationNSService.getAllDelegationNameServers(data);
        if (this.isComponentMounted) {
            this.setState({
                loading: false, data: res.nameserver, error: res.error, totalSize: res.totalRecords,
                page: data.pageNumber ? data.pageNumber : this.state.page,
                sizePerPage: data.numberOfRows ?
                    data.numberOfRows :
                    this.state.sizePerPage,
            });
        }

    }

    componentWillUnmount() {
        this.isComponentMounted = false;
    }

    handleFilterChange(e) {
        const {name, value} = e.target;
        const {filters} = this.state;
        const filterInfo = name.split('.');
        filters[filterInfo[0]][filterInfo[1]] = value;
        this.setState({filters: filters});
    }

    getDelegationNameServerTableColumns() {
        return [
            {
                dataField: 'recId',
                text: 'Record ID',
                headerAlign: 'center',
                classes: 'text-left p-0',
                headerStyle: {
                    width: '20%'
                },
                style: {
                    wordWrap: 'break-word'
                },


            },
            {
                dataField: 'cut_ns_fqdn',
                text: 'Server Name',
                headerAlign: 'center',
                classes: 'text-left p-0',
                headerStyle: {
                    width: '20%'
                },
                style: {
                    wordWrap: 'break-word'
                },

            },
            {
                dataField: 'modTime',
                text: 'Last Modified',
                headerAlign: 'center',
                classes: 'text-left p-0',
                headerStyle: {
                    width: '20%'
                },
                style: {
                    wordWrap: 'break-word'
                },
            },

            {
                dataField: 'delegationId',
                text: 'Delegation ID',
                headerAlign: 'center',
                classes: 'text-left p-0',
                headerStyle: {
                    width: '20%'
                },
                style: {
                    wordWrap: 'break-word'
                },
            },
            {
                dataField: 'zoneNum',
                text: 'Zone ID',
                headerAlign: 'center',
                classes: 'text-left p-0',
                headerStyle: {
                    width: '10%'
                },
                style: {
                    wordWrap: 'break-word'
                },
            },
            {
                text: "Action",
                dataField: "",
                headerAlign: 'center',
                headerStyle: {
                    width: "10%"
                },

                formatter: (cell, row, rowIndex) => <>
                    <Link
                        to={`/dns/zones/details/${this.props.match.params.zoneNum}/zoneDelegation/${this.props.match.params.id}/delg/nameserver/${row.recId}`}
                        key={"details_delgationNS"}
                        className={"color-dragon-blue mr-2"}
                    >Details</Link>
                    <Link
                        to={`/dns/zones/details/${this.props.match.params.zoneNum}/zoneDelegation/${this.props.match.params.id}/delg/nameserver/edit/${row.recId}`}
                        key={"edit_delgationNS"}
                        className={"color-dragon-blue mr-2"}
                    >Edit</Link>
                </>
            },


        ];

    }


    async handleTableChange(type, {filters, page, sortOrder, sortField, sizePerPage, totalSize}) {
        const currentIndex = (page - 1) * sizePerPage;
        let delegationNSSearchParams = {};
        if (sortField && sortOrder) {
            delegationNSSearchParams.orderDir = sortOrder;
            delegationNSSearchParams.orderBy = sortField;
        }

        delegationNSSearchParams.numberOfRows = sizePerPage;
        delegationNSSearchParams.pageNumber = page;
        await this.loadTableData(delegationNSSearchParams);

    }

    getAdvanceSearchDialog() {
        return <Dialog
            fullWidth={true}
            onClose={(event, reason) => {
                if (reason === 'backdropClick' || reason === 'escapeKeyDown') {
                    return false;
                }
            }}
            maxWidth="md"
            open={this.state.showAdvanceSearch}
        >
            <DialogTitle id="form-dialog-title"><b>DNS
                Search Delegations</b></DialogTitle>

            <DialogContent>
                <Form>

                    <Form.Group as={Row} className={'align-items-center'}>

                        <p>
                            There are different formats that can be used here for Zone Name and Delegation Name..
                            Please select the appropriate format before filling the fields.</p>

                        <RadioGroup value={this.state.filters.zoneSubType} onChange={this.handleFilterChange}
                                    name={"zoneSubType"}>
                            <p className={'font-weight-bold'}>There are different formats that can be used
                                here for Zone Name.
                                Please select the appropriate format before filling the fields.</p>

                            <FormControlLabel value="DOM"
                                              control={<Radio color="primary"/>}
                                              label="Forward and IP4 Arpa Zones (i.e. expressojoes.com. or 128/27.114.0.12.in-addr.arpa.)"/>
                            <FormControlLabel value="IP4" control={<Radio color="primary"/>}
                                              label="IP4 Arpa Zones (i.e. 128/27.114.0.12.in-addr.arpa.) Please note that the IP4 arpa search is always on the IP address of the arpa zone(i.e. 12.0.114.128/27 or 12.0.114 or 0.114).The exceptions are an ' Equals' or a ' Contains' search where the search string ends with '.in-addr.arpa.'.In this case the search is on the Arpa Address(i.e 128/27.114.0.12.in-addr.arpa. or 12.in-addr.arpa.)."/>
                            <FormControlLabel value="IP6" control={<Radio color="primary"/>}
                                              label="IP6 Arpa Zones (i.e. 2001:1890:1111 or 1.1.1.1.0.9.8.1.1.0.0.2.ip6.arpa.)  Please make sure your search argument includes one of the delimiters ('.' or ':') to indicate what IP6 format you are using.If you don't, the search will assume the input is an address (i.e. 2001:1890:1111)."/>

                        </RadioGroup>

                    </Form.Group>


                    <Form.Group as={Row} className={'align-items-center'}>
                        <Form.Label column sm="2" className={'font-weight-bold'}>
                            Delegation Name
                        </Form.Label>
                        <Col sm={2}>
                            <FormControl variant="outlined">
                                <InputLabel htmlFor="wildcard-company-search"> Delegation Name</InputLabel>
                                <Select
                                    autoWidth={true}
                                    className={'w-100'}
                                    name={'delegationName.comparator'}
                                    value={this.state.filters.delegationName.comparator}
                                    onChange={this.handleFilterChange}
                                    label="Delegation Name"
                                >
                                    {ComparatorHelper.getComparators.map(obj => (
                                        <MenuItem value={obj.value}
                                                  key={obj.value}>{obj.label}</MenuItem>
                                    ))}

                                </Select>
                            </FormControl>
                        </Col>
                        <Col sm={4}>
                            <Form.Control name={'delegationName.value'}
                                          defaultValue={this.state.filters.delegationName.value}
                                          onChange={this.handleFilterChange}
                            />
                        </Col>

                    </Form.Group>

                    <Form.Group as={Row} className={"align-items-center"}>

                        <Form.Label column sm="2" className={"font-weight-bold"}>
                            Zone Name
                        </Form.Label>
                        <Col sm={2}>
                            <FormControl variant="outlined">
                                <InputLabel htmlFor="wildcard-zoneName-search">
                                    Company</InputLabel>
                                <Select
                                    autoWidth={true}
                                    className={'w-100'}
                                    name={'zoneName.comparator'}
                                    value={this.state.filters.zoneName.comparator}
                                    onChange={this.handleFilterChange}
                                    label="Zone Name"
                                >
                                    {ComparatorHelper.getComparators.map(obj => (
                                        <MenuItem value={obj.value}
                                                  key={obj.value}>{obj.label}</MenuItem>
                                    ))}

                                </Select>
                            </FormControl>
                        </Col>
                        <Col sm={4}>
                            <Form.Control name={'zoneName.value'}
                                          defaultValue={this.state.filters.zoneName.value}
                                          onChange={this.handleFilterChange}
                            />
                        </Col>

                    </Form.Group>
                </Form>
            </DialogContent>

            <DialogActions>
                <Button onClick={async (e) => {
                    await this.loadTableData({numberOfRows: this.state.sizePerPage, pageNumber: this.state.page});
                    this.setState(
                        {showAdvanceSearch: false});
                }
                } color="primary" className={'dns-blue-button text-white'}
                >
                    Search
                </Button>
                <Button onClick={() => this.setState(
                    {showAdvanceSearch: false})}
                        color="primary" className={'dns-blue-button text-white'}>
                    Cancel
                </Button>
            </DialogActions>

        </Dialog>
    }


    paginationOptions() {
        return {
            sizePerPage: this.state.sizePerPage,
            page: this.state.page,
            totalSize: this.state.totalSize,
            alwaysShowAllBtns: true,
            withFirstAndLast: true,
            firstPageText: 'First',
            prePageText: 'Back',
            nextPageText: 'Next',
            lastPageText: 'Last',
            nextPageTitle: 'First page',
            prePageTitle: 'Pre page',
            firstPageTitle: 'Next page',
            lastPageTitle: 'Last page',
            showTotal: false,
            sizePerPageList: [
                {
                    text: '10', value: 10
                }, {
                    text: '20', value: 20
                },
                {
                    text: '50', value: 50
                },],
            pageButtonRenderer: pageRenderer,
            sizePerPageRenderer: ({
                                      options,
                                      currSizePerPage,
                                      onSizePerPageChange
                                  }) => <SizePerPageRenderer options={options}
                                                             currSizePerPage={currSizePerPage}
                                                             onSizePerPageChange={onSizePerPageChange}/>,

            disablePageTitle: true,
        };
    }


    render() {
        const {data} = this.state;
        let columns = this.getDelegationNameServerTableColumns();
        const paginationOptions = this.paginationOptions();


        return <div>
            <Helmet><title>
                DNS Delegation NameServers List Page
            </title></Helmet>
            <Container maxWidth={false} className={"px-2"}>
                <Card>
                    <CardContent>
                        <div className="mt-2 ml-3 mr-3 mb-2  pb-5">
                            <h5 className={"font-weight-bold mt-4 mb-4"}>
                                DNS Delegation NameServers List Page
                            </h5>

                            <div>
                                {this.props.alert.message &&
                                    <Alert severity={this.props.alert.type}>{this.props.alert.message}</Alert>}
                                <div className="pl-2 pr-2">

                                    <div className={'col text-right pt-2 pb-2'}>
                                        <Link
                                            className={"d-inline-block btn btn-primary dns-blue-button mr-1"}
                                            to={"/dns/zones/details/" + this.props.match.params.zoneNum + "/zoneDelegation/" + this.props.match.params.id + "/delg/nameserver/create"}
                                        >Insert</Link>
                                    </div>

                                    <BootstrapTable bootstrap4
                                                    keyField={"recId"}
                                                    data={data}
                                                    columns={columns}
                                                    noDataIndication="No matching records found"
                                                    onTableChange={this.handleTableChange}
                                                    pagination={paginationFactory(paginationOptions)}
                                                    id={"zoneDelegation_table"}
                                                    remote={{
                                                        pagination: true,
                                                    }} condensed
                                                    striped
                                                    hover
                                                    loading={true}
                                                    condensed
                                    />

                                </div>
                            </div>
                        </div>
                    </CardContent>
                </Card>
            </Container>
        </div>
    }
}

Search.propTypes = {
    classes: PropTypes.object.isRequired
};

function mapState(state) {
    const {alert} = state
    return {alert}
}

const actionCreators = {
    alertClear: alertActions.clear,
};

const connectedDelegationNameserver = withRouter(connect(mapState, actionCreators)(Search));
export {connectedDelegationNameserver as Search};
