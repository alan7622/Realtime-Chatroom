import React, {Component} from "react";
import {alertActions, delegationActions} from "../../../_actions";
import {withRouter} from "react-router-dom";
import {connect} from "react-redux";
import Form from "react-bootstrap/Form";
import {Col, Row} from "react-bootstrap";
import {
    Backdrop,
    Button,
    Card,
    CardContent,
    CircularProgress,
    Dialog,
    DialogActions,
    DialogTitle
} from "@material-ui/core";
import {Helmet} from "react-helmet";
import Container from "@material-ui/core/Container";
import {Alert} from "@material-ui/lab";
import PropTypes from "prop-types";
import {delegationService, zoneService} from "../../../_services";
import _ from "lodash";
import {
    removeEmptyValues,
} from "../../../_helpers";


class Delegation extends Component {
    constructor(props) {
        super(props);
        this.state = {
            zoneData: {},
            account: {},
            loading: true,
            alert: '',
            showDeleteConfirm: false,
            delegation: {
                accountId: '',
                recId: this.props.match.params.recId,
                zoneNum: this.props.match.params.zoneNum,
                delegationName: '',
                ns1: '',
                ns2: '',
                // zoneName: '',
                ttl1: '',
                ttl2: '',
                DType: '',

            },
        }
        console.log(this.state, "delegation state")

        this.isComponentMounted = false
        this.saveZoneDelegation = this.saveZoneDelegation.bind(this);
        this.deleteDelegation = this.deleteDelegation.bind(this);
        this.updateDelegationObj = this.updateDelegationObj.bind(this);
        this.getDeleteConfirmDialog = this.getDeleteConfirmDialog.bind(this);

    }


    saveZoneDelegation(e) {
        e.preventDefault()
        console.log(this.state.delegation, "delegation");

        if (this.isComponentMounted) {
            this.setState({loading: !this.props.isEmptyForm})//changed it so that it supports loading on create page

        }

        if (this.props.isEmptyForm && this.props.isEditable) {
            const delegations = removeEmptyValues({
                zoneName: this.state.zoneData.zoneName,
                ...this.state.delegation
            })

            delegations.delegationName = _.trimEnd(delegations.delegationName, '.') + '.'

            this.props.create(delegations);


        } else {
            const updateDelegations = removeEmptyValues({
                delegationName: this.state.delegation.delegationName,
                status: this.state.delegation.status,
                checkNames: this.state.delegation.checkNames,
                comments: this.state.delegation.comments,
                //...this.state.delegation
            })

            //updateDelegations.delegationName = _.trimEnd(updateDelegations.delegationName, '.') + '.'


            this.props.update(this.props.match.params.id, updateDelegations);

            /*
                        this.props.update(this.props.match.params.id, {
                            //accountId: this.state.zoneData.accountId,
                            delegationName: this.state.delegation.delegationName,
                            status:this.state.delegation.status,
                            checkNames:this.state.delegation.checkNames,
                            comments:this.state.delegation.comments,
                            //...this.state.delegation
                        });
            */
        }
    }

    updateDelegationObj(e) {
        let {name, value} = e.target;
        const {delegation} = this.state;
        value = value.trim();
        this.setState({delegation: {...delegation, [name]: value}})
    }


    async componentDidMount() {
        this.isComponentMounted = true;
        const res = await zoneService.getZoneById(this.props.match.params.zoneNum)
        // const resp = await accountService.getAccountById(this.props.match.params.accountId)

        if (this.isComponentMounted) {
            this.setState({loading: !this.props.isEmptyForm, zoneData: res.zone});
        }
        if (!this.props.isEmptyForm && this.isComponentMounted) {
            const res2 = await delegationService.getByDelegationId(this.props.match.params.id);
            if (this.props.isEditable && res2.delegation.DType === 'S') {
                {/*using dtype is not equal to subzone display edit for zonedelegation and hide if it is subzone.*/
                }
                this.props.history.push({
                    pathname: `/dns/zones/details/${this.props.match.params.zoneNum}/zoneDelegation`,
                    state: {showAlerts: true}
                })
            } else {
                if (!_.isEmpty(res2) && res2.success && this.isComponentMounted) {
                    this.setState({loading: false, delegation: res2.delegation});
                } else {
                    this.props.history.push({
                        pathname: `/dns/zones/details/${this.props.match.params.zoneNum}/zoneDelegation`,
                        state: {showAlerts: true}
                    })
                }
            }

        }
    }


    deleteDelegation() {
        this.setState({showDeleteConfirm: false, loading: true})
        this.props.delete(this.props.match.params.id, this.props.match.params.zoneNum);

    }

    componentWillUnmount() {
        this.isComponentMounted = false;
    }


    getDelegationPageButtons() {
        let pageElements = {
            pageTitle: '',
            pageButtons: [],
        };
        if (this.props.isEditable && this.props.isEmptyForm) {
            pageElements.pageTitle = "Create New Delegation"
            pageElements.pageButtons.push(<Button className={"dns-blue-button text-white mr-2"}
                                                  type={"submit"}
                                                  key={"insert_Dlg"}>Insert</Button>)
            pageElements.pageButtons.push(<Button className={"dns-blue-button text-white mr-2 col-md-1"}
                                                  onClick={() => {
                                                      this.props.alertClear();
                                                      this.props.history.goBack()

                                                  }

                                                  }
                                                  key={"cancel_update"}>Cancel</Button>)


        } else if (this.props.isEditable) {

            pageElements.pageTitle = "DNS Delegation Update"
            pageElements.pageButtons.push(<Button className={"dns-blue-button text-white mr-2 col-md-1"}
                                                  type={"submit"}
                                                  key={"update_Dlg"}>Update</Button>)
            pageElements.pageButtons.push(<Button className={"dns-blue-button text-white mr-2 col-md-1"}
                //onClick={() => this.props.history.goBack()}
                                                  onClick={() => this.props.history.goBack()}

                                                  key={"cancel_update"}>Cancel</Button>)


        } else {
            console.log(this.props.isEditable, " Details-this.props.isEditable")
            console.log(this.props.isEmptyForm, "details-this.props.empty")
            pageElements.pageTitle = "DNS Delegation Details"
            if (this.state.delegation.DType !== 'S') {
                {/*using dtype is not equal to subzone display edit for zonedelegations and hide if it is subzone.*/
                }
                pageElements.pageButtons.push(<Button className={"dns-blue-button text-white mt-2 mr-4 mb-4"}
                                                      onClick={() => {
                                                          this.props.alertClear();
                                                          this.props.history.push(`/dns/zones/details/${this.props.match.params.zoneNum}/zoneDelegation/edit/${this.props.match.params.id}`)
                                                      }}
                                                      key={"edit_Dlg"}>Go To Update</Button>)
                pageElements.pageButtons.push(<Button className={"dns-blue-button text-white mt-2 mr-4 mb-4"}
                                                      onClick={() => {
                                                          this.setState({showDeleteConfirm: true})
                                                      }} key={"delete"}>Delete</Button>)


            }


            pageElements.pageButtons.push(<Button className={"dns-blue-button text-white mt-2 mb-4"}
                                                  onClick={() => {
                                                      this.props.alertClear();

                                                      this.props.history.push(`/dns/zones/details/${this.props.match.params.zoneNum}/zoneDelegation`)
                                                  }}
                                                  key={"delegate_list"}>List Delegations</Button>)
            pageElements.pageButtons.push(<Button className={"dns-blue-button text-white ml-2 mt-2 mb-4"}
                                                  onClick={() => {
                                                      {
                                                          this.props.alertClear();

                                                          this.props.history.push(`/dns/zones/details/${this.props.match.params.zoneNum}/zoneDelegation/${this.props.match.params.id}/delg/nameserver`)
                                                      }
                                                  }}
                                                  key={"delegateNS_list"}>List Delegation NameServers</Button>)


        }

        return pageElements;
    }

    getDeleteConfirmDialog() {
        return !this.props.isEditable && <Dialog
            onClose={(event, reason) => {
                if (reason === 'backdropClick' || reason === 'escapeKeyDown') {
                    return false;
                }
            }}
            maxWidth="xs"
            aria-labelledby="confirmation-dialog-title"
            open={this.state.showDeleteConfirm}
        >
            <DialogTitle id="confirmation_dialog_title">Are you sure you want to delete this
                delegation?</DialogTitle>
            <DialogActions>
                <Button autoFocus onClick={this.deleteDelegation} className={"dns-blue-button text-white"}>
                    Delete
                </Button>
                <Button onClick={() => this.setState({showDeleteConfirm: false})}
                        className={"dns-blue-button text-white"}>
                    Cancel
                </Button>
            </DialogActions>
        </Dialog>
    }

    getZoneDelegationForm() {
        let {zoneData, delegation} = this.state;
        let {pageButtons} = this.getDelegationPageButtons();
        return <form onSubmit={this.saveZoneDelegation}>
            {this.props.alert.message &&
                <Alert severity={this.props.alert.type} className={"mb-3"}>{this.props.alert.message}</Alert>}
            <Form.Group as={Row} className={"align-items-center"}>
                <Form.Label column sm="2"
                            className={"font-weight-bold"}>
                    Zone ID
                </Form.Label>
                <Col sm={2}>
                    {zoneData.zoneNum}

                </Col>

                {(!this.props.isEditable) && <><Form.Label column sm="2"
                                                           className={"font-weight-bold"}>
                    Zone Name
                </Form.Label>
                    <Col sm="2">
                        {zoneData.zoneName}

                    </Col></>}
            </Form.Group>
            <Form.Group as={Row} className={"align-items-center"}>
                {(this.props.isEditable || !this.props.isEmptyForm) && <><Form.Label column sm="2"
                                                                                     className={"font-weight-bold"}>
                    Delegation RecId
                </Form.Label>
                    <Col sm={2}>
                        {delegation.recId}
                    </Col></>}

                <Form.Label column sm="2"
                            className={"font-weight-bold"}>
                    Account Id

                </Form.Label>
                <Col sm={2}>
                    {this.props.isEditable ?
                        <Form.Control name={"accountId"}
                                      onChange={this.updateDelegationObj}
                                      defaultValue={delegation.accountId ? delegation.accountId : ''}/> : delegation.accountId}


                </Col>


            </Form.Group>
            <Form.Group as={Row} className={"align-items-center"}>

                <Form.Label column sm="2"
                            className={"font-weight-bold"}>
                    *Delegation Name
                </Form.Label>
                <Col sm={4}>

                    {this.props.isEditable ?
                        <Form.Control name={"delegationName"}
                                      onChange={this.updateDelegationObj}
                                      className={"w-50 d-inline"}

                                      defaultValue={delegation.cutDnameHpart ? delegation.cutDnameHpart : ''}/> : delegation.cutDnameHpart}

                    <span className={"d-inline"}>{`${zoneData.zoneName}`}</span>

                </Col>
            </Form.Group>
            <Form.Group as={Row} className={"align-items-center"}>

                <Form.Label column sm="2"
                            className={"font-weight-bold"}>
                    Comment
                </Form.Label>
                <Col sm="2">
                    {this.props.isEditable ?

                        <Form.Control name={"comments"}
                                      onChange={this.updateDelegationObj}
                                      defaultValue={delegation.comments ? delegation.comments : ''}/> : delegation.comments}
                </Col>
                {!this.props.isEditable && <>    <Form.Label column sm="2"
                                                             className={"font-weight-bold"}>
                    Option
                </Form.Label>
                    <Col sm="4">
                        {delegation.option}
                    </Col></>}

            </Form.Group>
            <Form.Group as={Row} className={"align-items-center"}>


                {!this.props.isEditable && <><Form.Label column sm="2"
                                                         className={"font-weight-bold"}>
                    Delegation Type
                </Form.Label>
                    <Col sm={2}>
                        {delegation.DType}

                    </Col></>}
            </Form.Group>
            <Form.Group as={Row} className={"align-items-center"}>


                {(!this.props.isEmptyForm && this.props.isEditable) && <><Form.Label column sm="2"
                                                                                     className={"font-weight-bold"}>
                    Status </Form.Label>
                    <Col sm="4">
                        {this.props.isEditable ?
                            <Form.Control name={"status"}
                                          className={"w-25 d-inline"}
                                          onChange={this.updateDelegationObj}
                                          defaultValue={delegation.status ? delegation.status : ''}/> : delegation.status}

                        {this.props.isEditable && <> <p className={"d-inline"}>Either A for active or S for
                            suspended</p></>}
                    </Col></>}

            </Form.Group>
            <Form.Group as={Row} className={"align-items-center"}>

                {!this.props.isEditable && <> <Form.Label column sm="2"
                                                          className={"font-weight-bold"}>
                    First Name
                </Form.Label>
                    <Col sm="2">
                        {delegation.FName}

                    </Col></>}


                {!this.props.isEditable && <> <Form.Label column sm="2"
                                                          className={"font-weight-bold"}>
                    Middle Name
                </Form.Label>
                    <Col sm="2">

                        {delegation.MName}

                    </Col></>}


                {!this.props.isEditable && <>
                    <Form.Label column sm="2" className={"font-weight-bold"}>
                        Last Name
                    </Form.Label>
                    <Col sm="2">
                        {delegation.LName}
                    </Col></>}
            </Form.Group>
            <Form.Group as={Row} className={"align-items-center"}>
                {(this.props.isEditable && !this.props.isEmptyForm) && <> <Form.Label column sm="2"
                                                                                      className={"font-weight-bold"}>
                    Organization
                </Form.Label>

                    <Col sm="4">
                        {delegation.company}

                    </Col></>}
            </Form.Group>
            {(this.props.isEmptyForm) && <>  <p>You must provide at least one name server
                below to complete the creation of a Delegation. If you need
                to
                provide more than two servers , you can add them via the Delegations Detail Display Page after you
                finish the creation.
            </p></>}
            {(this.props.isEmptyForm) && <> <Form.Group as={Row}
                                                        className={"align-items-center"}>
                <Form.Label column sm="6"
                            className={"font-weight-bold"}>
                    Domains Name Servers:
                </Form.Label>
                <Col>
                    {}
                </Col>
            </Form.Group></>}
            {this.props.isEmptyForm && <>  <Form.Group as={Row}
                                                       className={"align-items-center"}>
                <Form.Label column sm="2"
                            className={"font-weight-bold"}>
                    1. *Server's Full Name:
                </Form.Label>
                <Col sm={2}>
                    {this.props.isEmptyForm ?

                        <Form.Control name={"ns1"}
                                      onChange={this.updateDelegationObj}
                                      defaultValue={delegation.ns1 ? delegation.ns1 : ''}/> : delegation.ns1}
                </Col>
                <Form.Label column sm="2"
                            className={"font-weight-bold"}>
                    Time To Live
                </Form.Label>
                <Col sm={2}>
                    {this.props.isEmptyForm ?

                        <Form.Control name={"ttl1"}
                                      onChange={this.updateDelegationObj}
                                      defaultValue={delegation.ttl1 ? delegation.ttl1 : ''}/> : delegation.ttl1}
                </Col>
            </Form.Group></>}
            {this.props.isEmptyForm && <>   <Form.Group as={Row}
                                                        className={"align-items-center"}>
                <Form.Label column sm="2"
                            className={"font-weight-bold"}>
                    2. Server's Full Name:
                </Form.Label>
                <Col sm={2}>
                    {this.props.isEmptyForm ?

                        <Form.Control name={"ns2"}
                                      onChange={this.updateDelegationObj}
                                      defaultValue={delegation.ns2 ? delegation.ns2 : ''}/> : delegation.ns2}
                </Col>
                <Form.Label column sm="2"
                            className={"font-weight-bold"}>
                    Time To Live
                </Form.Label>
                <Col sm={2}>
                    {this.props.isEmptyForm ?

                        <Form.Control name={"ttl2"}
                                      onChange={this.updateDelegationObj}
                                      defaultValue={delegation.ttl2 ? delegation.ttl2 : ''}/> : delegation.ttl2}

                </Col>

            </Form.Group></>}
            {this.props.isEmptyForm && <>
                <p>Those entries marked with * must be provided
                </p></>}
            <Form.Group as={Row} className={"align-items-center"}>
                {!this.props.isEditable && <> <Form.Label column sm="2" className={"font-weight-bold"}>
                    Address </Form.Label>
                    <Col sm="4">
                        {delegation.stAddr}

                    </Col></>}

                {!this.props.isEditable && <> <Form.Label column sm="2"
                                                          className={"font-weight-bold"}>
                    City </Form.Label>
                    <Col sm="4">
                        {delegation.city}

                    </Col></>}
            </Form.Group>
            <Form.Group as={Row} className={"align-items-center"}>


                {!this.props.isEditable && <> <Form.Label column sm="2"
                                                          className={"font-weight-bold"}>
                    State </Form.Label>
                    <Col sm="4">
                        {delegation.stateCode}

                    </Col></>}

                {!this.props.isEditable && <> <Form.Label column sm="2"
                                                          className={"font-weight-bold"}>
                    Country Code </Form.Label>
                    <Col sm="4">
                        {delegation.countryCode}

                    </Col></>}

            </Form.Group>
            <Form.Group as={Row} className={"align-items-center"}>
                {!this.props.isEditable && <> <Form.Label column sm="2"
                                                          className={"font-weight-bold"}>
                    Zip Code </Form.Label>
                    <Col sm="4">
                        {delegation.zip}

                    </Col></>}
                {!this.props.isEditable && <> <Form.Label column sm="2"
                                                          className={"font-weight-bold"}>
                    Phone Country Code </Form.Label>
                    <Col sm="4">
                        {delegation.phoneCountryCode}

                    </Col></>}

            </Form.Group>
            <Form.Group as={Row} className={"align-items-center"}>


                {!this.props.isEditable && <> <Form.Label column sm="2"
                                                          className={"font-weight-bold"}>
                    Phone Number </Form.Label>
                    <Col sm="4">
                        {this.state.account.phoneNum}

                    </Col></>}


                {!this.props.isEditable && <> <Form.Label column sm="2"
                                                          className={"font-weight-bold"}>
                    Extension </Form.Label>
                    <Col sm="4">
                        {this.state.account.ext}

                    </Col></>}

            </Form.Group>

            <Form.Group as={Row} className={"align-items-center"}>


                {!this.props.isEditable && <> <Form.Label column sm="2"
                                                          className={"font-weight-bold"}>
                    Fax Country Code </Form.Label>
                    <Col sm="4">
                        {this.state.account.faxCountryCode}

                    </Col></>}


                {!this.props.isEditable && <> <Form.Label column sm="2"
                                                          className={"font-weight-bold"}>
                    Fax Number </Form.Label>
                    <Col sm={4}>
                        {this.state.account.faxNum}

                    </Col></>}
            </Form.Group>
            <Form.Group as={Row} className={"align-items-center"}>


                {!this.props.isEditable && <> <Form.Label column sm="2"
                                                          className={"font-weight-bold"}>
                    Email </Form.Label>
                    <Col sm={4}>
                        {this.state.account.addrEmail}

                    </Col></>}


                {!this.props.isEditable && <> <Form.Label column sm="2"
                                                          className={"font-weight-bold"}>
                    Order Id </Form.Label>
                    <Col sm={4}>
                        {delegation.orderId}

                    </Col></>}
            </Form.Group>


            {
                !this.props.isEditable && <Form.Group as={Row} className={"align-items-center mb-2"}>
                    <Form.Label column sm="2" className={"font-weight-bold"}>
                        Created
                    </Form.Label>
                    <Col sm="2">
                        {delegation.createTime}
                    </Col>
                    <Form.Label column sm="2" className={"font-weight-bold"}>
                        Last Modified
                    </Form.Label>
                    <Col sm="2">
                        {delegation.updateTime}
                    </Col>

                    {!this.props.isEditable && <>  <Form.Label column sm="2" className={"font-weight-bold"}>
                        Modified By
                    </Form.Label>
                        <Col sm="2">
                            {this.props.isEditable ?
                                <Form.Control name={"modBy"} onChange={this.updateDelegationObj}
                                              defaultValue={delegation.modBy ? delegation.modBy : ''}/> : delegation.modBy}
                        </Col></>}
                </Form.Group>
            }


            <div className={"text-center"}>
                {pageButtons.map(buttonComp => buttonComp)}
            </div>
        </form>
    }

    render() {
        let {pageTitle} = this.getDelegationPageButtons();
        return (
            <>
                {this.getDeleteConfirmDialog()}
                {/*<Backdrop className={"page-loading"} style={{'zIndex': '10000', 'color': '#fff'}}
                          open={this.state.loading && this.props.loading}>
                    <CircularProgress color="inherit"/>
                </Backdrop>*/}
                <div>
                    <Helmet>
                        <title>DNS Admin | DNS Delegation Details Page</title>
                    </Helmet>
                    <Container maxWidth={false} className={"px-2"}>
                        <Card>
                            <CardContent>
                                <h5 className="font-weight-bold  text-capitalize text-left pt-3 pb-1 pl-4">{pageTitle}</h5>
                                <div className={"pb-2 pl-4"}>


                                    {this.getZoneDelegationForm()}
                                </div>
                            </CardContent>
                        </Card>
                    </Container>
                </div>
            </>)
    }

}

Delegation.defaultProps =
    {
        isEditable: false,
    };

Delegation.propTypes =
    {
        isEditable: PropTypes.bool.isRequired,
        isEmptyForm: PropTypes.bool

    }
;

function mapState(state) {
    const {saving, loading, saved, deleted} = state.delegations

    const {alert} = state
    return {saving, loading, saved, deleted, alert}

}

const actionCreators =
    {
        alertClear: alertActions.clear,
        create: delegationActions.create,
        update: delegationActions.update,
        delete: delegationActions.delete,


    };
const connectedDelegation = withRouter(connect(mapState, actionCreators)(Delegation));
export {connectedDelegation as Delegation}