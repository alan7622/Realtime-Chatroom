import {alertActions} from "../../../_actions";
import {Link, withRouter} from "react-router-dom";
import {connect} from "react-redux";
import {Helmet} from "react-helmet";
import Container from "@material-ui/core/Container";
import {
    Button,
    Card,
    CardContent,
    Dialog, DialogActions,
    DialogContent,
    DialogTitle,
    FormControl, FormControlLabel, InputLabel,
    MenuItem, Radio, RadioGroup,
    Select,
} from "@material-ui/core";
import {Alert} from "@material-ui/lab";
import BootstrapTable from "react-bootstrap-table-next";
import React, {Component} from "react";
import Form from "react-bootstrap/Form";
import {Col, Row} from "react-bootstrap";
import {ComparatorHelper} from "../../../_helpers";
import {delegationService, zoneService} from "../../../_services";
import {isAuthorized, pageRenderer, SizePerPageRenderer} from "../../../_components";
import paginationFactory from "react-bootstrap-table2-paginator";
import PropTypes from "prop-types";
import _ from "lodash";
import {Comparator} from "react-bootstrap-table2-filter";


const defaultFilters = {
    delegationName: {comparator: 'Eq', value: ''},
    companyName: {comparator: 'Eq', value: ''},
    zoneSubType: {comparator: '', value: 'IP4'},
    orderBy: {comparator: '', value: 'delegationNum'},
    orderDir: {comparator: '', value: 'asc'},
}

class Search extends Component {
    constructor(props) {
        super(props);
        this.state = {
            data: [],
            zoneData: {},
            advanceSearchApplied: false,
            filters: _.cloneDeep(defaultFilters),
            comparator: Comparator.EQ,
            error: '',
            delegationSearchParams: {},

            /*
                        filters: {
                            companyName: {comparator: 'Eq', value: ''},
                            delegationName: {comparator: 'Eq', value: ''},

                        },
            */
            showDeleteConfirm: false,
            showAdvanceSearch: false,
            page: 1,
            sizePerPage: 10,
            totalSize: 0,


        }
        this.isComponentMounted = false;
        this.getAdvanceSearchDialog = this.getAdvanceSearchDialog.bind(this)
        this.handleFilterChange = this.handleFilterChange.bind(this)
        this.handleTableChange = this.handleTableChange.bind(this);


    }

    async componentDidMount() {
        this.isComponentMounted = true;
      /*  setTimeout(() => {
            this.props.alertClear()
        }, 10000)*/
        await this.loadTableData({numberOfRows: this.state.sizePerPage, pageNumber: this.state.page});
        const res = await zoneService.getZoneById(this.props.match.params.zoneNum)
        if (this.isComponentMounted) {
            this.setState({zoneData: res.zone});
        }
    }

    async loadTableData(data) {
        if (this.isComponentMounted) {
            this.setState({loading: true})
        }
        for (var key in this.state.filters) {
            if (this.state.filters.hasOwnProperty(key) &&
                this.state.filters[key].value && this.state.filters[key].value != "...") {
                data[key +
                this.state.filters[key].comparator] = this.state.filters[key].value;
            }
        }


        data = {
            ...data,
            zoneNum: this.props.match.params.zoneNum,
        }
        const res = await delegationService.getAllDelegations(data);
        if (this.isComponentMounted) {
            this.setState({
                loading: false, data: res.delegation, error: res.error, totalSize: res.totalRecords,
                page: data.pageNumber ? data.pageNumber : this.state.page,
                sizePerPage: data.numberOfRows ?
                    data.numberOfRows :
                    this.state.sizePerPage,
            });//will uncomment once I chnage in all RR's the same format and this ternary condition is for sizeperpage change in pagination
        }
    }

    componentWillUnmount() {
        this.isComponentMounted = false;
    }

    handleFilterChange(e) {
        const {name, value} = e.target;
        const {filters} = this.state;
        const filterInfo = name.split('.');
        filters[filterInfo[0]][filterInfo[1]] = value;
        this.setState({filters: filters});
    }

    getZoneDelegationTableColumns() {
        return [
            {
                dataField: 'cutDnameHpart',
                text: 'Delegation Name',
                headerAlign: 'center',
                classes: 'text-left p-0',
                headerStyle: {
                    width: '25%'
                },
                style: {
                    wordWrap: 'break-word'
                },


            },
            {
                dataField: 'company',
                text: 'Company',
                headerAlign: 'center',
                classes: 'text-left p-0',
                headerStyle: {
                    width: '25%'
                },
                style: {
                    wordWrap: 'break-word'
                },

            },
            {
                dataField: 'accountId',
                text: 'Account ID',
                headerAlign: 'center',
                classes: 'text-left p-0',
                headerStyle: {
                    width: '20%'
                },
                style: {
                    wordWrap: 'break-word'
                },
            },
            {
                dataField: 'DType',
                text: 'D Type',
                headerAlign: 'center',
                classes: 'text-left p-0',
                headerStyle: {
                    width: '15%'
                },
                style: {
                    wordWrap: 'break-word'
                },
            },
            {
                text: "Action",
                dataField: "",
                headerAlign: 'center',
                headerStyle: {
                    width: "15%"
                },

                formatter: (cell, row, rowIndex) => <>
                    <Link
                        to={`/dns/zones/details/${this.props.match.params.zoneNum}/zoneDelegation/${row.recId}`}
                        //  to={`/dns/zones/details/${this.props.match.params.zoneNum}/rr/${this.props.match.params.type}/details/${row.recId}`}

                        key={"details_zone_delgationlist"}
                        className={"color-dragon-blue mr-2"}
                    >Details</Link>
                    {row.DType !== 'S' && isAuthorized('zu') && <Link
                        to={`/dns/zones/details/${this.props.match.params.zoneNum}/zoneDelegation/edit/${row.recId}`}
                        key={"edit_zone_delgationlist"}
                        className={"color-dragon-blue mr-2"}
                    >Edit</Link>}  {/*using dtype is not equal to subzone display edit for zonedelegation and hide if it is subzone.*/}
                </>
            },


        ];

    }

    async handleTableChange(type, {filters, page, sortOrder, sortField, sizePerPage, totalSize}) {
        const currentIndex = (page - 1) * sizePerPage;
        let delegationSearchParams = {};
        if (sortField && sortOrder) {
            delegationSearchParams.orderDir = sortOrder;
            delegationSearchParams.orderBy = sortField;
        }

        delegationSearchParams.numberOfRows = sizePerPage;
        delegationSearchParams.pageNumber = page;
        await this.loadTableData(delegationSearchParams);

    }

    getAdvanceSearchDialog() {
        return <Dialog
            fullWidth={true}
            onClose={(event, reason) => {
                if (reason === 'backdropClick' || reason === 'escapeKeyDown') {
                    return false;
                }
            }}
            maxWidth="md"
            open={this.state.showAdvanceSearch}
        >
            <DialogTitle id="form-dialog-title"><b>DNS
                Search Delegations</b></DialogTitle>

            <DialogContent>
                <Form>
                    <Form.Group as={Row} className={'align-items-center'}>
                        <Form.Label column sm="2" className={'font-weight-bold'}>
                            Delegation Name
                        </Form.Label>
                        <Col sm={2}>
                            <FormControl variant="outlined">
                                <InputLabel htmlFor="wildcard-company-search"> Delegation Name</InputLabel>
                                <Select
                                    autoWidth={true}
                                    className={'w-100'}
                                    name={'delegationName.comparator'}
                                    value={this.state.filters.delegationName.comparator}
                                    onChange={this.handleFilterChange}
                                    label="Delegation Name"
                                >
                                    {ComparatorHelper.getComparators.map(obj => (
                                        <MenuItem value={obj.value}
                                                  key={obj.value}>{obj.label}</MenuItem>
                                    ))}

                                </Select>
                            </FormControl>
                        </Col>
                        <Col sm={4}>
                            <Form.Control name={'delegationName.value'}
                                          defaultValue={this.state.filters.delegationName.value}
                                          onChange={this.handleFilterChange}
                            />
                        </Col>

                    </Form.Group>

                    <Form.Group as={Row} className={"align-items-center"}>

                        <Form.Label column sm="2" className={"font-weight-bold"}>
                            Company
                        </Form.Label>
                        <Col sm={2}>
                            <FormControl variant="outlined">
                                <InputLabel htmlFor="wildcard-companyName-search">
                                    Company</InputLabel>
                                <Select
                                    autoWidth={true}
                                    className={'w-100'}
                                    name={'companyName.comparator'}
                                    value={this.state.filters.companyName.comparator}
                                    onChange={this.handleFilterChange}
                                    label="Company"
                                >
                                    {ComparatorHelper.getComparators.map(obj => (
                                        <MenuItem value={obj.value}
                                                  key={obj.value}>{obj.label}</MenuItem>
                                    ))}

                                </Select>
                            </FormControl>
                        </Col>
                        <Col sm={4}>
                            <Form.Control name={'companyName.value'}
                                          defaultValue={this.state.filters.companyName.value}
                                          onChange={this.handleFilterChange}
                            />
                        </Col>

                    </Form.Group>
                </Form>

            </DialogContent>

            <DialogActions>
                <Button onClick={async (e) => {
                    await this.loadTableData({numberOfRows: this.state.sizePerPage, pageNumber: this.state.page});
                    this.setState(
                        {showAdvanceSearch: false});
                }
                } color="primary" className={'dns-blue-button text-white'}
                >
                    Search
                </Button>
                <Button onClick={() => this.setState(
                    {showAdvanceSearch: false})}
                        color="primary" className={'dns-blue-button text-white'}>
                    Cancel
                </Button>
            </DialogActions>

        </Dialog>
    }

    paginationOptions() {
        return {
            sizePerPage: this.state.sizePerPage,
            page: this.state.page,
            totalSize: this.state.totalSize,
            alwaysShowAllBtns: true,
            withFirstAndLast: true,
            firstPageText: 'First',
            prePageText: 'Back',
            nextPageText: 'Next',
            lastPageText: 'Last',
            nextPageTitle: 'First page',
            prePageTitle: 'Pre page',
            firstPageTitle: 'Next page',
            lastPageTitle: 'Last page',
            showTotal: false,
            sizePerPageList: [
                {
                    text: '10', value: 10
                }, {
                    text: '20', value: 20
                },
                {
                    text: '50', value: 50
                },],
            pageButtonRenderer: pageRenderer,
            sizePerPageRenderer: ({
                                      options,
                                      currSizePerPage,
                                      onSizePerPageChange
                                  }) => <SizePerPageRenderer options={options}
                                                             currSizePerPage={currSizePerPage}
                                                             onSizePerPageChange={onSizePerPageChange}/>,

            disablePageTitle: true,
        };
    }


    render() {
        const {data} = this.state;
        let columns = this.getZoneDelegationTableColumns();
        const paginationOptions = this.paginationOptions();


        return <div>
            <Helmet><title>
                DNS Zone Transfers ACLs
            </title></Helmet>

            <Container maxWidth={false} className={"px-2"}>
                <Card>
                    <CardContent>
                        <div className="mt-2 ml-3 mr-3 mb-2  pb-5">
                            <h5 className={"font-weight-bold mt-4 mb-4"}>
                                DNS Delegations
                            </h5>

                            <div>
                                {this.props.alert.message &&
                                    <Alert severity={this.props.alert.type}>{this.props.alert.message}</Alert>}
                                <div className="pl-2 pr-2">
                                    {this.getAdvanceSearchDialog()}

                                    <div className={'col text-right'}>
                                        <Link

                                            className={"d-inline-block btn btn-primary dns-blue-button mr-1"}
                                            to={"/dns/zones/details/" + this.props.match.params.zoneNum + "/zoneDelegation/create"}
                                        >Insert</Link>


                                        <Button aria-controls="simple-menu"
                                                aria-haspopup="true"
                                                color="primary"
                                                className={'dns-blue-button'}
                                                variant={'contained'}
                                                onClick={() => {
                                                    this.props.alertClear();
                                                    this.setState(
                                                        {showAdvanceSearch: true});
                                                }} key={'advance_search'}>Search</Button>
                                        {(JSON.stringify(this.state.filters) !== JSON.stringify(defaultFilters)) &&
                                            <Button type={"reset"} onClick={() => {
                                                this.props.alertClear();
                                                this.setState({filters: _.cloneDeep(defaultFilters), error: ''}, () => {
                                                    this.loadTableData({numberOfRows: 10, pageNumber: 1})
                                                });
                                            }} variant="contained"
                                                    className={"dns-blue-button text-white ml-2"}


                                            >clear</Button>}


                                    </div>
                                    <div className={"pt-4 pb-4"}>
                                            <span
                                                className={'font-weight-bold'}>Zone Name</span>: {this.state.zoneData.zoneName}

                                        <span
                                            className={'font-weight-bold  pl-5'}>Zone ID</span> : {this.state.zoneData.zoneNum}<br/>

                                    </div>
                                    <BootstrapTable bootstrap4
                                                    keyField={"recId"}
                                                    data={data}
                                                    columns={columns}
                                                    noDataIndication="No matching records found"
                                                    onTableChange={this.handleTableChange}
                                                    pagination={paginationFactory(paginationOptions)}
                                                    id={"zoneDelegation_table"}
                                                    remote={{
                                                        pagination: true,
                                                    }} condensed
                                                    striped
                                                    hover
                                                    loading={true}
                                                    condensed
                                    />

                                </div>
                            </div>
                        </div>
                    </CardContent>
                </Card>
            </Container>
        </div>
    }
}

function mapState(state) {
    const {alert} = state
    return {alert}
}

const actionCreators = {
    alertClear: alertActions.clear,
};

const connectedDelegation = withRouter(connect(mapState, actionCreators)(Search));
export {connectedDelegation as Search};
