export function authHeader() {
    // return authorization header with jwt token
    let user = JSON.parse(localStorage.getItem('user'));

   /* if (user && user.token) {
        return {'Authorization': 'Bearer ' + user.token};
    } else {
        /!* return {'content-type': 'application/x-www-form-urlencoded','csp-attuid':'attsuper'};*!/
        return {'csp-attuid': user.attuid};
    }*/

    if(user && user.attUid){
        return {'csp-attuid':user.attUid};
    }else{
        const attUID = getAttUIDFromCookie();
        return {'csp-attuid':attUID};
    }
}


export function getAttUIDFromCookie(){
    const attCookie = document.cookie.split(';').find(cookie => cookie && cookie.split("=")[0].trim()
        ==='AMWEBJCT!%2Fdragondev2!csp-attuid');
    console.log(attCookie,"attCookie")
    return attCookie ? attCookie.split("=")[1]: ''
}
