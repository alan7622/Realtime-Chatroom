import {getAttUIDFromCookie} from "./auth-header";

export const USER_RESPONSE_TO_REQUEST_MAP = {
    comment: "comments",
    privileges: "privs",
    serviceId: "serviceName",
    username: "userName"
}

export const FORM_ELEMENT_TYPES = {
    Text: 'text',
    Email: 'email',
    Password: 'password',
    Select: 'select',
    Number: 'number',
};

export  function updateObjectValue(obj, keys, value) {
    let currentObj = obj;

    for (let i = 0; i < keys.length - 1; i++) {
        const key = keys[i];
        if (!currentObj.hasOwnProperty(key) || typeof currentObj[key] !== "object") {
            currentObj[key] = {};
        }
        currentObj = currentObj[key];
    }

    const lastKey = keys[keys.length - 1];
    currentObj[lastKey] = value;

    return obj;
}

export const ACCOUNT_RESPONSE_TO_REQUEST_MAP = {
    FName: "fName",
    LName: "lName",
    MName: "mName",
    GQual: "gqual",
    XTel: "xTel",
}

export const DELEGATIONNS_RESPONSE_TO_REQUEST_MAP = {
    cut_ns_fqdn: "ns1",  //responsedata:requestdata (in api)
    comment: "comments",

}
export const DELEGATION_RESPONSE_TO_REQUEST_MAP = {
    cutDnameHpart: "delegationName",  //responsedata:requestdata (in api)


}

/*
export const HistoryLogHelper = {

    getDataFieldToFilterMap: (dataField,comparator='') => {
        const dataToFilterFields = {
            actionCode: 'action',
            zoneName:'zoneName'+comparator,
            domainName:'domainName'+comparator
        }
        return dataToFilterFields[dataField] != undefined ? dataToFilterFields[dataField] : dataField
    },
}
*/

export const HistoryLogHelper = {
    getZoneNameComparators: [
        {value: 'Eq', label: 'Equals to'},
        {value: 'Contains', label: 'Contains'},
        {value: 'Beg', label: 'Begins With'}]
    ,
    /*
        getFilterNameToApiFilter: (dataField, comparator = '') => {
            console.log(comparator);
            const dataToFilterFields = {
                zif: 'zoneNum',
                znf: 'zoneName',
                rif:'recId',
                rnf:'domainName',
                rtf:'typeCode',
                acf:'action',
                mbf:'modBy'

            };
            return (dataToFilterFields[dataField] != undefined ?
                dataToFilterFields[dataField] :
                dataField) + comparator;
        }
    */
}


export const TldHelper = {
    getTldComparators: [
        {value: 'Eq', label: 'Equals to'},
        {value: 'Contains', label: 'Contains'},
        {value: 'Beg', label: 'Begins With'}]
    ,

    getDataFieldToFilterMap: (dataField) => {
        const dataToFilterFields = {
            tlDomain: 'tld'
        }
        return dataToFilterFields[dataField] != undefined ? dataToFilterFields[dataField] : dataField
    }
}

export const UserHelper = {
    getEmailComparators: [
        {value: 'Eq', label: 'Equals to'},
        {value: 'Contains', label: 'Contains'},
        {value: 'Beg', label: 'Begins With'}],

    getDataFieldToFilterMap: (dataField) => {
        const dataToFilterFields = {
            addrEmail: 'emailAddr1',
        }
        return dataToFilterFields[dataField] != undefined ? dataToFilterFields[dataField] : dataField
    },
    getDataFieldToSortMap: (dataField) => {
        const dataToFilterFields = {
            userName: 'username',
            lName: 'lname',
            addrEmail: 'emailAddr1'
        }
        return dataToFilterFields[dataField] != undefined ? dataToFilterFields[dataField] : dataField
    }
}


export const AccountLogHelper = {
    getModifiedByComparators: [
        {value: 'Beg', label: 'Equals to'},
        {value: 'Contains', label: 'Contains'},
    ]
    ,
}

export const AddDomainHelper = {
    getZoneNameComparators: [
        {value: 'Eq', label: 'Equals to'},
        {value: 'Contains', label: 'Contains'},
        {value: 'Beg', label: 'Begins With'}],

    getUserIdComparators: [
        {value: 'Eq', label: 'Equals to'},
        {value: 'Contains', label: 'Contains'},
        {value: 'Beg', label: 'Begins With'}]


}

export const ComparatorHelper = {
    getComparators: [
        {value: 'Eq', label: 'Equals to'},
        {value: 'Contains', label: 'Contains'},
        {value: 'Beg', label: 'Begins With'}]
}


//capitalize only the first letter of the string.
export class Utility {
    static ucFirst(string) {
        return string.charAt(0).toUpperCase() + string.slice(1).toLowerCase();
    }
}


export const removeEmptyValues = (object) => {
    const keys = Object.keys(object);
    for (var i = 0; i < keys.length; ++i) {
        const key = keys[i];
        const value = object[key];
        if (value === null || value === undefined || value === '') {
            delete object[key];
        }
    }
    return object;
};


export const templatizedZoneStringParser = function (myTemplate, myString) {
    let remainder = '';
    var names = [];
    var parts = myTemplate.replace(/\[([^\]]+)]/g, function (str, name) {
        names.push(name);
        return "~";
    }).split("~");
    parts.push("~");


    var parser = function (myString) {
        var result = {};
        remainder = myString;
        var i, len, index;
        for (i = 0, len = names.length; i < len; i++) {
            remainder = remainder.substring(parts[i].length);
            index = remainder.indexOf(parts[i + 1]);
            result[names[i]] = remainder.substring(0, index);
            remainder = remainder.substring(index);
        }
        result[names[names.length - 1]] = remainder;
        return result;
    };

    return myString ? parser(myString) : parser;
};


export const templatizedStringParser = function (_template, _inputStr) {
    var startStr = "";
    var inputStr = _inputStr.replace(startStr, "");
    var template = "";
    //add c control on the correctness of template
    if (_template.indexOf(startStr) != 0) {
        return false;
    } else {
        template = _template.replace(startStr, "");
    }

    var getLables = function (patt, templateStr) {
        var i = 0;
        var tmp = patt.exec(templateStr);
        var lables = new Array();
        while (tmp) {
            lables[i] = new String(tmp).replace("[", "").replace("]", "");
            tmp = patt.exec(templateStr);
            ++i;
        }
        return lables;
    }
    var patt = /\[[a-z|_]+\]/ig; //pattern to recognize each label
    var delim = template.replace(patt, "[]").split("[]");
    //delimiter list
    var lable = getLables(patt, template)
    //Labels list
    var result = new Object();
    var endIndex;
    for (var i = 0; i < lable.length; i++) {
        inputStr = inputStr.replace(delim[i], "");
        endIndex = inputStr.indexOf(delim[i + 1]);
        if ((i + 1) == lable.length) {
            result[lable[i]] = inputStr.substring(0, endIndex ? endIndex : inputStr.length);
        } else {
            result[lable[i]] = inputStr.substring(0, endIndex)
            inputStr = inputStr.replace(result[lable[i]], "");
        }

    }
    return result;


}


/*const templ = "[order] [flags] [test]";

const rrData = {
    order: '100',
    flags: '10',
    test: 'test'
}
console.log(replaceTemplateWithData(templ, rrData));*/
export const replaceTemplateWithData = function (template, data) {
    for (const key in data) {
        template = template.replace(`[${key}]`, data[key])
    }
    console.log(template, "TEMPLATE")
    return template/*.replaceAll('""', ' ')*/;
}


export function getLoginId() {
    // return authorization header with jwt token
    let user = JSON.parse(localStorage.getItem('user'));

    if (user && user.userName) {
        return user.userName;
    }
}

export function deleteAllCookies() {
    var cookies = document.cookie.split(";");
    console.log(cookies, "cookies")
    for (var i = 0; i < cookies.length; i++) {
        var cookie = cookies[i];
        var eqPos = cookie.indexOf("=");
        var name = eqPos > -1 ? cookie.substr(0, eqPos) : cookie;
        document.cookie = name + "=;expires=Thu, 01 Jan 1970 00:00:00 GMT; path=/;";
        console.log(name + "=;expires=Thu, 01 Jan 1970 00:00:00 GMT")
    }
}



