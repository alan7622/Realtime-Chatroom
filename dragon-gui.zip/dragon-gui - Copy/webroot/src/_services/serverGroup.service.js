import config from 'config';
import {authHeader} from '../_helpers';
import axios from 'axios'
import querystring from "querystring";

export const serverGroupService = {
    getByZone,
    getByGroupCode,
    saveSrvrGrp


};
const returnTestData = true;


//async function getByZone(zoneNum) {

    async function getByZone(zoneNum) {

        let error = {}

    try {
        const requestOptions = {
            headers: authHeader(),
        };


        const resp = await axios.get(`${config.apiUrl}/srvrgrps/getSrvrGprsForZone?zoneNum=${zoneNum}`, requestOptions)
        if (resp.status == 200) {
            //return {success: true, server: resp.data.serverGroups};
            return {success: true, server: resp.data.dnsSrvGrpBOs,totalRecords: resp.data.totalRecords};

        }
    } catch (e) {
        if (e.response.status == 500) {
            error = e.response.data.requestError.serviceException
        } else if (e.response.status == 400) {
            error = e.response.data.requestError.serviceException
        } else if (e.response.status == 404) {
            error = e.response.data.requestError.serviceException
        }
        else {
            error = {text: "Internal Server Error"}

        }
    }

    return {success: false, server: [], error}

}


async function getByGroupCode(zoneNum, grpCode) {
    let error = {}

    try {
        const requestOptions = {
            headers: authHeader(),
        };


        const resp = await axios.get(`${config.apiUrl}/srvrgrps/getSrvrGprsForZone?zoneNum=${zoneNum}&grpCode=${grpCode}`, requestOptions)
        if (resp.status == 200) {
            return {success: true, server: resp.data.dnsSrvGrpBOs};

        }
    } catch (e) {
        try {
            if (e.response.status == 400) {
                error = e.response.data.requestError.serviceException
            } else if (e.response.status == 404) {
                error = e.response.data.requestError.serviceException
            } else if (e.response.status == 500) {
                error = {text: e.response.data.requestError.serviceException.text ? e.response.data.requestError.serviceException.text : "Internal server error"}

            } else {
                error = {text: e.response.data.requestError.serviceException.text ? e.response.data.requestError.serviceException.text : "Something went wrong"}

            }
        } catch (er) {
            error = {text: "API ERROR"}
        }

    }
 //   console.log(error,'error')
    return {success: false, server: [], error: error}

}


async function saveSrvrGrp(params) {


    let error = {}
    try {
        const requestOptions = {
            headers: {...authHeader(), 'content-type': 'application/x-www-form-urlencoded'}
        };
        let response;
        response = await axios.post(`${config.apiUrl}/srvrgrps/updateSrvrGrpForZone`, querystring.stringify(params), requestOptions);
        if (response.status == 200) {
            // return {success: true, server: response.data};
            return {success: true, rr: response.data.RRBOs, totalRecords: response.data.totalRecords};//will use this format once I make sure it works for all RR's search

        }

    } catch (e) {
       // console.log("Error test ", e)
        try {
            if (e.response.status == 400) {
                error = e.response.data.requestError.serviceException
            } else if (e.response.status == 404) {
                error = {text: e.response.data.requestError.serviceException}
            }
            else if (e.response.status == 500) {
                error = {text: e.response.data.requestError.serviceException.text ? e.response.data.requestError.serviceException.text : "Internal server error"}

            } else {
                error = {text: e.response.data.requestError.serviceException.text ? e.response.data.requestError.serviceException.text : "Some Internal Server Error"}

            }
        } catch (er) {
            error = {text: "Internal server error.Contact Customer Care."}
        }

    }
    return Promise.reject(error)

}

















