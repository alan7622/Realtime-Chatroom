import config from 'config';
import {authHeader} from '../_helpers';
import axios from "axios";
import userData from "../Sys/Users/user.json";
import querystring from "querystring";

export const userService = {
    getUsers,
    getByUserId,
    saveUser,
    deleteUser,
    login,

};


async function getUsers(params) {
    let error = "";
    try {
        const requestOptions = {
            headers: authHeader()
        };
        params = Object.fromEntries(Object.entries(params).filter(([_, v]) => v != null && v != ""));
        const response = await axios.post(`${config.apiUrl}/users/search`, querystring.stringify(params), requestOptions);
        if (response.status == 200) {
            return response.data;
        } else if (response.status == 202) {
            error = response.data;
        }

    } catch (error) {
        console.log("Error test for getUsers" + error)

    }

    return {userBOs: [], totalRecords: 0, error: error}

}


async function getByUserId(userId) {
    let error = {}

    try {
        const requestOptions = {
            headers: authHeader()
        };
        const resp = await axios.get(`${config.apiUrl}/users/${userId}`, requestOptions)


        if (resp.status == 200) {
            // return resp.data;
            return {success: true, user: resp.data};//will use this format once I make sure it works for all RR's search

        }


    } catch (e) {
        try {
            if (e.response.status == 400) {
                error = e.response.data.requestError.serviceException
            } else if (e.response.status == 404) {
                // error = e.response.data.requestError.serviceException
                error = e.response.data.requestError.serviceException
                // error = {text: e.response.data.requestError.serviceException.text ? e.response.data.requestError.serviceException.text : "Something went wrong"}


            } else {
                error = {text: e.response.data.requestError.serviceException.text ? e.response.data.requestError.serviceException.text : "Something went wrong"}

            }
        } catch (er) {
            error = {text: "API ERROR"}
        }

    }
    return {success: false, user: null, error: error}; //will be returning this object as it is not in the part of try and cacth block of user actions like saveuser


}


async function deleteUser(userId) {
    try {
        const requestOptions = {
            headers: authHeader()
        };
        const resp = await axios.delete(`${config.apiUrl}/users/${userId}`, requestOptions);
        return resp
    } catch (e) {
        let error = ''
        if (e.response.status == 500) {
            // error = {text: "Something went wrong"}
            error = {text: e.response.data.requestError.serviceException.text ? e.response.data.requestError.serviceException.text : "Internal Error.Please Contact AT&T DNS Customer Care and report the problem."}

        } else {
            error = e.response.data.requestError.serviceException
        }
        return Promise.reject(error)
    }

}

async function saveUser(user, userId = "") {
    let error = {}
    try {
        const requestOptions = {
            headers: {...authHeader(), 'content-type': 'application/x-www-form-urlencoded'}
        };
        let response;
        const params = new URLSearchParams(user).toString();
        if (userId) {
            response = await axios.put(`${config.apiUrl}/users/${userId}`, params, requestOptions);
        } else {
            response = await axios.post(`${config.apiUrl}/users`, params, requestOptions);
        }

        if (response.status == 200) {
            return {success: true, user: response.data};
        }

    } catch (e) {
        try {
            if (e.response.status == 400) {
                error = e.response.data.requestError.serviceException
            } else {
                error = {text: e.response.data.requestError.serviceException.text ? e.response.data.requestError.serviceException.text : "Something went wrong"}

            }
        } catch (er) {
            error = {text: "API ERROR"}
        }

    }
    return Promise.reject(error)

}

async function loginByJson(username, attuid, password) {

    try {

        const userdata = userData.find(u => u.attUid === attuid && u.userName === username && u.password === password);

        if (userdata) {
            console.log("inside USERDATA")
            return userdata;
            // return {success: false, user: null, error: error}; //will be returning this object as it is not in the part of try and cacth block of user actions like saveuser

        }
    } catch (er) {
        console.log(er)

    }
    return Promise.reject({text: 'Invalid user credentials'})

}

async function login(userName, attuid, password) {
    let error = "";
    try {
        const requestOptions = {
            headers: {
                'csp-attuid': attuid,
                'content-type': 'application/x-www-form-urlencoded'
            }
        };
        const params = new URLSearchParams({userName, password}).toString();

        const response = await axios.post(`${config.apiUrl}/users/authentication`, params, requestOptions);
        if (response.status == 200) {
            return response.data.userBOs[0];
        } else if(response.status ==202){
            return response.data

        }
    } catch (e) {

        try {
            if (e.response.status == 400) {
                error = e.response.data.requestError.serviceException.text ? e.response.data.requestError.serviceException.text : "Bad Request"
            } else if (e.response.status == 404) {
                error = e.response.data.requestError.serviceException.text ? e.response.data.requestError.serviceException.text : "Data Not Found"
            } else if (e.response.status == 500) {
                error = e.response.data.requestError.serviceException.text ? e.response.data.requestError.serviceException.text : "Internal Server Error"
            } else {
                error = {text: e.response.data.requestError.serviceException.text ? e.response.data.requestError.serviceException.text : "Something went wrong"}

            }
        } catch (er) {
            error = {text: "API ERROR"}
        }

        console.log("Error test for getUsers" + error)

    }
    return Promise.reject({text: error ? error : 'Invalid user credentials'})
   // return Promise.reject({text: 'Invalid user credentials'})

}

