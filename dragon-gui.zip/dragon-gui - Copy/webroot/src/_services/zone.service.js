import config from 'config';
import {authHeader} from '../_helpers';
import axios from 'axios'
import querystring from "querystring";

export const zoneService = {
    getAll,
    getZoneById,
    getZoneAndPtrByIp6,
    getZoneAndDelegationByIp6,
    saveZone,
    deleteZone,
    updateStatus,
    getZonesList,
    getSoaTemplate


};
const returnTestData = true;

async function getAll(data) {
    let error = {}

    let zoneBOs =
        {
            "totalRecords": 1,
            "zoneBOs": [
                {
                    "accountId": 1,
                    "comments": "TEST MATT",
                    "createTime": "2022-01-11T20:56:49Z",
                    "modBy": "mattsuper",
                    "serviceName": "WNMIS",
                    "updateTime": "2022-03-16T18:41:04Z",
                    "viewNum": 0,
                    "zoneName": "elos5011.com.",
                    "zoneNameR": "com.elos5011",
                    "zoneNum": 490,
                    "zoneStatus": "A",
                    "zoneSubType": "DOM",
                    "zoneUri": "http://mtznjv1guvm64.kvm.cip.att.com:7001/Dragon2Rest/resources/zones/search/490"
                }
            ]
        }
    try {
        const requestOptions = {
            method: 'POST',
            headers: authHeader()
        };
        data = Object.fromEntries(Object.entries(data).filter(([_, v]) => v != null && v != ""));
        console.log(data)

        const response = await axios.post(`${config.apiUrl}/zones/search`, querystring.stringify(data), requestOptions);
        //const response = await axios.post(`${config.apiUrl}/fatima/zones/search`, querystring.stringify(data), requestOptions);

        if (response.status == 200) {
            // return response.data;
            return {success: true, zones: response.data.zoneBOs, totalRecords: response.data.totalRecords};
            // return {success: true, zones:zoneBOs.zoneBOs, totalRecords: zoneBOs.totalRecords}; for api mock up response


        } else if (returnTestData) {
            return testData
            // return {success: false, zones: []}

        }
    } catch (e) {
        // console.log("TEST")
        console.log(e.response, "ERROR");


        if ([500, 404].includes(e.response.status)) {
            error = e.response.data?.requestError?.serviceException?.text ? e.response.data?.requestError?.serviceException?.text : 'Data Not found'
        }
        else {
            error = {text: "Internal Server Error"}
        }
        return Promise.reject(error)

    }
    return {success: false, zones: [], error}


}

async function getZoneById(zoneNum) {
    let error = ''

    try {
        const requestOptions = {
            method: 'GET',

            headers: authHeader()
        };
        const resp = await axios.get(`${config.apiUrl}/zones/${zoneNum}`, requestOptions)
        if (resp.status == 200) {
            return {success: true, zone: resp.data}
            // return {success: true,zone: zoneBOs}
        }
    } catch (e) {
        console.log(e.response, "response.data")
        // if ([500, 404].includes(e.response.status)) {
        if (e.response.status == 500 || e.response.status == 404) {
            error = {text: e.response.data?.requestError?.serviceException?.text ? e.response.data.requestError.serviceException.text : "Internal Error.Please Contact AT&T DNS Customer Care and report the problem."}
        } else {
            error = {text: "Internal Server Error"}
        }
        return Promise.reject({error: "Zone not found"})


    }

    // return Promise.reject({error: "Zone not found"})
    return {success: false, zone: null, error: error}; //will be returning this object as it is not in the part of try and cacth block of user actions like saveuser


}

async function getZonesList(recId) {
    try {
        const requestOptions = {
            method: 'GET',

            headers: authHeader()
        };
        const resp = await axios.get(`${config.apiUrl}/resources/distrlist/getZoneDetails?recId=${recId}`, requestOptions)
        if (resp.status == 200) {
            return {success: true, zone: resp.data}
        }
    } catch (e) {
        return {};
    }

}

async function getZoneAndPtrByIp6(ip6) {
    let error = {}

    try {
        const requestOptions = {
            headers: authHeader(),
            params: {ip6: ip6}

        };
        const resp = await axios.get(`${config.apiUrl}/rrs/getIp6ZonePtr`, requestOptions)
        console.log("PTR and Zone", resp)
        if (resp.status == 200) {
            return {success: true, zone: resp.data};
        }
    }

    catch (e) {

        try {
            if (e.response.status == 400) {
                console.log(e, "err")

                error = {text: e.response.data?.requestError?.serviceException?.text ? e.response.data.requestError.serviceException.text : "Bad Request.Please Contact AT&T DNS Customer Care and report the problem."}
            } else if (e.response.status == 404) {
                console.log(e.response, "err1")

                error = {text: e.response.data?.requestError?.serviceException?.text ? e.response.data.requestError.serviceException.text : "Data Not found.Please Contact AT&T DNS Customer Care and report the problem."}
            } else if (e.response.status == 401) {
                console.log(e.response, "err1")

                error = {text: e.response.data?.requestError?.serviceException?.text ? e.response.data.requestError.serviceException.text : "Unauthorized User."}
            } else if (e.response.status == 500) {
                console.log(e.response, "err1")

                error = {text: e.response.data?.requestError?.serviceException?.text ? e.response.data.requestError.serviceException.text : "Internal Server Error.Please Contact AT&T DNS Customer Care and report the problem."}
            } else {
                error = {text: "Internal Server Error"}

            }
        }
        catch (er) {
            error = {text: "API ERROR"}
        }

    }
    return {success: false, zone: [], error}

}

//async function getZoneAndDelegationByIp6(ip6) {
async function getZoneAndDelegationByIp6(data) {
    let error = {}

    try {
        const requestOptions = {
            headers: authHeader(),
           // params: {ip6: ip6}

        };

        data = Object.fromEntries(Object.entries(data).filter(([_, v]) => v != null && v != ""));

        const resp = await axios.post(`${config.apiUrl}/delegations/getZoneDel`, querystring.stringify(data), requestOptions)
        //const resp = await axios.get(`${config.apiUrl}/delegations/getZoneDel`, requestOptions)
        console.log(" Zone", resp)
        if (resp.status == 200) {
            return {success: true, zone: resp.data};
        }
    }
    catch (e) {

        try {
            if (e.response.status == 400) {
                console.log(e, "err 400")

                error = {text: e.response.data? e.response.data : "Bad Request.Please Contact AT&T DNS Customer Care and report the problem."}
            } else if (e.response.status == 404) {
                console.log(e.response, "err 404")

                error = {text: e.response.data? e.response.data: "Data Not found.Please Contact AT&T DNS Customer Care and report the problem."}
            } else if (e.response.status == 401) {
                console.log(e.response, "err 401")

                error = {text: e.response.data? e.response.data : "Unauthorized User."}
            } else if (e.response.status == 500) {
                console.log(e.response, "err 500")
                error = {text: e.response.data? e.response.data: "Bad Request.Please Contact AT&T DNS Customer Care and report the problem."}

              //  error = {text: e.response.data?.requestError?.serviceException?.text ? e.response.data.requestError.serviceException.text : "Internal Server Error.Please Contact AT&T DNS Customer Care and report the problem."}
                error = {text: e.response.data? e.response.data: "Internal Server Error"}
            } else {
                error = {text: "Internal Server Error"}

            }
        }
        catch (er) {
            error = {text: "API ERROR"}
        }

    }
   // return Promise.reject(error)

/*    return Promise.reject(error)


}


*/
    return {success: false, zone: [], error}


}


async function saveZone(zone, zoneNum = "") {
    let error = {}
    try {
        const requestOptions = {
            headers: {...authHeader(), 'content-type': 'application/x-www-form-urlencoded'}
        };
        let response;
        const params = new URLSearchParams(zone).toString();
        if (zoneNum) {
            response = await axios.put(`${config.apiUrl}/zones/${zoneNum}`, params, requestOptions);
        } else {
            response = await axios.post(`${config.apiUrl}/zones`, params, requestOptions);
            console.log("Response test for creating zone" + response)
            console.log("params" + params)
        }
        if (response.status == 200) {
            return {success: true, zone: response.data};
        }

    }
    catch (e) {

        try {
            if (e.response.status == 400) {
                console.log(e, "err")

                error = {text: e.response.data?.requestError?.serviceException?.text ? e.response.data.requestError.serviceException.text : "Bad Request.Please Contact AT&T DNS Customer Care and report the problem."}
            } else if (e.response.status == 404) {
                console.log(e.response, "err1")

                error = {text: e.response.data?.requestError?.serviceException?.text ? e.response.data.requestError.serviceException.text : "Data Not found.Please Contact AT&T DNS Customer Care and report the problem."}
            } else if (e.response.status == 401) {
                console.log(e.response, "err1")

                error = {text: e.response.data?.requestError?.serviceException?.text ? e.response.data.requestError.serviceException.text : "Unauthorized User."}
            } else if (e.response.status == 500) {
                console.log(e.response, "err1")

                error = {text: e.response.data?.requestError?.serviceException?.text ? e.response.data.requestError.serviceException.text : "Internal Server Error.Please Contact AT&T DNS Customer Care and report the problem."}
            } else {
                error = {text: "Internal Server Error"}

            }
        }
        catch (er) {
            error = {text: "API ERROR"}
        }

    }
    return Promise.reject(error)

}


async function deleteZone(zoneNum) {
    try {
        const requestOptions = {
            headers: authHeader()
        };
        const resp = await axios.delete(`${config.apiUrl}/zones/${zoneNum}`, requestOptions);
        return resp.data
    } catch (e) {
        let error = ''
        if (e.response.status == 500 || e.response.status == 404) {
            error = {text: e.response.data?.requestError?.serviceException?.text ? e.response.data.requestError.serviceException.text : "Internal Error.Please Contact AT&T DNS Customer Care and report the problem."}
        } else {
            error = {text: "Internal Server Error"}
        }
        return Promise.reject(error)
    }


}

async function updateStatus(zoneNum, status) {
    let error = {}
    try {
        const requestOptions = {
            headers: {...authHeader(), 'content-type': 'application/x-www-form-urlencoded'}
        };
        let response;
        const params = new URLSearchParams({zoneStatus: status}).toString()
        response = await axios.put(`${config.apiUrl}/zones/${zoneNum}/chgStatus`, params, requestOptions);
        if (response.status == 200) {
            return response.data;
        }

    } catch (e) {
        try {
            if (e.response.status == 400) {
                error = e.response.data.requestError.serviceException
            } else {
                error = {text: e.response.data.requestError.serviceException.text ? e.response.data.requestError.serviceException.text : "Internal Error.Please Contact AT&T DNS Customer Care and report the problem."}

            }
        } catch (er) {
            error = {text: "API ERROR"}
        }

    }
    return Promise.reject(error)

}

async function getSoaTemplate(accountId) {
    let error = {}

    try {
        const requestOptions = {
            method: 'POST',
            headers: authHeader()
        };
        const params = new URLSearchParams({accountId}).toString()

        const response = await axios.post(`${config.apiUrl}/zones/soatemplate`, params, requestOptions);
        if (response.status == 200) {
            // return response.data;
            return {success: true, soaTemplate: response.data};

        }
    } catch (e) {
        try {
            if (e.response.status == 400) {
                error = e.response.data.requestError.serviceException
            } else if (e.response.status == 404) {
                error = e.response.data.requestError.serviceException
            } else if (e.response.status == 500) {
                error = e.response.data.requestError.serviceException

            } else {
                error = {text: e.response.data.requestError.serviceException.text ? e.response.data.requestError.serviceException.text : "Internal Error.Please Contact AT&T DNS Customer Care and report the problem."}
            }
        } catch (er) {
            error = {text: "Internal error"}
        }
        return {success: false, soaTemplate: [], error: error};
    }

}







