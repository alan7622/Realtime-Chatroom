import config from 'config';
import {authHeader} from '../_helpers';
import axios from 'axios'
import querystring from 'querystring';


export const newDomainService = {
    getDomains,

};
const returnTestData = true;

async function getDomains(searchParams) {
    var error = ''
    try {
        const requestOptions = {
            method: 'POST',
            headers: authHeader()
        };
        const response = await axios.post(`${config.apiUrl}/addDomain/search`, querystring.stringify(searchParams), requestOptions);

        if (response.status == 200) {
            //  return response.data;
            return {success: true, addDomain: response.data.addDomainBOs, totalRecords: response.data.totalRecords};
        } /*else if (returnTestData) {

            return testData

        }*/
    }
    catch (e) {

        if (e.response.status == 400) {
            error = e.response.data.requestError.serviceException
        } else if (e.response.status == 404) {
            error = e.response.data.requestError.serviceException
        }
        else if (e.response.status == 500) {
            // error = e.response.data.requestError.serviceException
            error = {text: e.response.data.requestError.serviceException.text ? e.response.data.requestError.serviceException.text : "Internal server error"}

        } else {
            error = {text: e.response.data.requestError.serviceException.text ? e.response.data.requestError.serviceException.text : "Something went wrong"}

        }

    }
    console.log("ACCOUNT LOgs Failed", error)
    return {success: false, addDomains: [], error: error}
}
