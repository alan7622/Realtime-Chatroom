import config from 'config';
import {authHeader} from '../_helpers';
import axios from 'axios'
import querystring from 'querystring';
import testData from "../Sys/TLDs/tlds.json";


export const tldService = {
    getTlds,
    getByTlDomain,
    saveTld,
    deleteTLD
};
const returnTestData = true;

// Want to use async/await? Add the `async` keyword to your outer function/method.
async function getTlds(tld) {
    let error = {}

    try {
        const requestOptions = {
            method: 'POST',
            headers: authHeader()
        };
        console.log("test tlds1",tld)

        tld = Object.fromEntries(Object.entries(tld).filter(([_, v]) => v != null && v != ""));
        console.log("test tlds2",tld)

        const response = await axios.post(`${config.apiUrl}/tlds/search`, querystring.stringify(tld), requestOptions);
        console.log("testing TLD api"+response)

        if (response.status == 200) {
            return {success: true, tlDomains: response.data.tlDomainBOs,totalRecords:response.data.totalRecords}

        } else if (returnTestData) {
            console.log("response data for tld",tld)

            return testData
        }
    }

    catch (e) {

        try {

            if (e.response.status == 404) {
                error = e.response.data.requestError.serviceException
                console.log("status error",error)
            } else {
                error = {text: e.response.data.requestError.serviceException.text ? e.response.data.requestError.serviceException.text : "Something went wrong"}

            }
        } catch (er) {
            error = {text: "API ERROR"}
        }





        /*
        console.log("test tlds1",error)

        console.error(error);*/
    }
    return Promise.reject(error)

}
async function getByTlDomain(tlDomain) {
    try {
        const requestOptions = {
            headers: authHeader()
        };

        const resp = await axios.post(`${config.apiUrl}/tlds/search`,querystring.stringify({tldEq:tlDomain}), requestOptions)


        if (resp.status == 200) {
            return resp.data;
        }
    } catch (e) {
        console.log("test for TLD : tlDomain" + e)

        return testData;
    }
}
async function saveTld(tld) {
    let error = {}
    try {
        const requestOptions = {
            headers: {...authHeader(), 'content-type': 'application/x-www-form-urlencoded'}
        };
        let response;
        const params = new URLSearchParams(tld).toString();
       // console.log("TLD PARAMS",params)
        response = await axios.post(`${config.apiUrl}/tlds`, params, requestOptions);
       // console.log("TLD  CREATING",response)

        if (response.status == 200) {
            console.log("SUCCESS test for insert tlds",response )
            return {success: true, tld: response.data};
        }

    }
    catch (e) {
        console.log("Error test for insert tlds", e)
        try {

            if (e.response.status == 400) {
                error = e.response.data.requestError.serviceException
            } else {
                error = {text: e.response.data.requestError.serviceException.text ? e.response.data.requestError.serviceException.text : "Something went wrong"}

            }
        } catch (er) {
            error = {text: "API ERROR"}
        }

    }
    return Promise.reject(error)

}

async function deleteTLD(tlDomain) {
    try {
        const requestOptions = {
            headers: {...authHeader(), 'content-type': 'application/x-www-form-urlencoded'}
        };
        const params = new URLSearchParams({tlDomain:tlDomain}).toString();


        const resp = await axios.put(`${config.apiUrl}/tlds`, params,requestOptions);
        return resp
    } catch (e) {
        let error = ''
        if (e.response.status == 500) {
            error = {text: "Internal Server Error.Contact Customer Support"}
        } else {
            error = e.response.data.requestError.serviceException
        }
        return Promise.reject(error)
    }

}







