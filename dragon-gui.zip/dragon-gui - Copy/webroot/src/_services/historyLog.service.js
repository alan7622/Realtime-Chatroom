import config from 'config';
import {authHeader} from '../_helpers';
import axios from 'axios'
import querystring from 'querystring';


export const historyLogService = {
    getHistoryLogs,


};
const returnTestData = true;

async function getHistoryLogs(zoneNum) {
    var error=""
    try {
        const requestOptions = {
            method: 'POST',
            headers: authHeader()
        };
        console.log(zoneNum,"zoneNum")

        const response = await axios.post(`${config.apiUrl}/history/search`, querystring.stringify(zoneNum), requestOptions);
        //console.log("HistoryLog response api"+response)

        if (response.status == 200) {
            return {success:true,historyLogs:response.data.historyBOs,totalRecords: response.data.totalRecords};
        }
    }
    catch (e) {

        if (e.response.status == 500) {
            error = e.response.data.requestError.serviceException

        } else {
            error = {text: "Internal Error.Please Contact AT&T DNS Customer Care and report the problem."}
        }

    }
    console.log("HistoryLOg Failed",error)
    return {success:false,historyLogs:[],error:error}
}






