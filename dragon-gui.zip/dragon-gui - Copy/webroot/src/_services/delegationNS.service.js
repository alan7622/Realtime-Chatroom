import config from 'config';
import {authHeader} from '../_helpers';
import axios from 'axios'
import querystring from "querystring";

export const delegationNSService = {
    getAllDelegationNameServers,
    getByDelegationId,
    saveDelegationNameServer,
    deleteDelegationNameServer


};

//-------------Using the same below  functions for account NameServer delegation screens in GUI-------------

const returnTestData = true;

async function getAllDelegationNameServers(data) {
    let error = ''
    try {
        const requestOptions = {
            method: 'POST',
            headers: authHeader()
        };
        data = Object.fromEntries(Object.entries(data).filter(([_, v]) => v != null && v != ""));

        const response = await axios.post(`${config.apiUrl}/nameservers/search`, querystring.stringify(data), requestOptions);
        if (response.status == 200) {

            return {success: true, nameserver: response.data.nameserverBOs, totalRecords: response.data.totalRecords};//will use this format once I make sure it works for all RR's search

        } else if (response.status == 202) {
            error = response.data;
        }
    } catch (e) {
        if ([500, 404].includes(e.response.status)) {
            error = e.response.data?.requestError?.serviceException?.text ? e.response.data?.requestError?.serviceException?.text : 'Data Not found'
        } else {
            error = {text: "Internal Server Error"}
        }

    }
    return {success: false, nameserver: [], error}
}

async function getByDelegationId(recId) {
    let error = {}

    try {
        const requestOptions = {
            method: 'GET',

            headers: authHeader()
        };
        const resp = await axios.get(`${config.apiUrl}/nameservers/${recId}`, requestOptions)
        if (resp.status == 200) {
            return {success: true, nameserver: resp.data};//will use this format once I make sure it works for all RR's search


        }
    } catch (e) {
        if ([500, 404].includes(e.response.status)) {
            error = e.response.data?.requestError?.serviceException?.text ? e.response.data?.requestError?.serviceException?.text : 'Data Not found'
        } else {
            error = {text: "Internal Server Error"}
        }
    }
    return {success: false, nameserver: null, error: error}; //will be returning this object as it is not in the part of try and cacth block of user actions like saveuser
}

async function saveDelegationNameServer(recId, nameserver) {

    let error = {}
    try {
        const requestOptions = {
            headers: {...authHeader(), 'content-type': 'application/x-www-form-urlencoded'}
        };
        let response;
        const params = new URLSearchParams(nameserver).toString();
        if (recId) {

            response = await axios.put(`${config.apiUrl}/nameservers/${recId}`, params, requestOptions);
        } else {
            response = await axios.post(`${config.apiUrl}/nameservers`, params, requestOptions);
        }

        if (response.status == 200) {
            return {success: true, nameserver: response.data};
        }

    } catch (e) {
        try {
            if (e.response.status == 400) {
                error = e.response.data.requestError.serviceException
            } else if (e.response.status == 500) {
                // error = e.response.data.requestError.serviceException
                error = {text: e.response.data.requestError.serviceException.text ? e.response.data.requestError.serviceException.text : "Internal server error"}

            } else {
                error = {text: e.response.data.requestError.serviceException.text ? e.response.data.requestError.serviceException.text : "Something went wrong"}

            }
        } catch (er) {
            error = {text: "API ERROR"}
        }

    }
    return Promise.reject(error)

}

async function deleteDelegationNameServer(recId) {
    try {
        const requestOptions = {
            headers: authHeader()
        };
        const resp = await axios.delete(`${config.apiUrl}/nameservers/${recId}`, requestOptions);
        return resp
    } catch (e) {
        let error = ''
        if (e.response.status == 500) {
            error = {text: e.response.data.requestError.serviceException.text ? e.response.data.requestError.serviceException.text : "Internal server error"}
        } else {
            error = e.response.data.requestError.serviceException
        }
        return Promise.reject(error)
    }

}












