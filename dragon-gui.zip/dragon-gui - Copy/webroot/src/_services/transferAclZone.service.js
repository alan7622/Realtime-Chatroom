import {authHeader} from "../_helpers";
import axios from "axios";
import querystring from "querystring";
import config from 'config';

export const transferAclZone = {
    getAclXfer,
    getAllAclXferList,
    aclsUpdate,
    aclsDelete
};

async function getAclXfer(data) {
    try {
        const requestOptions = {
            method: 'POST',
            headers: authHeader()
        };
        console.log(data)
        console.log(querystring.stringify(data))
        //data = new URLSearchParams(data).toString();

        const response = await axios.post(`${config.apiUrl}/lists/getDeclarationAttrs`, querystring.stringify(data), requestOptions);
        console.log(response)
        //  const resp = await axios.get(`${config.apiUrl}/resources/distrlist/getZoneDetails?recId=${recId}`, requestOptions)
        if (response.status == 200) {
            return {
                success: true,
                xferzone: response.data.declarationAttrBOs,
                totalRecords: response.data.totalRecords
            };

        }
    } catch (e) {
        console.log(e)
        return {};
    }

}

async function getAllAclXferList(data) {
    let error = {}

/*
    let declarationAttrBOs = {

        "declarationAttrBOs": [
            {
                "attrName": "allowtransfer",
                "attrOwner": 490,
                "attrValue": "1.2.3.4;1.2.3.5",
                "recId": 149
            }
        ],
        "totalRecords": 1
    }
*/

    try {
        const requestOptions = {
            method: 'POST',
            headers: authHeader()
        };

        data = Object.fromEntries(Object.entries(data).filter(([_, v]) => v != null && v != ""));

        const response = await axios.post(`${config.apiUrl}/lists/getDeclarationAttrs`, querystring.stringify(data), requestOptions);
        console.log(response)
        if (response.status == 200) {
            return {
                success: true,
                //xferzone: declarationAttrBOs.declarationAttrBOs,//use it for mockup data  declarationAttrBOs from api
                xferzone: response.data.declarationAttrBOs,
                //totalRecords: declarationAttrBOs.totalRecords
                totalRecords: response.data.totalRecords
            };


        }
    }

    catch (e) {
        console.log("in catch", error)
        if (e.response.status == 500 || e.response.status == 404 ||e.response.status == 400) {
            error = {text: e.response.data?.requestError?.serviceException?.text ? e.response.data.requestError.serviceException.text : "Internal Error.Please Contact AT&T DNS Customer Care and report the problem."}
        } else {
            error = {text: "Internal Server Error"}
        }
    }


    return {success: false, xferzone: [], error}


}


async function aclsUpdate(zoneNum, acldata) {

    let error = ''

    try {
        const requestOptions = {
            //   headers: authHeader()
            headers: {...authHeader(), 'content-type': 'application/x-www-form-urlencoded'}

        };
        var data = {...acldata}//for middleman


        const resp = await axios.put(`${config.apiUrl}/zones/${zoneNum}`, querystring.stringify(data), requestOptions);//direct api call

       console.log(acldata,"acldata")
        if (resp.status == 200) {
            return resp.data
        } else if (resp.status == 202) {
            console.log("in try-delete- 202")
            error = resp.data.requestError.serviceException.text
        }

    }

    catch (e) {
        console.log("in catch", error)
        if (e.response.status == 500 || e.response.status == 404) {
            error = {text: e.response.data?.requestError?.serviceException?.text ? e.response.data.requestError.serviceException.text : "Internal Error.Please Contact AT&T DNS Customer Care and report the problem."}
        } else {
            error = {text: "Internal Server Error"}
        }
        return Promise.reject(error)
    }

}

async function aclsDelete(zoneNum) {
    try {
        const requestOptions = {
            headers: authHeader()
        };
        var data = {json: `{"allowtransfer": "delete"}`}//for middleman

        const resp = await axios.put(`${config.apiUrl}/zones/${zoneNum}`, querystring.stringify(data), requestOptions);//middleman api call

        if (resp.status == 200) {
            return resp.data
        } else if (resp.status == 202) {
            console.log("in try-delete- 202")
            return resp.data.requestError.serviceException.text
        }

    } catch (e) {
        let error = ''
        console.log("in catch", error)
        if (e.response.status == 500 || e.response.status == 404) {
            error = {text: e.response.data?.requestError?.serviceException?.text ? e.response.data.requestError.serviceException.text : "Internal Error.Please Contact AT&T DNS Customer Care and report the problem."}
        } else {
            error = {text: "Internal Server Error"}
        }
        return Promise.reject(error)
    }

}
