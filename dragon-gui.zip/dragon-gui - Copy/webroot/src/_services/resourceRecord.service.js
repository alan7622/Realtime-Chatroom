import config from 'config';
import {authHeader} from '../_helpers';
import axios from 'axios'
import querystring from "querystring";

export const resourceRecordService = {
    getAllRecords,
    getByRecordId,
    saveRecord,
    deleteRecord


};
const returnTestData = true;


async function getByRecordId(recId) {
    try {
        const requestOptions = {
            method: 'GET',

            headers: authHeader()
        };
        const resp = await axios.get(`${config.apiUrl}/rrs/${recId}`, requestOptions)
        console.log("resource record", resp)
        if (resp.status == 200) {
            console.log("resource record", resp)
            return resp.data
        }
    } catch (e) {
        console.log(e)
        return {};
    }
    return {};
}


async function getAllRecords(data) {
    let error = 'API ERROR'
    try {
        const requestOptions = {
            method: 'POST',
            headers: authHeader()
        };
        data = Object.fromEntries(Object.entries(data).filter(([_, v]) => v != null && v != ""));
        console.log(data, "serv")

        const response = await axios.post(`${config.apiUrl}/rrs/search`, querystring.stringify(data), requestOptions);
        console.log(response, "serv2")

        if (response.status == 200) {

            return {success: true, rr: response.data.RRBOs, totalRecords: response.data.totalRecords};//will use this format once I make sure it works for all RR's search
            //return {success: true, rr: response.data.RRBOs};//will use this format once I make sure it works for all RR's search

            // return response.data;
        } else if (returnTestData) {
            console.log("TEST")
            return {success: false, rr: []}
        }
    }

    catch (e) {
        // console.log("TEST")
        console.log(e.response, "ERROR");


        if (e.response.status == 500) {
            error = e.response.data.requestError.serviceException
        }else if (e.response.status == 400) {
            error = e.response.data.requestError.serviceException
        } else if (e.response.status == 404) {
            error = e.response.data.requestError.serviceException
        }


        else {
            error = {text: "Internal Server Error"}

        }


    }
    return {success: false, rr: [], error}
}

async function saveRecord(recId, rrDetails) {
    let error = {}
    try {
        const requestOptions = {
            headers: {...authHeader(), 'content-type': 'application/x-www-form-urlencoded'}
        };
        let response;
        const params = new URLSearchParams(rrDetails).toString();
        if (recId) {

            response = await axios.put(`${config.apiUrl}/rrs/${recId}`, params, requestOptions);
        } else {
            response = await axios.post(`${config.apiUrl}/rrs`, params, requestOptions);

        }

        if (response.status == 200) {
            return {success: true, rr: response.data};
        }

    } catch (e) {
        console.log("Error test for  resource record", e)
        try {
            if (e.response.status == 400) {
                error = e.response.data.requestError.serviceException
            } else if (e.response.status == 500) {
                // error = e.response.data.requestError.serviceException
                error = {text: e.response.data.requestError.serviceException.text ? e.response.data.requestError.serviceException.text : "Internal server error"}

            } else {
                error = {text: e.response.data.requestError.serviceException.text ? e.response.data.requestError.serviceException.text : "Something went wrong"}

            }
        }
        catch (er) {
            error = {text: "API ERROR"}
        }

    }
    return Promise.reject(error)

}

async function deleteRecord(recId) {
    try {
        const requestOptions = {
            headers: authHeader()
        };
        const resp = await axios.delete(`${config.apiUrl}/rrs/${recId}`, requestOptions);
        return resp
    } catch (e) {
        let error = ''
        if (e.response.status == 500) {
            error = {text: "Internal Server Error"}
        } else {
            error = e.response.data.requestError.serviceException
        }
        return Promise.reject(error)
    }

}












