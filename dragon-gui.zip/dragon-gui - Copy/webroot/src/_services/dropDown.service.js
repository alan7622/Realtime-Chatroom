import config from 'config';
import {authHeader} from '../_helpers';
import axios from 'axios'

export const dropDownService = {
    getByStates,
    getByCountries,
    getByServiceNames,
    getByServerGroups,
    getCustTypes,
    getByZoneServerGroups,

};

//http://mtznjv1guvm64.kvm.cip.att.com:7001/Dragon2Rest/resources/lists/getZoneServersGroups?zoneNum=490

// Want to use async/await? Add the `async` keyword to your outer function/method.


async function getByStates() {
    try {
        const requestOptions = {
            method: 'GET',
            headers: authHeader()
        };
        const resp = await axios.get(`${config.apiUrl}/lists/getStates`, requestOptions)
        if (resp.status == 200) {
            return {success: true, states: resp.data.stateBOs}
        }
    } catch (e) {
        return {};
    }
}

async function getByCountries() {
    try {
        const requestOptions = {
            method: 'GET',
            headers: authHeader()
        };
        const resp = await axios.get(`${config.apiUrl}/lists/getCountries`, requestOptions)
        if (resp.status == 200) {
            return {success: true, countries: resp.data.stateBOs}
        }
    } catch (e) {
        return {};
    }
}

async function getByServerGroups() {
    try {
        const requestOptions = {
            method: 'GET',
            headers: authHeader()
        };
        const resp = await axios.get(`${config.apiUrl}/lists/getDnsSrvGrps`, requestOptions)
        if (resp.status == 200) {
            return {success: true, srvrGrps: resp.data.serverGroups}
        }
    } catch (e) {
        return {};
    }
}


async function getByZoneServerGroups(zoneNum) {
    try {
        const requestOptions = {
            method: 'GET',
            headers: authHeader()
        };
        const resp = await axios.get(`${config.apiUrl}/lists/getZoneServersGroups?zoneNum=${zoneNum}`, requestOptions)
        if (resp.status == 200) {
            return {success: true, serverName: resp.data.dnsSrvGrpBOs}
        }
    } catch (e) {
        return {};
    }
}

async function getByServiceNames() {
    try {
        const requestOptions = {
            method: 'GET',
            headers: authHeader()
        };
        const resp = await axios.get(`${config.apiUrl}/lists/getServices`, requestOptions)
        if (resp.status == 200) {
            return {success: true, services: resp.data.stateBOs}
        }
    } catch (e) {
        return {};
    }
}


async function getCustTypes() {
    try {
        const requestOptions = {
            method: 'GET',
            headers: authHeader()
        };
        const resp = await axios.get(`${config.apiUrl}/lists/getCustTypes`, requestOptions)
        if (resp.status == 200) {
            return {success: true, customers: resp.data.stateBOs}
        }
    } catch (e) {
        return {};
    }
}

