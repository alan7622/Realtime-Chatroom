import config from 'config';
import {authHeader} from '../_helpers';
import axios from 'axios'
import querystring from 'querystring';


export const accountLogService = {
    getAccountLogs,

};
const returnTestData = true;

async function getAccountLogs(accountId) {
    var error = ""
    try {
        const requestOptions = {
            method: 'POST',
            headers: authHeader()
        };
        const response = await axios.post(`${config.apiUrl}/logAccounts/search`, querystring.stringify(accountId), requestOptions);


        if (response.status == 200) {
            console.log("ACCOUNT LOgs SUCCESS", response )

            return {success: true, accountLogs: response.data.logAccountBOs,totalRecords:response.data.totalRecords};
        }
    } catch (e) {

        if (e.response.status == 500) {
            error = e.response.data.requestError.serviceException

        } else {
            error = {text: "Internal Error.Please Contact AT&T DNS Customer Care and report the problem."}
        }

    }
    console.log("ACCOUNT LOgs Failed", error)
    return {success: false, accountLogs: [], error: error}

}




