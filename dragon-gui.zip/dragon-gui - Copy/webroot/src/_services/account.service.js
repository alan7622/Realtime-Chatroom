import config from 'config';
import {authHeader} from '../_helpers';
import testData from '../Dns/Accounts/accounts.json';
import axios from 'axios'
import querystring from 'querystring';

export const accountService = {
    getAll,
    getAccountById,
    saveAccount,
    deleteAccount,
    updateStatus,
    getByStates
};
const returnTestData = true;

// Want to use async/await? Add the `async` keyword to your outer function/method.
async function getAll(data) {
    let error = {}

    /* let accountBOs =
         {
             "accountBOs": [
                 {
                     "FName": "Nimitha",
                     "LName": "Srireddy",
                     "accountId": 4,
                     "accountUri": "http://mtznjv1guvm64.kvm.cip.att.com:7001/Dragon2Rest/resources/accounts/search/4",
                     "addrCity": "Middletown",
                     "addrLine2": "PAYING",
                     "addrZip": "07748",
                     "comments": "updating account for privs test",
                     "company": "Nimithas Nachos",
                     "countryCode": "US",
                     "createTime": "2021-03-03T20:41:57Z",
                     "custId": 0,
                     "custType": "PAYING",
                     "modBy": "mattacctmgr",
                     "serviceName": "WNMIS",
                     "stateCode": " NY",
                     "status": "A",
                     "updateTime": "2022-06-15T15:31:37Z"
                 }
             ],
             "totalRecords": 1
         }*/
    try {
        const requestOptions = {
            method: 'POST',
            headers: authHeader()
        };

        const response = await axios.post(`${config.apiUrl}/accounts/search`, querystring.stringify(data), requestOptions);
        if (response.status == 200) {
            return {success: true, accounts: response.data.accountBOs, totalRecords: response.data.totalRecords};
            //  return {success: true, accounts: accountBOs.accountBOs, totalRecords: accountBOs.totalRecords}; use it for mockup data from api


            // return response.data;
        } else if (returnTestData) {
            return testData
        }
    } catch (e) {
        try {
            if (e.response.status == 400) {
                error = e.response.data.requestError.serviceException
            } else if (e.response.status == 404) {
                error = e.response.data.requestError.serviceException
            } else if (e.response.status == 500) {
                error = e.response.data.requestError.serviceException

            } else {
                error = {text: e.response.data.requestError.serviceException.text ? e.response.data.requestError.serviceException.text : "Internal Error.Please Contact AT&T DNS Customer Care and report the problem."}
            }
            /* else {
                 error = {text: e.response.data.requestError.serviceException.text ? e.response.data.requestError.serviceException.text : "Internal Server Error"}

             }*/
        } catch (er) {
            error = {text: "API ERROR"}
        }
        return {success: false, accounts: [], totalRecords: 0, error: error};

    }

    /*
        catch (error) {

            console.error(error);
        }*/
}

async function getAccountById(accountId) {
    try {
        const requestOptions = {
            method: 'GET',

            headers: authHeader()
        };
        const resp = await axios.get(`${config.apiUrl}/accounts/${accountId}`, requestOptions)
        if (resp.status == 200) {
            return resp.data
        }
    } catch (e) {
        return {};
    }
}


async function saveAccount(account, accountId = "") {
    let error = {}
    try {
        const requestOptions = {
            headers: {...authHeader(), 'content-type': 'application/x-www-form-urlencoded'}
        };
        let response;
        const params = new URLSearchParams(account).toString();
        if (accountId) {
            response = await axios.put(`${config.apiUrl}/accounts/${accountId}`, params, requestOptions);

        } else {
            response = await axios.post(`${config.apiUrl}/accounts`, params, requestOptions);

        }

        if (response.status == 200) {
            return {success: true, account: response.data};
        }

    } catch (e) {
        try {
            if (e.response.status == 400) {
                error = e.response.data.requestError.serviceException
            } else if (e.response.status == 500) {
                error = e.response.data.requestError.serviceException
            } else {
                error = {text: e.response.data.requestError.serviceException.text ? e.response.data.requestError.serviceException.text : "Internal Error.Please Contact AT&T DNS Customer Care and report the problem."}

            }
        } catch (er) {
            error = {text: "API ERROR"}
        }

    }
    return Promise.reject(error)

}


async function deleteAccount(accountId) {
    try {
        const requestOptions = {
            headers: authHeader()
        };
        const resp = await axios.delete(`${config.apiUrl}/accounts/${accountId}`, requestOptions);
        return resp
    } catch (e) {
        let error = ''
        if (e.response.status == 500) {
            error = {text: "Internal Error.Please Contact AT&T DNS Customer Care and report the problem."}
        } else {
            error = e.response.data.requestError.serviceException
        }
        return Promise.reject(error)
    }

}

async function updateStatus(accountId, status) {
    let error = {}
    try {
        const requestOptions = {
            headers: {...authHeader(), 'content-type': 'application/x-www-form-urlencoded'}
        };
        let response;
        const params = new URLSearchParams({accountStatus: status}).toString()
        response = await axios.put(`${config.apiUrl}/accounts/${accountId}/chgStatus`, params, requestOptions);


        if (response.status == 200) {
            return response.data;
        }

    } catch (e) {
        try {
            if (e.response.status == 400) {
                error = e.response.data.requestError.serviceException
            } else {
                error = {text: e.response.data.requestError.serviceException.text ? e.response.data.requestError.serviceException.text : "Internal Error.Please Contact AT&T DNS Customer Care and report the problem."}

            }
        } catch (er) {
            error = {text: "API ERROR"}
        }

    }
    return Promise.reject(error)

}


async function getByStates() {
    try {
        const requestOptions = {
            method: 'GET',
            headers: authHeader()
        };
        const resp = await axios.get(`${config.apiUrl}/lists/getStates`, requestOptions)
        if (resp.status == 200) {
            return {success: true, states: resp.data.stateBOs}
        }
    } catch (e) {
        return {};
    }
}

