import React from 'react';
import {connect} from 'react-redux';
import Form from "react-bootstrap/Form";
import {Button, Grid, Paper, TextField} from "@material-ui/core";
import Container from "@material-ui/core/Container";
import Typography from "@material-ui/core/Typography";
import {alertActions, userActions} from "../_actions";
import {getAttUIDFromCookie, history} from '../_helpers';
import {Alert} from "@material-ui/lab";
import _ from "lodash";


class Login extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            username: '',
            attuid: '',
            password: '',
            submitted: false,
            loading: true,
        };
        this.isComponentMounted = false
        this.handleChange = this.handleChange.bind(this);
        this.loginSubmit = this.loginSubmit.bind(this);
        if ((this.props.location.state === undefined || !this.props.location.state.showAlerts) && !_.isEmpty(this.props.alert)) {
            this.props.alertClear()
        }
    }

    handleChange(e) {
        const {name, value} = e.target;
        if (!_.isEmpty(this.props.alert)) {
            this.props.alertClear()
        }
        this.setState({[name]: value});
    }

    loginSubmit(e) {
        e.preventDefault();

        this.setState({submitted: true});
        const {username, attuid, password,params} = this.state;
        if (username && password) {
            this.props.login(username, attuid, password);
          //  this.props.userAuthentication(params);
        } else {
            console.log("Not submitted", this.state)
        }
    }

    componentWillUnmount() {
        this.isComponentMounted = false
    }

    componentDidMount() {
        if (!this.isComponentMounted) {
            this.isComponentMounted = true
            if (this.props.loggedIn && this.props.useSelector) {
                history.push('/')
            } else {
                console.log(this.props.loggingIn, "this.props.loggingIn")
                if (!this.props.loggingIn) {
                    const attUid = getAttUIDFromCookie()
                    if (attUid) {//
                        this.props.loginWithAttuid(attUid);
                    } else {
                        this.setState({loading: false})
                    }
                }
            }
        }

    }

    render() {
        const {username, password, attuid, submitted, loading} = this.state;
        if (loading) {
            return <>Loading...</>

        }
        return (
            <>
                <Container>
                    <Paper className={"mt-5 mr-0 p-3"}>
                        <Typography gutterBottom variant="h5" align={"center"}>
                            <strong>Login Page</strong>
                        </Typography>
                        <div className="pl-5 pr-5 pt-4 pb-4">
                            <Form onSubmit={this.loginSubmit}>
                                {this.props.alert.message &&
                                <Alert severity={this.props.alert.type}>{this.props.alert.message}</Alert>}
                                <Grid item xs={3} sm={2} className={"pb-3"}>
                                    <TextField
                                        error={submitted && !username}
                                        id="username"
                                        label="Username"
                                        defaultValue=""
                                        helperText={submitted && !username ? "Username is required" : ''}
                                        variant="outlined"
                                        name={"username"}
                                        onChange={this.handleChange}
                                    />
                                </Grid>
                                <Grid item xs={3} sm={2} className={"pb-3"}>
                                    <TextField
                                        error={submitted && !attuid}
                                        id="attuid"
                                        label="Attuid"
                                        defaultValue=""
                                        helperText={submitted && !attuid ? "AttUid is required" : ''}
                                        variant="outlined" name={"attuid"}
                                        onChange={this.handleChange}

                                    />
                                </Grid>
                                <Grid item xs={3} sm={2} className={"pb-3"}>
                                    <TextField
                                        error={submitted && !password}
                                        id="password"
                                        label="Password"
                                        defaultValue=""
                                        helperText={submitted && !password ? "Password is required" : ''}
                                        variant="outlined"
                                        type={"password"}
                                        name={"password"}
                                        onChange={this.handleChange}
                                    />
                                </Grid>
                                <Grid item xs={4}>
                                    <Button variant="contained"
                                            className={"dns-blue-button text-white"} type={"submit"}>Login</Button>
                                </Grid>


                            </Form>
                        </div>
                    </Paper>
                </Container>
            </>

        );
    }
}


function mapState(state) {
    const {loggingIn, loggedIn, user} = state.authentication;
    console.log("state", state)
    const {alert} = state

    return {loggingIn, alert, loggedIn, user};
}

const actionCreators = {
    login: userActions.login,
    alertClear: alertActions.clear,
    loginWithAttuid: userActions.loginWithAttuid
};
const con = connect(mapState, actionCreators)(Login)
export {con as Login};
