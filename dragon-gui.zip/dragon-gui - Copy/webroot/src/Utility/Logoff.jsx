import React from "react";
import {
    Paper
} from "@material-ui/core";
import Typography from "@material-ui/core/Typography";
import {Layout} from "../_components/Layout";
import Container from "@material-ui/core/Container";
import Box from "@material-ui/core/Box";
import AttLogo from "../../assets/images/attdragon2.gif";
import SwooshImg from "../../assets/images/swoosh.gif";
import {HomeMenu} from "../_components";
import {Route, Switch} from "react-router-dom";
import {User as Profile} from "../Sys/Users";


const useStyles = theme => ({
    root: {
        display: 'flex',
    },
    toolbar: {
        paddingRight: 24, // keep right padding when drawer closed
    },
    toolbarIcon: {
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'flex-end',
        padding: '0 8px',
        backgroundImage: `url(${AttLogo})`,
        backgroundRepeat: 'no-repeat',
        backgroundSize: '95% 95%',
        ...theme.mixins.toolbar,
    },
    appBar: {
        zIndex: theme.zIndex.drawer + 1,
        backgroundImage: `url(${SwooshImg})`,
        backgroundRepeat: 'no-repeat',
        backgroundSize: 'cover',
        transition: theme.transitions.create(['width', 'margin'], {
            easing: theme.transitions.easing.sharp,
            duration: theme.transitions.duration.leavingScreen,
        }),
    },
    appBarShift: {
        marginLeft: drawerWidth,
        width: `calc(100% - ${drawerWidth}px)`,
        transition: theme.transitions.create(['width', 'margin'], {
            easing: theme.transitions.easing.sharp,
            duration: theme.transitions.duration.enteringScreen,
        }),
    },
    menuButton: {
        marginRight: 36,
        color: 'black'
    },
    menuButtonHidden: {
        display: 'none',
    },
    title: {
        flexGrow: 1,
    },
    drawerPaper: {
        position: 'relative',
        whiteSpace: 'nowrap',
        width: drawerWidth,
        transition: theme.transitions.create('width', {
            easing: theme.transitions.easing.sharp,
            duration: theme.transitions.duration.enteringScreen,
        }),
    },
    drawerPaperClose: {
        overflowX: 'hidden',
        transition: theme.transitions.create('width', {
            easing: theme.transitions.easing.sharp,
            duration: theme.transitions.duration.leavingScreen,
        }),
        width: theme.spacing(7),
        [theme.breakpoints.up('sm')]: {
            width: theme.spacing(9),
        },
    },
    appBarSpacer: theme.mixins.toolbar,
    content: {
        flexGrow: 1,
        height: '100vh',
        overflow: 'auto',
    },
    container: {
        paddingTop: theme.spacing(4),
        paddingBottom: theme.spacing(4),
    },
    paper: {
        padding: theme.spacing(2),
        display: 'flex',
        overflow: 'auto',
        flexDirection: 'column',
    },
    fixedHeight: {
        height: 240,
    },
});

class Logoff extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            loading: true,
        };
        this.isComponentMounted = false;
    }


    getMenu() {
        return HomeMenu;
    }

    render() {
        return (
            <><Layout menuItems={this.getMenu()}>
                <Switch>
                    <Route path={"/profile"} exact component={() => <Profile componentName={"profile"}/>}/>
                    <Route path="/" component={() => {
                        return (<Container maxWidth={false} className={"px-2"}>
                            <Paper>
                                <Box p={15}>
                                    <h5 className={"font-weight-bold text-left mt-1"}>
                                        Dragon Provisioning Logoff Page</h5>
                                    <Typography align={"left"} className={"mt-5 font-smaller"}>
                                        You are now logged off.<br/>
                                        You must log on again to use the Dragon system.

                                    </Typography>
                                </Box>

                            </Paper>
                        </Container>)
                    }}/>

                </Switch>

            </Layout>
            </>
        )
    }

}

export {Logoff as Logoff}
