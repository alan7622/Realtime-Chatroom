import React from 'react';
import Layout from "../_components/Layout";
import {Button, Dialog, DialogContent, Grid, Paper} from "@material-ui/core";
import Container from "@material-ui/core/Container";
import {userService} from "../_services";
import HomeIcon from "@material-ui/icons/Home";
import Alert from "react-popup-alert";

class SamplePage extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            loading: true,
            user: {},
            alertBox: {
                show: false,
                text: '',
                type: ''
            }
        };
        this.isComponentMounted = false;
    }

    getMenu() {
        return {
            navMenu: [
                {
                    path: '/sys',
                    label: 'Home',
                    icon: <HomeIcon/>
                },
                {
                    path: '/sys/users/search',
                    label: 'Users',
                },
                {
                    path: '/sys/accountlogs',
                    label: 'Account Logs'
                },
                {
                    path: '/sys/historylogs',
                    label: 'History Logs'
                },
                {
                    path: '/sys/tld',
                    label: 'Top Level Domains'
                },

            ],
            actionMenu: [{
                path: '/sys/tld',
                label: 'Update',
                onclick: async () => {
                    this.setState({loading: true})
                    const res = await userService.updateUser(this.state.user);
                    console.log(res)
                    if (res.success) {
                        this.setState({loading: false})
                        this.setState({alertBox: {show: true, text: 'Saved Successfuly', type: 'success'}})
                    }
                }
            },
                {
                    path: '/sys/tld',
                    label: 'Delete',
                    onclick: () => {
                        alert();
                    }
                }]
        }
    }

    async componentDidMount() {
        this.isComponentMounted = true;
        const user = await userService.getByUserId(this.props.match.params.id)
        if (this.isComponentMounted) {
            this.setState({loading: false, user: user});

        }
    }

    componentWillUnmount() {
        this.isComponentMounted = false;
    }

    render() {
        const {alertBox} = this.state
        return (
            <>
                <Layout menuItems={this.getMenu()}>
                    <Dialog
                        open={this.state.alertBox.show}
                        onClose={() => {
                            this.setState({alertBox: {show: !alertBox.show}})
                        }}
                        aria-labelledby="alert-dialog-title"
                        aria-describedby="alert-dialog-description"

                    >
                        The User record has been successfully updated </Dialog>
                    <Container maxWidth="lg">
                        <Paper className={"p-3"}>
                            <Grid container>
                                <Grid item xs={12}><h5><strong>Sys User Details </strong></h5></Grid>
                                <Grid item sm={6}>
                                    <Grid container>
                                        <Grid item sm={6}>ATT_UID:</Grid>
                                        <Grid item sm={6}>
                                            {this.state.user.attUid}
                                        </Grid>
                                    </Grid>
                                </Grid>
                                <Grid item sm={6}>
                                    <Grid container>
                                        <Grid item sm={6}>Create Time:</Grid>
                                        <Grid item sm={6}>
                                            {this.state.user.createTime}
                                        </Grid>
                                    </Grid>
                                </Grid>
                                <Grid item sm={6}>
                                    <Grid container>
                                        <Grid item sm={6}>Last Modified:</Grid>
                                        <Grid item sm={6}>
                                            {/*
                                                {this.state.user.attUid}
*/}
                                        </Grid>
                                    </Grid>
                                </Grid>
                                <Grid item sm={6}>
                                    <Grid container>
                                        <Grid item sm={6}>User Name:</Grid>
                                        <Grid item sm={6}>
                                            {this.state.user.userName}
                                        </Grid>
                                    </Grid>
                                </Grid>
                                <Grid item sm={6}>
                                    <Grid container>
                                        <Grid item sm={6}>Password:</Grid>
                                        <Grid item sm={6}>
                                            {this.state.user.password}
                                        </Grid>
                                    </Grid>
                                </Grid>
                                <Grid item sm={6}>
                                    <Grid container>
                                        <Grid item sm={6}>Login Enabled:</Grid>
                                        <Grid item sm={6}>
                                            {this.state.user.enabled}
                                        </Grid>
                                    </Grid>
                                </Grid>
                                <Grid item sm={6}>
                                    <Grid container>
                                        <Grid item sm={6}>First Name:</Grid>
                                        <Grid item sm={6}>
                                            {this.state.user.fName}
                                        </Grid>
                                    </Grid>
                                </Grid>
                                <Grid item sm={6}>
                                    <Grid container>
                                        <Grid item sm={6}>Last Name:</Grid>
                                        <Grid item sm={6}>
                                            {this.state.user.lName}
                                        </Grid>
                                    </Grid>
                                </Grid>
                                <Grid item sm={6}>
                                    <Grid container>
                                        <Grid item sm={6}>Comment:</Grid>
                                        <Grid item sm={6}>
                                            {this.state.user.comment}
                                        </Grid>
                                    </Grid>
                                </Grid>
                                <Grid item sm={6}>
                                    <Grid container>
                                        <Grid item sm={6}>Service ID:</Grid>
                                        <Grid item sm={6}>
                                            {this.state.user.serviceId}
                                        </Grid>
                                    </Grid>
                                </Grid>
                                <Grid item sm={6}>
                                    <Grid container>
                                        <Grid item sm={6}>Account ID:</Grid>
                                        <Grid item sm={6}>
                                            {/*
                                                {this.state.user.attUid}
*/}
                                        </Grid>
                                    </Grid>
                                </Grid>
                                <Grid item sm={6}>
                                    <Grid container>
                                        <Grid item sm={6}>Zone Name:</Grid>
                                        <Grid item sm={6}>
                                            {/*           {this.state.user.attUid}*/}
                                        </Grid>
                                    </Grid>
                                </Grid>
                                <Grid item sm={6}>
                                    <Grid container>
                                        <Grid item sm={6}>Privileges:</Grid>
                                        <Grid item sm={6}>
                                            {this.state.user.privileges}
                                        </Grid>
                                    </Grid>
                                </Grid>
                                <Grid item sm={6}>
                                    <Grid container>
                                        <Grid item sm={6}>Phone - Country Code:</Grid>
                                        <Grid item sm={6}>
                                            {/*  {this.state.user.attUid*/}}

                                        </Grid>
                                    </Grid>
                                </Grid>
                                <Grid item sm={6}>
                                    <Grid container>
                                        <Grid item sm={6}>Phone Number:</Grid>
                                        <Grid item sm={6}>
                                            {/*   {this.state.user.attUid}
*/}
                                        </Grid>
                                    </Grid>
                                </Grid>
                                <Grid item sm={6}>
                                    <Grid container>
                                        <Grid item sm={6}>Email Address:</Grid>
                                        <Grid item sm={6}>
                                            {this.state.user.addrEmail}

                                        </Grid>
                                    </Grid>
                                </Grid>
                                <Grid item sm={6}>
                                    <Grid container>
                                        <Grid item sm={6}>Address: </Grid>
                                        <Grid item sm={6}>
                                            {/*      {this.state.user.attUid}*/}
                                        </Grid>
                                    </Grid>
                                </Grid>
                                <Grid item sm={6}>
                                    <Grid container>
                                        <Grid item sm={6}>City:</Grid>
                                        <Grid item sm={6}>
                                            {/*  {this.state.user.attUid}*/}
                                        </Grid>
                                    </Grid>
                                </Grid>
                                <Grid item sm={6}>
                                    <Grid container>
                                        <Grid item sm={6}>State Code:</Grid>
                                        <Grid item sm={6}>
                                            {/*          {this.state.user.attUid}*/}
                                        </Grid>
                                    </Grid>
                                </Grid>
                                <Grid item sm={6}>
                                    <Grid container>
                                        <Grid item sm={6}>Country Code:</Grid>
                                        <Grid item sm={6}>
                                            {/* {this.state.user.attUid}*/}
                                        </Grid>
                                    </Grid>
                                </Grid>
                                <Grid item sm={6}>
                                    <Grid container>
                                        <Grid item sm={6}>Zip Code:</Grid>
                                        <Grid item sm={6}>
                                            {/*{this.state.user.attUid}*/}
                                        </Grid>
                                    </Grid>
                                </Grid>
                            </Grid>


                        </Paper>

                    </Container>
                </Layout>
            </>
        )
    }
}

export default SamplePage;