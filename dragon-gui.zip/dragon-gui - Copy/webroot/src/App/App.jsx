import React from 'react';
import {Router, Route, Switch, Redirect} from 'react-router-dom';
import {connect} from 'react-redux';
import {history} from '../_helpers';
import {userActions} from '../_actions';
import {Login} from '../Utility/Login';
import {RegisterPage} from '../RegisterPage';
import HomePage from '../Utility/HomePage'
import './app.scss'
import {DnsHome} from "../Dns";
import {SysHome} from "../Sys";
import 'bootstrap/dist/css/bootstrap.min.css';
import 'react-bootstrap-table-next/dist/react-bootstrap-table2.css';
import {UnAuthorized, PrivateRoute} from "../_components";
import {Logoff} from "../Utility";


class App extends React.Component {
    constructor(props) {
        super(props);
    }

    render() {

        return (<>
            <Router history={history}>
                <Switch>
                    <Route path="/error" exact component={UnAuthorized}/>
                    <Route path="/login" exact component={Login}/>
                    <Route path="/logoff" exact component={Logoff}/>


                        <Route path="/register" component={RegisterPage}/>

                        //route path for DNS
                        <PrivateRoute path={`/dns`} component={DnsHome}/>
                        <PrivateRoute path="/sys" component={SysHome}/>



                        <PrivateRoute path="/logout" component={() => {
                        this.props.logout();
                        console.log("Logout")
                        return <Redirect to={"/logoff"}/>;
                       // return<></> ;

                    }}/>

                        <PrivateRoute path="*" component={HomePage}/>


                        </Switch>
                        </Router>
                        </>);
                        }
                        }

                        function mapState(state) {
                        return {};
                    }

                        const actionCreators = {
                        logout: userActions.logout
                    };

                        const connectedApp = connect(mapState, actionCreators)(App);
                        export {connectedApp as App};