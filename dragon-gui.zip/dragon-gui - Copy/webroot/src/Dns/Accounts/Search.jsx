import React, {Component} from "react";
import clsx from "clsx";
import {Helmet} from "react-helmet";
import {
    Button,
    Dialog,
    DialogActions,
    DialogContent,
    DialogContentText,
    DialogTitle,
    FormControl,
    Grid,
    IconButton,
    InputLabel,
    Paper,
    Select,
    TextField,
    withStyles, Card, CardContent, FormControlLabel, RadioGroup, Radio,
} from "@material-ui/core";
import {Link} from 'react-router-dom';
import Container from "@material-ui/core/Container";
import {Form, Col, Row} from "react-bootstrap";
import PropTypes from "prop-types";
import {accountService, userService} from "../../_services";
import Box from "@material-ui/core/Box";
import filterFactory, {Comparator, selectFilter, textFilter} from "react-bootstrap-table2-filter";
import EditIcon from "@material-ui/icons/Edit";
import ListAltOutlinedIcon from "@material-ui/icons/ListAltOutlined";
import BootstrapTable from "react-bootstrap-table-next";
import ToolkitProvider from 'react-bootstrap-table2-toolkit';
import paginationFactory from 'react-bootstrap-table2-paginator';
import {connect} from "react-redux";
import {Alert} from "@material-ui/lab";
import {alertActions} from "../../_actions";
import _ from "lodash";
import {isAuthorized, pageRenderer, SizePerPageRenderer} from "../../_components";
import Divider from "@material-ui/core/Divider";


const useStyles = theme => ({
    root: {},
    searchButton: {
        /*
                backgroundColor: '#3f75b2',
        */
        backgroundColor: '#4789b6',
        marginBottom: '-10px',
        opacity: '1',
        color: '#FFF',
        width: '50%',
        '&:hover': {backgroundColor: '#3f6bb5', opacity: '1'}
    },
    filterContainer: {
        padding: '20px',
        marginBottom: '30px'
    },

    createAccountButton: {
        backgroundColor: '#4789b6',
        '&:hover': {
            backgroundColor: '#3f75b5',
        },
    },

    searchContainer: {
        textAlign: 'left'
    }
});

const defaultFilters = {
    accId: '',
    customerId: '',
    serviceAccId: '',
    cci: '',
    companyWildcard: "companyBeg",
    companyName: ''
}

class Search extends Component {
    constructor(props) {
        super(props);
        this.state = {
            filters: _.cloneDeep(defaultFilters),
            showFilterAlert: false,
            data: [],
            page: 1,
            sizePerPage: 10,
            totalSize: 0,
            accountSearchParams: {},
            loading: false,
            submitted: false,
            error: ''
        }
        this.handleTableChange = this.handleTableChange.bind(this)
        this.handleChange = this.handleChange.bind(this);
        this.handleClose = this.handleClose.bind(this);
        this.search = this.search.bind(this);
        this.getFilterAlert = this.getFilterAlert.bind(this);



        if ((this.props.location.state === null || this.props.location.state === undefined || !this.props.location.state.showAlerts) && !_.isEmpty(this.props.alert)) {
            this.props.alertClear()
        }



    }

    handleChange(e) {
        const {name, value} = e.target;
        const {filters} = this.state;
        this.setState({filters: {...filters, [name]: value}})
    }

    search(params) {
        const {filters} = this.state
        //TODO: Will try to find a better way to do this

        if (filters.accId || (filters.companyName && filters.companyWildcard) || filters.cci || filters.customerId || filters.serviceAccId) {
            var data = {
                ...params,
                cciEq: filters.cci,
                accountIdEq: filters.accId,
                srvAcctIdEq: filters.serviceAccId,
                custId: filters.customerId,
                [filters.companyWildcard]: filters.companyName
            };

            console.log(data, "filters")
            //srvAcctIdEq:filters.accId,
            data = Object.fromEntries(Object.entries(data).filter(([_, v]) => v != null && v != ""));
            //make API call
            this.setState({submitted: true, loading: true})
            //console.log(data, "filters")

            accountService.getAll(data).then(res => {
                console.log(res, "res")
                this.setState({
                    loading: false,
                    data: res.accounts,
                    totalSize: res.totalRecords,
                    sizePerPage: params.numberOfRows,
                    page: params.pageNumber,
                    error: res.success ? '' : res.error
                });

                //  this.setState({loading: false, data: res.accounts,totalSize: res.totalRecords, sizePerPage: params.params,page: params.pageNumber});
                //set the state after api is called(will show change of pagenumber after api is loaded)//trying to add pagination
            });
        } else {
            this.setState({showFilterAlert: true})
        }
    }

    handleClose() {
        this.setState({showFilterAlert: false})
    };

    getFilterAlert() {
        return (
            <Dialog
                open={this.state.showFilterAlert}
                onClose={this.handleClose}>
                <DialogTitle>{"Accounts Search Alert"}</DialogTitle>
                <Divider/>
                <DialogContent>
                    <DialogContentText>
                        You must enter at least one search criteria.
                    </DialogContentText>
                </DialogContent>
                <DialogActions>
                    <Button autoFocus onClick={this.handleClose} className={"dns-blue-button text-white"}>
                        Ok
                    </Button>
                </DialogActions>
            </Dialog>
        )
    }


    getAccountSearchColumns() {


        return [
            {
                dataField: 'accountId',
                text: 'Account_ID',
                headerAlign: 'center',
                headerClasses: 'p-1',
                classes: 'p-0 pl-1',
                headerStyle: {
                    width: "10%"
                },
            },

            {
                text: 'Status',
                dataField: 'status',
                headerAlign: 'center',
                headerClasses: 'p-1',
                classes: 'text-left p-0 pl-1',
                headerStyle: {
                    width: "5%"
                },
            },
            {
                text: 'CCI',
                dataField: 'cci',
                headerAlign: 'center',
                headerClasses: 'p-1',
                classes: 'text-left p-0 pl-1',
                headerStyle: {
                    width: "10%"
                },
            },
            {
                text: 'Service ID',
                dataField: 'serviceName',
                headerAlign: 'center',
                headerClasses: 'p-1',
                classes: 'text-left p-0 pl-1',
                headerStyle: {
                    width: "12%"
                },
            },
            {
                text: 'Service Acct ID',
                dataField: 'srvAcctId',
                headerAlign: 'center',
                headerClasses: 'p-1',
                classes: 'text-left p-0 pl-1',
                headerStyle: {
                    width: "13%"
                },
            },
            {
                text: 'Company',
                dataField: 'company',
                headerAlign: 'center',
                headerClasses: 'p-1',
                classes: 'text-left p-0 pl-1',
                headerStyle: {
                    width: "30%"
                },
            },
            {
                text: 'Customer ID',
                dataField: 'custId',
                headerAlign: 'center',
                headerClasses: 'p-1',
                classes: 'text-left p-0 pl-1',
                headerStyle: {
                    width: "10%"
                },
            },
            {
                text: "Action",
                dataField: "",
                headerAlign: 'center',
                headerClasses: 'p-1',
                classes: 'text-center p-0',
                headerStyle: {
                    width: "10%"
                },
                formatter: (cell, row, rowIndex) => <>
                    <Link
                        to={`/dns/accounts/details/${row.accountId}`}
                        key={"details_dns_account"}
                        className={"color-dragon-blue mr-2"}
                    >Details</Link>
                    {isAuthorized('au') && <Link
                        to={`/dns/accounts/edit/${row.accountId}`}
                        key={"edit_dns_account"}
                        className={"color-dragon-blue"}
                    >Edit</Link>}
                </>

            },
        ];

    }

    getFormData() {
        const {classes} = this.props;

        return <Form>
            <Grid container spacing={2}>
                <Grid item xs={2} sm={2}>
                    <TextField
                        id="accId"
                        label="Account Id"
                        variant="outlined"
                        name={"accId"}
                        onChange={this.handleChange}
                        value={this.state.filters.accId}
                    />
                </Grid>
                <Grid item xs={2} sm={2}>
                    <TextField
                        id="serviceAccId"
                        label="Service Account ID"
                        variant="outlined"
                        name={"serviceAccId"}
                        onChange={this.handleChange}
                        value={this.state.filters.serviceAccId}
                    />
                </Grid>
                <Grid item xs={2} sm={1}>
                    <TextField
                        id="cci"
                        label="CCI"
                        variant="outlined"
                        name={"cci"}
                        onChange={this.handleChange}
                        value={this.state.filters.cci}
                    />
                </Grid>

                <Grid item xs={3} sm={2}>
                    <TextField
                        id="customerId"
                        label="Customer ID"
                        variant="outlined"
                        name={"customerId"}
                        onChange={this.handleChange}
                        value={this.state.filters.customerId}
                    />
                </Grid>


                <Grid item xs={1}></Grid>


                <Grid item xs={3} sm={2}>
                    <FormControl variant="outlined" className={""}>
                        <InputLabel htmlFor="wildcard-company-search">Company</InputLabel>
                        <Select
                            native
                            value={this.state.filters.companyWildcard}
                            onChange={this.handleChange}
                            label="Company"
                            inputProps={{
                                name: 'companyWildcard',
                                id: 'wildcard-company-search',
                            }}
                        >
                            <option value={"companyBeg"}>Begins With</option>
                            <option value={"companyContains"}>Contains</option>
                            <option value={"companyEnd"}>Ends With</option>

                        </Select>
                    </FormControl>
                </Grid>
                <Grid item xs={3} sm={2}>
                    <TextField
                        id="outlined-helperText"
                        label="Company Name"
                        variant="outlined"
                        name={"companyName"}
                        value={this.state.filters.companyName}
                        onChange={this.handleChange}
                    />
                </Grid>

                {/*
                 <Grid item xs={4}>

                    <Form.Group as={Row} className={"align-items-center"}>
                        <Form.Label column sm="3" className={'font-weight-bold'}>
                            Ordered By </Form.Label>
                        <Col sm={9} key={"orderBy"}>
                            <RadioGroup value={""} name={"orderBy.value"}
                                      //  onChange={this.handleFilterChange}
                                        row={true}>

                                <FormControlLabel value=""
                                                  control={<Radio color="primary"/>}
                                                  label="Full Host Name"/>

                            </RadioGroup>
                        </Col>
                    </Form.Group>
                    <Form.Group as={Row} className={"align-items-center"}>
                        <Form.Label column sm="3" className={'font-weight-bold'}>
                            Ordered Direction </Form.Label>
                        <Col sm={9} key={"orderDir"}>
                            <RadioGroup value={""} name={"orderDir.value"}
                                     //   onChange={this.handleFilterChange}
                                        row={true}>

                                <FormControlLabel value="asc"
                                                  control={<Radio color="primary"/>}
                                                  label="Ascending"/>
                                <FormControlLabel value="desc" control={<Radio color="primary"/>}
                                                  label="Descending"/>


                            </RadioGroup>
                        </Col>
                    </Form.Group>
                    </Grid>
*/}

                <Grid item xs={4} className={classes.searchContainer}>
                    <Button onClick={() => this.search({pageNumber: 1, numberOfRows: 10})} variant="contained"
                            className={clsx(classes.searchButton)}
                        /*
                                                    disabled={true}
                        */
                    >Search Accounts</Button>
                    <Button type={"reset"} onClick={() => {
                        this.props.alertClear();
                        this.setState({filters: _.cloneDeep(defaultFilters), data: [], submitted: false, error: ''})
                    }} variant="contained"
                            className={"dns-blue-button text-white ml-2 mt-2"}
                    >clear</Button>

                </Grid>

                <em className={"mt-3"}>NOTE: Using multiple keys from different systems (Account ID, Service Account ID,
                    CCI and Customer ID)
                    may result in no records returned if mismatched.
                </em>

            </Grid>


        </Form>


    }

    paginationOptions() {
        return {
            sizePerPage: this.state.sizePerPage,
            page: this.state.page,
            totalSize: this.state.totalSize,
            alwaysShowAllBtns: true, // Always show next and previous button
            withFirstAndLast: true, // Hide the going to First and Last page button
            firstPageText: 'First',
            prePageText: 'Back',
            nextPageText: 'Next',
            lastPageText: 'Last',
            nextPageTitle: 'First page',
            prePageTitle: 'Pre page',
            firstPageTitle: 'Next page',
            lastPageTitle: 'Last page',
            showTotal: false,
            sizePerPageList: [
                {
                    text: '10', value: 10
                }, {
                    text: '20', value: 20
                }, {
                    text: '50', value: 50
                },
            ],
            pageButtonRenderer: pageRenderer,
            sizePerPageRenderer: ({
                                      options,
                                      currSizePerPage,
                                      onSizePerPageChange
                                  }) => <SizePerPageRenderer options={options}
                                                             currSizePerPage={currSizePerPage}
                                                             onSizePerPageChange={onSizePerPageChange}/>,
            disablePageTitle: true,
        };
    }


    async handleTableChange(type, {filters, page, sizePerPage, totalSize, sortOrder, sortField}) {
        const currentIndex = (page - 1) * sizePerPage;
        let accountSearchParams = {};
        if (sortField && sortOrder) {
            accountSearchParams.orderDir = sortOrder;
            accountSearchParams.orderBy = sortField;
        }

        accountSearchParams.numberOfRows = sizePerPage;
        accountSearchParams.pageNumber = page;
        await this.search(accountSearchParams);


    }


    render() {
        const {loading, data} = this.state;
        let columnsConfig = this.getAccountSearchColumns()
        if (_.isEmpty(data) || data.length < 2) {
            columnsConfig = columnsConfig.map(({filter, ...item}) => item)
        }
        const paginationOptions = this.paginationOptions();

        return (
            <div>
                {this.getFilterAlert()}
                <Helmet>
                    <title>Search Accounts | Home</title>
                </Helmet>
                <Box>
                    <Container className={"pl-1 pr-1 mb-5"}>

                        <Card>
                            <CardContent>
                          <div className={'mt-2 ml-2 mr-3 mb-2'}>
                                    {(!_.isEmpty(this.state.error) || !_.isEmpty(this.props.alert.message)) &&
                                    <Alert
                                        severity={!_.isEmpty(this.state.error) ? "error" : this.props.alert.type}>{(this.state.error && this.state.error.text) || this.props.alert.message}</Alert>}

                                    <ToolkitProvider
                                        keyField="accountId"
                                        data={data}
                                        columns={columnsConfig}
                                        columnToggle
                                        // search
                                        remote
                                    >
                                        {
                                            (props) => (
                                                <div className={"row mb-2 text-left mt-3 ml-3"}>
                                                    <h6 className={"pt-3 pb-3"}><strong>DNS Accounts Search</strong>
                                                    </h6>
                                                    {this.getFormData()}
                                                    {this.state.submitted && <div className={"row mb-2"}>

                                                        <h6 className={"mt-5 ml-4"}><strong>DNS Account Searching
                                                            Results</strong></h6>
                                                        <div className="pt-1 pb-5 ml-4 mr-4 mt-2 ">
                                                            {/* {this.state.alert &&
                                                            <Alert severity={"error"}>{this.state.alert.text} <a href={"#"}
                                                                                                                 onClick={async (e) => {
                                                                                                                     e.preventDefault();
                                                                                                                     this.setState({
                                                                                                                         modTimeFilter: {
                                                                                                                             ...this.state.modTimeFilter,
                                                                                                                             value: ""
                                                                                                                         }
                                                                                                                     });
                                                                                                                     await this.loadTableData()
                                                               }}>Clear</a></Alert>}*/}

                                                            <BootstrapTable bootstrap4
                                                                            keyField={"accountId"}
                                                                            filter={filterFactory()}
                                                                            noDataIndication="No matching records found"
                                                                            pagination={paginationFactory(paginationOptions)}
                                                                            {...props.baseProps}
                                                                            filterPosition={"top"}
                                                                            onTableChange={this.handleTableChange}
                                                                // options={options}
                                                                            remote={{
                                                                                pagination: true,
                                                                            }} loading={true}
                                                                            striped
                                                                            hover
                                                                            condensed
                                                            />
                                                        </div>
                                                    </div>}

                                                </div>
                                            )
                                        }
                                    </ToolkitProvider>
                                </div>

                            </CardContent>
                        </Card>
                    </Container>
                </Box>
            </div>


        );
    }


}

Search.propTypes = {
    classes: PropTypes.object.isRequired
};

const styledSearch = withStyles(useStyles)(Search);

function mapState(state) {
    const {deleted} = state.accounts
    const {alert} = state
    return {deleted, alert}
}

const actionCreators = {
    alertClear: alertActions.clear,
}
const connectedAccount = connect(mapState, actionCreators)(styledSearch);
export {connectedAccount as Search};


