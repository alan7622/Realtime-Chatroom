import React, {Component} from "react";
import {accountService} from "../../_services";
import {
    Backdrop,
    Button, Card, CardContent,
    CircularProgress,
    Dialog,
    DialogActions, DialogContent,
    DialogTitle,
} from "@material-ui/core";
import Container from "@material-ui/core/Container";
import Form from "react-bootstrap/Form";
import {Col, Row} from "react-bootstrap";
import PropTypes, {object} from "prop-types";
import {connect} from "react-redux";
import {withRouter} from "react-router-dom";
import {Helmet} from "react-helmet";
import {accountActions, alertActions} from "../../_actions";
import _ from "lodash";
import {Alert} from "@material-ui/lab";
import {ACCOUNT_RESPONSE_TO_REQUEST_MAP} from "../../_helpers";
import {dropDownService} from "../../_services/dropDown.service";
import {isAuthorized} from "../../_components";

class Account extends Component {
    constructor(props) {
        super(props);
        this.state = {
            loading: true,
            account: {
                addrLine2:'',
                custType:'',
            },
            dropdownValues: {
                stateCodes: [],
                countryCodes: [],
                serviceNames: [],
                custTypes: [],
            },
            formErrors: {
                cci: ""
            },
            saving: false,
            gettingAccount: false,
            showDeleteConfirm: false,
            showActivateConfirm: false,
            alert: '',
            ignoreFieldsUpdate: ["updateTime", "createTime", "accountId", "cci", "custId", "accountUri", "emailAddr1", "addrCity",],
            // ignoreFieldsCreate: ["updateTime", "createTime", "modBy", "accountId", "cci", "custId", "accountUri", "emailAddr1"]
            ignoreFieldsCreate: ["updateTime", "createTime", "modBy", "accountId", "custId", "accountUri", "emailAddr1"]


        };
        this.isComponentMounted = false;
        this.saveAccount = this.saveAccount.bind(this);
        this.updateAccountObj = this.updateAccountObj.bind(this);
        this.deleteAccount = this.deleteAccount.bind(this);
        this.getAccountForm = this.getAccountForm.bind(this);
        this.getDeleteConfirmDialog = this.getDeleteConfirmDialog.bind(this);
        this.getStatusConfirmDialog = this.getStatusConfirmDialog.bind(this);

        console.log(this.props, "this.props")

        if ((this.props.location.state === null || this.props.location.state === undefined || !this.props.location.state.showAlerts) && !_.isEmpty(this.props.alert)) {
            this.props.alertClear()
        }
    }

    saveAccount() {
        // const  accReqObj= _.pick(this.state.account,Object.keys(this.state.account).filter(field=>!this.state.ignoreFields.includes(field)))
        const errors = Object.values(this.state.formErrors).filter((val, index) => val != "")
        if (this.isComponentMounted) {
            this.setState({saving: true})
        }
        if (!this.state.account.addrLine2) {
            this.state.account.addrLine2 = null;
         //   this.state.account.addrLine2 = '';

        }
        if (this.props.isEmptyForm && this.props.isEditable) {
            const accReqObjCreate = _.pick(this.state.account, Object.keys(this.state.account).filter(field => !this.state.ignoreFieldsCreate.includes(field)))
            accReqObjCreate.custType =  accReqObjCreate.custType.split(":")[0] //splitting the code and name and  sending only code to api in th erequest to avoid sql exception .
            console.log(accReqObjCreate, "accReqObjCreate)")

            this.props.create(accReqObjCreate);

        } else {
            const accReqObjUpdate = _.pick(this.state.account, Object.keys(this.state.account).filter(field => !this.state.ignoreFieldsUpdate.includes(field)))
            this.props.update(accReqObjUpdate, this.props.match.params.id);
        }
        //   }

    }

    async getDropdownValues() {
        const stateResponse = await dropDownService.getByStates(this.state.stateCodes)
        const countryResponse = await dropDownService.getByCountries(this.state.countryCodes)
        const serviceResponse = await dropDownService.getByServiceNames(this.state.serviceNames)
        const custResponse = await dropDownService.getCustTypes(this.state.custTypes)

        if (stateResponse.success && countryResponse.success && serviceResponse.success && this.isComponentMounted) {
            this.setState({
                dropdownValues: {
                    stateCodes: stateResponse.states,
                    countryCodes: countryResponse.countries,
                    serviceNames: serviceResponse.services,
                    custTypes: custResponse.customers,
                }
            })
        }
    }

    async componentDidMount() {
        this.isComponentMounted = true;
        if (this.props.isEditable) {
            await this.getDropdownValues();
        }
        await this.getAccount();
        if (this.isComponentMounted) {
            this.setState({loading: false})
        }

    }

    validateField(name, value) {
        let errors = this.state.formErrors
        switch (name) {
            case "cci":
                //const isValid = /^[0-9.\/]{10}$/.test(value)
                const isValid = /^[0-9]*$/.test(value)//we are restricting  non-numeric digits here
                // const isValid = /^[0-9.\/]{1,10}*$/.test(value) //this will restrict to length of the digits as 10 not more than that
                //errors.cci = isValid ? "" : "cci should have '.' ,  10 digits(0-9) values"

                errors.cci = isValid ? "" : "cci  have upto 10 digits(0-9) values"
                break;

            default:
                break;
        }
        if (this.isComponentMounted) {
            this.setState({formErrors: errors})
        }

    }

    async getAccount() {
        if (!this.props.isEmptyForm && this.isComponentMounted) {
            this.setState({gettingAccount: true});
            this.isComponentMounted = true;
            const account = await accountService.getAccountById(this.props.match.params.id)
            if (this.isComponentMounted) {
                this.setState({account: account, gettingAccount: false});
            }
        }
    }

    deleteAccount() {
        if (this.isComponentMounted) {
            this.setState({showDeleteConfirm: false, loading: true})
        }
        this.props.delete(this.props.match.params.id);
    }

    componentWillUnmount() {
        this.isComponentMounted = false;
    }


    async componentWillUpdate(nextProps, nextState, nextContext) {
        //  if (nextProps.saved && this.state.loading) {

/*
        if (nextProps.saved && !_.isEqual(nextProps.account, this.state.account) && !_.isEmpty(nextProps.account)) {
            //  if (nextProps.saved && !_.isEqual(nextProps.zone, this.state.zone) && this.state.loading && !this.state.gettingZone && !nextState.gettingZone && (this.props.match.params.zoneType !== "primaryZone")) {
            this.setState({
                loading: false,
                account: nextProps.account
            })
        }
*/


        if (nextProps.saved && this.state.loading && !this.state.gettingAccount && !nextState.gettingAccount) {
            await this.getAccount();


        }
    }

    updateAccountObj(e) {

        let {name, value} = e.target;

        const {account} = this.state;
        if (ACCOUNT_RESPONSE_TO_REQUEST_MAP.hasOwnProperty(name)) {
            delete account[name];
            name = ACCOUNT_RESPONSE_TO_REQUEST_MAP[name]
        }
        if (name == "countryCode") {
            account.stateCode = ""
        }
        if (this.isComponentMounted) {
            this.setState({account: {...account, [name]: value}}, () => {
                this.validateField(name, value)
            })
        }
    }

    getAccountPageInfoElementsAndButtons() {
        let accountPageElements = {
            pageTitle: '',
            pageButtons: [],
        };


        if (this.props.isEditable && this.props.isEmptyForm) {
            accountPageElements.pageTitle = "DNS Accounts Insert Page"
            accountPageElements.pageButtons.push(<Button
                className={"dns-blue-button text-white  mr-2 text-center col-md-1"}
                onClick={this.saveAccount} key={"insert"}>Insert</Button>)

            accountPageElements.pageButtons.push(<Button
                className={"dns-blue-button text-white mr-2 text-center col-md-1"}
                onClick={() => this.props.history.push(`/dns/accounts/search`)}
                key={"cancel_insert"}>Cancel</Button>)
        } else if (this.props.isEditable && isAuthorized('au')) {
            accountPageElements.pageTitle = "DNS Account Update"
            accountPageElements.pageButtons.push(<Button className={"dns-blue-button text-white mr-2 col-md-1"}
                                                         onClick={this.saveAccount}
                                                         key={"update"}>Update</Button>)
            accountPageElements.pageButtons.push(<Button className={"dns-blue-button text-white mr-2 col-md-1"}

                                                         onClick={() => {
                                                             this.props.alertClear();

                                                             this.props.history.push(`/dns/accounts/details/${this.props.match.params.id}`)
                                                         }}//need to re-direct to search results page

                                                         key={"cancel_update"}>Cancel</Button>)


        } else {
            if (isAuthorized('ab')) {

                accountPageElements.pageTitle = "DNS Account Details"
                accountPageElements.pageButtons.push(<Button className={"dns-blue-button text-white mt-2 mr-4 mb-4"}
                                                             onClick={() => {
                                                                 this.props.alertClear();
                                                                 this.props.history.push(`/dns/accounts/edit/${this.props.match.params.id}`)
                                                             }}
                                                             key={"edit"}>Go To Update</Button>)

            }
            if (isAuthorized('ad')) {
                accountPageElements.pageButtons.push(<Button className={"dns-blue-button text-white mt-2 mr-4 mb-4"}
                                                             onClick={() => {
                                                                 this.props.alertClear();
                                                                 this.setState({showDeleteConfirm: true})
                                                             }} key={"delete"}>Delete</Button>)
            }


            accountPageElements.pageButtons.push(<Button className={"dns-blue-button text-white mt-2 mr-4 mb-4"}
                                                         onClick={() => {
                                                             this.setState({showActivateConfirm: true})
                                                         }} key={"account_status"}>{this.state.account.status == 'A' ?
                'Suspend' : 'Activate'}</Button>)
        }


        return accountPageElements;
    }

    getAccountForm() {
        const {account} = this.state
        let {pageButtons} = this.getAccountPageInfoElementsAndButtons();
        return <Form>
            {/*        {console.log(this.props.alert.type, "this.props.alert.type ")}
            {console.log(this.props.alert.message, "this.props.alert.message ")}*/}

            {this.props.alert.message &&
            <Alert severity={this.props.alert.type} className={"mb-3"}>{this.props.alert.message}</Alert>}
            <Form.Group as={Row} className={"align-items-center mb-2"}>
                <Form.Label column sm="2" className={"font-weight-bold"}>
                    CCI
                </Form.Label>
                <Col sm="2">
                    {this.props.isEditable ?
                        <>
                            <Form.Control name={"cci"} onChange={this.updateAccountObj}
                                //defaultValue={account.cci ? account.cci : ''}
                                          value={account.cci ? account.cci : ''}
                                          isInvalid={this.state.saving && this.state.formErrors.cci}
                                          required/>
                            <Form.Control.Feedback type="invalid">
                                {this.state.formErrors.cci}
                            </Form.Control.Feedback>
                        </>
                        : account.cci ? account.cci : ''}

                </Col>
                <Form.Label column sm="2" className={"font-weight-bold"}>
                    {this.props.isEditable ? "*" : ""}Account Type
                </Form.Label>
                <Col sm="2">
                    {this.props.isEmptyForm ?
                        <Form.Control as="select" name={"custType"}
                                      onChange={this.updateAccountObj}
                                      value={account.custType}>
                            <option value={""} key={0}>Select</option>
                            {this.state.dropdownValues.custTypes.map(state =>


                                /*<option value={state.code}
                                        key={state.name}>{state.code}</option>*/
                                <option value={(state.code + ":"+ state.name)}
                                        key={state.code + ":"+ state.name}>{state.code + " " + ":" + " " + state.name}</option>                                //  key={state.code}>{state.code + " " + ":" + " " + state.name}</option>

                            )}}</Form.Control> : account.custType}

                    {console.log(account.custType, "custtype")}

                </Col>
                <Form.Label column sm="2" className={"font-weight-bold"}>
                    {this.props.isEditable ? "*" : ""}Status
                </Form.Label>
                <Col sm="2">
                    {this.props.isEmptyForm ?
                        <Form.Control as="select" name={"status"}
                                      onChange={this.updateAccountObj}
                                      value={account.status}>
                            <option value={"A"}>A</option>
                            <option value={"S"}>S</option>
                        </Form.Control>
                        : account.status}
                </Col>
            </Form.Group>


            <Form.Group as={Row} className={"align-items-center mb-2"}>
                <Form.Label column sm="2" className={"font-weight-bold"}>
                    Service Account ID
                </Form.Label>
                <Col sm="2">
                    {this.props.isEditable ?
                        <Form.Control name={"srvAcctId"} onChange={this.updateAccountObj}
                                      defaultValue={account.srvAcctId ? account.srvAcctId : ''}/> : account.srvAcctId}
                </Col>
                {!this.props.isEmptyForm && <> <Form.Label column sm="2" className={"font-weight-bold"}>
                    Account ID </Form.Label>
                    <Col sm="2">
                        {account.accountId}
                    </Col></>}

                <Form.Label column sm="2" className={"font-weight-bold"}>
                    Customer ID
                </Form.Label>
                <Col sm="2">
                    {this.props.isEditable ?
                        <Form.Control name={"custId"}
                                     type="number" pattern="[0-9]*"
                                      onChange={this.updateAccountObj}
                                      defaultValue={account.custId ? account.custId : ''}/> : account.custId}

                </Col>
            </Form.Group>


            <Form.Group as={Row} className={"align-items-center mb-2"}>
                <Form.Label column sm="2" className={"font-weight-bold"}>
                    {this.props.isEditable ? "*" : ""}Service ID
                </Form.Label>
                <Col sm="2">

                    {this.props.isEditable ?
                        <Form.Control as="select" name={"serviceName"} onChange={this.updateAccountObj}
                                      value={account.serviceName}>
                            <option value={""}>Select</option>
                            {this.state.dropdownValues.serviceNames.map(state =>
                                <option value={state.code}
                                        key={state.code}>{state.code + " " + ":" + " " + state.name}</option>
                            )}}</Form.Control> : account.serviceName}
                </Col>
                <Form.Label column sm="2" className={"font-weight-bold"}>
                    {this.props.isEditable ? "*" : ""}Company
                </Form.Label>
                <Col sm="2 text-break">
                    {this.props.isEditable ?
                        <Form.Control name={"company"} onChange={this.updateAccountObj}
                                      defaultValue={account.company ? account.company : ''}/> : account.company}
                </Col>
            </Form.Group>

            {
                !this.props.isEditable && <Form.Group as={Row} className={"align-items-center mb-2"}>
                    <Form.Label column sm="2" className={"font-weight-bold"}>
                        Created
                    </Form.Label>
                    <Col sm="2">
                        {this.state.account.createTime}
                    </Col>
                    <Form.Label column sm="2" className={"font-weight-bold"}>
                        Last Modified
                    </Form.Label>
                    <Col sm="2">
                        {this.state.account.updateTime}
                    </Col>

                    {!this.props.isEditable && <>  <Form.Label column sm="2" className={"font-weight-bold"}>
                        Modified By
                    </Form.Label>
                        <Col sm="2">
                            {this.props.isEditable ?
                                <Form.Control name={"modBy"} onChange={this.updateAccountObj}
                                              defaultValue={account.modBy ? account.modBy : ''}/> : account.modBy}
                        </Col></>}
                </Form.Group>
            }

            <Form.Group as={Row} className={"align-items-center mb-2"}>
                <Form.Label column sm="2" className={"font-weight-bold"}>
                    {this.props.isEditable ? "*" : ""}First Name
                </Form.Label>

                <Col sm="2">
                    {this.props.isEditable ?
                        <Form.Control name={"fName"} onChange={this.updateAccountObj}
                                      defaultValue={account.FName ? account.FName : ''}/> : account.FName}
                </Col>
                <Form.Label column sm="2" className={"font-weight-bold"}>
                    Middle Name
                </Form.Label>
                <Col sm="2">
                    {this.props.isEditable ?
                        <Form.Control name={"mName"} onChange={this.updateAccountObj}
                                      defaultValue={account.mName ? account.mName : ''}/> : account.mName}
                </Col>

                <Form.Label column sm="2" className={"font-weight-bold"}>
                    {this.props.isEditable ? "*" : ""}Last Name
                </Form.Label>
                <Col sm="2">
                    {this.props.isEditable ?
                        <Form.Control name={"lName"} onChange={this.updateAccountObj}
                                      defaultValue={account.LName ? account.LName : ''}/> : account.LName}
                </Col>
            </Form.Group>

            <Form.Group as={Row} className={"align-items-center mb-2"}>
                <Form.Label column sm="2" className={"font-weight-bold"}>
                    {this.props.isEditable ? "*" : ""}Address1
                </Form.Label>
                <Col sm="2">

                    {this.props.isEditable ?
                        <Form.Control name={"addrLine1"} onChange={this.updateAccountObj}
                                      defaultValue={account.addrLine1 ? account.addrLine1 : ''}/> : account.addrLine1}
                </Col>
                <Form.Label column sm="2" className={"font-weight-bold"}>
                    Address2
                </Form.Label>
                <Col sm="2">
                    {this.props.isEditable ?
                        <Form.Control name={"addrLine2"} onChange={this.updateAccountObj}
                                      defaultValue={account.addrLine2 ? account.addrLine2 : ''}/> : account.addrLine2}
                </Col>


                <Form.Label column sm="2" className={"font-weight-bold"}>
                    {this.props.isEditable ? "*" : ""}City
                </Form.Label>
                <Col sm="2">
                    {this.props.isEditable ?
                        <Form.Control name={"addrCity"} onChange={this.updateAccountObj}
                                      defaultValue={account.addrCity ? account.addrCity : ''}/> : account.addrCity}
                </Col>
            </Form.Group>
            <Form.Group as={Row} className={"align-items-center mb-2"}>

                <Form.Label column sm="2" className={"font-weight-bold"}>
                    {this.props.isEditable ? "*" : ""}Country Code
                </Form.Label>
                <Col sm="2">
                    {this.props.isEditable ?
                        <Form.Control as="select" name={"countryCode"} onChange={this.updateAccountObj}
                                      value={account.countryCode}>
                            <option value={""} key={0}>Select</option>
                            {this.state.dropdownValues.countryCodes.map(country =>
                                <option value={country.code} key={country.code}>{country.name}</option>
                            )}
                        </Form.Control> : account.countryCode}
                </Col>


                <Form.Label column sm="2" className={"font-weight-bold"}>
                    State Code
                </Form.Label>
                <Col sm="2">
                    {this.props.isEditable ?
                        <Form.Control as="select" name={"stateCode"} onChange={this.updateAccountObj}
                                      value={account.stateCode} disabled={account.countryCode !== "US"}>
                            <option value={""} key={0}>Select</option>

                            {this.state.dropdownValues.stateCodes.map(state =>
                                <option value={state.code} key={state.code}>{state.name}</option>
                            )}</Form.Control> : account.stateCode}

                </Col>

                <Form.Label column sm="2" className={"font-weight-bold"}>
                    {this.props.isEditable ? "*" : ""}Zip Code
                </Form.Label>
                <Col sm="2">
                    {this.props.isEditable ?
                        <Form.Control name={"addrZip"} onChange={this.updateAccountObj}
                                      defaultValue={account.addrZip ? account.addrZip : ''}/> : account.addrZip}
                </Col>
            </Form.Group>
            <Form.Group as={Row} className={"align-items-center mb-2"}>
                <Form.Label column sm="2" className={"font-weight-bold"}>
                    Phone Country Code
                </Form.Label>
                <Col sm="2">
                    {this.props.isEditable ?
                        <Form.Control name={"phoneCountryCode"} onChange={this.updateAccountObj}
                                      defaultValue={account.phoneCountryCode ? account.phoneCountryCode : ''}/> : account.phoneCountryCode}

                </Col>
                <Form.Label column sm="2" className={"font-weight-bold"}>
                    Phone Number
                </Form.Label>
                <Col sm="2">
                    {this.props.isEditable ?
                        <Form.Control name={"phoneNum"} onChange={this.updateAccountObj}
                                      defaultValue={account.phoneNum ? account.phoneNum : ''}/> : account.phoneNum}

                </Col>
                <Form.Label column sm="2" className={"font-weight-bold"}>
                    Phone Extension
                </Form.Label>
                <Col sm="2">
                    {this.props.isEditable ?
                        <Form.Control name={"XTel"} onChange={this.updateAccountObj}
                                      defaultValue={account.XTel ? account.XTel : ''}/> : account.XTel}

                </Col>
            </Form.Group>
            <Form.Group as={Row} className={"align-items-center mb-2"}>
                <Form.Label column sm="2" className={"font-weight-bold"}>
                    G.Qualifier
                </Form.Label>
                <Col sm="2">
                    {this.props.isEditable ?
                        <Form.Control name={"gqual"} onChange={this.updateAccountObj}
                                      defaultValue={account.gqual ? account.gqual : ''}/> : account.gqual}
                </Col>
                <Form.Label column sm="2" className={"font-weight-bold"}>
                    Fax Country Code
                </Form.Label>
                <Col sm="2">
                    {this.props.isEditable ?
                        <Form.Control name={"faxCountryCode"} onChange={this.updateAccountObj}
                                      defaultValue={account.faxCountryCode ? account.faxCountryCode : ''}/> : account.faxCountryCode}
                </Col>
                <Form.Label column sm="2" className={"font-weight-bold"}>
                    Fax Number
                </Form.Label>
                <Col sm="2">
                    {this.props.isEditable ?
                        <Form.Control name={"faxNum"} onChange={this.updateAccountObj}
                                      defaultValue={account.faxNum ? account.faxNum : ''}/> : account.faxNum}
                </Col>
            </Form.Group>
            <Form.Group as={Row} className={"align-items-center mb-2"}>
                <Form.Label column sm="2" className={"font-weight-bold"}>
                    E-Mail Address
                </Form.Label>
                <Col sm="2">
                    {this.props.isEditable ?
                        <Form.Control name={"emailAddr1"} onChange={this.updateAccountObj}
                                      defaultValue={account.emailAddr1 ? account.emailAddr1 : ''}/> : account.emailAddr1}

                </Col>
                <Form.Label>

                </Form.Label>
                <Col>

                </Col>
                <Form.Label column sm="2" className={"font-weight-bold"}>
                    Comment
                </Form.Label>
                <Col sm="2">
                    {this.props.isEditable ?
                        <Form.Control name={"comments"} onChange={this.updateAccountObj}
                                      defaultValue={account.comments ? account.comments : ''}/> : account.comments}

                </Col>
            </Form.Group>
            <div className={"text-center mt-1"}>
                {pageButtons.map(buttonComp => buttonComp)}
            </div>
            {/*      {
                this.props.isAccountEditable &&*/}

            <em>
                Those entries marked with * must be provided<br></br>

                State drop down is for US only and will be ignored for non-US countries
            </em>
        </Form>


    }

    getDeleteConfirmDialog() {
        return !this.props.isEditable && <Dialog
            onClose={(event, reason) => {
                if (reason === 'backdropClick' || reason === 'escapeKeyDown') {
                    return false;
                }
            }}
            maxWidth="xs"
            aria-labelledby="confirmation-dialog-title"
            open={this.state.showDeleteConfirm}
        >
            <DialogTitle id="confirmation-dialog-title">Are you sure you want to delete this
                account?</DialogTitle>

            <DialogActions>
                <Button autoFocus onClick={this.deleteAccount} className={"dns-blue-button text-white"}>
                    Delete
                </Button>
                <Button onClick={() => this.setState({showDeleteConfirm: false})}
                        className={"dns-blue-button text-white"}>
                    Cancel
                </Button>
            </DialogActions>
        </Dialog>
    }

    getStatusConfirmDialog() {
        const {account} = this.state
        return !this.props.isEditable && <Dialog
            onClose={(event, reason) => {
                if (reason === 'backdropClick' || reason === 'escapeKeyDown') {
                    return false;
                }
            }}
            maxWidth="lg"
            aria-labelledby="confirmation-activate-dialog-title"
            open={this.state.showActivateConfirm}
        >
            <DialogTitle id="confirmation-activate-dialog-title">
                <b>Are you sure you want to {this.state.account.status === 'A' ? 'suspend' : 'activate'} this
                    account?</b>
            </DialogTitle>
            {/*  <DialogContent>
                <span><b>NOTICE:</b>Please check the account status below before you click the 'Execute' button.</span>
            </DialogContent>*/}
            <DialogContent>
                <div>
                    <span className={'font-weight-bold  mr-2'}>Account ID</span>: {account.accountId} <br/>
                    {/* <span className={'font-weight-bold'}>Modified</span>: {account.modBy + '' + account.updateTime}*/}
                    <span className={'font-weight-bold  mr-2'}>Modified By</span>: {account.modBy}<br/>
                    <span className={'font-weight-bold  mr-2'}>Last Modified Time </span>: {account.updateTime}<br/>
                    <span className={'font-weight-bold  mr-2'}>Status</span>: {account.status}
                </div>
            </DialogContent>
            <DialogActions>
                <Button onClick={() => {
                    this.setState({
                            loading: true,
                            showActivateConfirm: false
                        }, () => this.props.updateStatus(account.accountId, this.state.account.status === 'A' ? 'S' : 'A')
                    )

                    /*        this.setState({loading: true, showActivateConfirm: false}

                            this.props.updateStatus(account.accountId, this.state.account.status === 'A' ? 'S' : 'A')*/
                }} className={"dns-blue-button text-white"}>
                    Execute
                </Button>
                <Button onClick={() => this.setState({showActivateConfirm: false})}
                        className={"dns-blue-button text-white"}>
                    Cancel
                </Button>
            </DialogActions>
        </Dialog>
    }

    componentWillUnmount() {
        this.isComponentMounted = false;
    }

    render() {
        let {pageTitle} = this.getAccountPageInfoElementsAndButtons();

        if ((_.isEmpty(this.state.account) && !this.props.isEmptyForm) && !this.state.loading) {

            //  if (_.isEmpty(this.state.account) && (!this.state.loading)) {

            return <div>Loading....</div>
        }
        return (
            <>
                {this.getDeleteConfirmDialog()}
                {this.getStatusConfirmDialog()}
                <Backdrop className={"page-loading"} style={{'zIndex': '10000', 'color': '#fff'}}
                          open={this.state.loading && (this.props.saving == true)}>
                    <CircularProgress color="inherit"/>
                </Backdrop>
                <div>
                    <Helmet>
                        <title>DNS Accounts | Accounts</title>
                    </Helmet>
                    {/*  {this.props.isAccountEditable && <Dialog
    open={this.state.alertBox.show}
    onClose={() => {
    this.setState({alertBox: {show: !alertBox.show}})
    }}
    aria-labelledby="alert-dialog-title"
    aria-describedby="alert-dialog-description"
    >
    The Account record has been successfully updated </Dialog>}*/}
                    <Container className={"pl-1 pr-1"}>
                        <Card>
                            <CardContent>
                                <div className={'mt-2 ml-2 mr-3 mb-2'}>
                                    <h5 className="font-weight-bold  text-capitalize text-left mt-4 ml-5">{pageTitle}
                                    </h5>
                                    <div className="pt-3 pl-5">
                                        {this.getAccountForm()}
                                    </div>
                                </div>
                            </CardContent>
                        </Card>


                    </Container>
                </div>
            </>
        )
    }


}

Account.defaultProps = {
    isEditable: false,
};
Account.propTypes = {
    isEditable: PropTypes.bool.isRequired,
    isEmptyForm: PropTypes.bool

};

function mapState(state) {
    const {saving, saved, deleted} = state.accounts

    const {alert} = state
    return {saving, saved, deleted, alert}

}

const actionCreators = {
    create: accountActions.create,
    update: accountActions.update,
    delete: accountActions.delete,
    alertClear: alertActions.clear,
    updateStatus: accountActions.updateStatus
};


const connectedAccount = withRouter(connect(mapState, actionCreators)(Account));
export {connectedAccount as Account};


