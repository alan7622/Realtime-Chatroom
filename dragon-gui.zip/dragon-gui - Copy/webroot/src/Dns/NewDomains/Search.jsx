import React from "react";
import {alertActions, zoneActions} from '../../_actions';
import {connect} from "react-redux";
import {
    CardContent,
    Card,
    Menu,
    MenuItem,
    Dialog,
    Button,
    DialogTitle,
    DialogContent,
    DialogActions, Link, FormControl, Select, TextField, InputLabel, RadioGroup, FormControlLabel, Radio
} from "@material-ui/core";
import {Helmet} from "react-helmet";
import Container from "@material-ui/core/Container";
import BootstrapTable from 'react-bootstrap-table-next';
import filterFactory, {Comparator, textFilter} from 'react-bootstrap-table2-filter';
import _ from "lodash";
import {Alert} from "@material-ui/lab";
import {newDomainService} from "../../_services/newDomain.service";
import paginationFactory from 'react-bootstrap-table2-paginator';
import {AddDomainHelper, HistoryLogHelper, Utility} from "../../_helpers";
import {pageRenderer, SizePerPageRenderer} from "../../_components";
import Form from "react-bootstrap/Form";
import {Col, Row} from "react-bootstrap";
import {zoneService} from '../../_services';

const defaultFilters = {
    userName: {comparator: 'Eq', value: ''},
    zoneName: {comparator: 'Eq', value: ''},
    order: {
        by: "zoneName",
        dir: "asc"
    }
}

class Search extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            data: [],
            //   page: 1,
            loading: true,
            openPgMenu: null,
            comparator: Comparator.EQ,
            addDomainSearchParams: {},
            showZoneInfoDialog: false,
            showDeleteConfirm: false,
            showAdvanceSearch: false,
            page: 1,
            sizePerPage: 10,
            totalSize: 0,
            error:'',
            filters: _.cloneDeep(defaultFilters),
            zoneSelected: {
                zoneName: "",
                zoneNum: "",
                modBy: "",
                accountId: "",
                serviceName: "",
                zoneSubType: "",
                updateTime: ""
            }
        }
        this.isComponentMounted = false;
        this.handleNewDomainTableChange = this.handleNewDomainTableChange.bind(this)
        this.paginationOptions = this.paginationOptions.bind(this)
        this.getZoneInfoDialog = this.getZoneInfoDialog.bind(this)
        this.getAdvanceSearchDialog = this.getAdvanceSearchDialog.bind(this)
        this.handleFilterChange = this.handleFilterChange.bind(this);


        if ((this.props.location.state === null || this.props.location.state === undefined || !this.props.location.state.showAlerts) && !_.isEmpty(this.props.alert)) {
            this.props.alertClear()
        }
    }


    async componentDidMount() {
        this.isComponentMounted = true;
        const params = {}
        await this.loadTableData(params)
    }

    async loadTableData(params) {
        this.setState({loading: true});
        for (var key in this.state.filters) {
            if (this.state.filters.hasOwnProperty(key) &&
                this.state.filters[key].value) {
                params[key +
                this.state.filters[key].comparator] = this.state.filters[key].value;
            }
        }

        const res = await newDomainService.getDomains(params);
        if (this.isComponentMounted) {
            this.setState({loading: false, data: res.addDomain,error: res.success ? '' : res.error,
                showZoneInfoDialog: false});
        }
    }

    componentWillUnmount() {
        this.isComponentMounted = false;
    }

    handleFilterChange(e) {
        const {name, value} = e.target;
        const {filters} = this.state;
        const filterInfo = name.split('.');
        filters[filterInfo[0]][filterInfo[1]] = value;
        this.setState({filters: filters});
    }


    getNewDomainTableColumns() {
        const {classes} = this.props;
        return [
            {
                dataField: 'createTime',
                text: 'Created',
                classes: 'text-center p-0',
                headerAlign: 'center',
                headerStyle: {
                    width: "15%"
                },
                style: {
                    'wordWrap': 'break-word'
                },

            },
            {
                dataField: 'zoneNum',
                text: 'ZoneID',
                classes: 'text-center p-0',
                headerAlign: 'center',
                headerStyle: {
                    width: "10%"
                },
                style: {
                    'wordWrap': 'break-word'
                },
                formatter: (cell, row, rowIndex) => <Link onClick={async (e) => {
                    e.preventDefault();
                    const res = await zoneService.getZoneById(cell);
                    this.setState({showZoneInfoDialog: true, zoneSelected: res.zone})
                }}> {cell}</Link>
            },
            {
                dataField: 'zoneName',
                text: 'Zone Name',
                // filter: textFilter({placeholder: 'Search'}),
                sort: true,
                classes: 'text-center p-0',
                headerAlign: 'center',
                headerStyle: {
                    width: "20%"
                },
                style: {
                    'wordWrap': 'break-word'
                },
            },

            {
                dataField: 'modBy',
                text: 'Modified By',
                // filter: textFilter({placeholder: 'Search'}),
                sort: true,
                classes: 'text-center p-0',
                headerAlign: 'center',
                headerStyle: {
                    width: "15%"
                },
                style: {
                    'wordWrap': 'break-word'
                },
            },
            {
                dataField: 'code',
                text: 'Status',
                // filter: textFilter({placeholder: 'Search', comparator: Comparator.EQ}),
                classes: 'text-center p-0',
                headerAlign: 'center',
                headerStyle: {
                    width: "10%"
                },
                style: {
                    'wordWrap': 'break-word'
                },

            },

            {
                dataField: 'lastcode',
                text: 'Last Status',
                classes: 'text-center p-0',
                headerAlign: 'center',
                headerStyle: {
                    width: "10%"
                },
                style: {
                    'wordWrap': 'break-word'
                },
            },
            {
                dataField: 'deadline',
                text: 'Deadline',
                classes: 'text-center p-0',
                headerAlign: 'center',
                headerStyle: {
                    width: "10%"
                },
                style: {
                    'wordWrap': 'break-word'
                },
            },

            {
                dataField: 'registrant',
                text: 'Registrant',
                classes: 'text-center p-0',
                headerAlign: 'center',
                headerStyle: {
                    width: "10%"
                },
                style: {
                    'wordWrap': 'break-word'
                },
            },


        ];
    }


    paginationOptions() {
        return {
            sizePerPage: this.state.sizePerPage,
            page: this.state.page,
            totalSize: this.state.totalSize,
            alwaysShowAllBtns: true,
            withFirstAndLast: true,
            firstPageText: 'First',
            prePageText: 'Back',
            nextPageText: 'Next',
            lastPageText: 'Last',
            nextPageTitle: 'First page',
            prePageTitle: 'Pre page',
            firstPageTitle: 'Next page',
            lastPageTitle: 'Last page',
            showTotal: false,
            sizePerPageList: [
                {
                    text: '10', value: 10
                }, {
                    text: '20', value: 20
                },
                {
                    text: '50', value: 50
                },],
            pageButtonRenderer: pageRenderer,
            sizePerPageRenderer: ({
                                      options,
                                      currSizePerPage,
                                      onSizePerPageChange
                                  }) => <SizePerPageRenderer options={options}
                                                             currSizePerPage={currSizePerPage}
                                                             onSizePerPageChange={onSizePerPageChange}/>,
            disablePageTitle: true,
        };
    }


    async handleNewDomainTableChange(type, {filters, sortField, sortOrder, page, sizePerPage, totalSize}) {
        let addDomainSearchParams = {}
        if (type === 'sort') {
            addDomainSearchParams.OrderDir = sortOrder;
            addDomainSearchParams.OrderBy = sortField;
        } else if (type === 'filter') {
            if (_.isEmpty(filters)) {
                addDomainSearchParams = {}
            }
            for (const [columnField, colFilterInfo] of Object.entries(filters)) {
                let comparator = colFilterInfo.comparator
                let value = colFilterInfo.filterVal
                if (_.isObject(value) && value.hasOwnProperty('comparator')) {
                    value = colFilterInfo.filterVal.value
                    comparator = colFilterInfo.filterVal.comparator

                }
                if (value == "") {
                    continue;
                }

                switch (comparator) {
                    case Comparator.EQ:
                        addDomainSearchParams[`${(columnField)}Eq`] = value
                        break;
                    case Comparator.LIKE:
                        addDomainSearchParams[`${(columnField)}Contains`] = value
                        break;
                    case Comparator.GT:
                        addDomainSearchParams[`${(columnField)}Beg`] = value
                        break;
                    default:
                        addDomainSearchParams[`${(columnField)}${Utility.ucFirst(comparator)}`] = value
                        break;

                }


            }
        }

        await this.loadTableData(addDomainSearchParams);
    }


    getZoneInfoDialog() {
        const {zoneSelected} = this.state

        return <Dialog
            onClose={(event, reason) => {
                if (reason === 'backdropClick' || reason === 'escapeKeyDown') {
                    return false;
                }
            }}
            maxWidth="lg"
            aria-labelledby="confirmation-activate-dialog-title"
            open={this.state.showZoneInfoDialog}
        >
            <DialogTitle>
                <b>Zone Deletion</b>
            </DialogTitle>

            <DialogContent>
                <Row><Col className={'font-weight-bold'}>Zone ID</Col><Col>{zoneSelected.zoneNum}</Col></Row>
                <Row><Col className={'font-weight-bold'}>Zone Name</Col><Col>{zoneSelected.zoneName}</Col></Row>
                <Row><Col className={'font-weight-bold'}>Type of
                    Service</Col><Col>{zoneSelected.zoneSubType}</Col></Row>
                <Row><Col className={'font-weight-bold'}>Service ID</Col><Col>{zoneSelected.serviceName}</Col></Row>
                <Row><Col className={'font-weight-bold'}>Account ID</Col><Col>{zoneSelected.accountId}</Col></Row>
                <Row><Col className={'font-weight-bold'}>Last Modified</Col><Col>{zoneSelected.updateTime}</Col></Row>
                <Row><Col className={'font-weight-bold'}>Modified By</Col><Col>{zoneSelected.modBy}</Col></Row>

                <p className={"mt-3"}>Deleting the Zone will automatically delete all DNS resource records under this
                    zone. Please be sure!
                </p>
            </DialogContent>
            <DialogActions>

                <Button color="primary" className={'dns-blue-button text-white'}
                        onClick={async () => {
                            this.setState({showDeleteConfirm: false, loading: true});
                            await zoneService.deleteZone(zoneSelected.zoneNum);
                            await this.loadTableData({})
                        }}
                >
                    Delete Zone
                </Button>
                <Button onClick={() => this.setState({showZoneInfoDialog: false})}
                        color="primary" className={'dns-blue-button text-white'}>
                    Close
                </Button>
            </DialogActions>
        </Dialog>
    }

    getAdvanceSearchDialog() {
        return <Dialog
            fullWidth={true}
            onClose={(event, reason) => {
                if (reason === 'backdropClick' || reason === 'escapeKeyDown') {
                    return false;
                }
            }}
            maxWidth="lg"
            open={this.state.showAdvanceSearch}>
            <DialogTitle id="form-dialog-title"><b>DNS New Domains Search</b></DialogTitle>

            <DialogContent>
                <Form>
                    <Form.Group as={Row} className={'align-items-center'}>
                        <Form.Label column sm="2" className={'font-weight-bold'}>
                            Zone Name
                        </Form.Label>
                        <Col sm={2}>
                            <FormControl variant="outlined">
                                <InputLabel htmlFor="wildcard-company-search">Zone
                                    Name</InputLabel>
                                <Select
                                    autoWidth={true}
                                    className={'w-100'}
                                    name={'zoneName.comparator'}
                                    value={this.state.filters.zoneName.comparator}
                                    onChange={this.handleFilterChange}
                                    label="Zone Name"
                                >
                                    {AddDomainHelper.getZoneNameComparators.map(obj => (
                                        <MenuItem value={obj.value}
                                                  key={obj.value}>{obj.label}</MenuItem>
                                    ))}

                                </Select>
                            </FormControl>
                        </Col>
                        <Col sm={4}>
                            <Form.Control name={'zoneName.value'}
                                          defaultValue={this.state.filters.zoneName.value}
                                          onChange={this.handleFilterChange}
                            />
                        </Col>

                    </Form.Group>
                    <Form.Group as={Row} className={'align-items-center'}>
                        <Form.Label column sm="2" className={'font-weight-bold'}>
                            User Id
                        </Form.Label>


                        <Col sm={2}>
                            <FormControl variant="outlined">
                                <InputLabel htmlFor="wildcard-company-search">User Id</InputLabel>
                                <Select
                                    autoWidth={true}
                                    className={'w-100'}
                                    name={'userName.comparator'}
                                    value={this.state.filters.userName.comparator}
                                    onChange={this.handleFilterChange}
                                    label="User Id"
                                >
                                    {AddDomainHelper.getUserIdComparators.map(obj => (
                                        <MenuItem value={obj.value}
                                                  key={obj.value}>{obj.label}</MenuItem>
                                    ))}

                                </Select>
                            </FormControl>
                        </Col>
                        <Col sm={2}>
                            <Form.Control name={'userName.value'}
                                          defaultValue={this.state.filters.userName.value}
                                          onChange={this.handleFilterChange}
                            />
                        </Col>

                        {/*    <Col sm={4}>
                            <Form.Control name={'userName.value'}
                                          value={this.state.filters.userName.value}
                                          onChange={this.handleFilterChange}/>
                        </Col>*/}
                    </Form.Group>

                    <Form.Group as={Row} className={"align-items-center"}>
                        <Form.Label column sm="3" className={'font-weight-bold'}>
                            Ordered By </Form.Label>
                        <Col sm={9}>
                            <RadioGroup value={this.state.filters.order.by} name={"order.by"}
                                        onChange={this.handleFilterChange} row={true}>

                                <FormControlLabel value="zoneName"
                                                  control={<Radio color="primary"/>}
                                                  label="Zone Name"/>
                                <FormControlLabel value="userName"
                                                  control={<Radio color="primary"/>}
                                                  label="User Name"/>

                            </RadioGroup>
                        </Col>
                    </Form.Group>
                    <Form.Group as={Row} className={"align-items-center"}>
                        <Form.Label column sm="3" className={'font-weight-bold'}>
                            Ordered Direction </Form.Label>
                        <Col sm={9}>
                            <RadioGroup value={this.state.filters.order.dir} name={"order.dir"}
                                        onChange={this.handleFilterChange} row={true}>

                                <FormControlLabel value="asc"
                                                  control={<Radio color="primary"/>}
                                                  label="Ascending"/>
                                <FormControlLabel value="desc" control={<Radio color="primary"/>}
                                                  label="Descending"/>


                            </RadioGroup>
                        </Col>
                    </Form.Group>

                </Form>
            </DialogContent>

            <DialogActions>
                <Button onClick={async (e) => {
                    await this.loadTableData({numberOfRows: this.state.sizePerPage, pageNumber: this.state.page});
                    this.setState(
                        {showAdvanceSearch: false});
                }
                } color="primary" className={'dns-blue-button text-white'}
                >
                    Search
                </Button>
                <Button onClick={() => this.setState(
                    {showAdvanceSearch: false})}
                        color="primary" className={'dns-blue-button text-white'}>
                    Close
                </Button>
                <Button type={"reset"} onClick={() => {
                    this.setState({filters: _.cloneDeep(defaultFilters)}, () => {
                        console.log(defaultFilters, "defaultFilters");
                        console.log(this.state, "STATE");
                        this.loadTableData({numberOfRows: 10, pageNumber: 1})
                    });
                }} variant="contained"
                        className={"dns-blue-button text-white ml-2"}
                        disabled={JSON.stringify(this.state.filters) === JSON.stringify(defaultFilters)}>clear</Button>

            </DialogActions>


        </Dialog>
    }


    render() {
        const {classes} = this.props;
        const paginationOptions = this.paginationOptions();
        const {loading, data} = this.state;
        const columns = this.getNewDomainTableColumns();

        return (

            <div>
                <Helmet>
                    <title>DNS New Domains | DNS Admin</title>
                </Helmet>
                {this.getZoneInfoDialog()}

                <Container className={"pl-1 pr-1"}>
                    <Card>
                        <CardContent className={"px-0"}>
                            <div className={'mt-3 ml-3 mr-3 mb-3'}>

                                <h5 className="font-weight-bold  text-capitalize text-left pt-1 pl-2">DNS New
                                    Domains List Page
                                </h5>
                                {this.getAdvanceSearchDialog()}

                                <div className={'col text-right mt-2 mb-2'}>
                                    <Button aria-controls="simple-menu"
                                            aria-haspopup="true"
                                            color="primary"
                                            className={'dns-blue-button'}
                                            variant={'contained'}
                                            onClick={() => {
                                                this.setState(
                                                    {showAdvanceSearch: true});
                                            }} key={'advance_search'}>Search</Button>
                                    {(JSON.stringify(this.state.filters) !== JSON.stringify(defaultFilters)) &&
                                    <Button type={"reset"} onClick={() => {
                                        this.setState({filters: _.cloneDeep(defaultFilters)}, () => {
                                            this.loadTableData({numberOfRows: 10, pageNumber: 1})
                                        });
                                    }} variant="contained"
                                            className={"dns-blue-button text-white ml-2"}


                                    >clear</Button>
                                    }

                                </div>
                                <div className={"pb-2"}>
                                    {/*{this.props.alert.message && <Alert
                                        severity={this.props.alert.type}>{this.props.alert.message}</Alert>}*/}
                                    {(!_.isEmpty(this.state.error) || !_.isEmpty(this.props.alert.message)) &&
                                    <Alert
                                        severity={!_.isEmpty(this.state.error) ? "error" : this.props.alert.type}>{(this.state.error && this.state.error.text) || this.props.alert.message}</Alert>}

                                </div>

                                <div className="pl-2 pr-2 mt-2">

                                    <BootstrapTable bootstrap4
                                                    keyField="zoneNum"
                                                    data={data}
                                                    remote={{
                                                        pagination: true,
                                                    }}
                                                    onTableChange={this.handleNewDomainTableChange}
                                                    columns={columns}
                                                    filter={filterFactory()}
                                                    filterPosition={"top"}
                                                    pagination={paginationFactory(paginationOptions)}
                                                    id={"newDomain_table"}
                                                    striped
                                                    hover
                                                    condensed

                                    />
                                </div>
                                <div className={"mt-3"}>
                                    <p>
                                        Explanation of Status and Last Status Values</p>

                                    <p>
                                        Status shows the results of the DNS query for the NS records of the domain name
                                        when
                                        the domain was added by the DPT user. Last Status shows the most recent DNS
                                        query
                                        results from the daily audit program. Domains that do not have a Last Status of
                                        6
                                        are automatically deleted by the audit program once they reach the deadline.</p>

                                    <p> Values: </p>
                                    <p>1.DNS query on the domain name timed out.</p>
                                    <p>2.The domain name is not registered (DNS query returned NXDOMAIN).</p>
                                    <p>3.The domain name exists, but has no nameserver records assigned. (DNS query
                                        returned
                                        NOERROR).</p>
                                    <p>4.The domain name exists and has one or more nameserver records, but the
                                        nameserver
                                        records do not include all the AT&T nameserver records assigned to the domain in
                                        the
                                        DRAGON database.</p>
                                    <p>5.DNS query on the domain name returned an error.</p>
                                    <p>6.The domain name exists and has nameserver records that include all the AT&T
                                        nameserver records assigned to the domain in the DRAGON database.</p>
                                </div>
                            </div>

                        </CardContent>
                    </Card>
                </Container>
            </div>

        );
    }
}


function mapState(state) {
    const {alert} = state
    return {alert}
}

const actionCreators = {
    alertClear: alertActions.clear,
}

const connectedNewDomain = connect(mapState, actionCreators)(Search);
export {connectedNewDomain as Search};