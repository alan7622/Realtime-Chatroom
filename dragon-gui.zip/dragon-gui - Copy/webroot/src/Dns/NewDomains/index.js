export {Search as NewDomainSearch} from './Search';

