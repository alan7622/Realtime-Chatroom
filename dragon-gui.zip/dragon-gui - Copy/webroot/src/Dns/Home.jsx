import {DragonRoute, Layout, ZoneSuspendMenu} from "../_components";
import {Route, Switch, matchPath} from "react-router-dom";
import {Account, AccountSearch} from "./Accounts";
import Container from "@material-ui/core/Container";
import {Paper} from "@material-ui/core";
import Box from "@material-ui/core/Box";
import Typography from "@material-ui/core/Typography";
import React, {useState} from "react";
import {Helmet} from "react-helmet";
import {AccountMenu, DnsAdminMenu, ZoneMenu} from "../_components";
import {ZoneSearch, Zone, ZonePTR, ZoneDelegation} from "./Zones";
import {connect, useStore} from "react-redux";
import {HistoryLogSearch} from "../Common/HistoryLogs";
import {NewDomainSearch} from "./NewDomains";
import {ListAllRecords} from "./Zones/ResourceRecords/ListAll-Records";
import {
    TransferZone
} from "../Common/AccountDelegations";
import {
    Delegation,
    DelegationSearch,
} from "../Common/ZoneDelegations/ZoneDelagationList";
import {DelegationNameserver, DelegationNameserverSearch} from "../Common/ZoneDelegations/ZoneDelegationNameServers";
import {XferIPv4Acl} from "./Zones/ZoneTransfers/ZoneTransferIPV4Acl";
import {store} from "../_helpers";
import {AccountDelegations, AccountDelegationsSearch} from "../Common/AccountDelegations/Delegations";
import {AccountDelegationNS, AccountDelegationNSSearch} from "../Common/AccountDelegations/DelegationNS";
import {zoneActions} from "../_actions";
import {XferIPv6Acl} from "./Zones/ZoneTransfers/ZoneTransferIPV6Acl";
import {SlaveNameServer} from "./Zones/Servers/Non-Att-NameServers";


const {Component} = require("react");

class Home extends Component {
    constructor(props) {
        super(props);
        this.state = {
            loading: true,
            user: {},
            menuItems: null,
            alertBox: {
                show: false,
                text: '',
                type: ''
            }
        };
        this.isComponentMounted = false;
        this.getMenu = this.getMenu.bind(this)
    }

    componentDidMount() {
        this.isComponentMounted = true;
        if (this.isComponentMounted) {
            this.getMenu()
        }

    }

//Used this to clear or add the RR's and Servers on home/dns screen but delete screen hides message successful fails
    componentDidUpdate(prevProps, prevState, snapshot) {
        if (prevProps.location.pathname != this.props.location.pathname) {
            this.getMenu()
        }
    }

    componentWillUnmount() {
        this.isComponentMounted = false;
    }

    getMenu() {
        const reduxStore = store.getState()
        let match;
        if (matchPath(this.props.location.pathname, "/dns/accounts/details/:id")) {
            this.setState({menuItems: AccountMenu})
        }
        else if (match = matchPath(this.props.location.pathname, {
            path: "/dns/zones/search/details/:id/zoneDelegation",
            exact: true
        })) {
            const {id} = match.params
            if (!reduxStore.zones.hasOwnProperty('zone')) {
                this.props.getZoneById(id)
            }
            let menuItems = ZoneSuspendMenu;
            if (reduxStore.zones.zone?.zoneStatus === 'A') {
                menuItems = ZoneMenu
            }
            if (reduxStore.zones.zone?.zoneType === 'S') {
                menuItems = menuItems.filter(m => !["Resource Records", "Delegation Under this Zone", "List All Records"].includes(m.label))
            }
            /* if (reduxStore.zones.zone?.pathname === '/dns/zones/details/:id/zoneDelegation') {
                 menuItems = menuItems.filter(m => !["List All Records"].includes(m.label))
             }*/
            this.setState({menuItems})
        } else if (match = matchPath(this.props.location.pathname, {
            path: "/dns/zones/search/details/:id/zoneDelegation/:delegationId",
            exact: true
        })) {
            const {id} = match.params
            if (!reduxStore.zones.hasOwnProperty('zone')) {
                this.props.getZoneById(id)
            }
            let menuItems = ZoneSuspendMenu;
            if (reduxStore.zones.zone?.zoneStatus === 'A') {
                menuItems = ZoneMenu
            }
            if (reduxStore.zones.zone?.zoneType === 'S') {
                menuItems = menuItems.filter(m => !["Resource Records", "Delegation Under this Zone", "List All Records"].includes(m.label))
            }
            /* if (reduxStore.zones.zone?.pathname === '/dns/zones/details/:id/zoneDelegation') {
                 menuItems = menuItems.filter(m => !["List All Records"].includes(m.label))
             }*/
            this.setState({menuItems})
        } else if (match = matchPath(this.props.location.pathname, {
            path: "/dns/zones/search/details/:id/zoneDelegation/:delegationId/delg/nameserver",
            exact: true
        })) {
            const {id} = match.params
            if (!reduxStore.zones.hasOwnProperty('zone')) {
                this.props.getZoneById(id)
            }
            let menuItems = ZoneSuspendMenu;
            if (reduxStore.zones.zone?.zoneStatus === 'A') {
                menuItems = ZoneMenu
            }
            if (reduxStore.zones.zone?.zoneType === 'S') {
                menuItems = menuItems.filter(m => !["Resource Records", "Delegation Under this Zone", "List All Records"].includes(m.label))
            }
            /* if (reduxStore.zones.zone?.pathname === '/dns/zones/details/:id/zoneDelegation') {
                 menuItems = menuItems.filter(m => !["List All Records"].includes(m.label))
             }*/
            this.setState({menuItems})
        } else if (match = matchPath(this.props.location.pathname, {
            path: "/dns/zones/search/details/:id/zoneDelegation/:delegationId/delg/nameserver/:recId",
            exact: true
        })) {
            const {id} = match.params
            if (!reduxStore.zones.hasOwnProperty('zone')) {
                this.props.getZoneById(id)
            }
            let menuItems = ZoneSuspendMenu;
            if (reduxStore.zones.zone?.zoneStatus === 'A') {
                menuItems = ZoneMenu
            }
            if (reduxStore.zones.zone?.zoneType === 'S') {
                menuItems = menuItems.filter(m => !["Resource Records", "Delegation Under this Zone", "List All Records"].includes(m.label))
            }
            /* if (reduxStore.zones.zone?.pathname === '/dns/zones/details/:id/zoneDelegation') {
                 menuItems = menuItems.filter(m => !["List All Records"].includes(m.label))
             }*/
            this.setState({menuItems})
        }
        else if (match = matchPath(this.props.location.pathname, {path: "/dns/zones/search/details/:id",})) {
            console.log(match,"match")
            const {id} = match.params
            if (!reduxStore.zones.hasOwnProperty('zone')) {
                this.props.getZoneById(id)
            }
            var menuItems1 = _.cloneDeep(ZoneSuspendMenu);
            if (reduxStore.zones.zone?.zoneStatus === 'A') {
                menuItems1 = _.cloneDeep(ZoneMenu)
            }

            if (reduxStore.zones.zone?.zoneType === 'S') {
                menuItems1[5].children = menuItems1[5].children.filter(c => c.label != 'Non ATT Name Servers')
                menuItems1 = menuItems1.filter(m => !["Resource Records", "Delegation Under this Zone", "List All Records"].includes(m.label))
            } else if (reduxStore.zones.zone?.zoneType === 'P') {
                menuItems1[5].children = menuItems1[5].children.filter(c => c.label != 'Masterlist Name Servers')
            } else {
                console.log("else", reduxStore.zones)

            }
            this.setState({menuItems:menuItems1})
        } else {
            console.log("menuItems")
            this.setState({menuItems: DnsAdminMenu})
        }
    }

    render() {
        if (this.state.menuItems === null) {
            return <>...Loading</>
        }
        return (
            <>
                <Helmet>
                    <title>DNS Administration Page | Home</title>
                </Helmet>
                <Layout menuItems={this.state.menuItems}>
                    <Switch>

                        <Route path="/dns/zones/search/details/:id/servers/:type/nameserver/edit/:recId"
                               component={() => <SlaveNameServer isEditable={true}/>

                               }
                               exact/>

                        <Route path="/dns/zones/search/details/:id/servers/:type/nameserver/create"
                               component={() => <SlaveNameServer isEmptyForm={true} isEditable={true}/>

                               }
                               exact/>


                        {/* ----Account Routes ----*/}


                        {/*
                        <Route path="/dns/accounts/details/:id/create/:zoneType" component={() => <Zone/>} exact/>
*/}

                        <Route path="/dns/accounts/details/:id/create/:zoneType"
                               component={() => <Zone isEmptyForm={true} updateMenu={this.getMenu} isEditable={false}/>}
                               exact/>

                        <Route path="/dns/accounts/search" component={AccountSearch} exact/>

                        <DragonRoute path="/dns/accounts/details/:id" unauthorizedMsg="User cannot list accounts"
                                     title={"Dragon Provisioning Error Page"}
                                     priv={"ab"} component={<Account/>} exact/>

                        <DragonRoute path="/dns/accounts/edit/:id"
                                     unauthorizedMsg="You must have the update privilege to modify these records."
                                     title={"Dragon Provisioning Error Page"}
                                     priv={"au"}
                                     component={<Account isEditable={true}/>} exact/>
                        <DragonRoute path="/dns/accounts/create"
                                     unauthorizedMsg="You must have the update privilege to modify these records."
                                     title={"Dragon Provisioning Error Page"}
                                     priv={"ai"}
                                     component={<Account isEmptyForm={true} isEditable={true}/>} exact/>
                        <Route path="/dns/accounts/activate" component={Account} exact/>
                        <Route path="/dns/accounts/suspend" component={Account} exact/>
                        <Route path="/dns/accounts/details/:accountId/zones/search/:zoneType?"
                               component={() => <ZoneSearch key={2}/>}
                               exact/>


                        {/* ----Zone Routes ----*/}

                        <Route path="/dns/zones/search" component={() => <ZoneSearch key={1}/>} exact/>


                        <Route path="/dns/zones/search/details/:id" component={() => <Zone updateMenu={this.getMenu}/>}
                               exact/>
                        <Route path="/dns/zones/edit/:id"
                               component={() => <Zone updateMenu={this.getMenu} isEditable={true}/>} exact/>

                        {/* ---- Account Delegation Routes ----*/}

                        <Route path="/dns/accounts/details/:accountId/acctDelg" component={AccountDelegationsSearch}
                               exact/>
                        <Route path="/dns/accounts/details/:accountId/acctDelg/create"
                               component={() => <AccountDelegations isEmptyForm={true} isEditable={true}/>

                               }
                               exact/>
                        <Route path="/dns/accounts/details/:accountId/acctDelg/:id" component={AccountDelegations}
                               exact/>
                        <Route path="/dns/accounts/details/:accountId/acctDelg/edit/:id"
                               component={() => <AccountDelegations isEditable={true}/>} exact/>


                        {/* ---- Account Delegation Name Servers Routes ----*/}

                        <Route path="/dns/accounts/details/:accountId/acctDelg/:id/nameServers/acctDelgNS"
                               component={AccountDelegationNSSearch}
                               exact/>


                        <Route
                            path="/dns/accounts/details/:accountId/acctDelg/:delegationId/nameServers/acctDelgNS/create"
                            component={() => <AccountDelegationNS isEmptyForm={true} isEditable={true}/>

                            }
                            exact/>
                        <Route path="/dns/accounts/details/:accountId/acctDelg/:delegationId/nameServers/acctDelgNS/:id"
                               component={AccountDelegationNS}
                               exact/>
                        <Route
                            path="/dns/accounts/details/:accountId/acctDelg/:delegationId/nameServers/acctDelgNS/edit/:id"
                            component={() => <AccountDelegationNS isEditable={true}/>} exact/>


                        {/* ---- Zone Delegation Routes ----*/}


                        <Route path="/dns/zones/search/details/:zoneNum/zoneDelegation" component={DelegationSearch}
                               exact/>
                        <Route path="/dns/zones/search/details/:zoneNum/zoneDelegation/create"
                               component={() => <Delegation isEmptyForm={true} isEditable={true}/>

                               }
                               exact/>

                        <Route path="/dns/zones/search/details/:zoneNum/zoneDelegation/:delegationId"
                               component={Delegation}
                               exact/>

                        <Route path="/dns/zones/search/details/:zoneNum/zoneDelegation/edit/:delegationId"
                               component={() => <Delegation isEditable={true}/>} exact/>


                        {/* ---- Zone Delegation Name Servers Routes ----*/}


                        <Route path="/dns/zones/search/details/:zoneNum/zoneDelegation/:delegationId/delg/nameserver"
                               component={DelegationNameserverSearch} exact/>

                        <Route
                            path="/dns/zones/search/details/:zoneNum/zoneDelegation/:delegationId/delg/nameserver/create"
                            component={() => <DelegationNameserver isEmptyForm={true} isEditable={true}/>} exact/>

                        <Route
                            path="/dns/zones/search/details/:zoneNum/zoneDelegation/:delegationId/delg/nameserver/:recId"
                            component={DelegationNameserver} exact/>


                        <Route
                            path="/dns/zones/search/details/:zoneNum/zoneDelegation/:delegationId/delg/nameserver/edit/:recId"
                            component={() => <DelegationNameserver isEditable={true}/>} exact/>


                        <Route path="/dns/zones/search/details/:zoneNum/xferzones/aclv4/details/:id"
                               component={XferIPv4Acl}
                               exact/>
                        <Route path="/dns/zones/search/details/:zoneNum/xferzones/aclv4/:id"
                               component={() => <XferIPv4Acl isEditable={true}/>} exact/>

                        <Route path="/dns/zones/search/details/:zoneNum/xferzones/aclv6/details/:id"
                               component={XferIPv6Acl}
                               exact/>


                        <Route path="/dns/zones/search/details/:zoneNum/xferzones/aclv6/edit/:id"
                               component={() => <XferIPv6Acl isEditable={true}/>} exact/>

                        <DragonRoute path="/dns/zones/search/details/:id/create/:zoneType"
                                     unauthorizedMsg="You must have the update privilege to modify these records."
                                     title={"Dragon Provisioning Error Page"}
                                     priv={"zi"}
                                     component={<Zone isEmptyForm={true} updateMenu={this.getMenu} isEditable={false}/>}
                                     exact/>

                        <Route path="/dns/zones/search/details/:zoneNum/:type" component={() => <ListAllRecords
                            updateMenu={this.getMenu}
                        />} exact/>


                        <Route path="/dns/zones/ptr" component={ZonePTR} exact/>
                        <Route path="/dns/zones/delegation" component={ZoneDelegation} exact/>

                        <Route path="/dns/zones/search/details/:zoneNum/:category/:type/:action?/:id?"
                               render={(props) => {

                                   // const zoneMenuIndex = props.match.params.category ==='rr'?4:5
                                   var zoneMenuIndex = 5
                                   if (props.match.params.category === 'rr') {
                                       zoneMenuIndex = 4
                                   }
                                   /*else if (props.match.params.category === 'servers') {
                                       zoneMenuIndex = 5
                                   }*/
                                   else if (props.match.params.category === 'xferzones') {
                                       zoneMenuIndex = 3
                                   }
                                   //    console.log(zoneMenuIndex, "zoneMenuIndex")
                                   const rrMenu = ZoneMenu[zoneMenuIndex].children.find(element => {
                                       return "name" in element && element.name === props.match.params.type


                                   })
                                   return props.match.params.action ?
                                       React.cloneElement(rrMenu?.component[props.match.params.action], {updateMenu: this.getMenu}) :
                                       [React.cloneElement(rrMenu?.component?.search, {updateMenu: this.getMenu})];
                               }} exact/>


                        <Route path="/dns/historylogs" component={HistoryLogSearch} exact/>
                        <Route path="/dns/domains" component={NewDomainSearch} exact/>


                        <Route path="*" component={() => {
                            return (
                                <Container maxWidth={false} className={"px-2"}>
                                    <Paper>
                                        <Box p={15}>
                                            <h6 className={"font-weight-bold text-center"}>DNS
                                                Administration Page</h6>

                                            <Typography component={"div"} variant="inherit" align={"left"}>
                                                <p className={"text-wrap"}>
                                                    From DNS Administration page you can administer DNS Accounts or DNS
                                                    Zones by
                                                    clicking on the appropriate menu bar above.</p>
                                            </Typography>
                                        </Box>
                                    </Paper>
                                </Container>)
                        }}/>


                    </Switch>

                </Layout>

            </>
        )
    }
}

function mapState(state) {
    return {}
}

const actionCreators = {getZoneById: zoneActions.getZoneById,};

const connectedHome = connect(mapState, actionCreators)(Home);
export {connectedHome as Home};
