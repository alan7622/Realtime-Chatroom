export {Home as DnsHome} from './Home';
