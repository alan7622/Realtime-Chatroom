import React, {Component} from "react";
import {accountService, zoneService} from "../../_services";
import {
    Backdrop,
    Button, Card, CardContent,
    CircularProgress,
    Dialog,
    DialogActions, DialogContent,
    DialogTitle, FormControlLabel, Radio, RadioGroup
} from "@material-ui/core";
import Container from "@material-ui/core/Container";
import Form from "react-bootstrap/Form";
import {Col, Row} from "react-bootstrap";
import PropTypes from "prop-types";
import {connect} from "react-redux";
import {withRouter} from "react-router-dom";
import {Helmet} from "react-helmet";
import {alertActions, zoneActions} from "../../_actions";
import {Alert} from "@material-ui/lab";
import _ from "lodash";
import {templatizedStringParser} from "../../_helpers";


class Zone extends Component {
    constructor(props) {
        super(props);
        this.state = {
            loading: true,
            zone: {
                zoneSubType: "IP4",
            },
            soaTemplate: {
                rrName: '',
                rrType: '',
                soaSource: '',
                soaEmail: '',
                soaExpire: '',
                soaRefresh: '',
                soaRetry: '',
                soaTtl: '',
                TTL: '',
            },

            json: {
                a: {
                    checkNames: 'Y',
                },

                p: {
                    soaSource: "",
                    soaEmail: "",
                    soaRefresh: "",
                    soaRetry: "",
                    soaTtl: "",
                    // allowtransfer: "1.2.3.4;1.2.3.5",
                    //allowquery: "1.2.3.4;1.2.3.5",
                    TTL: "",
                },
                withoutAllowTransfer: {
                    TTL: "8900"
                },
                s: {
                    masterlist1: "",
                    masterlist2: ""
                },
            },
            showDeleteConfirm: false,
            showActivateConfirm: false,
            alert: ''

        };
        this.isComponentMounted = false;
        this.saveZone = this.saveZone.bind(this);
        this.updateFormObj = this.updateFormObj.bind(this);
        this.deleteZone = this.deleteZone.bind(this);
        this.getZoneForm = this.getZoneForm.bind(this);
        this.getPrimaryZoneForm = this.getPrimaryZoneForm.bind(this);
        this.getSecondaryZoneForm = this.getSecondaryZoneForm.bind(this);
        this.getDeleteConfirmDialog = this.getDeleteConfirmDialog.bind(this);
        this.getZoneStatusConfirmDialog = this.getZoneStatusConfirmDialog.bind(this);


        if ((this.props.location.state === null || this.props.location.state === undefined || !this.props.location.state.showAlerts) && !_.isEmpty(this.props.alert)) {
            this.props.alertClear()
        }
    }

    saveZone(e) {

        e.preventDefault()
        this.setState({saving: true})

        let res, accountId;

        const {zoneName, ...zone} = this.state.zone
        if (this.props.match.params.zoneType === "primaryZone") {
            //  this.props.create({...zone, zoneName: `${zoneName}.`, json: JSON.stringify(this.state.json.p),zoneType: "P",});//
            const tmp = Object.fromEntries(Object.entries(this.state.json.p).filter(([_, v]) => v != null && v != ""));

            this.props.create({
                ...zone,
                zoneName: `${zoneName}`,
                json: JSON.stringify(tmp),
                // json: JSON.stringify(this.state.soaTemplate),
                zoneType: "P",
            });//removing '.' at the end of zoneName. Sp is taking care of it.

        } else if (this.props.match.params.zoneType === "secondaryZone") {
            let json = {masterlist: this.state.json.s.masterlist1 + ";" + this.state.json.s.masterlist2}
            this.props.create({...zone, zoneName, json: JSON.stringify(json), zoneType: "S"});

        } else {
            const {accountId, ...zone} = this.state.zone
            zone.account = accountId
            //this.props.update(zone, this.props.match.params.id);
            this.props.update({
                comments: zone.comments,
                serviceName: zone.serviceName,
                accountId: zone.account
            }, this.props.match.params.id);


        }

    }

    async componentDidMount() {
        setTimeout(() => {
            this.props.alertClear()
        }, 10000)//this clears alert message on listing or search page after 10 seconds
        await this.getZone();
    }

    tmpl = '[rrName] IN [rrType] [soaSource] [soaEmail] [soaRefresh] [soaRetry] [soaExpire] [soaTtl] [TTL]'

    //template=@     IN  SOA  ns-west.cerf.net. rm-hostmaster.ems.att.com. 1 10800 3600 604800 86400


    async getZone() {
        this.isComponentMounted = true;
        let resp, res, tmplResponse;

        if (this.isComponentMounted) {
            this.setState({gettingZone: true});
            let accountId, serviceName;
            if (this.props.match.path == '/dns/accounts/details/:id/create/:zoneType') {
                resp = await accountService.getAccountById(this.props.match.params.id)
                accountId = resp.accountId;
                serviceName = resp.serviceName;

                res = await zoneService.getSoaTemplate(this.props.match.params.id)//api call for display valid soa data to users before inserting zone from soatemplate table
                // accountId = res.accountId;
                tmplResponse = templatizedStringParser(this.tmpl, res.soaTemplate.soaTemplate)//parsing the rrstr data to display soa data in its respective fields


            } else {
                resp = await zoneService.getZoneById(this.props.match.params.id)
                if (resp.success) {
                    accountId = resp.zone.accountId;
                    serviceName = resp.zone.serviceName;
                }

                res = await zoneService.getSoaTemplate(accountId)
                tmplResponse = templatizedStringParser(this.tmpl, res.soaTemplate.soaTemplate)

            }
            //   const resp = await zoneService.getZoneById(this.props.match.params.id)
            const zone = this.state.zone
            if (this.isComponentMounted) {
                if (this.props.match.params.zoneType) {
                    zone.accountId = accountId
                    zone.serviceName = serviceName

                    this.setState({
                        gettingZone: false,
                        zone,
                        loading: false,
                        soaTemplate: tmplResponse
                    })
                } else {
                    this.setState({loading: false, zone: resp.zone, gettingZone: false});

                }
            }


        }
    }

    deleteZone() {
        this.setState({showDeleteConfirm: false, loading: true})
        this.props.delete(this.props.match.params.id);
    }

    componentWillUnmount() {
        this.isComponentMounted = false;
        //this.props.alertClear()
        this.props.clearStack() //adding _clearStack function in zone action to clear the zone details from previous state in redux
    }

    async componentDidUpdate(nextProps, nextState, nextContext) {

        if (nextProps.saved && !_.isEqual(nextProps.zone, this.state.zone) && !_.isEmpty(nextProps.zone)) {
            //  if (nextProps.saved && !_.isEqual(nextProps.zone, this.state.zone) && this.state.loading && !this.state.gettingZone && !nextState.gettingZone && (this.props.match.params.zoneType !== "primaryZone")) {
            this.setState({
                loading: false,
                zone: nextProps.zone
            })
        }
    }

    updateFormObj(e) {

        let {name, value} = e.target;

        const {zone, json} = this.state;
        let nameSplit = name.split('.')
        //  value=value.trim(); used to trim the blank space in form field
        if (nameSplit.length == 1) {
            this.setState({zone: {...zone, [name]: value}});
        } else if (nameSplit[0] === 'json') {
            json[nameSplit[1]][nameSplit[2]] = value
            // console.log("json[nameSplit[1]][nameSplit[2]]", json[nameSplit[1]][nameSplit[2]])
            this.setState({json});
        }


    }

    getZoneStatusConfirmDialog() {
        const {zone} = this.state
        return !this.props.isEditable && <Dialog
            onClose={(event, reason) => {
                if (reason === 'backdropClick' || reason === 'escapeKeyDown') {
                    return false;
                }
            }}
            maxWidth="lg"
            aria-labelledby="confirmation-activate-dialog-title"
            open={this.state.showActivateConfirm}
        >
            <DialogTitle id="confirmation-activate-dialog-title">
                <b> Are you sure you want to {this.state.zone.zoneStatus === 'A' ? 'suspend' : 'activate'} this
                    zone?</b>


            </DialogTitle>
            <DialogContent>
                <span><b>NOTICE:</b> Suspending this zone will cause the DNS server to refuse to answer queries for records in this zone.</span>

            </DialogContent>

            <DialogContent>

                <div>
                    <span className={'font-weight-bold mr-2'}>Zone Name</span>: {zone.zoneName} <br/>
                    <span className={'font-weight-bold mr-2'}>Modified</span>: {zone.modBy + zone.updateTime} <br/>
                    <span className={'font-weight-bold mr-2'}>Status</span>: {zone.zoneStatus} <br/>
                    <span className={'font-weight-bold mr-2'}>ServiceID</span>: {zone.serviceName} <br/>
                    <span className={'font-weight-bold mr-2'}>Zone Number</span>: {zone.zoneNum}
                </div>

            </DialogContent>
            <DialogActions>

                <Button onClick={() => {
                    {
                        //   console.log(this.state.zone.zoneStatus, "ACTIVATEORSUSPEND")
                    }

                    this.setState({
                            loading: true,
                            showActivateConfirm: false
                        }, () => this.props.updateStatus(zone.zoneNum, this.state.zone.zoneStatus === 'A' ? 'S' : 'A')
                    )
                }} className={"dns-blue-button text-white"}>
                    Execute
                </Button>
                <Button onClick={() => this.setState({showActivateConfirm: false})}
                        className={"dns-blue-button text-white"}>
                    Cancel
                </Button>
            </DialogActions>
        </Dialog>
    }

    getDeleteConfirmDialog() {
        return !this.props.isEditable && <Dialog
            onClose={(event, reason) => {
                if (reason === 'backdropClick' || reason === 'escapeKeyDown') {
                    return false;
                }
            }}
            maxWidth="xs"
            aria-labelledby="confirmation-dialog-title"
            open={this.state.showDeleteConfirm}
        >
            <DialogTitle id="confirmation-dialog-title">Are you sure you want to delete this
                zone?</DialogTitle>

            <DialogActions>
                <Button autoFocus onClick={this.deleteZone} className={"dns-blue-button text-white"}>
                    Delete
                </Button>
                <Button onClick={() => this.setState({showDeleteConfirm: false})}
                        className={"dns-blue-button text-white"}>
                    Cancel
                </Button>
            </DialogActions>
        </Dialog>
    }

    getPageForm() {
        if (this.props.match.params.zoneType === "primaryZone") {
            return this.getPrimaryZoneForm();
        } else if (this.props.match.params.zoneType === "secondaryZone") {
            return this.getSecondaryZoneForm();
        } else if (this.props.isEditable) {
            let actionButtons = [<Button className={"dns-blue-button text-white mr-2 col-md-1"}
                                         onClick={this.saveZone}
                                         key={"update"}>Update</Button>,
                <Button className={"dns-blue-button text-white mr-2 col-md-1"}
                        onClick={() => {
                            this.props.alertClear();
                            this.props.history.push(`/dns/zones/details/${this.props.match.params.id}`)
                        }}
                        key={"cancel_update"}>Cancel</Button>];
            return this.getZoneForm("DNS Zones Update Page", actionButtons);
        } else {
            let actionButtons = [<Button className={"dns-blue-button text-white mt-2 mr-4 mb-4"}
                                         onClick={() => {
                                             this.props.alertClear();
                                             this.props.history.push(`/dns/zones/edit/${this.props.match.params.id}`)
                                         }}
                                         key={"edit"}>Go To Update</Button>,
                <Button className={"dns-blue-button text-white mt-2 mr-4 mb-4"}
                        onClick={() => {
                            this.setState({showDeleteConfirm: true})
                        }} key={"delete"}>Delete</Button>,
                <Button className={"dns-blue-button text-white mt-2 mr-4 mb-4"}
                        onClick={() => {
                            this.setState({showActivateConfirm: true})
                        }} key={"zone_status"}>{this.state.zone.zoneStatus == 'A' ?
                    'Suspend' : 'Activate'}</Button>];
            return this.getZoneForm("DNS Zones Details Page", actionButtons);

        }

    }

    getZoneForm(pageTitle, pageButtons) {
        const {json, zone} = this.state

        return (<>
            <h6 className={"font-weight-bold  text-capitalize text-left pt-3 pb-4"}>{pageTitle}</h6>
            <Form>
                {this.props.alert.message &&
                <Alert severity={this.props.alert.type}>{this.props.alert.message}</Alert>}
                <Form.Group as={Row} className={"align-items-center"}>
                    <Form.Label column sm="2" className={"font-weight-bold"}>
                        Zone Name
                    </Form.Label>
                    <Col sm="6">
                        {zone.zoneName}
                    </Col>
                    <Form.Label column sm="2" className={"font-weight-bold"}>
                        Zone Number
                    </Form.Label>
                    <Col sm="2">
                        {zone.zoneNum}
                    </Col>

                </Form.Group>
                <Form.Group as={Row} className={"align-items-center"}>
                    <Form.Label column sm="2" className={"font-weight-bold"}>
                        Account Id </Form.Label>
                    <Col sm="2">
                        {this.props.isEditable ?
                            <Form.Control name={"accountId"} onChange={this.updateFormObj}
                                          defaultValue={zone.accountId ? zone.accountId : ''}/> : zone.accountId}

                    </Col>
                    {
                        !this.props.isEditable && <> <Form.Label column sm="2" className={"font-weight-bold"}>
                            Status </Form.Label>
                            <Col sm="2">
                                {this.props.isEmptyForm ?
                                    <Form.Control as="select" name={"zoneStatus"}
                                                  onChange={this.updateFormObj}
                                                  value={zone.zoneStatus}>
                                        <option value={"A"}>A</option>
                                        <option value={"S"}>S</option>
                                    </Form.Control>
                                    : zone.zoneStatus}
                            </Col></>}
                    <Form.Label column sm="2" className={"font-weight-bold"}>
                        Service ID </Form.Label>
                    <Col sm="2">
                        {this.props.isEditable ?
                            <Form.Control name={"serviceName"} onChange={this.updateFormObj}
                                          defaultValue={zone.serviceName ? zone.serviceName : ''}/> : zone.serviceName}
                    </Col>

                </Form.Group>
                {
                    !this.props.isEditable &&
                    <Form.Group as={Row} className={"align-items-center"}> <Form.Label column sm="2"
                                                                                       className={"font-weight-bold"}>
                        Modified By
                    </Form.Label>
                        <Col sm="2">
                            {zone.modBy}
                        </Col>
                        <Form.Label column sm="2" className={"font-weight-bold"}>
                            Created </Form.Label>
                        <Col sm="2">
                            {zone.createTime}
                        </Col>
                        <Form.Label column sm="2" className={"font-weight-bold"}>
                            Last Modified </Form.Label>
                        <Col sm="2">
                            {zone.updateTime}
                        </Col>
                    </Form.Group>
                }


                <Form.Group as={Row} className={"align-items-center"}>
                    <Form.Label column sm="2" className={"font-weight-bold"}>
                        Check Host Name
                    </Form.Label>
                    <Col sm="2">
                        {this.props.isEditable ?
                            <Form.Control as="select" name={"checknames"}
                                          value={json.a.checknames}>
                                <option value={"S"}>Y</option>
                                <option value={"P"}>N</option>
                            </Form.Control>
                            : json.a.checknames}
                    </Col>

                    <Form.Label column sm="2" className={"font-weight-bold"}>
                        Type Of Service </Form.Label>

                    <Col sm="2">
                        {zone.zoneType}

                        {/*
                        {zone.zoneSubType}
*/}
                    </Col>
                    {/* <Col sm="2">
                        {!this.props.isEditable ?
                            <Form.Control name={"zoneSubType"} onChange={this.updateFormObj}
                                          value={zone.zoneSubType ? zone.zoneSubType : ''}/> : zone.zoneSubType}
                    </Col>*/}
                    {!this.props.isEditable && <><Form.Label column sm="2" className={"font-weight-bold"}>
                        Service Name </Form.Label>
                        <Col sm="2">
                            {this.props.isEditable ?
                                <Form.Control name={"serviceName"} onChange={this.updateFormObj}
                                              defaultValue={zone.serviceName ? zone.serviceName : ''}/> : zone.serviceName}

                        </Col>
                    </>
                    }

                </Form.Group>
                <Form.Group as={Row} className={"align-items-center"}>

                    {!this.props.isEditable && <>     <Form.Label column sm="2" className={"font-weight-bold"}>
                        Order ID </Form.Label>
                        <Col sm="2">
                            {zone.orderId}
                            {this.props.isEditable ?
                                <Form.Control name={"orderId"} onChange={this.updateFormObj}
                                              defaultValue={zone.orderId ? zone.orderId : ''}/> : zone.orderId}
                        </Col></>}
                    {!this.props.isEditable && <> <Form.Label column sm="2" className={"font-weight-bold"}>
                        Option
                    </Form.Label>
                        <Col sm="2">
                            {this.props.isEditable ?
                                <Form.Control name={"option"} onChange={this.updateFormObj}
                                              defaultValue={zone.option ? zone.option : ''}/> : zone.option}

                        </Col></>}
                    <Form.Label column sm="2" className={"font-weight-bold"}>
                        Comments
                    </Form.Label>
                    <Col sm="2">
                        {this.props.isEditable ?
                            <Form.Control name={"comments"} onChange={this.updateFormObj}
                                          defaultValue={zone.comments ? zone.comments : ''}/> : zone.comments}
                    </Col>
                </Form.Group>

                <div className={"text-center"}>
                    {pageButtons.map(buttonComp => buttonComp)}
                </div>
            </Form></>)
    }

    getPrimaryZoneForm() {
        const {json, zone, soaTemplate} = this.state
        return (<>

            {this.props.alert.message &&
            <Alert severity={this.props.alert.type}>{this.props.alert.message}</Alert>}
            <h6 className="font-weight-bold  text-capitalize text-left mt-2 mb-4">Primary Zone Creation </h6>

            <span><b>NOTE:</b> Zones created with Service ID WNMIS and HOST will default to not allowing zone transfers.
            To allow zone transfers from the AT&T servers assigned to this zone, please use the XFER ACL selection
            from the Resource Record menu bar. The first ACL created for this zone will be the one blocking
            all transfers.
            </span>

            <div className={"pt-4 pb-4"}>
            <span
                className={'font-weight-bold ml-2'}
                key={"serviceName"}>Service Id</span> : {zone.serviceName}

                <span
                    className={'font-weight-bold  ml-5'}
                    key={"accountId"}>Account ID</span> : {zone.accountId}

            </div>


            <Form>

                <Form.Group as={Row} className={"align-items-center ml-1 mt-1"}>
                    <RadioGroup value={this.state.zone.zoneSubType} name={"zoneSubType"}
                                onChange={this.updateFormObj}>
                        <p className={'ml-1 font-italic'}>There are different formats that can be used
                            here for Zone Name.
                            Please select the appropriate format before filling the fields.</p>
                       {/* <FormControlLabel value="IP4" control={<Radio color="primary"/>}
                                          label=" IP4 Arpa Zones (i.e. 128/27.114.0.12.in-addr.arpa.)
          Please note that the IP4 arpa search is always on the IP address of the arpa zone(i.e. 12.0.114.128/27 or 12.0.114 or 0.114).
          The exceptions are an Equals or a Contains search where the search string ends with .in-addr.arpa..
          In this case the search is on the Arpa Address(i.e 128/27.114.0.12.in-addr.arpa. or 12.in-addr.arpa.)."/>
*/}

                        <FormControlLabel value="IP4" control={<Radio color="primary"/>}
                                          label=" IP4 Arpa Zones (i.e. 128/27.114.0.12.in-addr.arpa.)
          Please note that the IP4 arpa search is always on the IP address of the arpa zone(i.e. 12.0.114.128/27 or 12.0.114 or 0.114).
          The exceptions are an Equals or a Contains search where the search string ends with .in-addr.arpa..
          In this case the search is on the Arpa Address(i.e 128/27.114.0.12.in-addr.arpa. or 12.in-addr.arpa.)."/>

                        <FormControlLabel value="IP6" control={<Radio color="primary"/>}
                                          label=" IP6 Arpa Zones (i.e. 2001:1890:1111::/48 or 1.1.1.1.0.8.9.1.1.0.0.2.ip6.arpa.)
. . . . ..If you are adding an IP6 block that is not on the 4 byte/16 bit boundary like these below
. . . . ..(i.e. 2001:1892:0055::/48, 2001:1892:0055:6677::/64, 2001:1892:0055:6677:8888::/80),
. . . . ..you need to zero fill the last 4 bytes(i.e. 2001:1892:0055:5500::/56, not 2001:1892:0055:55::/56)"/>

                    </RadioGroup>
                </Form.Group>
                <Form.Group as={Row} className={"align-items-center"}>
                    <Form.Label column sm="2" className={"font-weight-bold"}>
                        {this.props.isEmptyForm ? "*" : ""} Zone Name
                    </Form.Label>
                    <Col sm="4">
                        <Form.Control name={"zoneName"} onChange={this.updateFormObj}
                                      defaultValue={zone.zoneName ? zone.zoneName : ''}/>

                    </Col>
                    <Form.Label column sm="2" className={"font-weight-bold"}>
                        Check Host Name
                    </Form.Label>
                    <Col sm="4">
                        {this.props.isEmptyForm ?
                            <Form.Control as="select" name={"checkNames"}
                            >
                                <option value={"Y"}>Y</option>
                                <option value={"N"}>N</option>
                            </Form.Control> : zone.checkNames}
                    </Col>

                </Form.Group>
                <Form.Group as={Row} className={"align-items-center mb-5"}>
                    <Form.Label column sm="2" className={"font-weight-bold"}>
                        Comments
                    </Form.Label>
                    <Col sm="4">
                        <Form.Control name={"comments"} onChange={this.updateFormObj}
                                      defaultValue={zone.comments ? zone.comments : ''}/>
                    </Col>
                </Form.Group>
                <span className={"font-weight-bold"}>Please fill in following fields with the zone's SOA (start of authority) resource record:</span>
                <Form.Group as={Row} className={"align-items-center mt-2"}>
                    <Form.Label column sm="2" className={"font-weight-bold"}>
                        {this.props.isEmptyForm ? "*" : ""}E-mail Address
                    </Form.Label>
                    <Col sm="4">
                        <Form.Control name={"json.p.soaEmail"}
                                      placeholder={this.state.soaTemplate.soaEmail}
                                      onChange={this.updateFormObj}
                                      defaultValue={json.p.soaEmail ? json.p.soaEmail : ''}/>
                    </Col>
                    <Form.Label column sm="2" className={"font-weight-bold"}>
                        {this.props.isEmptyForm ? "*" : ""}Refresh Time
                    </Form.Label>
                    <Col sm="4">
                        <Form.Control name={"json.p.soaRefresh"}
                                      placeholder={this.state.soaTemplate.soaRefresh}
                                      onChange={this.updateFormObj}
                                      defaultValue={json.p.soaRefresh ? json.p.soaRefresh : ''}/>

                    </Col>
                </Form.Group>
                <Form.Group as={Row} className={"align-items-center"}>
                    <Form.Label column sm="2" className={"font-weight-bold"}>
                        {this.props.isEmptyForm ? "*" : ""}Retry Time
                    </Form.Label>
                    <Col sm="4">
                        <Form.Control name={"json.p.soaRetry"}
                                      placeholder={this.state.soaTemplate.soaRetry} onChange={this.updateFormObj}
                                      defaultValue={json.p.soaRetry ? json.p.soaRetry : ''}/>
                    </Col>
                    <Form.Label column sm="2" className={"font-weight-bold"}>
                        {this.props.isEmptyForm ? "*" : ""}Expire Time
                    </Form.Label>
                    <Col sm="4">
                        <Form.Control name={"json.p.soaExpire"}
                                      placeholder={this.state.soaTemplate.soaExpire}
                                      onChange={this.updateFormObj}
                                      defaultValue={json.p.soaExpire ? json.p.soaExpire : ''}/>
                    </Col>
                </Form.Group>
                <Form.Group as={Row} className={"align-items-center"}>
                    <Form.Label column sm="2" className={"font-weight-bold"}>
                        {this.props.isEmptyForm ? "*" : ""}Minimum TTL
                    </Form.Label>
                    <Col sm="4">
                        <Form.Control name={"json.p.soaTtl"}
                                      placeholder={this.state.soaTemplate.soaTtl}
                                      onChange={this.updateFormObj}
                                      defaultValue={json.p.soaTtl ? json.p.soaTtl : ''}/>
                    </Col>
                    <Form.Label column sm="2" className={"font-weight-bold"}>
                        Time To Live
                    </Form.Label>
                    <Col sm="4">
                        <Form.Control name={"json.p.TTL"}
                                      onChange={this.updateFormObj}
                                      defaultValue={json.p.TTL ? json.p.TTL : ''}/>

                    </Col>
                </Form.Group>
                <div className={"text-center"}>
                    <Button className={"dns-blue-button text-white mr-2 col-md-1"}
                            onClick={this.saveZone}
                            key={"insert"}>Insert</Button>
                </div>
            </Form>
        </>)

    }

    getSecondaryZoneForm() {
        const {json, zone} = this.state
        return (<>
            {this.props.alert.message &&
            <Alert severity={this.props.alert.type}>{this.props.alert.message}</Alert>}
            <h6 className="font-weight-bold  text-capitalize text-left mt-3 mb-3">Secondary Zone Creation</h6>
            <span className={"pb-4"}> <b>NOTE:</b> Zones created with Service ID WNMIS and HOST will default to not allowing zone transfers.
To allow zone transfers from the AT&T servers assigned to this zone, please use the XFER ACL selection
from the Resource Record menu bar. The first ACL created for this zone will be the one blocking
all transfers.</span>

            <div className={"pt-4 pb-2"}>
            <span
                className={'font-weight-bold ml-2'}
                key={"serviceName"}>Service Id</span>: {zone.serviceName}

                <span
                    className={'font-weight-bold  pl-5'}
                    key={"accountId"}>Account ID</span> : {zone.accountId}

            </div>
            <form onSubmit={this.saveZone}>
                <Form.Group as={Row} className={"align-items-center ml-1 mt-1"}>
                    <RadioGroup value={this.state.zone.zoneSubType} name={"zoneSubType"}

                                onChange={this.updateFormObj}>
                        <p className={'font-weight-bold ml-1'}>There are different formats that can be used
                            here for Zone Name.
                            Please select the appropriate format before filling the fields.</p>
                        <FormControlLabel value="IP4"
                                          control={<Radio
                                              color="primary"/>}
                                          label="Forward and IP4 Arpa Zones (i.e. expressojoes.com. or 128/27.114.0.12.in-addr.arpa.)"/>
                        <FormControlLabel value="IP6" control={<Radio color="primary"/>}
                                          label=" IP6 Arpa Zones (i.e. 2001:1890:1111::/48 or 1.1.1.1.0.8.9.1.1.0.0.2.ip6.arpa.)
. . . . ..If you are adding an IP6 block that is not on the 4 byte/16 bit boundary like these below
. . . . ..(i.e. 2001:1892:0055::/48, 2001:1892:0055:6677::/64, 2001:1892:0055:6677:8888::/80),
. . . . ..you need to zero fill the last 4 bytes(i.e. 2001:1892:0055:5500::/56, not 2001:1892:0055:55::/56)"/>

                    </RadioGroup>
                </Form.Group>

                <Form.Group as={Row} className={"align-items-center"}>
                    <Form.Label column sm="2" className={"font-weight-bold"}>
                        {this.props.isEmptyForm ? "*" : ""}Zone Name
                    </Form.Label>
                    <Col sm="4">
                        <Form.Control name={"zoneName"} onChange={this.updateFormObj}
                                      defaultValue={zone.zoneName ? zone.zoneName : ''}
                                      required={true}/>

                    </Col>
                    <Form.Label column sm="2" className={"font-weight-bold"}>
                        Check Host Name
                    </Form.Label>
                    <Col sm="4">
                        <Form.Control as="select"
                        >
                            <option value={"Y"}>Y</option>
                            <option value={"N"}>N</option>
                        </Form.Control>
                    </Col>
                </Form.Group>

                <Form.Group as={Row} className={"align-items-center mb-5"}>
                    <Form.Label column sm="2" className={"font-weight-bold"}>
                        Comments
                    </Form.Label>
                    <Col sm="4">
                        <Form.Control name={"comments"} onChange={this.updateFormObj}
                                      defaultValue={zone.comments ? zone.comments : ''}/>
                    </Col>
                </Form.Group>
                <span className={"font-weight-bold"}>Please provide at least one Primary Name Server for the zone in following fields:</span>
                {[...Array(this.props.match.params.id == 'multiple' ? 3 : 1)].map((e, i) => {
                    return <div key={i} className={"py-3 px-3"}>

                        <Form.Group as={Row} key={`group1${i}`} className={"align-items-left"}>
                            <Form.Label column sm="2" className={"font-weight-bold"}>
                                {this.props.isEmptyForm ? "*" : ""}Server1 Name</Form.Label>
                            <Col sm="2">
                                <Form.Control
                                    name={`soaSource${i}`}
                                    onChange={this.updateFormObj}
                                    defaultValue={json.p.soaSource ? zone.soaSource : ''} required={true}/>
                            </Col>
                            <Form.Label column sm="2" className={"font-weight-bold"}>
                                {this.props.isEmptyForm ? "*" : ""}IP Address
                            </Form.Label>
                            <Col sm="2">
                                <Form.Control name={"json.s.masterlist1"} onChange={this.updateFormObj}
                                              defaultValue={json.s.masterlist1 ? json.s.masterlist1 : ''}
                                              required={true}/>

                            </Col>
                            <Form.Label column sm="2" className={"font-weight-bold"}>
                                IP6 Address
                            </Form.Label>
                            <Col sm="2">
                                <Form.Control name={"json.s.masterlist2"} onChange={this.updateFormObj}
                                              defaultValue={json.s.masterlist2 ? json.s.masterlist2 : ''}
                                    /* required={true}*//>

                            </Col>
                        </Form.Group>
                        <Form.Group as={Row} key={`group2${i}`} className={"align-items-left"}>
                            <Form.Label column sm="2" className={"font-weight-bold"}>
                                Server2 Name</Form.Label>
                            <Col sm="2">
                                <Form.Control
                                    name={`soaSource${i}`}
                                    onChange={this.updateFormObj}
                                    defaultValue={json.s.soaSource ? zone.soaSource : ''}/>
                            </Col>
                            <Form.Label column sm="2" className={"font-weight-bold"}>
                                IP Address
                            </Form.Label>
                            <Col sm="2">
                                <Form.Control
                                    name={`ipaddr${i}`}
                                    onChange={this.updateFormObj}
                                    defaultValue={zone.ipaddr ? zone.ipaddr : ''}/>

                            </Col>
                            <Form.Label column sm="2" className={"font-weight-bold"}>
                                IP6 Address
                            </Form.Label>
                            <Col sm="2">
                                <Form.Control
                                    name={`ip6addr${i}`}
                                    onChange={this.updateFormObj}
                                    defaultValue={zone.ip6addr ? zone.ip6addr : ''}/>

                            </Col>
                        </Form.Group>
                        <Form.Group as={Row} key={`group3${i}`} className={"align-items-left"}>
                            <Form.Label column sm="2" className={"font-weight-bold"}>
                                Server3 Name</Form.Label>
                            <Col sm="2">
                                <Form.Control name={`soaSource${i}`}
                                              onChange={this.updateFormObj}
                                              defaultValue={zone.soaSource ? zone.soaSource : ''}/>
                            </Col>
                            <Form.Label column sm="2" className={"font-weight-bold"}>
                                IP Address
                            </Form.Label>
                            <Col sm="2">
                                <Form.Control name={`ipaddr${i}`}
                                              onChange={this.updateFormObj}
                                              defaultValue={zone.ipaddr ? zone.ipaddr : ''}/>

                            </Col>
                            <Form.Label column sm="2" className={"font-weight-bold"}>
                                IP6 Address
                            </Form.Label>
                            <Col sm="2">
                                <Form.Control name={`ip6addr${i}`} onChange={this.updateFormObj}
                                              defaultValue={zone.ip6addr ? zone.ip6addr : ''}/>

                            </Col>
                        </Form.Group>


                        <hr/>
                    </div>
                })}


                <div className={"text-center"}>
                    <Button className={"dns-blue-button text-white mr-2 col-md-1"}
                        //onClick={this.saveZone}
                            type={"submit"}
                            key={"insert"}>Insert</Button>
                </div>
            </form>
        </>)


    }


    render() {
        if ((this.state.loading)) {
            return <div>Loading....</div>
        }
        return (
            <>
                {this.getDeleteConfirmDialog()}
                {this.getZoneStatusConfirmDialog()}
                <Backdrop className={"page-loading"} style={{'zIndex': '10000', 'color': '#fff'}}
                          open={this.state.loading && (this.props.saving == true)}>
                    <CircularProgress color="inherit"/>
                </Backdrop>
                <div>
                    <Helmet>
                        <title>DNS zones | zones</title>
                    </Helmet>

                    <Container maxWidth={false} className={"px-2"}>
                        <Card>
                            <CardContent>
                                <div className="pt-3 pl-4 pr-5">

                                    {this.getPageForm()}

                                </div>
                            </CardContent>
                        </Card>
                    </Container>
                </div>
            </>
        )
    }


}

Zone.defaultProps = {
    isEditable: false,
};
Zone.propTypes = {
    isEditable: PropTypes.bool.isRequired,
    isEmptyForm: PropTypes.bool

};

function mapState(state) {
    const {saving, loading, saved, deleted, zone} = state.zones

    const {alert, clear} = state
    return {saving, loading, saved, deleted, alert, zone, clear}

}

const actionCreators = {
    create: zoneActions.create,
    update: zoneActions.update,
    delete: zoneActions.delete,
    updateStatus: zoneActions.updateStatus,
    alertClear: alertActions.clear,
    clearStack: zoneActions.clearStack
};


const connectedzone = withRouter(connect(mapState, actionCreators)(Zone));
export {connectedzone as Zone};


