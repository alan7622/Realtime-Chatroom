// 07/10/2023: DRAGON3-516 --> Removing advance search button as the acl value is always a long string and is a single value for zone.
// 07/10/2023: DRAGON3-513 --> Display Insert button when the data in table is empty

import React, {Component} from "react";
import {alertActions} from "../../../../_actions";
import {Link, withRouter} from "react-router-dom";
import {connect} from "react-redux";
import {Helmet} from "react-helmet";
import {
    Card,
    CardContent,
} from "@material-ui/core";
import Container from "@material-ui/core/Container";
import BootstrapTable from "react-bootstrap-table-next";
import {Alert} from "@material-ui/lab";
import {transferAclZone, zoneService} from "../../../../_services";
import _ from "lodash";
import overlayFactory from "react-bootstrap-table2-overlay";


/*const defaultFilters = {
    attrValue: {comparator: 'Eq', value: ''},
} //DRAGON3-516*/

class Search extends Component {

    constructor(props) {
        super(props);
        this.state = {
            data: [],
            zoneData: {},
            showDeleteConfirm: false,
            showAdvanceSearch: false,
            loading:true,

        }
        this.isComponentMounted = false;
        this.handleFilterChange = this.handleFilterChange.bind(this)


        if ((this.props.location.state === null || this.props.location.state === undefined || !this.props.location.state.showAlerts) && !_.isEmpty(this.props.alert)) {
            this.props.alertClear()
        }
    }

    async componentDidMount() {
        this.isComponentMounted = true;
        const res = await zoneService.getZoneById(this.props.match.params.zoneNum)
        if (this.isComponentMounted) {
            this.setState({zoneData: res.zone});
        }
        await this.loadTableData({});

    }

    async loadTableData(params) {
        if (this.isComponentMounted) {
            this.setState({loading: true})
        }
        params.attrOwner = this.props.match.params.zoneNum
        params.attrName = "allowtransfer"
        for (var key in this.state.filters) {
            if (this.state.filters.hasOwnProperty(key) &&
                this.state.filters[key].value) {
                params[key +
                this.state.filters[key].comparator] = this.state.filters[key].value;
            }
        }

        //   data = {...data, zoneNum: this.props.match.params.zoneNum, rrType: this.props.match.params.type}
        const res = await transferAclZone.getAclXfer(params)
        if (this.isComponentMounted) {
            this.setState({
                data: res.xferzone,
                loading: false,
                totalSize: res.totalRecords
            });
        }
    }


    componentWillUnmount() {
        this.isComponentMounted = false;
    }


    handleFilterChange(e) {
        const {name, value} = e.target;
        const {filters} = this.state;
        const filterInfo = name.split('.');
        filters[filterInfo[0]][filterInfo[1]] = value;
        this.setState({filters: filters});
    }

    extractColumnData(rawData, columnName) {
        const data = rawData.split(',').filter(x => (x && x.split('/').length > 1 && x.split('/')[0].split('.').length > 1))
        /*//if separator is semicolon
            const data = rawData.split(',').filter(x => (x && x.split('/').length>1 && x.split('/')[0].split('.').length>1 ))*/

        return data.map(y => y.split('/')[columnName === 'ip' ? 0 : 1]).join(',');
        /*//incase if we have two separators , ; between ipblock we can use below code
        const rawData="255.255.255.255/32,;ffff:ffff:ffff:ffff:ffff:ffff:ffff:ffff/128;"
        const data = (rawData.split(';').map(x => x.split(',').filter(y => y)))
        data.filter(y=> y.length && y[0].split('/').length>1 && y[0].split('/')[0].split('.').length>1 )
        const res =  data.map(y => y.split('/')[1]).join(',');
        console.log(res)*/
    }

    getZoneTransferACLV4TableColumns() {
        return [
            /*
                        {
                            dataField: 'allowtransfer',
                            text: 'IP Address',
                            headerAlign: 'center',
                            classes: 'text-left p-0',
                            headerStyle: {
                                width: '20%'
                            },
                            style: {
                                wordWrap: 'break-word'
                            },
                            // formatter: (cell, row, rowIndex) => this.extractColumnData(row.attrValue, 'ip')
                        },
            */
            {
                dataField: 'attrValue',
                text: 'Value',
                headerAlign: 'center',
                classes: 'text-left p-0',
                headerStyle: {
                    width: '70%'
                },
                style: {
                    wordWrap: 'break-word'
                },
                //formatter: (cell, row, rowIndex) => this.extractColumnData(row.attrValue, 'mask')
            },
            {
                text: "Action",
                dataField: "",
                headerAlign: 'center',
                headerStyle: {
                    width: "30%"
                },
                formatter: (cell, row, rowIndex) => <>
                    <Link
                        to={`/dns/zones/details/${this.props.match.params.zoneNum}/xferzones/${this.props.match.params.type}/details/${row.recId}`}
                        key={"details_" + row.recId}
                        className={"color-dragon-blue mr-2"}
                    >Details</Link>
                    <Link
                        to={`/dns/zones/details/${this.props.match.params.zoneNum}/xferzones/${this.props.match.params.type}/edit/${row.recId}`}
                        key={"edit_" + row.recId}
                        className={"color-dragon-blue mr-2"}

                    >Edit</Link>
                </>

            }


            /*{
                dataField: 'updateTime',
                text: 'Last Modified',
                headerAlign: 'center',
                classes: 'text-left p-0',
                headerStyle: {
                    width: '20%'
                },
                style: {
                    wordWrap: 'break-word'
                },
            },*/
        ];

    }

    /*
        getAdvanceSearchDialog() {
            const {zoneData} = this.state

            return <Dialog
                fullWidth={true}
                onClose={(event, reason) => {
                    if (reason === 'backdropClick' || reason === 'escapeKeyDown') {
                        return false;
                    }
                }}
                maxWidth="lg"
                open={this.state.showAdvanceSearch}
            >
                <DialogTitle id="form-dialog-title"><h6 className={"font-weight-bolder"}>DNS Search Resource Records
                    Page</h6>
                </DialogTitle>
                <DialogContent>
                    <Form>
                        <Form.Group as={Row} className={'align-items-center'}>
                            <Form.Label column sm="2" className={'font-weight-bold'}>
                                IP Address
                            </Form.Label>
                            <Col sm={4}>
                                <Form.Control name={'attrValue.value'}
                                              value={this.state.filters.attrValue.value}
                                              onChange={this.handleFilterChange}/>
                            </Col>
                        </Form.Group>

                    </Form>
                </DialogContent>

                <DialogActions>
                    <Button onClick={async (e) => {
                        await this.loadTableData({});
                        this.setState(
                            {showAdvanceSearch: false});
                    }
                    } color="primary" className={'dns-blue-button text-white'}
                    >
                        Search RRs
                    </Button>
                    <Button onClick={() => this.setState(
                        {showAdvanceSearch: false})}
                            color="primary" className={'dns-blue-button text-white'}>
                        Close
                    </Button>
                    <Button type={"reset"} onClick={() => {
                        this.setState({filters: _.cloneDeep(defaultFilters)}, () => {
                            this.loadTableData({numberOfRows: 10, pageNumber: 1})
                        });
                    }} variant="contained"
                            className={"dns-blue-button text-white ml-2"}
                            disabled={JSON.stringify(this.state.filters) === JSON.stringify(defaultFilters)}>clear</Button>

                </DialogActions>


            </Dialog>
        } //DRAGON3-516
    */


    render() {
        const {data} = this.state;
        let columns = this.getZoneTransferACLV4TableColumns();

        return <div>
            <Helmet><title>
                DNS Zone Transfers ACLs
            </title></Helmet>

            <Container maxWidth={false} className={"px-2"}>
                <Card>
                    <CardContent>
                        <div className="mt-2 ml-2 mr-3 mb-2  pb-5">
                            <h5 className={"font-weight-bold mt-4 mb-4"}>DNS Zone Transfers ACLs</h5>
                            {/*
                            {this.getAdvanceSearchDialog()} //DRAGON3-516
*/}

                            <div>
                                {this.props.alert.message &&
                                    <Alert severity={this.props.alert.type}>{this.props.alert.message}</Alert>}
                                <div className="pl-2 pr-2">
                                   {/* {(!this.state.loading && _.isEmpty(this.state.data)) && <Link
                                        className={"d-inline-block btn btn-primary dns-blue-button mr-1"}
                                        to={"/dns/zones/details/" + this.props.match.params.zoneNum + "/xferzones/" + this.props.match.params.type + "/create"}
                                    >Insert Record</Link>} DRAGON3-513*/}

                                   <Link
                                        className={"d-inline-block btn btn-primary dns-blue-button mr-1"}
                                        to={"/dns/zones/details/" + this.props.match.params.zoneNum + "/xferzones/" + this.props.match.params.type + "/create"}
                                    >Insert Record</Link>
                                    {/*
                                    <div className={"col text-right mt-2 mb-2"}>
                                        <Button aria-controls="simple-menu"
                                                aria-haspopup="true"
                                                color="primary"
                                                className={'dns-blue-button'}
                                                variant={'contained'}
                                                onClick={() => {
                                                    this.props.alertClear();
                                                    this.setState(
                                                        {showAdvanceSearch: true});
                                                }} key={'advance_search'}>Search</Button>

                                        {(JSON.stringify(this.state.filters) !== JSON.stringify(defaultFilters)) &&
                                            <Button type={"reset"} onClick={() => {
                                                this.setState({filters: _.cloneDeep(defaultFilters)}, () => {
                                                    this.loadTableData({numberOfRows: 10, pageNumber: 1})
                                                });
                                            }} variant="contained"
                                                    className={"dns-blue-button text-white ml-2"}


                                            >clear</Button>
                                        }
                                    </div>    //DRAGON3-516
*/}

                                    <div className={"pt-4 pb-4"}>
                                            <span
                                                className={'font-weight-bold'}>Zone Name</span>: {this.state.zoneData.zoneName}

                                        <span
                                            className={'font-weight-bold  pl-5'}>Zone ID</span> : {this.state.zoneData.zoneNum}<br/>

                                    </div>

                                    <BootstrapTable bootstrap4
                                                    keyField={"recId"}
                                                    data={data}
                                                    columns={columns}
                                                    noDataIndication="Table is Empty"
                                                    loading={this.state.loading}
                                                   // overlay={overlayFactory({spinner: true})}
                                                    remote
                                                    condensed
                                                    striped
                                                    hover
                                                    loading={true}
                                    />

                                    <b>NOTE:</b><p> To block all transfers for a zone, the zone should have a single ACL
                                    with
                                    an IP of 255.255.255.255 and a netmask of 32.</p>
                                </div>
                            </div>
                        </div>
                    </CardContent>
                </Card>
            </Container>
        </div>
    }

}


function mapState(state) {
    const {alert, clear} = state
    return {alert, clear}
}


const actionCreators =
    {
        alertClear: alertActions.clear,
    }

const connectedTransferZone = withRouter(connect(mapState, actionCreators)(Search));
export {connectedTransferZone as Search};