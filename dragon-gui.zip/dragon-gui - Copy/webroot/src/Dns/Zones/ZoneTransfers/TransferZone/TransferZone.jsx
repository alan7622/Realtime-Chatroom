//07/12/2023: DRAGON3-514 -->removing list zone transfer acl button
import React, {Component} from "react";
import PropTypes from "prop-types";
import {alertActions, serverGroupActions, transferAclZones, zoneActions} from "../../../../_actions";
import {withRouter} from "react-router-dom";
import {connect} from "react-redux";
import Form from "react-bootstrap/Form";
import {Alert} from "@material-ui/lab";
import {Col, Row} from "react-bootstrap";
import {
    Backdrop,
    Button,
    Card,
    CardContent,
    CircularProgress,
    Dialog,
    DialogActions,
    DialogTitle
} from "@material-ui/core";
import {Helmet} from "react-helmet";
import Container from "@material-ui/core/Container";
import {transferAclZone as transferAclZoneService} from "../../../../_services";
import _ from "lodash";

class TransferZone extends Component {

    constructor(props) {
        super(props);
        this.state = {
            loading: true,
            zoneData: '',
            aclData: [],
            showDeleteConfirm: false,
            alert:'',
            error:'',
            attrName: 'allowtransfer',
            declarationAttr: {
                zoneNum: this.props.match.params.zoneNum,
                comments: '',
                json: {
                    //buddy: 'n',
                    "allowtransfer": "",
                    all_zones_in_account: 'n'
                },

            },

        }
        this.isComponentMounted = true;
        this.getDeleteConfirmDialog = this.getDeleteConfirmDialog.bind(this);
        this.deleteAcl = this.deleteAcl.bind(this);
        this.updateObj = this.updateObj.bind(this);
        this.saveTransferZone = this.saveTransferZone.bind(this);
        this.getDeleteConfirmDialog = this.getDeleteConfirmDialog.bind(this);


        if ((this.props.location.state === null || this.props.location.state === undefined || !this.props.location.state.showAlerts) && !_.isEmpty(this.props.alert)) {
            this.props.alertClear()
        }
    }

    async componentDidMount() {
        this.isComponentMounted = true;
        this.props.getZoneById(this.props.match.params.zoneNum)
        let data = {
            attrOwner: this.props.match.params.zoneNum, attrName: this.state.attrName
        }
        const response = await transferAclZoneService.getAllAclXferList(data)
        if (response.success) {

            this.setState({aclData: response.xferzone, loading: false})
        }
        else {
            this.setState({xferzone: {}, loading: false,error:response.error.text})

        }

    }

    saveTransferZone(e) {
        e.preventDefault()
        let appendPrvAllowTransfer = '';
        if (this.props.isEmptyForm) {
            let aclAllowTransfer = this.state.aclData.filter(obj => obj.attrName == "allowtransfer")
            if (aclAllowTransfer.length) {
                appendPrvAllowTransfer = aclAllowTransfer[0]?.attrValue
            }
        }

        let requestBodyJson = {
            allowtransfer: appendPrvAllowTransfer
        }
        let acldata = {}
        let sendJson = false
        if (!_.isEmpty(this.state.declarationAttr.json.allowtransfer)) {
            requestBodyJson.allowtransfer += this.state.declarationAttr.json.allowtransfer
            sendJson = true
        }
        if (this.state.declarationAttr.json.all_zones_in_account != 'n') {
            requestBodyJson.allowtransfer += ";all_zones_in_account";
            sendJson = true
        }
        if (sendJson) {
            acldata.json = JSON.stringify(requestBodyJson)
        }
        if (this.state.declarationAttr.comments) {
            acldata.comments = this.state.declarationAttr.comments;
        }
        this.setState({loading: true})

   /*     let requestBodyJson = {
            allowtransfer:
                appendPrvAllowTransfer +
                (this.state.declarationAttr.json.allowtransfer ? this.state.declarationAttr.json.allowtransfer : '')

        }
        if (this.state.declarationAttr.json.all_zones_in_account != 'n') {
            requestBodyJson.allowtransfer += "all_zones_in_account";
        }

        let acldata = {
            json: JSON.stringify(requestBodyJson)
        }
        */

        if (this.props.isEditable) {
            this.props.update(this.props.match.params.zoneNum, acldata, this.props.match.params.type);//false is for excludeRRStr(in resourcerecordactions file) condition is not true in which it allows  user to update rrStr

        }
    }

    componentWillUnmount() {
        this.isComponentMounted = false;
    }


    updateObj(e) {
        if (e.keyCode === 8 && e.target.selectionStart === 0 && e.target.selectionEnd === e.target.value.length) {
            e.preventDefault(); // Prevent default backspace behavior
            e.target.value = ""; // Clear the input value
        }
        let {name, value} = e.target;
        const {declarationAttr} = this.state
        declarationAttr.json[name] = value;
        this.setState(declarationAttr);


    }

    getDeleteConfirmDialog() {
        return !this.props.isEditable && <Dialog
            onClose={(event, reason) => {
                if (reason === 'backdropClick' || reason === 'escapeKeyDown') {
                    return false;
                }
            }}
            maxWidth="xs"
            aria-labelledby="confirmation-dialog-title"
            open={this.state.showDeleteConfirm}>
            <DialogTitle id="confirmation_dialog_title">Are you sure you want to delete this
                record?</DialogTitle>
            <DialogActions>
                <Button autoFocus onClick={this.deleteAcl} className={"dns-blue-button text-white"}>
                    Delete
                </Button>
                <Button onClick={() => this.setState({showDeleteConfirm: false})}
                        className={"dns-blue-button text-white"}>
                    Cancel
                </Button>
            </DialogActions>
        </Dialog>
    }

    deleteAcl() {
        this.setState({showDeleteConfirm: false, loading: true})
        this.props.delete(this.props.match.params.zoneNum, this.props.match.params.id, this.props.match.params.type);
    }


    getPageButtons() {
        let pageElements = {
            pageTitle: '',
            pageButtons: [],
        }
        if (this.props.isEditable && this.props.isEmptyForm) {
            // pageElements.pageTitle = "DNS Record Creation"
            pageElements.pageButtons.push(<Button className={"dns-blue-button text-white mr-2"}
                                                  type={"submit"}//using the submit form instead of click button
                                                  key={"insert"}>Insert</Button>)
            pageElements.pageButtons.push(<Button className={"dns-blue-button text-white mr-2 col-md-1"}
                                                  onClick={() => {
                                                      this.props.alertClear();
                                                      this.props.history.goBack()
                                                  }}
                                                  key={"cancel_update"}>Cancel</Button>)


        } else if (this.props.isEditable) {
            pageElements.pageTitle = "DNS  Record Update"
            pageElements.pageButtons.push(<Button className={"dns-blue-button text-white mr-2 col-md-1"}
                                                  type={"submit"}
                                                  onClick={() => this.props.alertClear()}

                                                  key={"update"}>Update</Button>)
            pageElements.pageButtons.push(<Button className={"dns-blue-button text-white mr-2 col-md-1"}
                                                  onClick={() => {
                                                      this.props.alertClear();

                                                      this.props.history.goBack()
                                                  }}
                                                  key={"cancel_update"}>Cancel</Button>)


        } else {
            pageElements.pageButtons.push(<Button className={"dns-blue-button text-white mt-2 mr-4 mb-4"}
                                                  onClick={() => {
                                                      this.props.alertClear();
                                                      this.props.history.push(`/dns/zones/details/${this.props.match.params.zoneNum}/xferzones/${this.props.match.params.type}/edit/${this.props.match.params.id}`)
                                                  }} key={"edit"}>Go To Update</Button>)
            pageElements.pageButtons.push(<Button className={"dns-blue-button text-white mt-2 mr-4 mb-4"}
                                                  onClick={() => {
                                                      this.props.alertClear();
                                                      this.setState({showDeleteConfirm: true})
                                                  }} key={"delete"}>Delete</Button>)

            pageElements.pageButtons.push(<Button className={"dns-blue-button text-white mt-2 mb-4"}
                                                  onClick={() => {
                                                      this.props.alertClear();
                                                      this.props.history.push(`/dns/zones/details/${this.props.match.params.zoneNum}/xferzones/${this.props.match.params.type}`)
                                                  }}
                                                  key={"list_users"}>List Zone Transfer ACLs</Button>)
        }


        return pageElements;
    }


    getAclForm() {
        const {json, aclData} = this.state
        let {pageButtons} = this.getPageButtons();
        return <form onSubmit={this.saveTransferZone}>
            <h5 className={"font-weight-bold"}>DNS Zone Transfer ACL Record</h5>

            <Form.Group as={Row} className={"align-items-center"}>
                <Form.Label column sm="2"
                            className={"font-weight-bold"}>
                    Zone ID
                </Form.Label>
                <Col sm="4">
                    {this.props.zone?.zoneNum}
                </Col>
            </Form.Group>
            <Form.Group as={Row} className={"align-items-center"}>
                <Form.Label column sm="2"
                            className={"font-weight-bold"}>
                    Zone Name
                </Form.Label>
                <Col sm="4">
                    {this.props.zone?.zoneName}
                </Col>
            </Form.Group>

            <Form.Group as={Row} className={"align-items-center"}>
                <Form.Label column sm="2"
                            className={"font-weight-bold"}>
                    {this.props.isEditable ? "*" : ""} Value
                </Form.Label>
                <Col sm="6">
                    {this.props.isEditable ?
                        <Form.Control name={"allowtransfer"}
                                      onChange={this.updateObj}
                                      onKeyDown={this.updateObj}
                                      required={true}
                                      defaultValue={!this.props.isEmptyForm && !_.isEmpty(aclData) ? aclData.filter(obj => obj.attrName === "allowtransfer")[0].attrValue : ''}
                        /> : !_.isEmpty(aclData) ? aclData.filter(obj => obj.attrName === "allowtransfer")[0].attrValue : ''}
                </Col>
            </Form.Group>

            <Form.Group as={Row} className={"align-items-center"}>
                <Form.Label column sm="2"
                            className={"font-weight-bold"}>
                    Add this ACL to all zones
                </Form.Label>
                <Col sm="2">

                    {this.props.isEditable ?
                        <Form.Control as="select" name={"all_zones_in_account"}
                                      onChange={this.updateObj}
                                      onKeyDown={this.updateObj}
                                      value={this.state.declarationAttr.json.all_zones_in_account}>
                            <option value={"y"}>Y</option>
                            <option value={"n"}>N</option>
                        </Form.Control>
                        : this.state.declarationAttr.json.all_zones_in_account}
                </Col>
            </Form.Group>
            <Form.Group as={Row} className={"align-items-center"}>
                <Form.Label column sm="2"
                            className={"font-weight-bold"}>
                    Comment
                </Form.Label>
                <Col sm="4">

                    {this.props.isEditable ?
                        <Form.Control name={"comments"}
                                      onChange={this.updateObj}
                                      onKeyDown={this.updateObj}
                                      defaultValue={this.state.declarationAttr.json.comments ? this.state.declarationAttr.json.comments : ''}
                        /> : this.state.declarationAttr.json.comments}
                </Col>
            </Form.Group>

            <div className={"text-center"}>
                {pageButtons.map(buttonComp => buttonComp)}
            </div>

        </form>
    }


    componentWillUnmount() {
        this.isComponentMounted = false;
    }

    componentWillMount() {
    }

    checkIpMask(octet1, octet2,
                octet3, octet4, mask) {
        let account;

        if (mask <= 0 || mask > 32)
            return -1;
        if (octet1 > 255 || octet1 < 0)
            return -1;
        if (octet2 > 255 || octet2 < 0)
            return -1;
        if (octet3 > 255 || octet3 < 0)
            return -1;
        if (octet4 > 255 || octet4 < 0)
            return -1;

        switch (mask) {
            case 8:
                if (octet2 != 0 || octet3 != 0 || octet4 != 0)
                    return -1;
                return 0;
            case 16:
                if (octet3 != 0 || octet4 != 0) {
                    return -1;
                }
                return 0;
            case 24:
                if (octet4 != 0) {
                    return -1;
                }
                return 0;
            case 32:
                return 0;
            default:
                if (mask > 24 && mask <= 32) {

                    switch (mask) {
                        case 25:
                            account = 128;
                            break;
                        case 26:
                            account = 64;
                            break;
                        case 27:
                            account = 32;
                            break;
                        case 28:
                            account = 16;
                            break;
                        case 29:
                            account = 8;
                            break;
                        case 30:
                            account = 4;
                            break;
                        case 31:
                            account = 2;
                            break;
                        default:
                            return -1;
                    }
                    if (octet4 % account != 0) {
                        return -1;
                    }
                    return 0;
                } else if (mask > 16 && mask < 24) {

                    if (octet4 != 0) {
                        return -1;
                    }
                    switch (mask) {
                        case 17:
                            account = 128;
                            break;
                        case 18:
                            account = 64;
                            break;
                        case 19:
                            account = 32;
                            break;
                        case 20:
                            account = 16;
                            break;
                        case 21:
                            account = 8;
                            break;
                        case 22:
                            account = 4;
                            break;
                        case 23:
                            account = 2;
                            break;
                        default:
                            return -1;
                    }
                    if (octet3 % account != 0) {
                        return -1;
                    }
                    return 0;
                } else if (mask > 8 && mask < 16) {
                    if (octet3 != 0 || octet4 != 0) {
                        return -1;
                    }
                    switch (mask) {
                        case 9:
                            account = 128;
                            break;
                        case 10:
                            account = 64;
                            break;
                        case 11:
                            account = 32;
                            break;
                        case 12:
                            account = 16;
                            break;
                        case 13:
                            account = 8;
                            break;
                        case 14:
                            account = 4;
                            break;
                        case 15:
                            account = 2;
                            break;
                        default:
                            return -1;
                    }
                    if (octet2 % account != 0) {
                        return -1;
                    }
                    return 0;
                } else if (mask > 0 && mask < 8) {
                    if (octet2 != 0 || octet3 != 0 || octet4 != 0) {
                        return -1;
                    }
                    switch (mask) {
                        case 1:
                            account = 128;
                            break;
                        case 2:
                            account = 64;
                            break;
                        case 3:
                            account = 32;
                            break;
                        case 4:
                            account = 16;
                            break;
                        case 5:
                            account = 8;
                            break;
                        case 6:
                            account = 4;
                            break;
                        case 7:
                            account = 2;
                            break;
                        default:
                            return -1;
                    }
                    if (octet1 % account != 0) {
                        return -1;
                    }
                    return 0;
                }
                break;
        }
        return -1;
    }//need to check values of octet1,2,3,4 and mask

    render() {
        return <>
            {/*

*/}
            {/*  <Backdrop className={"page-loading"} style={{'zIndex': '10000', 'color': '#fff'}}
                      open={this.state.loading && (this.props.saving == true)}>
                <CircularProgress color="inherit"/>
            </Backdrop>*/}
            <div>
                <Helmet>
                    <title>DNS xfer zones | zones</title>
                </Helmet>

                <Container maxWidth={false} className={"px-2"}>
                    <Card>
                        <CardContent>
                            <div className="pt-3 pl-4 pr-5">
                                {/*
                                <h6 className={"font-weight-bold  text-capitalize text-left pt-3 pb-4"}>title</h6>
*/}
                                <div className={"pb-2"}>
                                    {(this.props.alert.message || this.state.error)  && <Alert
                                        severity={this.props.alert.type ? this.props.alert.type:"error"}>{this.props.alert.message ? this.props.alert.message:this.state.error}</Alert>}</div>
                                {this.getDeleteConfirmDialog()}
                                {this.getAclForm()}

                            </div>
                        </CardContent>
                    </Card>
                </Container>
            </div>
        </>
    }

}

TransferZone.defaultProps = {
    isEditable: false,
};
TransferZone.propTypes = {
    isEditable: PropTypes.bool,
    isEmptyForm: PropTypes.bool
};
TransferZone.defaultProps = {
    isEditable: false,
    isEmptyForm: false
}

function mapState(state) {
    const {alert, clear} = state
    // const {loading, saved, deleted, deleting} = state.srvrGrp
    const {loading, zone} = state.zones

    return {alert, clear, loading, zone}
}

const actionCreators = {
    alertClear: alertActions.clear,
    getZoneById: zoneActions.getZoneById,
    update: transferAclZones.update,
    delete: transferAclZones.delete
};


const connectedTransferZone = withRouter(connect(mapState, actionCreators)(TransferZone));
export {connectedTransferZone as TransferZone};

