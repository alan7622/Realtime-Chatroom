import React, {Component} from "react";
import {alertActions} from "../../../../_actions";
import {Link, withRouter} from "react-router-dom";
import {connect} from "react-redux";
import {Helmet} from "react-helmet";
import {Card, CardContent} from "@material-ui/core";
import Container from "@material-ui/core/Container";
import BootstrapTable from "react-bootstrap-table-next";
import {Alert} from "@material-ui/lab";
import {transferAclZone, zoneService} from "../../../../_services";


class Search extends Component {

    constructor(props) {
        super(props);
        this.state = {
            data: [],
            zoneData: {},

        }
        this.isComponentMounted = false;
    }

    async componentDidMount() {
        this.isComponentMounted = true;
        const res = await zoneService.getZoneById(this.props.match.params.zoneNum)
        if (this.isComponentMounted) {
            this.setState({zoneData: res.zone});
        }
        await this.loadTableData({});

    }

    async loadTableData(params) {
        if (this.isComponentMounted) {
            this.setState({loading: true})
        }
        params.attrOwner = this.props.match.params.zoneNum
        for (var key in this.state.filters) {
            if (this.state.filters.hasOwnProperty(key) &&
                this.state.filters[key].value) {
                params[key +
                this.state.filters[key].comparator] = this.state.filters[key].value;
            }
        }
        console.log(params)

        const res = await transferAclZone.getAclXfer(params)
        if (this.isComponentMounted) {
            this.setState({
                data: res.xferzone,
                loading: false,
                totalSize: res.totalRecords
            });
        }
    }


    componentWillUnmount() {
        this.isComponentMounted = false;
    }

    extractColumnData(rawData, columnName){
        const data = rawData.split(',').filter(x => (x && x.split('/').length>1 && x.split('/')[0].split(':').length>1 ))
        /*//if separator is semicolon
            const data = rawData.split(',').filter(x => (x && x.split('/').length>1 && x.split('/')[0].split('.').length>1 ))*/

        console.log(data,"data")
        return  data.map(y => y.split('/')[columnName==='ip' ? 0 : 1]).join(',');
        /*//incase if we have two separators , ; between ipblock we can use below code
        const rawData="255.255.255.255/32,;ffff:ffff:ffff:ffff:ffff:ffff:ffff:ffff/128;"
        const data = (rawData.split(';').map(x => x.split(',').filter(y => y)))
        data.filter(y=> y.length && y[0].split('/').length>1 && y[0].split('/')[0].split('.').length>1 )
        const res =  data.map(y => y.split('/')[1]).join(',');
        console.log(res)*/
    }


    getZoneTransferACLV6TableColumns() {
        return [
/*
            {
                dataField: 'updateTime',
                text: 'Last Modified',
                headerAlign: 'center',
                classes: 'text-left p-0',
                headerStyle: {
                    width: '20%'
                },
                style: {
                    wordWrap: 'break-word'
                },
            },
*/
            {
                dataField: 'attrValue',
                text: 'IP Address',
                headerAlign: 'center',
                classes: 'text-left p-0',
                headerStyle: {
                    width: '20%'
                },
                style: {
                    wordWrap: 'break-word'
                },
                formatter: (cell, row, rowIndex) => this.extractColumnData(row.attrValue, 'ip')



            },
            {
                dataField: 'attrValue',
                text: 'NetMask',
                headerAlign: 'center',
                classes: 'text-left p-0',
                headerStyle: {
                    width: '20%'
                },
                style: {
                    wordWrap: 'break-word'
                },
                formatter: (cell, row, rowIndex) => this.extractColumnData(row.attrValue, 'mask')


            },
            {
                text: "Action",
                dataField: "",
                headerAlign: 'center',
                headerStyle: {
                    width: "20%"
                },
                formatter: (cell, row, rowIndex) => <>
                    <Link
                        to={`/dns/zones/details/${this.props.match.params.zoneNum}/xferzones/${this.props.match.params.rrType}/details`}
                        key={"details_dns_srvrgrp"}
                        className={"color-dragon-blue mr-2"}
                    >Details</Link>
                    <Link
                        to={`/dns/zones/details/${this.props.match.params.zoneNum}/servers/${this.props.match.params.rrType}/edit/`}
                        key={"details_dns_srvrgrp"}
                        className={"color-dragon-blue mr-2"}
                    >Edit</Link>
                </>

            }
        ];

    }

    render() {
        const {data} = this.state;
        let columns = this.getZoneTransferACLV6TableColumns();

        return <div>
            <Helmet><title>
                DNS Zone Transfers ACLs
            </title></Helmet>

            <Container maxWidth={false} className={"px-2"}>
                <Card>
                    <CardContent>
                        <div className="mt-2 ml-2 mr-3 mb-2  pb-5">
                            <h5 className={"font-weight-bold mt-4 mb-4"}>DNS Zone Transfers ACLs</h5>

                            <div>
                                {this.props.alert.message &&
                                <Alert severity={this.props.alert.type}>{this.props.alert.message}</Alert>}
                                <div className="pl-2 pr-2">
                                    <div className={"pt-4 pb-4"}>
                                            <span
                                                className={'font-weight-bold'}>Zone Name</span>: {this.state.zoneData.zoneName}

                                        <span
                                            className={'font-weight-bold  pl-5'}>Zone ID</span> : {this.state.zoneData.zoneNum}<br/>

                                    </div>

                                    <BootstrapTable bootstrap4
                                                    keyField={"zoneNum"}
                                                    data={data}
                                                    columns={columns}
                                                    noDataIndication="Table is Empty"
                                                    remote
                                                    condensed
                                                    striped
                                                    hover
                                                    loading={true}
                                    />
                                  <b>NOTE:</b>  <p>To block all transfers for a zone, the zone should have a single ACL with an IP6 address, ffff:ffff:ffff:ffff:ffff:ffff:ffff:ffff and netmask of 128.</p>

                                    <p> To get a full list of these RR records, go to Search and click on the Search RRs button without entering any search arguments.</p>

                                </div>
                            </div>
                        </div>
                    </CardContent>
                </Card>
            </Container>
        </div>
    }

}


function mapState(state) {
    const {alert} = state
    return {alert}
}


const actionCreators =
    {
        alertClear: alertActions.clear,
    }

const connectedXferIPv6Acl = withRouter(connect(mapState, actionCreators)(Search));
export {connectedXferIPv6Acl as Search};