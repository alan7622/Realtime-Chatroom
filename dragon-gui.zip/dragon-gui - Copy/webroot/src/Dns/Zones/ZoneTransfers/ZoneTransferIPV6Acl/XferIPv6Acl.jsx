import {Component} from "react";
import PropTypes from "prop-types";
import {alertActions} from "../../../../_actions";
import {withRouter} from "react-router-dom";
import {connect} from "react-redux";

class XferIPv6Acl extends Component {

    render() {
        return <></>
    }

}

XferIPv6Acl.defaultProps = {
    isEditable: false,
};
XferIPv6Acl.propTypes = {
    isEditable: PropTypes.bool,
    isEmptyForm: PropTypes.bool
};
XferIPv6Acl.defaultProps = {
    isEditable: false,
    isEmptyForm: false
}

function mapState(state) {
    const {alert} = state
    return {alert}
}

const actionCreators = {
    alertClear: alertActions.clear,
};



const connectedXferIPv6Acl= withRouter(connect(mapState, actionCreators)(XferIPv6Acl));
export {connectedXferIPv6Acl as XferIPv6Acl};

