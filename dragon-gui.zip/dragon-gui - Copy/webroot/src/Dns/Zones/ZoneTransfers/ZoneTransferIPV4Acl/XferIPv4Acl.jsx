import React, {Component} from "react";
import PropTypes from "prop-types";
import {alertActions, serverGroupActions} from "../../../../_actions";
import {withRouter} from "react-router-dom";
import {connect} from "react-redux";
import Form from "react-bootstrap/Form";
import {Alert} from "@material-ui/lab";
import {Col, Row} from "react-bootstrap";
import {
    Backdrop,
    Button,
    Card,
    CardContent,
    CircularProgress,
    Dialog,
    DialogActions,
    DialogTitle
} from "@material-ui/core";
import {Helmet} from "react-helmet";
import Container from "@material-ui/core/Container";

class XferIPv4Acl extends Component {

    constructor(props) {
        super(props);
        this.state = {
            data: [],
            //zoneData: {},
            zone: {},
            showDeleteConfirm: false,
            showAdvanceSearch: false,

        }
        this.isComponentMounted = false;
        this.getDeleteConfirmDialog = this.getDeleteConfirmDialog.bind(this);


    }

    saveXferAclZone() {
        if (this.isComponentMounted) {

            this.setState({loading: true, saving: true})
        }


        if (this.props.isEmptyForm && this.props.isEditable) {
            //rrGrp:same as zoneNum for now,comments:comments from user
            this.props.create();
        } else {
            this.props.update(this.props.match.params.id);
        }

    }


    async componentDidMount() {
        this.isComponentMounted = true;
        console.log(octet1, "octet1")
        //api call
        //details of the transfer zone
    }



    getDeleteConfirmDialog() {
        return !this.props.isEditable && <Dialog
            onClose={(event, reason) => {
                if (reason === 'backdropClick' || reason === 'escapeKeyDown') {
                    return false;
                }
            }}
            maxWidth="xs"
            aria-labelledby="confirmation-dialog-title"
            open={this.state.showDeleteConfirm}
        >
            <DialogTitle id="confirmation_dialog_title">Are you sure you want to delete this
                record?</DialogTitle>
            <DialogActions>
                <Button autoFocus onClick={this.deleteRR} className={"dns-blue-button text-white"}>
                    Delete
                </Button>
                <Button onClick={() => {
                    if (this.isComponentMounted) {
                        this.setState({showDeleteConfirm: false})
                    }
                }}
                        className={"dns-blue-button text-white"}>
                    Cancel
                </Button>
            </DialogActions>
        </Dialog>
    }



    getPageButtons(){
        let pageElements = {
            pageTitle: '',
            pageButtons: [],
        }
        if (this.props.isEditable && this.props.isEmptyForm) {
            pageElements.pageTitle = "DNS Zone Transfer ACL Creation"
            pageElements.pageButtons.push(<Button className={"dns-blue-button text-white mr-2"}
                                                  onClick={this.saveXferAclZone}
                                                  key={"insert"}>Insert</Button>)
            pageElements.pageButtons.push(<Button className={"dns-blue-button text-white mr-2 col-md-1"}
                                                  onClick={() => {
                                                      this.props.alertClear();
                                                      this.props.history.push(`/dns/zones/details/${this.props.match.params.zoneNum}/xferacv4/details/${this.props.match.params.id}`)
                                                  }}
                                                  key={"cancel_update"}>Cancel</Button>)


        } else if (this.props.isEditable) {
            pageElements.pageTitle = "DNS Zone Transfer ACL Update"
            pageElements.pageButtons.push(<Button className={"dns-blue-button text-white mr-2 col-md-1"}
                                                  onClick={this.saveXferAclZone}
                                                  key={"update"}>Update</Button>)
            pageElements.pageButtons.push(<Button className={"dns-blue-button text-white mr-2 col-md-1"}
                                                  onClick={() => {
                                                      this.props.alertClear();
                                                      this.props.history.goBack()
                                                  }}
                                                  key={"cancel_update"}>Cancel</Button>)


        } else {
            pageElements.pageTitle = "DNS Zone Transfer ACL Details"
            pageElements.pageButtons.push(<Button className={"dns-blue-button text-white mt-2 mr-4 mb-4"}
                                                  onClick={() => this.props.history.push(`/dns/zones/details/${this.props.match.params.zoneNum}/xferacv4/details/${this.props.match.params.id}`)}
                                                  key={"edit"}>Go To Update</Button>)
            pageElements.pageButtons.push(<Button className={"dns-blue-button text-white mt-2 mr-4 mb-4"}
                                                  onClick={() => {
                                                      if (this.isComponentMounted) {
                                                          this.setState({showDeleteConfirm: true})
                                                      }
                                                  }} key={"delete"}>Delete</Button>)
            pageElements.pageButtons.push(<Button className={"dns-blue-button text-white mt-2 mb-4"}
                                                  onClick={() => this.props.history.push(`/dns/zones/details/${this.props.match.params.zoneNum}/xferacv4/details/${this.props.match.params.id}`)}
                                                  key={"list_a_records"}>List Zone Transfer Acl  Records</Button>)


        }

        return [pageElements];

       // return [<button></button>]
    }

    getPageTitle(){
        //url === edit retutn "edit zone "
        return
    }


    getXferIPv4AclForm() {
        const {zone} = this.state
        const pageButtons = this.getPageButtons();

        const pageTitle = this.pageTitle();
        return (<>
            <h6 className={"font-weight-bold  text-capitalize text-left pt-3 pb-4"}>{pageTitle}</h6>
            <Form>
                {this.props.alert.message &&
                <Alert severity={this.props.alert.type}>{this.props.alert.message}</Alert>}
                <Form.Group as={Row} className={"align-items-center"}>
                    <Form.Label column sm="2" className={"font-weight-bold"}>
                        Zone Number
                    </Form.Label>
                    <Col sm="2">
                        {zone.zoneNum}
                    </Col>
                    <Form.Label column sm="2" className={"font-weight-bold"}>
                        Record Id </Form.Label>
                    <Col sm="2">
                        {this.props.isEditable ?
                            <Form.Control name={"recId"} onChange={this.updateZoneObj}
                                          defaultValue={zone.recId ? zone.recId : ''}/> : zone.recId}

                    </Col>
                </Form.Group>
                <Form.Group as={Row} className={"align-items-center"}>

                    <Form.Label column sm="2" className={"font-weight-bold"}>
                        IP/Network Address</Form.Label>
                    <Col sm="2">
                        {this.props.isEditable ?
                            <Form.Control name={"allowtransfer"} onChange={this.updateZoneObj}
                                          defaultValue={zone.allowtransfer ? zone.allowtransfer : ''}/> : zone.allowtransfer}
                    </Col>
                    {!this.props.isEditable && <>     <Form.Label column sm="2" className={"font-weight-bold"}>
                        Netmask </Form.Label>
                        <Col sm="2">
                            {zone.masterlist}
                            {this.props.isEditable ?
                                <Form.Control name={"masterlist"} onChange={this.updateZoneObj}
                                              defaultValue={zone.masterlist ? zone.masterlist : ''}/> : zone.masterlist}
                        </Col></>}

                </Form.Group>
                {
                    !this.props.isEditable &&
                    <Form.Group as={Row} className={"align-items-center"}> <Form.Label column sm="2"
                                                                                       className={"font-weight-bold"}>
                        Modified By
                    </Form.Label>
                        <Col sm="2">
                            {zone.modBy}
                        </Col>
                        <Form.Label column sm="2" className={"font-weight-bold"}>
                            Created </Form.Label>
                        <Col sm="2">
                            {zone.createTime}
                        </Col>
                        <Form.Label column sm="2" className={"font-weight-bold"}>
                            Last Modified </Form.Label>
                        <Col sm="2">
                            {zone.updateTime}
                        </Col>
                    </Form.Group>
                }

                <Form.Group as={Row} className={"align-items-center"}>

                    <Form.Label column sm="2" className={"font-weight-bold"}>
                        Comments
                    </Form.Label>
                    <Col sm="2">
                        {this.props.isEditable ?
                            <Form.Control name={"comment"} onChange={this.updateZoneObj}
                                          defaultValue={zone.comments ? zone.comments : ''}/> : zone.comments}
                    </Col>
                </Form.Group>

                <div className={"text-center"}>
                    {pageButtons.map(buttonComp => buttonComp)}
                </div>
            </Form></>)
    }


    componentWillUnmount() {
        console.log("UNMOUNTING")
        this.isComponentMounted = false;
    }

    componentWillMount() {
    }

    checkIpMask(octet1, octet2,
                octet3, octet4, mask) {
        let account;

        if (mask <= 0 || mask > 32)
            return -1;
        if (octet1 > 255 || octet1 < 0)
            return -1;
        if (octet2 > 255 || octet2 < 0)
            return -1;
        if (octet3 > 255 || octet3 < 0)
            return -1;
        if (octet4 > 255 || octet4 < 0)
            return -1;

        switch (mask) {
            case 8:
                if (octet2 != 0 || octet3 != 0 || octet4 != 0)
                    return -1;
                return 0;
            case 16:
                if (octet3 != 0 || octet4 != 0) {
                    return -1;
                }
                return 0;
            case 24:
                if (octet4 != 0) {
                    return -1;
                }
                return 0;
            case 32:
                return 0;
            default:
                if (mask > 24 && mask <= 32) {

                    switch (mask) {
                        case 25:
                            account = 128;
                            break;
                        case 26:
                            account = 64;
                            break;
                        case 27:
                            account = 32;
                            break;
                        case 28:
                            account = 16;
                            break;
                        case 29:
                            account = 8;
                            break;
                        case 30:
                            account = 4;
                            break;
                        case 31:
                            account = 2;
                            break;
                        default:
                            return -1;
                    }
                    if (octet4 % account != 0) {
                        return -1;
                    }
                    return 0;
                } else if (mask > 16 && mask < 24) {

                    if (octet4 != 0) {
                        return -1;
                    }
                    switch (mask) {
                        case 17:
                            account = 128;
                            break;
                        case 18:
                            account = 64;
                            break;
                        case 19:
                            account = 32;
                            break;
                        case 20:
                            account = 16;
                            break;
                        case 21:
                            account = 8;
                            break;
                        case 22:
                            account = 4;
                            break;
                        case 23:
                            account = 2;
                            break;
                        default:
                            return -1;
                    }
                    if (octet3 % account != 0) {
                        return -1;
                    }
                    return 0;
                } else if (mask > 8 && mask < 16) {
                    if (octet3 != 0 || octet4 != 0) {
                        return -1;
                    }
                    switch (mask) {
                        case 9:
                            account = 128;
                            break;
                        case 10:
                            account = 64;
                            break;
                        case 11:
                            account = 32;
                            break;
                        case 12:
                            account = 16;
                            break;
                        case 13:
                            account = 8;
                            break;
                        case 14:
                            account = 4;
                            break;
                        case 15:
                            account = 2;
                            break;
                        default:
                            return -1;
                    }
                    if (octet2 % account != 0) {
                        return -1;
                    }
                    return 0;
                } else if (mask > 0 && mask < 8) {
                    if (octet2 != 0 || octet3 != 0 || octet4 != 0) {
                        return -1;
                    }
                    switch (mask) {
                        case 1:
                            account = 128;
                            break;
                        case 2:
                            account = 64;
                            break;
                        case 3:
                            account = 32;
                            break;
                        case 4:
                            account = 16;
                            break;
                        case 5:
                            account = 8;
                            break;
                        case 6:
                            account = 4;
                            break;
                        case 7:
                            account = 2;
                            break;
                        default:
                            return -1;
                    }
                    if (octet1 % account != 0) {
                        return -1;
                    }
                    return 0;
                }
                break;
        }
        return -1;
    }//need to check values of octet1,2,3,4 and mask

    render() {
        return <>
            {/*
           {this.getDeleteConfirmDialog()}
*/}
            <Backdrop className={"page-loading"} style={{'zIndex': '10000', 'color': '#fff'}}
                      open={this.state.loading && (this.props.saving == true)}>
                <CircularProgress color="inherit"/>
            </Backdrop>
            <div>
                <Helmet>
                    <title>DNS xfer zones | zones</title>
                </Helmet>

                <Container maxWidth={false} className={"px-2"}>
                    <Card>
                        <CardContent>
                            <div className="pt-3 pl-4 pr-5">

                                {this.getXferIPv4AclForm()}

                            </div>
                        </CardContent>
                    </Card>
                </Container>
            </div>
        </>
    }

}

XferIPv4Acl.defaultProps = {
    isEditable: false,
};
XferIPv4Acl.propTypes = {
    isEditable: PropTypes.bool,
    isEmptyForm: PropTypes.bool
};
XferIPv4Acl.defaultProps = {
    isEditable: false,
    isEmptyForm: false
}

function mapState(state) {
    const {alert} = state
    // const {loading, saved, deleted, deleting} = state.srvrGrp
    return {alert}
}

const actionCreators = {
    alertClear: alertActions.clear,
    // create: serverGroupActions.create,
};


const connectedXferIPv4Acl = withRouter(connect(mapState, actionCreators)(XferIPv4Acl));
export {connectedXferIPv4Acl as XferIPv4Acl};

