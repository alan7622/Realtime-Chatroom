import React from "react";
import {alertActions, zoneActions} from "../../../../_actions";
import {connect} from "react-redux";
import {
    CardContent,
    withStyles,
    Card,
} from "@material-ui/core";
import {Helmet} from "react-helmet";
import Container from "@material-ui/core/Container";
import Box from "@material-ui/core/Box";
import BootstrapTable from 'react-bootstrap-table-next';
import filterFactory, {Comparator} from 'react-bootstrap-table2-filter';
import paginationFactory from 'react-bootstrap-table2-paginator';
import _ from "lodash";
import {Alert} from "@material-ui/lab";
import {Link, withRouter} from "react-router-dom";
import {resourceRecordService} from "../../../../_services/resourceRecord.service";
import PropTypes from "prop-types";
import {isAuthorized, pageRenderer, SizePerPageRenderer} from "../../../../_components";
import {transferAclZone as transferAclZoneService} from "../../../../_services";

const useStyles = theme => ({
    root: {},
    searchButton: {
        backgroundColor: '#4789b6',
        marginBottom: '-10px',
        opacity: '1',
        color: '#FFF',
        width: '50%',
        '&:hover': {backgroundColor: '#3f6bb5', opacity: '1'}
    },
    filterContainer: {
        padding: '20px',
        marginBottom: '30px'
    },

    createAccountButton: {
        backgroundColor: '#4789b6',
        '&:hover': {
            backgroundColor: '#3f75b5',
        },
    },

    searchContainer: {
        textAlign: 'left'
    }
});

class Search extends React.Component {

    constructor(props) {
        super(props);
        this.state = {

            // data: [],
            data: null,
            secondaryNS: null,
            zoneName: '',
            zoneData: '',
            loading: true,
            rrType: '',
            comparator: Comparator.EQ,
            showDeleteConfirm: false,
            showAdvanceSearch: false,
            error: '',
            rrSearchParams: {},
            page: 1,
            sizePerPage: 10,
            totalSize: 0,
            nsType: '',
            srvrgrps: '',
            rr: {
                rrGrp: this.props.match.params.zoneNum,
                rrStr: '',
                rrType: this.props.match.params.type,
                nsType: this.props.match.params.type,
                comments: '',
                recId: '',
                srvrGrp: '',
                rrName: '@'

            },


        }


        this.isComponentMounted = true;
        this.handleTableChange = this.handleTableChange.bind(this);


        if ((this.props.location.state === null || this.props.location.state === undefined || !this.props.location.state.showAlerts) && !_.isEmpty(this.props.alert)) {
            this.props.alertClear()
        }
    }

    async componentDidMount() {

        if (!_.isEmpty(this.props.zone) && this.props.zone?.zoneNum == this.props.match.params.zoneNum) {

        }
        else {
            this.props.getZoneById(this.props.match.params.zoneNum)

        }

    }

    async loadTableData(data) {
        data = {
            ...data,
            zoneNum: this.props.match.params.zoneNum,
            rrType: data.rrType,
            nsType: data.nsType,


        }
        const res = await resourceRecordService.getAllRecords(data);
        const {rrName, rrTtl, rrType, rrData, comments, rrGrp, ...rr} = this.state.rr
        const rrNS = this.props.match.params.type.split("-")
        if (this.isComponentMounted) {
            this.setState({
                loading: false,
                data: res.rr.filter((row) => row.rrName === '@'),//using this display only '@' rrNames to avoid subzones
                error: res.error,
                totalSize: res.totalRecords,
                page: data.pageNumber ? data.pageNumber : this.state.page,
                sizePerPage: data.numberOfRows ?
                    data.numberOfRows :
                    this.state.sizePerPage,
                rrType: data.rrType, nsType: data.nsType,

            });

        }


    }


    async loadNSTableData() {
        let secondaryNSRequest = {attrOwner: this.props.match.params.zoneNum, attrName: "localservers"}
        const response = await transferAclZoneService.getAllAclXferList(secondaryNSRequest)

        if (this.isComponentMounted) {
            this.setState({
                page: this.state.page,
                secondaryNS: response.xferzone,
                loading: false
            })
        }
    }


    async componentDidUpdate(prevProps, prevState, snapshot) {
        console.log(_.isEqual(prevProps.zone, this.props.zone), "this.props - Zone.jsx")
        if (((this.state.loading && this.props.zone) || !_.isEqual(prevProps.zone, this.props.zone))) {


            if ((this.state.data === null) || this.state.secondaryNS === null) {
                console.log(this.state.data, "abc")
                if (this.props.zone.zoneType === 'S') {
                    await this.loadNSTableData({})

                } else {
                    console.log("In Primary")
                    const rrNS = this.props.match.params.type.split("-")

                    await this.loadTableData({
                        zoneNum: this.props.match.params.zoneNum,
                        rrType: rrNS[1],
                        nsType: rrNS[0],
                        numberOfRows: this.state.sizePerPage,
                        pageNumber: this.state.page,
                    });
                }
            }


            this.setState({
                zoneData: _.omit(this.props.zone, ['soaTemplate']),
                loading: false
            }, () => {

                if (prevProps.zone?.zoneStatus != this.props.zone?.zoneStatus) {
                    console.log("this.props - Zone.jsx")
                    this.props.updateMenu();
                }
            })
        }
    }


    componentWillUnmount() {
        this.isComponentMounted = false;
    }

    async handleTableChange(type, {filters, page, sortOrder, sortField, sizePerPage, totalSize}) {
        const currentIndex = (page - 1) * sizePerPage;
        let rrSearchParams = {};
        if (sortField && sortOrder) {
            rrSearchParams.orderDir = sortOrder;
            rrSearchParams.orderBy = sortField;
        }

        rrSearchParams.numberOfRows = sizePerPage;
        rrSearchParams.pageNumber = page;
        rrSearchParams.rrType = this.state.rrType;
        rrSearchParams.nsType = this.state.nsType;


        await this.loadTableData(rrSearchParams);

    }


    getAttNameServersColumns() {
        return [

            {
                text: 'Server Name',
                dataField: 'rrData',
                headerAlign: 'center',
                // sort: true,
                headerStyle: {
                    width: "35%",
                },
                headerEvents: {
                    onClick: (e, column, columnIndex) => {
                        return false
                        e.preventDefault()
                    }
                },
            },
            {
                text: 'Resource Record Name',
                dataField: 'rrName',
                showHideSelection: true,
                headerAlign: 'center',
                headerStyle: {
                    width: "10%"
                },

            },//use it  as test block till it goes to live

            {
                text: 'Last Modified',
                dataField: 'modTime',
                showHideSelection: true,
                headerAlign: 'center',
                headerStyle: {
                    width: "20%"
                },
            },
            {
                text: 'Server Group',
                dataField: 'srvrGrp',
                showHideSelection: true,
                headerAlign: 'center',
                headerStyle: {
                    width: "20%"
                },
            },
            {
                text: "Action",
                dataField: "",
                headerAlign: 'center',
                headerClasses: 'p-1',
                classes: 'p-0',
                headerStyle: {
                    width: "15%"
                },
                formatter: (cell, row, rowIndex) => <>

                    <Link
                        to={`/dns/zones/details/${this.props.match.params.zoneNum}/servers/${this.props.match.params.type}/details/${row.recId}`}
                        key={"details_record" + rowIndex}
                        className={"color-dragon-blue mr-2"}
                    >Details</Link>
                    {isAuthorized('ru') && <Link
                        to={`/dns/zones/details/${this.props.match.params.zoneNum}/servers/${this.props.match.params.type}/edit/${row.recId}`}
                        key={"edit_record" + rowIndex}
                        className={"color-dragon-blue"}
                    >Edit</Link>

                    }

                </>

            }

            ,
        ]
            ;
    }


    getSecondaryAttNameServersColumns() {
        return [
            {

                text: 'Server Name',
                dataField: 'attrValue',
                headerAlign: 'center',
                formatter: (cell, row, rowIndex) => row.attrValue.replace('@', ''), //correct?: if there are multiple instances of @ usage then we use replace()
                headerStyle: {
                    width: "50%"
                },
            },
            {
                text: 'Last Modified',
                dataField: 'modTime',
                showHideSelection: true,
                headerAlign: 'center',
                headerStyle: {
                    width: "25%"
                },
            },
            {
                text: "Action",
                dataField: "",
                headerAlign: 'center',
                headerClasses: 'p-1',
                classes: 'p-0',
                headerStyle: {
                    width: "25%"
                },
                formatter: (cell, row, rowIndex) => <>

                  {/*  <Link
                        to={`/dns/zones/details/${this.props.match.params.zoneNum}/servers/${this.props.match.params.type}/details/${row.recId}`}
                        key={"details_record" + rowIndex}
                        className={"color-dragon-blue mr-2"}
                    >Details</Link>*/}
                  {/*  {isAuthorized('ru') && <Link
                        to={`/dns/zones/details/${this.props.match.params.zoneNum}/servers/${this.props.match.params.type}/edit/${row.recId}`}
                        key={"edit_record" + rowIndex}
                        className={"color-dragon-blue"}
                    >Edit</Link>

                    }  */}      {isAuthorized('rd') && <Link
                        to={`/dns/zones/details/${this.props.match.params.zoneNum}/servers/${this.props.match.params.type}/edit/${row.recId}`}
                        key={"edit_record" + rowIndex}
                        className={"color-dragon-blue"}
                    >Delete</Link>

                    }

                </>

            }
        ];

    }


    getBootStrapTable() {
        const {rr, data, secondaryNS} = this.state;
        const paginationOptions = this.paginationOptions();
        if (this.props.zone?.zoneType === 'P') {
            return (<BootstrapTable bootstrap4
                                    keyField="recId"
                //data={data}
                                    data={data ? data : []}
                                    remote={{pagination: true}}
                                    onTableChange={this.handleTableChange}
                                    columns={this.getAttNameServersColumns()}
                                    filter={filterFactory()}
                                    filterPosition={"top"}
                                    pagination={paginationFactory(paginationOptions)}
                                    noDataIndication="Table is Empty"
                                    id={"rr_attns_table"}
                                    condensed/>)

        } else {
            return (<>
                <BootstrapTable bootstrap4
                                keyField="attrValue"
                                data={secondaryNS?.length ? secondaryNS[0]?.attrValue?.split(',').map(v => ({
                                    attrValue: v,
                                    recId: secondaryNS[0]?.recId
                                })) : []}

                    //  data={this.state.secondaryNS?.length ? this.state.secondaryNS[0]?.attrValue?.split(',').map(v => ({attrValue: v,recId: this.state.secondaryNS[0]?.recId})) : []}
                                columns={this.getSecondaryAttNameServersColumns()}
                                onTableChange={this.handleTableChange}
                                loading={this.state.loading}
                                noDataIndication="Table is Empty"
                                id={"sec_ns_table"}
                                key={"sec_ns_table"}
                                condensed/>

            </>)
        }
    }


    paginationOptions() {
        return {
            sizePerPage: this.state.sizePerPage,
            page: this.state.page,
            totalSize: this.state.totalSize,
            alwaysShowAllBtns: true,
            withFirstAndLast: true,
            firstPageText: 'First',
            prePageText: 'Back',
            nextPageText: 'Next',
            lastPageText: 'Last',
            nextPageTitle: 'First page',
            prePageTitle: 'Pre page',
            firstPageTitle: 'Next page',
            lastPageTitle: 'Last page',
            showTotal: false,
            sizePerPageList: [
                {
                    text: '10', value: 10
                }, {
                    text: '20', value: 20
                },
                {
                    text: '50', value: 50
                },],
            pageButtonRenderer: pageRenderer,
            sizePerPageRenderer: ({
                                      options,
                                      currSizePerPage,
                                      onSizePerPageChange
                                  }) => <SizePerPageRenderer options={options}
                                                             currSizePerPage={currSizePerPage}
                                                             onSizePerPageChange={onSizePerPageChange}/>,

            disablePageTitle: true,
        };
    }


    render() {
        return (
            <div>
                <Helmet>
                    <title>DNS Resource Records|TXT Record</title>
                </Helmet>
                <Box>
                    <Container maxWidth={false} className={"px-2"}>
                        <Card>
                            <CardContent className={"px-0"}>
                                <h5 className="font-weight-bold  text-capitalize text-left pt-3 pl-5">The Zone's AT&T
                                    DNS Name Servers List</h5>
                                <div>
                                    {(!_.isEmpty(this.state.error) || !_.isEmpty(this.props.alert.message)) &&
                                        <Alert
                                            severity={!_.isEmpty(this.state.error) ? "error" : this.props.alert.type}>{(this.state.error && this.state.error.text) || this.props.alert.message}</Alert>}
                                    <div className="pl-5 pr-5">
                                        <div className={"col text-right mt-2 mb-2"}>
                                            {isAuthorized('ri') && <Link
                                                className={"d-inline-block btn btn-primary dns-blue-button mr-1"}
                                                to={"/dns/zones/details/" + this.props.match.params.zoneNum + "/servers/" + this.props.match.params.type + "/create"}
                                            >Insert Record</Link>}
                                        </div>

                                        <div className={"pt-2 pb-2"}>
                                            <span
                                                className={'font-weight-bold'}
                                                key={"zoneName"}>Zone Name</span>: {this.props.zone?.zoneName}

                                            <span
                                                className={'font-weight-bold  pl-5'}
                                                key={"zoneNum"}>Zone ID</span> : {this.props.zone?.zoneNum}<br/>

                                        </div>


                                        {this.getBootStrapTable()}

                                        {/*   <BootstrapTable bootstrap4
                                                        keyField="recId"
                                                      //  data={data}
                                                        data={this.state.secondaryNS?.length ? this.state.secondaryNS[0]?.attrValue?.split(',').map(v => ({attrValue: v})) : []}
                                                        remote={{pagination: true}}
                                                        onTableChange={this.handleTableChange}
                                                        columns={columns}
                                                        filter={filterFactory()}
                                                        filterPosition={"top"}
                                                        pagination={paginationFactory(paginationOptions)}
                                                        noDataIndication="Table is Empty"
                                                        id={"rr_attns_table"}
                                                        condensed
                                        />*/}
                                    </div>
                                </div>
                            </CardContent>
                        </Card>
                    </Container>
                </Box>
            </div>);
    }
}


Search.propTypes = {
    classes: PropTypes.object.isRequired
};
const styledSearch = withStyles(useStyles)(Search);

function mapState(state) {
    const {loading, zone} = state.zones

    const {alert, clear} = state
    return {loading, alert, zone, clear}
}


const actionCreators =
    {
        alertClear: alertActions.clear,
        getZoneById: zoneActions.getZoneById,

    }

const connectedAttNameServers = withRouter(connect(mapState, actionCreators)(styledSearch));
export {connectedAttNameServers as Search};