import React, {Component} from "react";
import Container from "@material-ui/core/Container";
import {withRouter} from "react-router-dom";
import {
    Backdrop,
    Button, Card,
    CardContent,
    CircularProgress,
    Dialog,
    DialogActions,
    DialogTitle,
    Paper
} from "@material-ui/core";
import PropTypes from "prop-types";
import {alertActions, serverGroupActions} from "../../../../_actions";
import Form from 'react-bootstrap/Form'
import {Col} from "react-bootstrap";
import {Row} from "react-bootstrap";
import {Alert} from '@material-ui/lab';
import {connect} from "react-redux";
import {Helmet} from "react-helmet";
import {resourceRecordService} from "../../../../_services/resourceRecord.service";
import {resourceRecordActions} from "../../../../_actions/resourceRecords.actions";
import _ from "lodash";
import {history} from "../../../../_helpers";
import {dropDownService, serverGroupService, zoneService} from "../../../../_services";


class AttNameServers extends Component {
    constructor(props) {
        super(props);
        this.state = {
            loading: true,
            showDeleteConfirm: false,
            zoneData: {},
            servers: {
                srvrgrps: this.props.match.params.srvrgrps,
            },
            dropdownValues: {
                serviceNames: [],
                serverGroups: []
            },
            rr: {
                rrGrp: this.props.match.params.zoneNum,
                rrStr: '',
                rrType: this.props.match.params.type,
                nsType: this.props.match.params.type,
                comments: '',
                recId: '',
                srvrGrp: '',

            },
            alert: '',

        };
        console.log("LOAD")
        this.isComponentMounted = false;
        this.saveAttNameServers = this.saveAttNameServers.bind(this);
        this.updateRRObj = this.updateRRObj.bind(this);
        this.deleteAttNameServers = this.deleteAttNameServers.bind(this);
        this.getDeleteConfirmDialog = this.getDeleteConfirmDialog.bind(this);
        // this.getRRPageButtons = this.getRRPageButtons.bind(this);

        if ((this.props.location.state === undefined || !this.props.location.state.showAlerts) && !_.isEmpty(this.props.alert)) {
            this.props.alertClear()
        }

    }


    async getDropdownValues() {
        //const serviceResponse = await dropDownService.getByServiceNames()
        const serviceResponse = await dropDownService.getByZoneServerGroups(this.props.match.params.zoneNum)
        const srvrGrpResponse = await serverGroupService.getByZone(this.props.match.params.zoneNum)
        if (serviceResponse.success && srvrGrpResponse.success && this.isComponentMounted) {
            // if (serviceResponse.success && this.isComponentMounted) {
            this.setState({
                dropdownValues: {
                    // serviceNames: serviceResponse.services,
                    serverGroups: srvrGrpResponse.server,
                    serviceNames: serviceResponse.serverName,

                }
            })
        }
    }

    saveAttNameServers(e) {
        e.preventDefault()

        if (this.isComponentMounted) {
            this.setState({loading: !this.props.isEmptyForm})//changed it so that it supports loading on create page
        }
        const {rrName, rrTtl, rrType, rrData, comments, rrGrp, ...rr} = this.state.rr
        const rrNS = this.props.match.params.type.split("-")
        const resourceRecord = {
            rrStr: "@" + (rrTtl ? (" " + rrTtl) : "") + " IN " + rrNS[1] + " " + (rrData ? rrData : ""),
            rrType: rrNS[1],
            nsType: rrNS[0],
            rrGrp,
            comments
        }
        if (this.props.isEmptyForm && this.props.isEditable) {
            this.props.create(resourceRecord, 'servers');
        } else {
            console.log("Updating", resourceRecord)
            this.props.update(this.props.match.params.id, resourceRecord, false);
        }
    }

    async componentDidMount() {
        this.isComponentMounted = true;
        if (this.props.isEditable) {
            await this.getDropdownValues();
        }
        const res = await zoneService.getZoneById(this.props.match.params.zoneNum)
        if (this.isComponentMounted) {
            this.setState({loading: !this.props.isEmptyForm, zoneData: res.zone});
            // this.setState({zoneData: res.zone});
        }
        if (!this.props.isEmptyForm && this.isComponentMounted) {

            const rr = await resourceRecordService.getByRecordId(this.props.match.params.id,);
            // const srvrGrp = await serverGroupService.getByZone(this.props.match.params.id);

            if (!_.isEmpty(rr) && this.isComponentMounted) {

                this.setState({loading: false, rr: rr});

            } else {
                this.props.history.push(`/dns/zones/details/${this.props.match.params.zoneNum}/servers/${this.props.match.params.type}`);
            }

        }
    }

    deleteAttNameServers() {
        this.setState({showDeleteConfirm: false, loading: true})
        this.props.delete(this.props.match.params.id);
    }


    componentWillUnmount() {
        this.isComponentMounted = false;
    }

    componentDidUpdate(prevProps, prevState, snapshot) {
        if (this.state.loading !== prevState.loading) {
            this.setState({loading: false})

        }
        console.log(prevState)
        //  this.setState({loading:false})
    }


    updateRRObj(e) {
        let {name, value} = e.target;
        const {rr} = this.state;

        this.setState({rr: {...rr, [name]: value}})
    }


    getAttNameServersPageButtons() {
        let pageElements = {
            pageTitle: '',
            pageButtons: [],
        }
        if (this.props.isEditable && this.props.isEmptyForm) {
            pageElements.pageTitle = "Adding ATT DNS Name Server"
            pageElements.pageButtons.push(<Button className={"dns-blue-button text-white mr-2"}
                                                  onClick={this.saveAttNameServers}
                                                  key={"insert"}>Insert</Button>)
            pageElements.pageButtons.push(<Button className={"dns-blue-button text-white mr-2 col-md-1"}
                                                  onClick={() => this.props.history.goBack()}
                                                  key={"cancel_update"}>Cancel</Button>)


        } else if (this.props.isEditable) {
            pageElements.pageTitle = "AT&T Name Server Update"
            pageElements.pageButtons.push(<Button className={"dns-blue-button text-white mr-1 col-md-1"}
                                                  onClick={this.saveAttNameServers}
                                                  key={"update"}>Update</Button>)
            pageElements.pageButtons.push(<Button className={"dns-blue-button text-white mr-2 col-md-1"}
                                                  onClick={() => this.props.history.goBack()}
                                                  key={"cancel_update"}>Cancel</Button>)


        } else {
            pageElements.pageTitle = "ATT DNS Name Server Details"
            pageElements.pageButtons.push(<Button className={"dns-blue-button text-white mt-2 mr-4 mb-4"}
                                                  onClick={() => this.props.history.push(`/dns/zones/details/${this.props.match.params.zoneNum}/servers/${this.props.match.params.type}/edit/${this.props.match.params.id}`)}
                                                  key={"edit"}>Go To Update</Button>)
            pageElements.pageButtons.push(<Button className={"dns-blue-button text-white mt-2 mr-4 mb-4"}
                                                  onClick={() => {
                                                      this.setState({showDeleteConfirm: true})
                                                  }} key={"delete"}>Delete</Button>)
            pageElements.pageButtons.push(<Button className={"dns-blue-button text-white mt-2 mb-4"}
                                                  onClick={() => this.props.history.push(`/dns/zones/details/${this.props.match.params.zoneNum}/servers/${this.props.match.params.type}`)}
                                                  key={"list_users"}>List ATTNS Records</Button>)


        }

        return pageElements;
    }

    getDeleteConfirmDialog() {
        return !this.props.isEditable && <Dialog
            onClose={(event, reason) => {
                if (reason === 'backdropClick' || reason === 'escapeKeyDown') {
                    return false;
                }
            }}
            maxWidth="xs"
            aria-labelledby="confirmation-dialog-title"
            open={this.state.showDeleteConfirm}
        >
            <DialogTitle id="confirmation_dialog_title">Are you sure you want to delete this
                record?</DialogTitle>
            <DialogActions>
                <Button autoFocus onClick={this.deleteAttNameServers} className={"dns-blue-button text-white"}>
                    Delete
                </Button>
                <Button onClick={() => this.setState({showDeleteConfirm: false})}
                        className={"dns-blue-button text-white"}>
                    Cancel
                </Button>
            </DialogActions>
        </Dialog>
    }


    getAttNameServersForm() {
        const {rr, zoneData} = this.state
        let {pageButtons} = this.getAttNameServersPageButtons();

        return <form onSubmit={this.saveAttNameServers}>
            <Form.Group as={Row} className={"align-items-center"}>
                <Form.Label column sm="2"
                            className={"font-weight-bold"}>
                    Zone ID
                </Form.Label>
                <Col sm="4">
                    {rr.rrGrp}
                </Col>
                {!this.props.isEmptyForm && !this.props.isEditable && <><Form.Label column sm="2"
                                                                                    className={"font-weight-bold"}>
                    Zone Name
                </Form.Label>
                    <Col sm="4">
                        {zoneData.zoneName}
                    </Col></>}
            </Form.Group>
            <Form.Group as={Row} className={"align-items-center"}>
                {!this.props.isEmptyForm &&
                <> <Form.Label column sm="2" className={"font-weight-bold"}>
                    Record ID
                </Form.Label>
                    <Col sm="4">
                        {rr.recId}
                    </Col></>}
                {!this.props.isEmptyForm && !this.props.isEditable && <><Form.Label column sm="2"
                                                                                    className={"font-weight-bold"}>
                    Modified By
                </Form.Label>
                    <Col sm="4">
                        {rr.modBy}
                    </Col></>}
            </Form.Group>
            <Form.Group as={Row} className={"align-items-center"}>
                {!this.props.isEmptyForm && !this.props.isEditable && <> <Form.Label column sm="2"
                                                                                     className={"font-weight-bold"}>
                    Create Time
                </Form.Label>
                    <Col sm="4">
                        {rr.createTime}
                    </Col></>}


                {!this.props.isEmptyForm && !this.props.isEditable && <>  <Form.Label column sm="2"
                                                                                      className={"font-weight-bold"}>
                    Last Modified
                </Form.Label>
                    <Col sm="4">
                        {rr.modTime}
                    </Col></>}


            </Form.Group>
            <Form.Group as={Row} className={"align-items-center"}>


                <Form.Label column sm="2" className={"font-weight-bold"}>
                    DNS Server Group
                </Form.Label>

                <Col sm="4">
                    {this.props.isEditable ?
                        <Form.Control as="select" name={"srvrGrp"}//need to add api call of list of nameservrgroups
                                      onChange={this.updateRRObj}
                                      value={rr.srvrGrp}>
                            <option value={""} key={0}>Select</option>
                            {this.state.dropdownValues.serverGroups.map(servers =>
                                //    <option value={servers.code} key={servers.code}>{servers.name}</option>)}
                                <option value={servers.groupCode} key={servers.groupCode}>{servers.groupCode}</option>)}


                        </Form.Control> : rr.srvrGrp}
                </Col>
            </Form.Group>

            {this.props.isEmptyForm && <p>Please choose a name server below with server group you selected above</p>}

            <Form.Group as={Row} className={"align-items-center"}>


                <Form.Label column sm="2" className={"font-weight-bold"}>
                    Server's Full Name
                </Form.Label>


                <Col sm="4">
                    {this.props.isEditable ? this.state.rr.srvrGrp &&
                        <Form.Control as="select" name={"rrData"}
                                      onChange={this.updateRRObj}
                                      value={rr.rrData}>
                            <option value={""} key={0}>Select</option>

                            {this.state.dropdownValues.serviceNames.filter((v, i, a) => v.groupCode == this.state.rr.srvrGrp).map(serverName =>
                                <option value={serverName.ns_dname_fqdn}
                                        key={serverName.ns_dname_fqdn}>{serverName.ns_dname_fqdn}</option>
                            )}}</Form.Control> : rr.rrData}

                </Col>
            </Form.Group>
            <Form.Group as={Row} className={"align-items-center"}>
                <Form.Label column sm="2" className={"font-weight-bold"}>
                    Time To Live
                </Form.Label>
                <Col sm="4">
                    {this.props.isEditable ?
                        <Form.Control name={"rrTtl"}
                                      onChange={this.updateRRObj}
                                      defaultValue={rr.rrTtl ? rr.rrTtl : ''}/> : rr.rrTtl}
                </Col>

                <Form.Label column sm="2" className={"font-weight-bold"}>
                    Comment
                </Form.Label>
                <Col sm="4">
                    {this.props.isEditable ?
                        <Form.Control name={"comments"}
                                      onChange={this.updateRRObj}
                                      value={rr.comments ? rr.comments : ''}/> : rr.comments}
                </Col>
            </Form.Group>
            <div className={"text-center"}>
                {pageButtons.map(buttonComp => buttonComp)}
            </div>
        </form>


    }


    componentWillUnmount() {
        this.isComponentMounted = false;
    }

    render() {
        let {pageTitle} = this.getAttNameServersPageButtons();
        if (this.state.loading) {
            return <div>Loading....</div>
        }
        return (
            <>
                {this.getDeleteConfirmDialog()}
                <Backdrop className={"page-loading"} style={{'zIndex': '10000', 'color': '#fff'}}
                          open={this.state.loading}>
                    <CircularProgress color="inherit"/>
                </Backdrop>
                <div>
                    <Helmet>
                        <title>DNS Admin | DNS ATTNS Details Page</title>
                    </Helmet>
                    <Container maxWidth={false} className={"px-2"}>
                        <Card>
                            <CardContent>
                                <div className={'mt-3 ml-3 mr-3 mb-3'}>
                                    <h5 className="font-weight-bold  text-capitalize text-left pt-3 pb-3 pl-2">{pageTitle}</h5>
                                    <div className="pt-3 pl-4 pr-5">
                                        {this.props.alert.message && <Alert
                                            severity={this.props.alert.type}>{this.props.alert.message}</Alert>}</div>
                                    {this.getAttNameServersForm()}
                                </div>
                            </CardContent>
                        </Card>
                    </Container>
                </div>
            </>
        )
    }

}

AttNameServers.defaultProps = {
    isEditable: false,
};
AttNameServers.propTypes = {
    isEditable: PropTypes.bool,
    isEmptyForm: PropTypes.bool
};

AttNameServers.defaultProps = {
    isEditable: false,
    isEmptyForm: false
}

function mapState(state) {
    const {alert} = state
    return {alert}

}

const actionCreators = {
    create: resourceRecordActions.create,
    delete: resourceRecordActions.delete,
    update: resourceRecordActions.update,
    alertClear: alertActions.clear,
};


const connectedAttNameServers = withRouter(connect(mapState, actionCreators)(AttNameServers));
export {connectedAttNameServers as AttNameServers};

