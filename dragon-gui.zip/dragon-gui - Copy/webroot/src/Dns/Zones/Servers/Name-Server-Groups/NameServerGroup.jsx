import React, {Component} from "react";
import Container from "@material-ui/core/Container";
import {withRouter} from "react-router-dom";
import {
    Backdrop,
    Button,
    Card,
    CardContent,
    CircularProgress,
    Dialog,
    DialogActions,
    DialogTitle,
} from "@material-ui/core";
import PropTypes from "prop-types";
import {alertActions, serverGroupActions, zoneActions} from "../../../../_actions";
import Form from 'react-bootstrap/Form'
import {Col} from "react-bootstrap";
import {Row} from "react-bootstrap";
import {Alert} from '@material-ui/lab';
import {connect} from "react-redux";
import {Helmet} from "react-helmet";
import _ from "lodash";
import {dropDownService, zoneService} from "../../../../_services";
import {serverGroupService} from "../../../../_services/serverGroup.service";
import {isAuthorized} from "../../../../_components";


class NameServerGroup extends Component {
    constructor(props) {
        super(props);
        this.state = {
            loading: false,
            showDeleteConfirm: false,
            zoneData: {},
            server: {
                //srvrGrp: '',
                groupCode: '',
                groupName: '',
                // srvrgrps: this.props.match.params.srvrgrps,

            },
            dropdownValues: {
                serverGroup: [],
            },
            rr: {
                rrGrp: this.props.match.params.zoneNum,
                rrStr: '',
                rrType: this.props.match.params.type,
                comments: '',
                recId: '',


            },
            alert: '',

        };
        this.isComponentMounted = false;
        this.srvrGrpAction = this.srvrGrpAction.bind(this);
        this.updateSrvrObj = this.updateSrvrObj.bind(this);
        //   this.deleteSrvrGrp = this.deleteSrvrGrp.bind(this);
        this.getDeleteConfirmDialog = this.getDeleteConfirmDialog.bind(this);

        if ((this.props.location.state === undefined || !this.props.location.state.showAlerts) && !_.isEmpty(this.props.alert)) {
            this.props.alertClear()
        }

    }


    srvrGrpAction(action) {
        if (this.isComponentMounted) {
            this.setState({loading: !this.props.isEmptyForm, showDeleteConfirm: false})
            /*  this.setState({loading: true})*/
        }

        this.props.post({
            zoneNum: this.props.match.params.zoneNum,
            groupName: this.state.server.groupCode,
            action: action
        });

    }


    async componentDidMount() {
        this.isComponentMounted = true;
        if (this.props.isEditable) {
            await this.getDropdownValues();
        }
        /*     const res = await zoneService.getZoneById(this.props.match.params.zoneNum)
             if (this.isComponentMounted) {

                 this.setState({loading: !this.props.isEmptyForm, zoneData: res.zone});
             }*/

        this.props.getZoneById(this.props.match.params.zoneNum)

        if (!this.props.isEmptyForm && this.isComponentMounted) {
            const srvrGrp = await serverGroupService.getByGroupCode(this.props.match.params.zoneNum, this.props.match.params.id);
            if (!_.isEmpty(srvrGrp) && srvrGrp.success && this.isComponentMounted) {
                this.setState({loading: false, server: srvrGrp.server[0]});
            } /*else {
                this.props.alertClear()
                console.log(this.state.server.groupName, "this.state.server.groupName")
                this.props.history.push(`/dns/zones/details/${this.props.match.params.zoneNum}/servers/${this.props.match.params.type}`);
            }*/
        }

    }

    componentDidUpdate(prevProps, prevState, snapshot) {
        if (((this.state.loading && this.props.zone) || !_.isEqual(prevProps.zone, this.props.zone))) {

            this.setState({
                zoneData: _.omit(this.props.zone, ['soaTemplate']),
                loading: false
            }, () => {

                if (prevProps.zone?.zoneStatus != this.props.zone?.zoneStatus) {
                    this.props.updateMenu();
                }
            })
        }
    }

    componentWillUnmount() {
        this.isComponentMounted = false;
    }


    async getDropdownValues() {
        const srvGrpResponse = await dropDownService.getByServerGroups()
        if (srvGrpResponse.success && this.isComponentMounted) {
            this.setState({
                dropdownValues: {
                    serverGroup: srvGrpResponse.srvrGrps
                }
            })
        }
    }


    updateSrvrObj(e) {
        if (e.keyCode === 8 && e.target.selectionStart === 0 && e.target.selectionEnd === e.target.value.length) {
            e.preventDefault(); // Prevent default backspace behavior
            e.target.value = ""; // Clear the input value
        }
        console.log("onchange test")

        let {name, value} = e.target;
        const {server} = this.state;
//console.log(server,"...server")
        this.setState({server: {...server, [name]: value}})
    }


    /*
        deleteSrvrGrp() {
            this.setState({showDeleteConfirm: false, loading: true})
            this.props.delete(this.props.match.params.id);
        }
    */


    getSrvrGrpPageButtons() {
        let pageElements = {
            pageTitle: '',
            pageButtons: [],
        }
        if (this.props.isEditable && this.props.isEmptyForm) {
            pageElements.pageTitle = "Zone's DNS Server Group Creation"
            pageElements.pageButtons.push(<Button className={"dns-blue-button text-white mr-2"}
                                                  onClick={() => this.srvrGrpAction('A')}
                                                  key={"insert"}>Insert</Button>)
            pageElements.pageButtons.push(<Button className={"dns-blue-button text-white mr-2 col-md-1"}
                                                  onClick={() => {
                                                      this.props.alertClear();
                                                      this.props.history.goBack()
                                                  }}
                                                  key={"cancel_update"}>Cancel</Button>)


        } else if (this.props.isEditable) {
            pageElements.pageTitle = "Reloading the Zone to the Server Group"
            pageElements.pageButtons.push(<Button className={"dns-blue-button text-white mr-2 col-md-1"}
                                                  onClick={() => this.srvrGrpAction('U')}
                                                  key={"update"}>Update</Button>)
            pageElements.pageButtons.push(<Button className={"dns-blue-button text-white mr-2 col-md-1"}
                                                  onClick={() => this.props.history.goBack()}
                                                  key={"cancel_update"}>Cancel</Button>)


        } else {
            /*    if (isAuthorized('ru')) {

                    pageElements.pageTitle = "Zone's DNS Server Group Details"
                    pageElements.pageButtons.push(<Button className={"dns-blue-button text-white mt-2 mr-4 mb-4"}
                                                          onClick={() => this.props.history.push(`/dns/zones/details/${this.props.match.params.zoneNum}/servers/${this.props.match.params.type}/edit/${this.props.match.params.id}`)}
                                                          key={"edit"}>Go To Update</Button>)
                }*/ //commenting go to update now since we are not sure about this functionality and there is thing to update here now.
            if (isAuthorized('rd')) {

                pageElements.pageButtons.push(<Button className={"dns-blue-button text-white mt-2 mr-4 mb-4"}
                                                      onClick={() => {
                                                          this.setState({showDeleteConfirm: true})
                                                      }}
                                                      key={"delete"}>Delete</Button>)
            }
            pageElements.pageButtons.push(<Button className={"dns-blue-button text-white mt-2 mb-4"}
                                                  onClick={() => this.props.history.push(`/dns/zones/details/${this.props.match.params.zoneNum}/servers/${this.props.match.params.type}`)}
                                                  key={"list_srvrgrp"}>List Name Server Groups</Button>)


        }


        return pageElements;
    }


    getDeleteConfirmDialog() {
        return !this.props.isEditable && <Dialog
            onClose={(event, reason) => {
                if (reason === 'backdropClick' || reason === 'escapeKeyDown') {
                    return false;
                }
            }}
            maxWidth="xs"
            aria-labelledby="confirmation-dialog-title"
            open={this.state.showDeleteConfirm}
        >
            <DialogTitle id="confirmation_dialog_title">Are you sure you want to delete this
                record?</DialogTitle>
            <DialogActions>
                <Button autoFocus onClick={() => this.srvrGrpAction('D')} className={"dns-blue-button text-white"}>
                    Delete
                </Button>
                <Button onClick={() => this.setState({showDeleteConfirm: false})}
                        className={"dns-blue-button text-white"}>
                    Cancel
                </Button>
            </DialogActions>
        </Dialog>
    }


    getSrvrGrpForm() {
        const {rr, server} = this.state
        let {pageButtons} = this.getSrvrGrpPageButtons();
        // console.log("NAME:", this.state.server)

        return <Form>
            <Form.Group as={Row} className={"align-items-center"}>
                <Form.Label column sm="2"
                            className={"font-weight-bold"}>
                    Zone ID
                </Form.Label>
                <Col sm="2">
                    {this.props.match.params.zoneNum}
                </Col>
            </Form.Group>

            <Form.Group as={Row} className={"align-items-center"}>

                <Form.Label column sm="2" className={"font-weight-bold"}>
                    {this.props.isEmptyForm ? "*" : ""}DNS Server Group
                </Form.Label>
                <Col sm="2">
                    {this.props.isEmptyForm ?
                        <Form.Control as="select" name={"groupCode"}
                                      onChange={this.updateSrvrObj}
                                      onKeyDown={this.updateSrvrObj}
                                      required={true}
                                      value={server.groupCode}>
                            <option value={""} key={0}>Select</option>
                            {console.log(server.groupCode, "rr.groupCode")}
                            {this.state.dropdownValues.serverGroup.map(server =>

                                <option value={server} key={server}>{server}</option>)}

                            {/*
                                since its array we can only use server in the value
*/}
                        </Form.Control> : server.groupCode}


                    {/*    {this.props.isEditable ?
                        <Form.Control as="select" name={"groupName"}
                                      onChange={this.updateSrvrObj}
                                      value={server.groupName}>
                            <option value={""}>None Selected</option>
                            <option value={"MISgrp"}>MISgrp</option>
                            <option value={"ATTgrp"}>ATTgrp</option>
                            <option value={"GMSgrp"}>GMSgrp</option>
                            <option value={"HSTgrp"}>HSTgrp</option>
                            <option value={"APgrp"}>APgrp</option>
                            <option value={"BLSgrp"}>BLSgrp</option>
                            <option value={"AKAMgrp"}>AKAMgrp</option>
                            <option value={"SVMgrp"}>SVMgrp</option>
                            <option value={"GMISgrp"}>GMISgrp</option>
                            <option value={"None Selected"}>None Selected</option>
                        </Form.Control> : server.groupName}
*/}

                    {/*          {this.props.isEditable ?
                            <Form.Control name={"groupName"}
                                          onChange={this.updateSrvrObj}
                                          defaultValue={server.groupName ? server.groupName : ''}/> : server.groupName}*/}
                </Col>
            </Form.Group>
            <Form.Group as={Row} className={"align-items-center"}>

                {(this.props.isEmptyForm || !this.props.isEditable) && <> <Form.Label column sm="2"
                                                                                      className={"font-weight-bold"}>
                    Comment
                </Form.Label></>}
                <Col sm="2">
                    {this.props.isEmptyForm ?
                        <Form.Control name={"comments"}
                                      onChange={this.updateSrvrObj}
                                      onKeyDown={this.updateSrvrObj}
                                      defaultValue={server.comments ? server.comments : ''}/> : server.comments}
                </Col>
            </Form.Group>

            <Form.Group as={Row} className={"align-items-center"}>
                {!this.props.isEmptyForm && !this.props.isEditable && <> <Form.Label column sm="2"
                                                                                     className={"font-weight-bold"}>
                    Create Time
                </Form.Label>
                    <Col sm="4">
                        {server.createTime}
                    </Col></>}
            </Form.Group>

            <Form.Group as={Row} className={"align-items-center"}>


                {!this.props.isEmptyForm && !this.props.isEditable && <>  <Form.Label column sm="2"
                                                                                      className={"font-weight-bold"}>
                    Last Modified
                </Form.Label>
                    <Col sm="4">
                        {server.modTime}
                    </Col></>}


            </Form.Group>

            <Form.Group as={Row} className={"align-items-center"}>
                {!this.props.isEmptyForm && !this.props.isEditable && <>   <Form.Label column sm="2"
                                                                                       className={"font-weight-bold"}>
                    Modified By </Form.Label>
                    <Col sm="2">
                        {server.modBy}
                    </Col></>}
            </Form.Group>
            <div className={"text-center"}>
                {pageButtons.map(buttonComp => buttonComp)}
            </div>

        </Form>


    }


    render() {
        let {pageTitle} = this.getSrvrGrpPageButtons();
        if (this.state.loading) {
            return <div>Loading....</div>
        }
        return (
            <>
                {this.getDeleteConfirmDialog()}
                <Backdrop className={"page-loading"} style={{'zIndex': '10000', 'color': '#fff'}}
                          open={this.state.loading}>
                    <CircularProgress color="inherit"/>
                </Backdrop>
                <div>
                    <Helmet>
                        <title>DNS Admin | DNS NameServerGroup Details Page</title>
                    </Helmet>
                    <Container maxWidth={false} className={"px-2"}>
                        <Card>
                            <CardContent>
                                <h6 className="font-weight-bold  text-capitalize text-left pt-3 pb-4 pl-4">{pageTitle}</h6>
                                <div className="pl-4 pr-2">

                                    <div className={"pb-2"}>
                                        {this.props.alert.message && <Alert
                                            severity={this.props.alert.type}>{this.props.alert.message}</Alert>}</div>
                                    {console.log(this.props.alert.message, "this.props.alert.message ")}
                                    {this.getSrvrGrpForm()}
                                </div>
                            </CardContent>
                        </Card>

                    </Container>
                </div>
            </>
        )
    }

}

NameServerGroup.defaultProps = {
    isEditable: false,
};
NameServerGroup.propTypes = {
    isEditable: PropTypes.bool,
    isEmptyForm: PropTypes.bool
};
NameServerGroup.defaultProps = {
    isEditable: false,
    isEmptyForm: false
}

function mapState(state) {
    // const {alert} = state
    // const {loading, saved, deleted, deleting} = state.srvrGrp
    //return {alert, loading, saved, deleted, deleting}


    const {loading, zone} = state.zones
    // const {saved, deleted, deleting} = state.srvrGrp
    const {alert, clear} = state
    return {loading, alert, zone, clear}
}

const actionCreators = {
    alertClear: alertActions.clear,
    post: serverGroupActions.post,
    getZoneById: zoneActions.getZoneById,

};


const connectedNameServerGroup = withRouter(connect(mapState, actionCreators)(NameServerGroup));
export {connectedNameServerGroup as NameServerGroup};

