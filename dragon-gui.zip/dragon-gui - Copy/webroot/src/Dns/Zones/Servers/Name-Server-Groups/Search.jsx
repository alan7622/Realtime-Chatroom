import React from "react";
import {alertActions, zoneActions} from "../../../../_actions";
import {connect} from "react-redux";
import {
    CardContent,
    withStyles,
    Card
} from "@material-ui/core";
import {Helmet} from "react-helmet";
import Container from "@material-ui/core/Container";
import BootstrapTable from 'react-bootstrap-table-next';
import filterFactory, {Comparator} from 'react-bootstrap-table2-filter';
import paginationFactory from 'react-bootstrap-table2-paginator';
import _ from "lodash";
import {Alert} from "@material-ui/lab";
import {Link, withRouter} from "react-router-dom";
import {serverGroupService, zoneService} from "../../../../_services";
import PropTypes from "prop-types";
import {isAuthorized, pageRenderer, SizePerPageRenderer} from "../../../../_components";


const useStyles = theme => ({
    root: {},
    searchButton: {
        backgroundColor: '#4789b6',
        marginBottom: '-10px',
        opacity: '1',
        color: '#FFF',
        width: '50%',
        '&:hover': {backgroundColor: '#3f6bb5', opacity: '1'}
    },
    filterContainer: {
        padding: '20px',
        marginBottom: '30px'
    },

    createAccountButton: {
        backgroundColor: '#4789b6',
        '&:hover': {
            backgroundColor: '#3f75b5',
        },
    },

    searchContainer: {
        textAlign: 'left'
    }
});

class Search extends React.Component {

    constructor(props) {
        super(props);
        this.state = {
            data: [],
            zoneName: '',
            zoneData: '',
            rrType: '',
            error: '',
            loading: true,
            comparator: Comparator.EQ,
            showDeleteConfirm: false,
            showAdvanceSearchConfirm: false,
            page: 1,
            sizePerPage: 10,
            totalSize: 0,
            rrSearchParams: {},


        }

        this.isComponentMounted = false;
        this.handleTableChange = this.handleTableChange.bind(this);


        if ((this.props.location.state === null || this.props.location.state === undefined || !this.props.location.state.showAlerts) && !_.isEmpty(this.props.alert)) {
            this.props.alertClear()
        }
    }


    async componentDidMount() {
        this.isComponentMounted = true;
       /* setTimeout(() => {
            this.props.alertClear()
        }, 10000)*///this clears alert message on listing or search page after 10 seconds
        //const res = await zoneService.getZoneById(this.props.match.params.zoneNum)
        this.props.getZoneById(this.props.match.params.zoneNum)
        await this.loadTableData(this.props.match.params.zoneNum);
       /* if (this.isComponentMounted) {
            this.setState({zoneData: res.zone});

        }*/
    }

    async loadTableData(zoneNum) {
        if (this.isComponentMounted) {

            this.setState({loading: true})
        }

        /*params = {
            ...params,
            zoneNum: this.props.match.params.zoneNum,
        }*/
        const res = await serverGroupService.getByZone(zoneNum);
        if (this.isComponentMounted) {
            this.setState({
                loading: false,
                data: res.server,
                error: res.error,
                totalSize: res.totalRecords,
            });

        }
    }

    componentDidUpdate(prevProps, prevState, snapshot) {
        console.log(_.isEqual(prevProps.zone, this.props.zone),"this.props - Zone.jsx")
        if( ((this.state.loading && this.props.zone)|| !_.isEqual(prevProps.zone, this.props.zone))) {

            this.setState({
                zoneData: _.omit(this.props.zone, ['soaTemplate']),
                loading: false
            }, () => {

                if( prevProps.zone?.zoneStatus != this.props.zone?.zoneStatus) {
                    console.log("this.props - Zone.jsx")
                    this.props.updateMenu();
                }})
        }
    }


    componentWillUnmount() {
        this.isComponentMounted = false;
    }

    async handleTableChange(type, {filters, page, sortOrder, sortField, sizePerPage, totalSize}) {
        const currentIndex = (page - 1) * sizePerPage;
        let rrSearchParams = {};
        if (sortField && sortOrder) {
            rrSearchParams.orderDir = sortOrder;
            rrSearchParams.orderBy = sortField;
        }

        rrSearchParams.numberOfRows = sizePerPage;
        rrSearchParams.pageNumber = page;
        rrSearchParams.rrType = this.state.rrType;
        rrSearchParams.nsType = this.state.nsType;


        await this.loadTableData(rrSearchParams);

    }

    getNSTableColumns() {

        return [


            {
                text: 'Server Group',
                dataField: 'groupCode',
                headerAlign: 'center',
                // sort: true,
                headerStyle: {
                    width: "15%",
                },
                headerEvents: {
                    onClick: (e, column, columnIndex) => {
                        return false
                        e.preventDefault()
                    }
                },
            },
            {
                text: 'Last Modified',
                dataField: 'modTime',
                /*hidden: true,
                showHideSelection: true,*/
                showHideSelection: true,
                // filter: dateFilter(),
                headerAlign: 'center',
                headerStyle: {
                    width: "15%"
                },
            },
            {
                text: 'Modified By',
                dataField: 'modBy',
                headerAlign: 'center',
                // sort: true,
                headerStyle: {
                    width: "15%",
                },
            },

            {
                text: "Action",
                dataField: "",
                headerAlign: 'center',
                headerStyle: {
                    width: "20%"
                },

                formatter: (cell, row, rowIndex) => <>
                    <Link
                        to={`/dns/zones/details/${this.props.match.params.zoneNum}/servers/${this.props.match.params.type}/details/${row.groupCode}`}
                        key={"details_dns_srvrgrp"}
                        className={"color-dragon-blue mr-2"}
                    >Details</Link>
                </>
            },


        ];
    }

    paginationOptions() {
        return {
            sizePerPage: this.state.sizePerPage,
            page: this.state.page,
            totalSize: this.state.totalSize,
            alwaysShowAllBtns: true,
            withFirstAndLast: true,
            firstPageText: 'First',
            prePageText: 'Back',
            nextPageText: 'Next',
            lastPageText: 'Last',
            nextPageTitle: 'First page',
            prePageTitle: 'Pre page',
            firstPageTitle: 'Next page',
            lastPageTitle: 'Last page',
            showTotal: false,
            sizePerPageList: [
                {
                    text: '10', value: 10
                }, {
                    text: '20', value: 20
                },
                {
                    text: '50', value: 50
                },],
            pageButtonRenderer: pageRenderer,
            sizePerPageRenderer: ({
                                      options,
                                      currSizePerPage,
                                      onSizePerPageChange
                                  }) => <SizePerPageRenderer options={options}
                                                             currSizePerPage={currSizePerPage}
                                                             onSizePerPageChange={onSizePerPageChange}/>,

            disablePageTitle: true,
        };
    }


    render() {
        const {classes} = this.props;
        const paginationOptions = this.paginationOptions();
        const {loading, data} = this.state;
        const columns = this.getNSTableColumns();
        return (

            <div>
                <Helmet>
                    <title>DNS Resource Records|NS Record</title>
                </Helmet>
                <Container maxWidth={false} className={"px-2"}>
                    <Card>
                        <CardContent>
                            <h5 className="font-weight-bold  text-capitalize text-left pt-3 pb-1 pl-4">
                                DNS Server Groups List
                            </h5>
                            <div>
                                {(!_.isEmpty(this.state.error) || !_.isEmpty(this.props.alert.message)) &&
                                <Alert
                                    severity={!_.isEmpty(this.state.error) ? "error" : this.props.alert.type}>{(this.state.error && this.state.error.text) || this.props.alert.message}</Alert>}
                                <div className="pl-4 pr-2">
                                    <div className={"col text-right mt-2 mb-2"}>
                                        {isAuthorized('ri') &&   <Link
                                            className={"d-inline-block btn btn-primary dns-blue-button mr-1"}
                                            to={"/dns/zones/details/" + this.props.match.params.zoneNum + "/servers/" + this.props.match.params.type + "/create"}
                                        >Insert Record</Link>}
                                    </div>

                                    <div className={"pt-3 pb-3"}>
                                            <span
                                                className={'font-weight-bold'}>Zone Name</span>: {this.state.zoneData.zoneName}

                                        <span
                                            className={'font-weight-bold  pl-5'}>Zone ID</span> : {this.state.zoneData.zoneNum}<br/>
                                    </div>

                                    <BootstrapTable bootstrap4
                                                    keyField="groupCode"
                                                    data={data}
                                                    remote={{pagination: true}}
                                                    onTableChange={this.handleTableChange}
                                                    columns={columns}
                                                    filter={filterFactory()}
                                                    filterPosition={"top"}
                                                    pagination={paginationFactory(paginationOptions)}
                                                    noDataIndication="Table is Empty"
                                                    id={"rr_txt_table"}
                                                    condensed
                                    />
                                </div>
                            </div>
                        </CardContent>
                    </Card>
                </Container>
            </div>);
    }
}


Search.propTypes = {
    classes: PropTypes.object.isRequired
};
const styledSearch = withStyles(useStyles)(Search);

function mapState(state) {
    const { loading,  zone} = state.zones

    const {alert, clear} = state
    return { loading, alert, zone, clear}
}


const actionCreators =
    {
        alertClear: alertActions.clear,
        getZoneById: zoneActions.getZoneById,

    }

const connectedRrTxt = withRouter(connect(mapState, actionCreators)(styledSearch));
export {connectedRrTxt as Search};