export {Search as NameServerGroupSearch} from './Search';
export * from './NameServerGroup';