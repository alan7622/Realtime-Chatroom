import React from "react";
import {alertActions, nameServerActions, zoneActions} from "../../../../_actions";
import {connect} from "react-redux";
import {
    CardContent,
    withStyles,
    Tooltip,
    Card, Dialog, DialogTitle, DialogActions, Button
} from "@material-ui/core";
import {Helmet} from "react-helmet";
import Container from "@material-ui/core/Container";
import Box from "@material-ui/core/Box";
import BootstrapTable from 'react-bootstrap-table-next';
import filterFactory, {Comparator, customFilter, textFilter} from 'react-bootstrap-table2-filter';
import paginationFactory from 'react-bootstrap-table2-paginator';
import _ from "lodash";
import {Alert} from "@material-ui/lab";
import {Link, withRouter} from "react-router-dom";
import {transferAclZone as transferAclZoneService, zoneService} from "../../../../_services";
import {resourceRecordService} from "../../../../_services/resourceRecord.service";
import PropTypes from "prop-types";
import {isAuthorized, pageRenderer, SizePerPageRenderer} from "../../../../_components";


const useStyles = theme => ({
    root: {},
    searchButton: {
        backgroundColor: '#4789b6',
        marginBottom: '-10px',
        opacity: '1',
        color: '#FFF',
        width: '50%',
        '&:hover': {backgroundColor: '#3f6bb5', opacity: '1'}
    },
    filterContainer: {
        padding: '20px',
        marginBottom: '30px'
    },

    createAccountButton: {
        backgroundColor: '#4789b6',
        '&:hover': {
            backgroundColor: '#3f75b5',
        },
    },

    searchContainer: {
        textAlign: 'left'
    }
});

class Search extends React.Component {

    constructor(props) {
        super(props);
        this.state = {
            data: null,
            primaryNS: null,
            zoneName: '',
            loading: true,
            rrType: '',
            comparator: Comparator.EQ,
            showAdvanceSearch: false,
            showDeleteNSConfirm: false,
            error: '',
            rrSearchParams: {},
            nsParams: {},
            deleteNSrecId: '',
            primaryServerName: '',
            page: 1,
            sizePerPage: 10,
            totalSize: 0,
            nsType: '',
            srvrgrps: '',
        }

        this.isComponentMounted = true;
        //this.isComponentMounted = false;
        this.handleTableChange = this.handleTableChange.bind(this);
        this.handlePrimaryNSTableChange = this.handlePrimaryNSTableChange.bind(this);
        this.getDeleteNSConfirmDialog = this.getDeleteNSConfirmDialog.bind(this);
        this.deleteNS = this.deleteNS.bind(this);


        if ((this.props.location.state === null || this.props.location.state === undefined || !this.props.location.state.showAlerts) && !_.isEmpty(this.props.alert)) {
            this.props.alertClear()
        }
    }


    async componentDidMount() {
        if (!_.isEmpty(this.props.zone) && this.props.zone?.zoneNum == this.props.match.params.zoneNum) {

        } else {
            this.props.getZoneById(this.props.match.params.zoneNum)
        }

    }


    async loadTableData(data) {
        data = {
            ...data,
            zoneNum: this.props.match.params.zoneNum,
            rrType: data.rrType,
            nsType: data.nsType,

        }
        const res = await resourceRecordService.getAllRecords(data);

        this.setState({
            loading: false,
            //  data: res.rr,
            data: res.rr.filter((row) => row.rrName === '@'),//using this display only '@' rrNames to avoid subzones
            error: res.error,
            totalSize: res.totalRecords,
            page: data.pageNumber ? data.pageNumber : this.state.page,
            sizePerPage: data.numberOfRows ?
                data.numberOfRows :
                this.state.sizePerPage,
            rrType: data.rrType, nsType: data.nsType
        });

    }

    async loadNSTableData(nameServerData) {
        let primaryNSRequest = {
            zoneNum: this.props.match.params.zoneNum,
            pageNumber: nameServerData.page ? nameServerData.page : this.state.page,
            numberOfRows: nameServerData.sizePerPage ? nameServerData.sizePerPage : this.state.sizePerPage
        }
        const response = await zoneService.getSecondaryZoneNameServers(primaryNSRequest)


        this.setState({
            primaryNS: response.secZones,
            totalSize: response.totalRecords,
            page: this.state.page,
            loading: false,
            error: response.error,

        })
    }


    async componentDidUpdate(prevProps, prevState, snapshot) {
        console.log(this.props.zone, 'hey')
        if (((this.state.loading && this.props.zone) || !_.isEqual(prevProps.zone, this.props.zone))) {
            if (this.props.zone.zoneType === 'S' && (this.state.primaryNS === null) || (this.props.deleted)) {
                console.log(this.state.data, "xyz")
                let primaryNSRequest = {
                    zoneNum: this.props.match.params.id,
                    pageNumber: 1,
                    numberOfRows: 10
                }
                await this.loadNSTableData(primaryNSRequest)
                this.props.updateMenu();

            }
            else if (this.props.zone.zoneType === 'P' && this.state.data === null) {
                console.log("nnn")
                const rrNS = this.props.match.params.type.split("-")
                await this.loadTableData({
                    zoneNum: this.props.match.params.zoneNum,
                    rrType: rrNS[1],
                    nsType: rrNS[0],
                    numberOfRows: this.state.sizePerPage,
                    pageNumber: this.state.page
                });
                this.props.updateMenu();

            }
        }
    }


    componentWillUnmount() {
        this.isComponentMounted = false;
    }

    async handleTableChange(type, {filters, page, sortOrder, sortField, sizePerPage, totalSize}) {
        const currentIndex = (page - 1) * sizePerPage;
        let rrSearchParams = {};
        if (sortField && sortOrder) {
            rrSearchParams.orderDir = sortOrder;
            rrSearchParams.orderBy = sortField;
        }

        rrSearchParams.numberOfRows = sizePerPage;
        rrSearchParams.pageNumber = page;
        rrSearchParams.rrType = this.state.rrType;
        rrSearchParams.nsType = this.state.nsType;
        await this.loadTableData(rrSearchParams);

    }

    async handlePrimaryNSTableChange(type, {filters, page, sizePerPage, totalSize, sortOrder, sortField}) {
        const currentIndex = (page - 1) * sizePerPage;
        let nsParams = {};
        if (sortField && sortOrder) {
            nsParams.orderDir = sortOrder;
            nsParams.orderBy = sortField;
        }

        nsParams.numberOfRows = sizePerPage;
        nsParams.pageNumber = page;
        nsParams.zoneNum = this.props.match.params.zoneNum;
        await this.loadNSTableData(nsParams);


    }


    getNonAttNameServersColumns() {

        return [


            {
                text: 'Server Name',
                dataField: 'rrData',//this is the RHS data of rr
                headerAlign: 'center',
                headerStyle: {
                    width: "40%",
                },
                headerClasses: 'p-1',
                classes: 'text-left p-0',
                style: {
                    'wordWrap': 'break-word'
                },
            },
            {
                text: 'Resource Record Name',
                dataField: 'rrName',
                showHideSelection: true,
                headerAlign: 'center',
                headerStyle: {
                    width: "25%"
                },

            },
            /*
                        {
                            text: 'IP Address',
                            dataField: '',//we are not  displaying any ip address for  Non-ATT NS similar to old dragon  update in DRAGON3-346
                            showHideSelection: true,
                            headerAlign: 'center',
                            headerStyle: {
                                width: "20%"
                            },
                            headerClasses: 'p-1',
                            classes: 'text-left p-0',
                            style: {
                                'wordWrap': 'break-word'
                            },
                        },
            */
            /*
                        {
                            text: 'IP6 Address',
                            dataField: 'ip6', //we are not  displaying any ip address for  Non-ATT NS similar to old dragon  update in DRAGON3-346
                            showHideSelection: true,
                            headerAlign: 'center',
                            headerStyle: {
                                width: "20%"
                            },
                            headerClasses: 'p-1',
                            classes: 'text-left p-0',
                            style: {
                                'wordWrap': 'break-word'
                            },
                        },
            */
            {
                text: 'Last Modified',
                dataField: 'modTime',
                showHideSelection: true,
                headerAlign: 'center',
                headerStyle: {
                    width: "20%"
                },
            },
            {
                text: "Action",
                dataField: "",
                headerAlign: 'center',
                headerClasses: 'p-1',
                classes: 'p-0',
                headerStyle: {
                    width: "15%"
                },
                formatter: (cell, row, rowIndex) => <>
                    <Link
                        to={`/dns/zones/search/details/${this.props.match.params.zoneNum}/servers/${this.props.match.params.type}/details/${row.recId}`}
                        key={"details_record" + rowIndex}
                        className={"color-dragon-blue mr-2"}
                    >Details</Link>
                    {isAuthorized('ru') && <Link
                        to={`/dns/zones/search/details/${this.props.match.params.zoneNum}/servers/${this.props.match.params.type}/edit/${row.recId}`}
                        key={"edit_record" + rowIndex}
                        className={"color-dragon-blue"}
                    >Edit</Link>}
                </>

            },
        ];
    }

    getSlaveNonAttNSColumns() {

        return [
            {

                text: 'Host Name',
                dataField: 'serverName',
                headerAlign: 'center',
                headerStyle: {
                    width: "25%"
                },
            }, {

                text: 'IPV4 Address',
                dataField: 'ip4',
                headerAlign: 'center',
                headerStyle: {
                    width: "25%"
                },
            }, {

                text: 'IPV6 Address',
                dataField: 'ip6',
                headerAlign: 'center',
                headerStyle: {
                    width: "35%"
                },
            }, {
                text: "Action",
                dataField: "",
                headerAlign: 'center',
                headerStyle: {
                    width: "15%"
                },
                classes: 'text-center p-0',
                style: {
                    'wordWrap': 'break-word'
                },
                formatter: (cell, row, rowIndex) => <>
                    <Link onClick={async (e) => {
                        e.preventDefault();
                        this.setState({
                            showDeleteNSConfirm: true,
                            deleteNSrecId: row.recId,
                            primaryServerName: row.serverName
                        })
                    }}
                          to={``}

                          className={"color-dragon-blue mr-3"}
                          key={"slave_del"}
                    > Delete</Link>


                    <Link
                        to={`/dns/zones/search/details/${this.props.match.params.zoneNum}/servers/${this.props.match.params.type}/nameserver/edit/${row.recId}`}
                        key={"edit_record"}
                        className={"color-dragon-blue"}
                    >Update</Link>


                    {/*<Link
                        to={`/dnsprov/dnsAdmin/zones/${this.props.match.params.id}/priNS/edit/${row.recId}`}
                        key={"edit_record"}
                        className={"color-dragon-blue"}
                    >Update</Link>*/}

                </>
            },];


    }


    getBootStrapTable() {
        const {rr, data, primaryNS} = this.state;
      //  console.log(this.state, "abc")
        const paginationOptions = this.paginationOptions();
        if (this.props.zone?.zoneType === 'P') {
            return (<BootstrapTable bootstrap4
                                    keyField="recId"
                                    data={data ? data : []}
                                    remote={{pagination: true}}
                                    onTableChange={this.handleTableChange}
                                    columns={this.getNonAttNameServersColumns()}
                                    filter={filterFactory()}
                                    filterPosition={"top"}
                                    pagination={paginationFactory(paginationOptions)}
                                    noDataIndication="Table is Empty"
                                    id={"rr_attns_table"}
                                    condensed/>)

        } else {
            return (<>
                <BootstrapTable bootstrap4
                                keyField="attrValue"
                                keyField="recId"
                                data={primaryNS ? primaryNS : []}
                                remote={{
                                    pagination: true,
                                }}
                                loading={this.state.loading}
                                columns={this.getSlaveNonAttNSColumns()}
                                onTableChange={this.handlePrimaryNSTableChange}
                                noDataIndication="Table is Empty"
                                id={"sec_ns_table"}
                                key={"sec_ns_table"}
                                condensed/>

            </>)
        }
    }

    getDeleteNSConfirmDialog() {
        return !this.props.isEditable && <Dialog
            fullWidth={true}

            onClose={(event, reason) => {
                if (reason === 'backdropClick' || reason === 'escapeKeyDown') {
                    return false;
                }
            }}
            maxWidth="md"
            aria-labelledby="confirmation-dialog-title"
            open={this.state.showDeleteNSConfirm}
        >
            <div className={"mt-2 ml-4"}>

                <DialogTitle id="confirmation_dialog_title"><span
                    className={"font-weight-bold text-center"}>Are you sure you want to delete the following DNS record in the domain {this.props.zone?.zoneName}</span></DialogTitle>


                <span
                    className={"ml-3"}>Deleting a critical DNS record will disrupt the operation of your network.</span>
                <span className={"ml-3"}>It is strongly recommended that you print or save a copy of this record in case you
                  need to restore it later.</span><br/>
                <div className={"mt-2"}>
                    <span className={"ml-3 mt-3"}>Click on the button to cancel this action.</span>
                </div>
                <div className={" ml-3 mt-4"}>
                    <span>{this.props.zone?.zoneName}</span>
                    <span className={"ml-5"}>{"IN"} {"NS"}</span>
                    <span className={"ml-5"}>{this.state.primaryServerName}</span>
                </div>

                <DialogActions>
                    <Button autoFocus onClick={this.deleteNS} className={"dns-blue-button text-white"}>
                        Delete
                    </Button>
                    <Button onClick={() => this.setState({showDeleteNSConfirm: false})}
                            className={"dns-blue-button text-white"}>
                        Cancel
                    </Button>
                </DialogActions>
            </div>
        </Dialog>


    }

    deleteNS() {
        this.setState({showDeleteNSConfirm: false, loading: true})
        this.props.deleteNS(this.state.deleteNSrecId, this.props.match.params.id);
    }


    paginationOptions() {
        return {
            sizePerPage: this.state.sizePerPage,
            page: this.state.page,
            totalSize: this.state.totalSize,
            alwaysShowAllBtns: true,
            withFirstAndLast: true,
            firstPageText: 'First',
            prePageText: 'Back',
            nextPageText: 'Next',
            lastPageText: 'Last',
            nextPageTitle: 'First page',
            prePageTitle: 'Pre page',
            firstPageTitle: 'Next page',
            lastPageTitle: 'Last page',
            showTotal: false,
            sizePerPageList: [
                {
                    text: '10', value: 10
                }, {
                    text: '20', value: 20
                },
                {
                    text: '50', value: 50
                },],
            pageButtonRenderer: pageRenderer,
            sizePerPageRenderer: ({
                                      options,
                                      currSizePerPage,
                                      onSizePerPageChange
                                  }) => <SizePerPageRenderer options={options}
                                                             currSizePerPage={currSizePerPage}
                                                             onSizePerPageChange={onSizePerPageChange}/>,

            disablePageTitle: true,
        };
    }


    render() {
        return (

            <div>
                <Helmet>
                    <title>DNS Resource Records|TXT Record</title>
                </Helmet>
                <Box>
                    <Container maxWidth={false} className={"px-2"}>
                        <Card>
                            <CardContent>
                                <div className={'mt-3 ml-3 mr-3 mb-3'}>

                                    {(this.props.zone?.zoneType !== 'S') &&
                                    <h5 className="font-weight-bold  text-capitalize text-left pt-1 pb-1 pl-2">

                                        DNS Non-ATT NS Records List
                                    </h5> ? <h5 className="font-weight-bold  text-capitalize text-left pt-1 pb-1 pl-2">

                                        DNS Non-ATT NS Records List
                                    </h5> : <h5 className="font-weight-bold  text-capitalize text-left pt-1 pb-1 pl-2">

                                        Masterlist NS Records List
                                    </h5>}


                                    {/*   <h5 className="font-weight-bold  text-capitalize text-left pt-1 pb-1 pl-2">

                                    DNS Non-ATT NS Records List
                                </h5>*/}
                                    <div>

                                        {this.getDeleteNSConfirmDialog()}


                                        {this.props.alert.message && <Alert
                                            severity={this.props.alert.type}>{this.props.alert.message}</Alert>}
                                        {/*                                        {(!_.isEmpty(this.state.error) || !_.isEmpty(this.props.alert.message)) &&
                                            <Alert
                                                severity={!_.isEmpty(this.state.error) ? "error" : this.props.alert.type}>{(this.state.error && this.state.error.text) || this.props.alert.message}</Alert>}*/}
                                        <div className="pl-5 pr-5">
                                            <div className={"col text-right mt-2 mb-2"}>
                                                {isAuthorized('ri') && (this.props.zone?.zoneType !== 'S' && <Link
                                                    className={"d-inline-block btn btn-primary dns-blue-button mr-1"}
                                                    to={"/dns/zones/search/details/" + this.props.match.params.zoneNum + "/servers/" + this.props.match.params.type + "/create"}
                                                >Insert Record</Link>) ? <Link
                                                    className={"d-inline-block btn btn-primary dns-blue-button mr-1"}
                                                    to={"/dns/zones/search/details/" + this.props.match.params.zoneNum + "/servers/" + this.props.match.params.type + "/create"}
                                                >Insert Record</Link> : <Link
                                                    className={"d-inline-block btn btn-primary dns-blue-button mr-1"}
                                                    to={"/dns/zones/search/details/" + this.props.match.params.zoneNum + "/servers/" + this.props.match.params.type + "/nameserver/create"}
                                                >Insert Record</Link>}
                                            </div>

                                            <div className={"pt-3 pb-3"}>
                                            <span
                                                className={'font-weight-bold'}>Zone Name</span>: {this.props.zone?.zoneName}

                                                <span
                                                    className={'font-weight-bold  pl-5'}>Zone ID</span> : {this.props.zone?.zoneNum}<br/>
                                            </div>


                                            {this.getBootStrapTable()}

                                            {/*               <BootstrapTable bootstrap4
                                                            keyField="recId"
                                                            data={data}
                                                            remote={{pagination: true}}
                                                            onTableChange={this.handleTableChange}
                                                            columns={columns}
                                                            filter={filterFactory()}
                                                            filterPosition={"top"}
                                                            pagination={paginationFactory(paginationOptions)}
                                                            noDataIndication="Table is Empty"
                                                            id={"rr_attns_table"}
                                                            condensed
                                            />*/}
                                        </div>
                                    </div>
                                </div>
                            </CardContent>
                        </Card>
                    </Container>
                </Box>
            </div>);
    }
}


Search.propTypes = {
    classes: PropTypes.object.isRequired
};
const styledSearch = withStyles(useStyles)(Search);

function mapState(state) {
    const {zone} = state.zones
    const {deleted} = state.nameservers
    const loading = state.zones.loading || state.nameservers.loading
    const {alert, clear} = state
    return {loading, alert, zone, deleted, clear}
}


const actionCreators =
    {
        alertClear: alertActions.clear,
        getZoneById: zoneActions.getZoneById,
        deleteNS: nameServerActions.deleteNS,


    }

const connectedNonAttNameServers = withRouter(connect(mapState, actionCreators)(styledSearch));
export {connectedNonAttNameServers as Search};