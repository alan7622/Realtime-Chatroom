import React, {Component} from "react";
import Container from "@material-ui/core/Container";
import {withRouter} from "react-router-dom";
import {
    Backdrop,
    Button, Card,
    CardContent,
    CircularProgress,
    Dialog,
    DialogActions,
    DialogTitle,
} from "@material-ui/core";
import PropTypes from "prop-types";
import {alertActions, zoneActions} from "../../../../_actions";
import Form from 'react-bootstrap/Form'
import {Col} from "react-bootstrap";
import {Row} from "react-bootstrap";
import {Alert} from '@material-ui/lab';
import {connect} from "react-redux";
import {Helmet} from "react-helmet";
import _ from "lodash";
import {resourceRecordService, zoneService} from "../../../../_services";
import {resourceRecordActions} from "../../../../_actions/resourceRecords.actions";
import {isAuthorized} from "../../../../_components";


class NonAttNameServers extends Component {
    constructor(props) {
        super(props);
        this.state = {
            loading: true,
            showDeleteConfirm: false,
            zoneData: {},
            rr: {
                rrGrp: this.props.match.params.zoneNum,
                rrStr: '',
                rrType: this.props.match.params.type,
                comments: '',
                recId: '',

            },
            alert: '',

        };
        this.isComponentMounted = false;
        this.saveNonATTNameSrvr = this.saveNonATTNameSrvr.bind(this);
        this.updateSrvrObj = this.updateSrvrObj.bind(this);
        this.deleteSrvr = this.deleteSrvr.bind(this);
        this.getDeleteConfirmDialog = this.getDeleteConfirmDialog.bind(this);


        if ((this.props.location.state === undefined || !this.props.location.state.showAlerts) && !_.isEmpty(this.props.alert)) {
            this.props.alertClear()
        }

    }


    saveNonATTNameSrvr(e) {
        e.preventDefault()

        if (this.isComponentMounted) {
            this.setState({loading: !this.props.isEmptyForm})//changed it so that it supports loading on create page

        }
        const {rrName, rrTtl, rrType, rrData, comments, rrGrp, ...rr} = this.state.rr
        const rrNS = this.props.match.params.type.split("-")
        const resourceRecord = {
            rrStr: "@" + (rrTtl ? (" " + rrTtl) : "") + " IN " + rrNS[1] + " " + (rrData ? rrData : ""),
            rrType: rrNS[1],
            nsType: rrNS[0],
            rrGrp,
            //comments its ;s saving as undefined using below condition to send as '' string if no value
            comments:comments?comments:''
        }
        if (this.props.isEmptyForm && this.props.isEditable) {
            this.props.create(resourceRecord, 'servers');
        } else {
            console.log("nameserver not")
            this.props.update(this.props.match.params.id, resourceRecord, false);
        }

    }

    async componentDidMount() {
        this.isComponentMounted = true;
        this.props.getZoneById(this.props.match.params.zoneNum)

        if (!this.props.isEmptyForm && this.isComponentMounted) {

            const rr = await resourceRecordService.getByRecordId(this.props.match.params.id);
            if (!_.isEmpty(rr) && this.isComponentMounted) {
                this.setState({loading: false, rr: rr});

            }
        }
    }

    componentDidUpdate(prevProps, prevState, snapshot) {
        if (((this.state.loading && this.props.zone) || !_.isEqual(prevProps.zone, this.props.zone))) {

            this.setState({
                zoneData: _.omit(this.props.zone, ['soaTemplate']),
                loading: false
            }, () => {

                if (prevProps.zone?.zoneStatus != this.props.zone?.zoneStatus) {
                    this.props.updateMenu();
                }
            })
        }
    }


    deleteSrvr() {
        this.setState({showDeleteConfirm: false, loading: true})
        this.props.delete(this.props.match.params.id);
    }

    componentWillUnmount() {
        this.isComponentMounted = false;
    }


    updateSrvrObj(e) {
        if (e.keyCode === 8 && e.target.selectionStart === 0 && e.target.selectionEnd === e.target.value.length) {
            e.preventDefault(); // Prevent default backspace behavior
            e.target.value = ""; // Clear the input value
        }
        console.log("onchange test")

        let {name, value} = e.target;
        const {rr} = this.state;

        this.setState({rr: {...rr, [name]: value}})
    }


    getNonAttNSPageButtons() {
        let pageElements = {
            pageTitle: '',
            pageButtons: [],
        }
        if (this.props.isEditable && this.props.isEmptyForm) {
            pageElements.pageTitle = " DNS NON-ATT NS Record Creation"
            pageElements.pageButtons.push(<Button className={"dns-blue-button text-white mr-2"}
                                                  onClick={this.saveNonATTNameSrvr}
                                                  key={"insert"}>Insert</Button>)
            pageElements.pageButtons.push(<Button className={"dns-blue-button text-white mr-2 col-md-1"}
                                                  onClick={() => this.props.history.goBack()}
                                                  key={"cancel_update"}>Cancel</Button>)


        } else if (this.props.isEditable) {
            pageElements.pageTitle = "DNS Non-ATT NS Record Update"
            pageElements.pageButtons.push(<Button className={"dns-blue-button text-white mr-2 col-md-1"}
                                                  onClick={this.saveNonATTNameSrvr}
                                                  key={"update"}>Update</Button>)
            pageElements.pageButtons.push(<Button className={"dns-blue-button text-white mr-2 col-md-1"}
                                                  onClick={() => this.props.history.goBack()}
                                                  key={"cancel_update"}>Cancel</Button>)


        }

        else {

            if (isAuthorized('ru')) {

                pageElements.pageTitle = "DNS Non-ATT NS Record Details"
                pageElements.pageButtons.push(<Button className={"dns-blue-button text-white mt-2 mr-4 mb-4"}
                                                      onClick={() => this.props.history.push(`/dns/zones/search/details/${this.props.match.params.zoneNum}/servers/${this.props.match.params.type}/edit/${this.props.match.params.id}`)}
                                                      key={"edit"}>Go To Update</Button>)

            }
            if (isAuthorized('rd')) {

                pageElements.pageButtons.push(<Button className={"dns-blue-button text-white mt-2 mr-4 mb-4"}
                                                      onClick={() => {
                                                          this.setState({showDeleteConfirm: true})
                                                      }} key={"delete"}>Delete</Button>)

            }
            pageElements.pageButtons.push(<Button className={"dns-blue-button text-white mt-2 mb-4"}
                                                  onClick={() => this.props.history.push(`/dns/zones/search/details/${this.props.match.params.zoneNum}/servers/${this.props.match.params.type}`)}
                                                  key={"list_users"}>List NS Records</Button>)


        }

        return pageElements;
    }

    getDeleteConfirmDialog() {
        return !this.props.isEditable && <Dialog
            onClose={(event, reason) => {
                if (reason === 'backdropClick' || reason === 'escapeKeyDown') {
                    return false;
                }
            }}
            maxWidth="xs"
            aria-labelledby="confirmation-dialog-title"
            open={this.state.showDeleteConfirm}
        >
            <DialogTitle id="confirmation_dialog_title">Are you sure you want to delete this
                record?</DialogTitle>
            <DialogActions>
                <Button autoFocus onClick={this.deleteSrvr} className={"dns-blue-button text-white"}>
                    Delete
                </Button>
                <Button onClick={() => this.setState({showDeleteConfirm: false})}
                        className={"dns-blue-button text-white"}>
                    Cancel
                </Button>
            </DialogActions>
        </Dialog>
    }

    getNonAttNSForm() {
        const {rr, zoneData} = this.state
        let {pageButtons} = this.getNonAttNSPageButtons();


        return (<>
            <Form className={"mt-4"}>

                <Form.Group as={Row} className={"align-items-center"}>
                    <Form.Label column sm="2"
                                className={"font-weight-bold"}>
                        Zone ID
                    </Form.Label>
                    <Col sm="4">
                        {this.props.match.params.zoneNum}
                    </Col>
                    {this.props.isEmptyForm && <>
                        <Form.Label column sm="2"
                                    className={"font-weight-bold"}>
                            Zone Name
                        </Form.Label>
                        <Col sm="4">
                            {zoneData.zoneName}
                        </Col></>
                    }
                </Form.Group>
                <Form.Group as={Row} className={"align-items-center"}>
                    <Form.Label column sm="2" className={"font-weight-bold"}>
                        {this.props.isEmptyForm ? "*" : ""}Server's Full Name
                    </Form.Label>
                    <Col sm="4">
                        {this.props.isEditable ?
                            <Form.Control name={"rrData"}
                                          onChange={this.updateSrvrObj}
                                          onKeyDown={this.updateSrvrObj}
                                          defaultValue={rr.rrData ? rr.rrData : ''}/> : rr.rrData}
                    </Col>
                    {!this.props.isEmptyForm &&
                        <> <Form.Label column sm="2" className={"font-weight-bold"}>
                            Record ID
                        </Form.Label>
                            <Col sm="4">
                                {rr.recId}
                            </Col></>}
                </Form.Group>
                {/*
                <Form.Group as={Row} className={"align-items-center"}>
                    <Form.Label column sm="2" className={"font-weight-bold"}>
                        {this.props.isEmptyForm ? "*" : ""}IP Address
                    </Form.Label>
                    <Col sm="4">
                        {this.props.isEditable ?
                            <Form.Control name={"ip"}
                                          onChange={this.updateSrvrObj}
                                          defaultValue={rr.ip ? rr.ip : ''}/> : rr.ip}
                    </Col>
                    <Form.Label column sm="2" className={"font-weight-bold"}>
                        {this.props.isEmptyForm ? "*" : ""}IP6 Address
                    </Form.Label>
                    <Col sm="4">
                        {this.props.isEditable ?
                            <Form.Control name={"ip6"}
                                          onChange={this.updateSrvrObj}
                                          defaultValue={rr.ip6 ? rr.ip6 : ''}/> : rr.ip6}
                    </Col>
//Commenting ip and ip6 address in new code as it was not used to search mainly FQDN is used
                </Form.Group>
*/}
                <Form.Group as={Row} className={"align-items-center"}>
                    {!this.props.isEmptyForm && !this.props.isEditable && <> <Form.Label column sm="2"
                                                                                         className={"font-weight-bold"}>
                        Create Time
                    </Form.Label>
                        <Col sm="4">
                            {rr.createTime}
                        </Col></>}


                    {!this.props.isEmptyForm && !this.props.isEditable && <>  <Form.Label column sm="2"
                                                                                          className={"font-weight-bold"}>
                        Last Modified
                    </Form.Label>
                        <Col sm="4">
                            {rr.modTime}
                        </Col></>}


                </Form.Group>


                <Form.Group as={Row} className={"align-items-center"}>
                    <Form.Label column sm="2" className={"font-weight-bold"}>
                        Time To Live
                    </Form.Label>
                    <Col sm="4">
                        {this.props.isEditable ?
                            <Form.Control name={"rrTtl"}
                                          onChange={this.updateSrvrObj}
                                          onKeyDown={this.updateSrvrObj}
                                          defaultValue={rr.rrTtl ? rr.rrTtl : ''}/> : rr.rrTtl}
                    </Col>

                    <Form.Label column sm="2" className={"font-weight-bold"}>
                        Comment
                    </Form.Label>
                    <Col sm="4">
                        {this.props.isEditable ?
                            <Form.Control name={"comments"}
                                          onChange={this.updateSrvrObj}
                                          onKeyDown={this.updateSrvrObj}
                                          defaultValue={rr.comments ? rr.comments : ''}/> : rr.comments}
                    </Col>
                </Form.Group>


                <Form.Group as={Row} className={"align-items-center"}>
                    {!this.props.isEmptyForm && !this.props.isEditable && <><Form.Label column sm="2"
                                                                                        className={"font-weight-bold"}>
                        Modified By
                    </Form.Label>
                        <Col sm="4">
                            {rr.modBy}
                        </Col></>}


                    <Form.Label column sm="2" className={"font-weight-bold"}>
                        Validated
                    </Form.Label>
                    <Col sm="4">

                        {this.props.isEditable ?
                            <Form.Control as="select" name={"status"}
                                          onChange={this.updateSrvrObj}
                                          onKeyDown={this.updateSrvrObj}
                                          value={rr.json}>
                                <option value={"Y"}>Y</option>
                                <option value={"N"}>N</option>
                            </Form.Control> : rr.json}
                    </Col>
                </Form.Group>


                <div className={"text-center"}>
                    {pageButtons.map(buttonComp => buttonComp)}
                </div>

            </Form>
        </>)


    }


    render() {
        let {pageTitle} = this.getNonAttNSPageButtons();
        if (this.state.loading) {
            return <div>Loading....</div>
        }
        return (
            <>
                {this.getDeleteConfirmDialog()}
                <Backdrop className={"page-loading"} style={{'zIndex': '10000', 'color': '#fff'}}
                          open={this.state.loading}>
                    <CircularProgress color="inherit"/>
                </Backdrop>
                <div>
                    <Helmet>
                        <title>DNS Admin | DNS TXT Details Page</title>
                    </Helmet>
                    <Container maxWidth={false} className={"px-2"}>
                        <Card>
                            <CardContent>
                                <div className={'mt-3 ml-3 mr-3 mb-3'}>
                                    <h5 className="font-weight-bold  text-capitalize text-left mt-3 mb-3 ml-2">{pageTitle}</h5>

                                    <div className={"pb-2"}>
                                        {this.props.alert.message && <Alert
                                            severity={this.props.alert.type}>{this.props.alert.message}</Alert>}</div>
                                    {this.getNonAttNSForm()}
                                </div>
                            </CardContent>
                        </Card>
                    </Container>
                </div>
            </>
        )
    }

}

NonAttNameServers.defaultProps = {
    isEditable: false,
};
NonAttNameServers.propTypes = {
    isEditable: PropTypes.bool,
    isEmptyForm: PropTypes.bool
};
NonAttNameServers.defaultProps = {
    isEditable: false,
    isEmptyForm: false
}

function mapState(state) {
    const {loading, zone} = state.zones

    const {alert, clear} = state
    return {loading, alert, zone, clear}
}

const actionCreators = {
    alertClear: alertActions.clear,
    create: resourceRecordActions.create,
    delete: resourceRecordActions.delete,
    update: resourceRecordActions.update,
    getZoneById: zoneActions.getZoneById,

};


const connectedNonAttNameServers = withRouter(connect(mapState, actionCreators)(NonAttNameServers));
export {connectedNonAttNameServers as NonAttNameServers};

