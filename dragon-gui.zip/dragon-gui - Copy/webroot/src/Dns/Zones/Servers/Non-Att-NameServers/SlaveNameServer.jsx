import React from "react";
import PropTypes from "prop-types";
import {alertActions, nameServerActions, zoneActions} from "../../../../_actions";
import {withRouter} from "react-router-dom";
import {connect} from "react-redux";
import {Helmet} from "react-helmet";
import {
    Backdrop,
    Button,
    Card,
    CardContent, CircularProgress,
    Dialog,
    DialogActions,
    DialogContent,
    DialogContentText,
    DialogTitle
} from "@material-ui/core";
import Container from "@material-ui/core/Container";
import {Col, Form, Row} from "react-bootstrap";
import {zoneService} from "../../../../_services";
import {Alert} from "@material-ui/lab";
import _ from "lodash";
import Divider from "@material-ui/core/Divider";
import {isAuthorized} from "../../../../_components";

class SlaveNameServer extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            loading: true,
            primaryNS: '',
            showFilterAlert: false,
            zoneData: {},
            nameServer: {
                comments: '',
                recId: this.props.match.params.recId,
                ip6: '',
                ip4: '',
                serverName: '',
                host: '',
                zoneNum: this.props.match.params.id
            },


        }

        this.isComponentMounted = false;
        this.saveNS = this.saveNS.bind(this);
        this.updateNSObj = this.updateNSObj.bind(this);
        this.getIpFilterAlert = this.getIpFilterAlert.bind(this);
        this.handleClose = this.handleClose.bind(this);


        if ((this.props.location.state === null || this.props.location.state === undefined || !this.props.location.state.showAlerts) && !_.isEmpty(this.props.alert)) {
            this.props.alertClear()
        }

    }


    async componentDidMount() {
        this.isComponentMounted = true;
        if (this.isComponentMounted) {
            this.props.getZoneById(this.props.match.params.id)
            if (!this.props.isEmptyForm) {
                const response = await zoneService.getNSByRecId(this.props.match.params.recId)
                if (response.success) {
                    this.setState({nameServer: response.primaryNS})
                }
                else{
//re-direct to search page TO DO
                        this.props.history.push(`/dns/zones/search/details/${this.props.match.params.id}/servers/${this.props.match.params.type}`);
                }
            }
            this.setState({loading: false})

        }
    }

    componentDidUpdate(prevProps, prevState, snapshot) {
        console.log("didUpdate")

        if (((this.state.loading && this.props.zone) || !_.isEqual(prevProps.zone, this.props.zone))) {

            this.setState({
                zoneData: _.omit(this.props.zone, ['soaTemplate']),
                loading: false
            },
                () => {

                if (prevProps.zone?.zoneStatus != this.props.zone?.zoneStatus) {
                    this.props.updateMenu();
                }
            })
        }



             /*   if (this.state.loading && !this.props.loading && (!_.isEqual(this.props, prevProps))) {
                    console.log("loading false")

                    this.setState({loading: false})
                   // this.props.updateMenu();

                }*/

    }

    saveNS(e) {
        e.preventDefault()
        //  console.log("in saveNS()")
        console.log(this.state.nameServer, "this.state.nameServer")

        let nsDetails = {
            zoneNum: this.props.zone?.zoneNum,
            ip4: this.state.nameServer.ip4,
            ip6: this.state.nameServer.ip6,
            comments: this.state.nameServer.comments ? this.state.nameServer.comments : ''
        }

        /*   if (this.state.nameServer.hasOwnProperty("ip4")) {
               nsDetails.ip4 = this.state.nameServer.ip4 && this.state.nameServer.ip4 != undefined ? this.state.nameServer.ip4 : ''
           }
           if (this.state.nameServer.hasOwnProperty("ip6")) {

               nsDetails.ip6 = this.state.nameServer.ip6 && this.state.nameServer.ip6 != undefined ? this.state.nameServer.ip6 : ''
           }*/
        if (this.state.nameServer.hasOwnProperty("serverName")) {

            nsDetails.host = this.state.nameServer.serverName
            // nsDetails.host ='abc1.com'
        }

        this.setState({loading: true})

        if (this.props.isEmptyForm && this.props.isEditable) {
            this.props.create(nsDetails);
        } else {
console.log("nameserver update")
            this.props.update(this.props.match.params.recId, nsDetails);

        }
    }


    getIpFilterAlert() {
        return (
            <Dialog
                open={this.state.showFilterAlert}
                onClose={this.handleClose}>
                <DialogTitle>{" Required IP Address"}</DialogTitle>
                <Divider/>
                <DialogContent>
                    <DialogContentText>
                        You must enter either ip4 or ip6 address.
                    </DialogContentText>
                </DialogContent>
                <DialogActions>
                    <Button autoFocus onClick={this.handleClose} className={"dns-blue-button text-white"}>
                        Ok
                    </Button>
                </DialogActions>
            </Dialog>
        )
    }

    handleClose() {
        this.setState({showFilterAlert: false})
    };


    componentWillUnmount() {
        this.isComponentMounted = false
    }


    updateNSObj(e) {
        if (e.keyCode === 8 && e.target.selectionStart === 0 && e.target.selectionEnd === e.target.value.length) {
            e.preventDefault(); // Prevent default backspace behavior
            e.target.value = ""; // Clear the input value
        }
        let {name, value} = e.target;
        const {nameServer} = this.state
        nameServer[name] = value;
        this.setState(nameServer);
    }


    /*
        updateNSObj(e) {
         /!*   if (e.keyCode === 8 && e.target.selectionStart === 0 && e.target.selectionEnd === e.target.value.length) {
                e.preventDefault(); // Prevent default backspace behavior
                e.target.value = ""; // Clear the input value
            }*!/

            let {name, value} = e.target;

            const nameServer = this.state
            console.log(value,"value")

            this.setState({nameServer: {...nameServer, [name]: value}})

        }
    */


    getNSPageButtons() {
        let pageElements = {
            pageTitle: '',
            pageButtons: [],
        }
        if (this.props.isEmptyForm) {
            pageElements.pageTitle = "Masterlist Name Server Creation"
            pageElements.pageButtons.push(<Button className={"dns-blue-button text-white mr-2"}
                                                  type={"submit"}//using the submit form instead of click button
                                                  key={"insert"}>Insert</Button>)
            pageElements.pageButtons.push(<Button className={"dns-blue-button text-white mr-2 col-md-1"}
                                                  onClick={() => {
                                                      this.props.alertClear();
                                                      this.props.history.goBack()
                                                  }}
                                                  key={"cancel_update"}>Cancel</Button>)


        }
        else if (this.props.isEditable) {
            pageElements.pageTitle = "Masterlist Name Server Update"
            pageElements.pageButtons.push(<Button className={"dns-blue-button text-white mr-2 col-md-1"}
                                                  type={"submit"}
                                                  key={"update"}>Update</Button>)
            pageElements.pageButtons.push(<Button className={"dns-blue-button text-white mr-2 col-md-1"}
                                                  onClick={() => {
                                                      this.props.alertClear();

                                                      this.props.history.goBack()
                                                  }}
                                                  key={"cancel_update"}>Cancel</Button>)


        }

        else {

            if (isAuthorized('ru')) {

                pageElements.pageTitle = "DNS Non-ATT NS Record Details"
                pageElements.pageButtons.push(<Button className={"dns-blue-button text-white mt-2 mr-4 mb-4"}
                                                      onClick={() => this.props.history.push(`/dns/zones/search/details/${this.props.match.params.zoneNum}/servers/${this.props.match.params.type}/edit/${this.props.match.params.id}`)}
                                                      key={"edit"}>Go To Update</Button>)

            }
            if (isAuthorized('rd')) {

                pageElements.pageButtons.push(<Button className={"dns-blue-button text-white mt-2 mr-4 mb-4"}
                                                      onClick={() => {
                                                          this.setState({showDeleteConfirm: true})
                                                      }} key={"delete"}>Delete</Button>)

            }
            pageElements.pageButtons.push(<Button className={"dns-blue-button text-white mt-2 mb-4"}
                                                  onClick={() => this.props.history.push(`/dns/zones/search/details/${this.props.match.params.zoneNum}/servers/${this.props.match.params.type}`)}
                                                  key={"list_users"}>List NS Records</Button>)


        }

        return pageElements;
    }


    getNameServerForm() {
        const {nameServer} = this.state
        //  console.log(this.props.zone?.zoneName, "zone")
        let {pageButtons} = this.getNSPageButtons();
        return <form onSubmit={this.saveNS}>
            {(this.props.isEditable && !this.props.isEmptyForm) ?
                <span className={"pl-2"}>Updating a critical DNS record incorrectly will disrupt the operation of your network.It is strongly recommended that you print or save a copy of this record in case you need to restore it later.</span> : ''}
            <br/>
            <span className={"pl-2 font-italic"}>
    A value is expected for either one or both of 'IPv4 Address' and 'IPv6 Address'.</span>

            <Form.Group as={Row} className={"align-items-center"}>
                <Form.Label column sm="2"
                            className={"font-weight-bold"}>
                    Domain Name
                </Form.Label>
                <Col sm="4">

                    {this.props.zone?.zoneName}

                </Col>
            </Form.Group>
            <Form.Group as={Row} className={"align-items-center"}>
                <Form.Label column sm="2"
                            className={"font-weight-bold"}>
                    {this.props.isEditable ? "*" : ""} Host Name
                </Form.Label>
                <Col sm="4">
                    {this.props.isEditable ?

                        <Form.Control name={"serverName"}
                                      onChange={this.updateNSObj}
                                      onKeyDown={this.updateNSObj}
                                      defaultValue={nameServer?.serverName ? nameServer.serverName : ''}
                                      required={true}/> : nameServer.serverName}
                </Col>

            </Form.Group>

            <Form.Group as={Row} className={"align-items-center"}>


                <Form.Label column sm="2"
                            className={"font-weight-bold"}>
                    {this.props.isEditable ? "*" : ""} IPv4 Address
                </Form.Label>
                <Col sm="4">
                    {this.props.isEditable ?

                        <Form.Control name={"ip4"}
                                      onChange={this.updateNSObj}
                                      onKeyDown={this.updateNSObj}
                                      defaultValue={nameServer?.ip4 ? nameServer.ip4 : ''}
                        /> : nameServer.ip4}
                </Col>

            </Form.Group>


            <Form.Group as={Row} className={"align-items-center"}>


                <Form.Label column sm="2"
                            className={"font-weight-bold"}>
                    {this.props.isEditable ? "*" : ""} IPv6 Address
                </Form.Label>
                <Col sm="4">
                    {this.props.isEditable ?

                        <Form.Control name={"ip6"}
                                      onChange={this.updateNSObj}
                                      onKeyDown={this.updateNSObj}
                                      defaultValue={nameServer?.ip6 ? nameServer.ip6 : ''}
                        /> : nameServer.ip6}
                </Col>
                <span className={"pt-1 pl-4"}>
                    IPV6 address entered as expanded, 2001:1890:8000:0000:0000:0000:1428:00ab,</span>
                <span className={"pt-1 pl-1"}>or compressed chunk format 2001:1890:8000::1428:ab
</span>
            </Form.Group>
            <Form.Group as={Row} className={"align-items-center"}>

                <Form.Label column sm="2" className={"font-weight-bold"}>
                    Comment
                </Form.Label>
                <Col sm="4">
                    {this.props.isEditable ?
                        <Form.Control name={"comments"}
                                      onChange={this.updateNSObj}
                                      onKeyDown={this.updateNSObj}
                                      defaultValue={nameServer?.comments ? nameServer.comments : ''}
                        /> : nameServer.comments}
                </Col>

            </Form.Group>

            {/*

            <div className={"text-center"}>
                {this.getIpFilterAlert()}
                <Button className={"dns-blue-button text-white mr-2 col-md-1"}
                    //onClick={this.saveZone}
                        type={"submit"}
                        key={"insert"}>Insert</Button>
            </div>
*/}

            <div className={"text-center"}>

                {this.getIpFilterAlert()}

                {pageButtons.map(buttonComp => buttonComp)}

            </div>
        </form>

    }


    render() {
        let {pageTitle} = this.getNSPageButtons();
        console.log(this.state, "state")

        return (<>

            <div>
                <Helmet>
                    <title>AT&T DPT Resource Records</title>
                </Helmet>
                <Container maxWidth={false} className={"px-2"}>
                    <Card>
                        <CardContent>
                            <div className={'mt-3 ml-4 mr-3 mb-3'}>

                                <h6 className="font-weight-bold text-capitalize text-left pt-3 pb-3 pl-2">{pageTitle}</h6>
                                <Backdrop open={this.state.loading} className={"page-loading"}
                                          style={{'zIndex': '10000', 'color': '#fff'}}>
                                    <CircularProgress color="inherit"/>
                                </Backdrop>
                                <div className={"pb-2"}>
                                    {this.props.alert.message && <Alert
                                        severity={this.props.alert.type}>{this.props.alert.message}</Alert>}</div>
                                {this.getIpFilterAlert()}
                                {this.getNameServerForm()}

                            </div>
                        </CardContent>
                    </Card>
                </Container>
            </div>
        </>)
    }

}


SlaveNameServer.defaultProps = {
    isEditable: false,
};
SlaveNameServer.propTypes = {
    isEditable: PropTypes.bool,
    isEmptyForm: PropTypes.bool
};
SlaveNameServer.defaultProps = {
    isEditable: false,
    isEmptyForm: false,
}


function mapState(state) {
    const {alert, clear} = state
    const {loading, zone} = state.zones

    return {alert, clear, loading, zone}


}

const actionCreators =
    {
        alertClear: alertActions.clear,
        getZoneById: zoneActions.getZoneById,
        create: nameServerActions.create,
        update: nameServerActions.update,


    }
;


const connectedSlaveNameServer = withRouter(connect(mapState, actionCreators)(SlaveNameServer));
export {connectedSlaveNameServer as SlaveNameServer};