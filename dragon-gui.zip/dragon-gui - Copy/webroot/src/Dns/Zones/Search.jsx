import React, {Component} from "react";
import {
    Button, Card, CardContent, Dialog, DialogActions, DialogContent, DialogContentText, DialogTitle,
    FormControl, FormControlLabel,
    Grid, IconButton, InputLabel,
    Paper, Radio, RadioGroup, Select, TextField,
    withStyles
} from "@material-ui/core";
import Container from "@material-ui/core/Container";
import Box from "@material-ui/core/Box";
import BootstrapTable from "react-bootstrap-table-next";
import ToolkitProvider, {ColumnToggle} from 'react-bootstrap-table2-toolkit';
import paginationFactory from 'react-bootstrap-table2-paginator';
import filterFactory, {textFilter} from "react-bootstrap-table2-filter";
import {Col, Form, NavLink, Row} from "react-bootstrap";
import {zoneService} from "../../_services";
import Divider from "@material-ui/core/Divider";
import {Helmet} from "react-helmet";
import {Link} from "react-router-dom";
import _ from "lodash";
import {Alert} from "@material-ui/lab";
import {alertActions} from "../../_actions";
import {connect} from "react-redux";
import PropTypes from "prop-types";
import {isAuthorized, pageRenderer, ShowHideButton, SizePerPageRenderer} from "../../_components";


const useStyles = theme => ({
    root: {},
    searchButton: {
        backgroundColor: '#4789b6',
        marginBottom: '-28px',
        opacity: '1',
        color: '#FFF',
        width: '50%',
        '&:hover': {backgroundColor: '#3f6bb5', opacity: '0.6'}
    },
    filterContainer: {
        padding: '20px',
        marginBottom: '25px'
    },

    createZoneButton: {
        backgroundColor: '#4789b6',
        '&:hover': {
            backgroundColor: '#3f75b5',
        },
    },

    searchContainer: {
        textAlign: 'center'
    }
});

const defaultFilters = {
    accountId: '',
    zoneNum: '',
    zoneNameWildcard: 'begins',
    zoneName: '',
    zoneSubType: 'DOM',
    // billableZone:'',
}//declaring it as const to avoid its usage as reference
class Search extends Component {
    constructor(props) {
        super(props);
        this.state = {

            filters: {
                ..._.cloneDeep(defaultFilters),
                billableZone: this.props.match.params.zoneType === 'billable' ? 'yes' : ''
                , accountId: this.props.match.params.accountId,
            },//usimg cloneDeep to avoid reference usage of var in JS
            showFilterAlert: false,
            data: [],
            loading: false,
            submitted: false,
            page: 1,
            sizePerPage: 10,
            totalSize: 0,
            zoneSearchParams: {},
            error: '',
        }

        this.handleChange = this.handleChange.bind(this);
        this.handleClose = this.handleClose.bind(this);
        this.searchZone = this.searchZone.bind(this);
        this.getZoneFilterAlert = this.getZoneFilterAlert.bind(this);
        this.handleTableChange = this.handleTableChange.bind(this)

        /*if ((this.props.location.state === null || this.props.location.state === undefined || !this.props.location.state.showAlerts) && !_.isEmpty(this.props.alert)) {
            this.props.alertClear()
        }
*/


        if ((this.props.location.state === null || this.props.location.state === undefined || !this.props.location.state.showAlerts) && !_.isEmpty(this.props.alert)) {
            this.props.alertClear()
        }
    }


    handleChange(e) {
        let {name, value} = e.target;
        const {filters} = this.state;
        // let {filters} = this.state;

        // value =value.trim(); //used to trim the blank space in form field
        // filters =filters.trim(); //used to trim the blank space in form field

        this.setState({filters: {...filters, [name]: value}})

    }

    componentDidMount() {
        console.log("mounting")
        this.isComponentMounted = true;
        setTimeout(() => {
            this.props.alertClear()
        }, 10000)//this clears alert message on listing or search page after 10 seconds
        if (this.props.match.params.accountId && this.isComponentMounted) {
            this.searchZone({
                    numberOfRows: this.state.sizePerPage,
                    pageNumber: this.state.page,
                    billableZone: this.state.filters.billableZone
                }
            )

        }

    }

    componentDidUpdate(prevProps, prevState, snapshot) {
        if (!_.isEqual(prevProps, this.props)) {
            console.log(this.state, "this.state")
            this.searchZone({
                numberOfRows: this.state.sizePerPage,
                pageNumber: this.state.page,
                billableZone: this.props.match.params.zoneType === 'billable' ? 'yes' : ''
            })

        }

    }

    componentWillUnmount() {
        console.log("Unmounting")
        this.isComponentMounted = false;

        this.props.alertClear()
        // this.props.clearStack()

    }

    searchZone(params) {
        const {filters} = this.state
        console.log("FILTERS", filters)
        if (filters.accountId || (filters.zoneName && filters.zoneNameWildcard && filters.zoneSubType)
            || filters.zoneNum) {
            let data = {accountId: filters.accountId, zoneNum: filters.zoneNum, ...params}//add billable in the payload
            if (filters.zoneName) {
                console.log("data.zoneSubType", data.zoneSubType)

                data.zoneSubType = filters.zoneSubType;
                switch (filters.zoneNameWildcard) {
                    case "equals":
                        data.zoneNameEq = filters.zoneName;
                        break;
                    case "contains":
                        data.zoneNameContains = filters.zoneName;
                        break;

                    default:
                        data.zoneNameBeg = filters.zoneName;
                        break;
                }

            }
            //make API call
            if (this.isComponentMounted) {
                this.setState({submitted: true, loading: true})
            }

            zoneService.getAll(data).then(res => {
                if (this.isComponentMounted) {
                    console.log(data, "data")
                    this.setState({
                        loading: false,
                        data: res.zones,
                        totalSize: res.totalRecords,
                        page: params.pageNumber,
                        billableZone: filters.billableZone
                    });
                }
            });
        } else if (this.isComponentMounted) {
            this.setState({showFilterAlert: true})
        }
    }

    handleClose() {
        if (this.isComponentMounted) {
            this.setState({showFilterAlert: false})
        }
    };

    getZoneFilterAlert() {
        return (
            <Dialog
                open={this.state.showFilterAlert}
                onClose={this.handleClose}>
                <DialogTitle>{"Zone Search Alert"}</DialogTitle>
                <Divider/>
                <DialogContent>
                    <DialogContentText>
                        You must enter at least one search criteria.
                    </DialogContentText>
                </DialogContent>
                <DialogActions>
                    <Button autoFocus onClick={this.handleClose} className={"dns-blue-button text-white"}>
                        Ok
                    </Button>
                </DialogActions>
            </Dialog>
        )
    }

    getZoneSearchColumns() {
        return [
            {
                dataField: 'zoneNum',
                text: 'Zone Number',
                // filter: textFilter({placeholder: 'Search'}),
                headerAlign: 'center',
                headerClasses: 'p-1',
                classes: 'text-left p-0 pl-1',
                headerStyle: {
                    width: "9%",
                },
                style: {
                    'wordWrap': 'break-word'
                },
            },
            {
                text: 'Date Created',
                dataField: 'createTime',
                //filter: textFilter({placeholder: 'Search'}),
                headerAlign: 'center',
                headerClasses: 'p-1',
                classes: 'text-left p-0 pl-1',

                style: {
                    'wordWrap': 'break-word'
                },
                headerStyle: {
                    width: "13%",
                },

            },
            {
                text: 'Last Modified',
                dataField: 'updateTime',
                // filter: textFilter({placeholder: 'Search'}),
                style: {
                    'wordWrap': 'break-word'
                },
                headerAlign: 'center',
                headerClasses: 'p-1',
                classes: 'text-left p-0 pl-1',
                headerStyle: {
                    width: "13%",
                },
            },
            {
                text: 'P/S',
                dataField: 'zoneType',
                //   filter: textFilter({placeholder: 'Search'}),
                headerAlign: 'center',
                headerClasses: 'p-1',
                classes: 'text-left p-0 pl-1',
                headerStyle: {
                    width: "5%",
                },
                style: {
                    'wordWrap': 'break-word'
                },

            },
            {
                text: 'Service ID',
                dataField: 'serviceName',
                // filter: textFilter({placeholder: 'Search'}),
                headerAlign: 'center',
                headerClasses: 'p-1',
                classes: 'text-left p-0 pl-1',
                headerStyle: {
                    width: "7%",
                },
                style: {
                    'wordWrap': 'break-word'
                },
            },
            {
                text: 'Account ID',
                dataField: 'accountId',
                //filter: textFilter({placeholder: 'Search'}),
                headerAlign: 'center',
                headerClasses: 'p-1',
                classes: 'text-left p-0 pl-1',
                headerStyle: {
                    width: "9%",
                },
                style: {
                    'wordWrap': 'break-word'
                },
            },
            {
                text: 'Zone Name',
                dataField: 'zoneName',
                // filter: textFilter({placeholder: 'Search'}),
                headerAlign: 'center',
                headerClasses: 'p-1',
                classes: 'p-0',
                headerStyle: {
                    width: "22%",
                },
                style: {
                    'wordWrap': 'break-word'
                },
            },
            {
                text: 'ATT Arpa Block',
                dataField: 'attArpaBlock',
                showHideSelection: true,
                hidden: true,
                headerAlign: 'center',
                headerClasses: 'p-1',
                classes: 'text-left p-0 pl-1',

                headerStyle: {
                    width: "7%",
                },
                style: {
                    'wordWrap': 'break-word'
                },
            },
            {
                text: 'Prefix Length',
                dataField: 'prefixLength',
                // filter: textFilter({placeholder: 'Search'}),
                showHideSelection: true,
                hidden: true,
                headerAlign: 'center',
                headerClasses: 'p-1',
                classes: 'text-left p-0 pl-1',
                headerStyle: {
                    width: "7%",
                },
                style: {
                    'wordWrap': 'break-word'
                },
            },
            {
                text: "Action",
                dataField: "",
                headerAlign: 'center',
                headerClasses: 'p-1',
                classes: 'text-center p-0',
                headerStyle: {
                    width: "8%",
                },
                formatter: (cell, row, rowIndex) => <>
                    <Link
                        to={`/dns/zones/details/${row.zoneNum}`}
                        key={"details_dns_zone"}
                        className={"color-dragon-blue mr-2"}
                    >Details</Link>
                    {isAuthorized('zu') && <Link
                        to={`/dns/zones/edit/${row.zoneNum}`}
                        key={"edit_dns_zone"}
                        className={"color-dragon-blue"}
                    >Edit</Link>}

                </>

            },
        ];

    }


    getZoneFormData() {
        return <><h6 className={"font-weight-bold pt-3 pb-3 "}>DNS Zones Search Page</h6>

            <Form>

                <Grid container spacing={2}>
                    <Grid item xs={2} sm={2}>
                        <TextField
                            id="outlined-helperText"
                            label="Account Id"
                            variant="outlined"
                            name={"accountId"}
                            onChange={this.handleChange}
                            value={this.state.filters.accountId}
                        />
                    </Grid>
                    <Grid item xs={2} sm={2}>
                        <TextField
                            id="zoneNum"
                            label="Zone Number"
                            variant="outlined"
                            name={"zoneNum"}
                            onChange={this.handleChange}
                            value={this.state.filters.zoneNum}
                        />
                    </Grid>
                    <Grid item xs={1}></Grid>

                    <Grid item xs={2} sm={2}>
                        <FormControl variant="outlined" className={""}>
                            <InputLabel htmlFor="wildcard-zoneName-search">Zone Name</InputLabel>
                            <Select
                                native
                                value={this.state.filters.zoneNameWildcard}
                                onChange={this.handleChange}
                                label="Zone Name"
                                inputProps={{
                                    name: 'zoneNameWildcard',
                                    id: 'wildcard-zoneName-search',
                                }}
                            >
                                <option value={"begins"}>Begins With</option>
                                <option value={"contains"}>Contains</option>
                                <option value={"equals"}>Equal</option>
                            </Select>
                        </FormControl>
                    </Grid>
                    <Grid item xs={2} sm={2}>
                        <TextField
                            id="zoneName"
                            label="Zone Name"
                            onChange={this.handleChange}
                            variant="outlined"
                            name={"zoneName"}
                            value={this.state.filters.zoneName}
                        />
                    </Grid>
                    {this.state.filters.zoneName &&
                        <RadioGroup value={this.state.filters.zoneSubType} onChange={this.handleChange}
                                    name={"zoneSubType"}>
                            <p className={'font-weight-bold'}>There are different formats that can be used
                                here for Zone Name.
                                Please select the appropriate format before filling the fields.</p>

                            <FormControlLabel value="DOM"
                                              control={<Radio color="primary"/>}
                                              label="Forward and IP4 Arpa Zones (i.e. expressojoes.com. or 128/27.114.0.12.in-addr.arpa.)"/>
                            <FormControlLabel value="IP4" control={<Radio color="primary"/>}
                                              label="IP4 Arpa Zones (i.e. 128/27.114.0.12.in-addr.arpa.) Please note that the IP4 arpa search is always on the IP address of the arpa zone(i.e. 12.0.114.128/27 or 12.0.114 or 0.114).The exceptions are an ' Equals' or a ' Contains' search where the search string ends with '.in-addr.arpa.'.In this case the search is on the Arpa Address(i.e 128/27.114.0.12.in-addr.arpa. or 12.in-addr.arpa.)."/>
                            <FormControlLabel value="IP6" control={<Radio color="primary"/>}
                                              label="IP6 Arpa Zones (i.e. 2001:1890:1111 or 1.1.1.1.0.9.8.1.1.0.0.2.ip6.arpa.)  Please make sure your search argument includes one of the delimiters ('.' or ':') to indicate what IP6 format you are using.If you don't, the search will assume the input is an address (i.e. 2001:1890:1111)."/>

                        </RadioGroup>}

                    {/* <Grid item xs={4}>

                    <Form.Group as={Row} className={"align-items-center"}>
                        <Form.Label column sm="3" className={'font-weight-bold'}>
                            Ordered By </Form.Label>
                        <Col sm={9} key={"orderBy"}>
                            <RadioGroup value={""} name={"orderBy.value"}
                                      //  onChange={this.handleFilterChange}
                                        row={true}>

                                <FormControlLabel value=""
                                                  control={<Radio color="primary"/>}
                                                  label="Full Host Name"/>

                            </RadioGroup>
                        </Col>
                    </Form.Group>
                    <Form.Group as={Row} className={"align-items-center"}>
                        <Form.Label column sm="3" className={'font-weight-bold'}>
                            Ordered Direction </Form.Label>
                        <Col sm={9} key={"orderDir"}>
                            <RadioGroup value={""} name={"orderDir.value"}
                                     //   onChange={this.handleFilterChange}
                                        row={true}>

                                <FormControlLabel value="asc"
                                                  control={<Radio color="primary"/>}
                                                  label="Ascending"/>
                                <FormControlLabel value="desc" control={<Radio color="primary"/>}
                                                  label="Descending"/>


                            </RadioGroup>
                        </Col>
                    </Form.Group>
                    </Grid>*/}

                    <Grid item xs={8}>
                        <Button onClick={() => this.searchZone({pageNumber: 1, numberOfRows: 10})} variant="contained"
                                className={"dns-blue-button text-white"}
                        >Search</Button>
                        <Button type={"reset"} onClick={() => {
                            this.props.alertClear();
                            this.setState({filters: _.cloneDeep(defaultFilters), data: [], submitted: false})
                        }} variant="contained"
                                className={"dns-blue-button text-white ml-2"}
                        >clear</Button>

                    </Grid>

                </Grid>
            </Form></>

    }

    paginationOptions() {
        return {
            sizePerPage: this.state.sizePerPage,
            page: this.state.page,
            totalSize: this.state.totalSize,
            alwaysShowAllBtns: true,
            withFirstAndLast: true,
            firstPageText: 'First',
            prePageText: 'Back',
            nextPageText: 'Next',
            lastPageText: 'Last',
            nextPageTitle: 'First page',
            prePageTitle: 'Pre page',
            firstPageTitle: 'Next page',
            lastPageTitle: 'Last page',
            showTotal: false,
            sizePerPageList: [
                {
                    text: '10', value: 10
                }, {
                    text: '20', value: 20
                }, {
                    text: '50', value: 50
                },
            ],
            pageButtonRenderer: pageRenderer,
            sizePerPageRenderer: ({
                                      options,
                                      currSizePerPage,
                                      onSizePerPageChange
                                  }) => <SizePerPageRenderer options={options}
                                                             currSizePerPage={currSizePerPage}
                                                             onSizePerPageChange={onSizePerPageChange}/>,
            disablePageTitle: true,
        };
    }

    async handleTableChange(type, {filters, page, sizePerPage, totalSize, sortOrder, sortField}) {
        const currentIndex = (page - 1) * sizePerPage;
        let zoneSearchParams = {};
        if (sortField && sortOrder) {
            zoneSearchParams.orderDir = sortOrder;
            zoneSearchParams.orderBy = sortField;
        }

        zoneSearchParams.numberOfRows = sizePerPage;
        zoneSearchParams.pageNumber = page;
        await this.searchZone(zoneSearchParams);


    }


    render() {
        const {loading, data} = this.state;
        const {classes} = this.props;
        let {pageTitle} = this.getZoneFormData()
        const paginationOptions = this.paginationOptions();

        let columnsConfig = this.getZoneSearchColumns()
        if (_.isEmpty(data) || data.length < 2) {
            columnsConfig = columnsConfig.map(({filter, ...item}) => item)
        }
        return (
            <div>
                {this.getZoneFilterAlert()}
                <Helmet>
                    <title>Search Zones | Home</title>
                </Helmet>
                <Box>
                    <Container maxWidth={false} className={"px-2"}>
                        <Card>
                            <CardContent>
                                <div className="mt-2 ml-2 mr-3 mb-2  pb-5">
                                    <div className={"row mb-2 text-left mt-3 ml-3"}>
                                        <div className={"col"}>
                                            {/*   <h6 className={"font-weight-bold pt-3 pb-3 "}>DNS Zones Search Page</h6>*/}
                                            <h6 className="font-weight-bold  text-capitalize text-left pt-3 pb-3">{pageTitle}</h6>
                                        </div>
                                    </div>
                                    {!this.props.match.params.accountId && <div className={"row"}>
                                        <div className={"col ml-4"}>

                                            {(!_.isEmpty(this.state.error) || !_.isEmpty(this.props.alert.message)) &&
                                                <Alert
                                                    severity={!_.isEmpty(this.state.error) ? "error" : this.props.alert.type}>{(this.state.error && this.state.error.text) || this.props.alert.message}</Alert>}
                                            {/*
                                            {this.props.alert.message && <Alert
                                                severity={this.props.alert.type}>{this.props.alert.message}</Alert>}*/}
                                            {this.getZoneFormData()}
                                        </div>
                                    </div>}
                                    {this.state.submitted && <>
                                        <div className={"row"}>
                                            <div className={"col"}>
                                                <h6 className={"mt-3 ml-3"}><strong>DNS Zone Searching
                                                    Results</strong></h6>
                                            </div>
                                        </div>
                                        <div className={"row"}>
                                            <div className={"col"}>

                                                <ToolkitProvider
                                                    keyField="zoneNum"
                                                    data={data}
                                                    columns={columnsConfig}
                                                    columnToggle
                                                >
                                                    {
                                                        (props) => (
                                                            <>
                                                                <div className="text-right pb-2">
                                                                    <ShowHideButton
                                                                        columnToggleProps={props.columnToggleProps}
                                                                        className={"d-inline-block"}></ShowHideButton>
                                                                </div>
                                                                <BootstrapTable bootstrap4
                                                                                filter={filterFactory()}
                                                                                pagination={paginationFactory(paginationOptions)}
                                                                                {...props.baseProps}
                                                                                noDataIndication="No matching records found"
                                                                                filterPosition={"top"}
                                                                                onTableChange={this.handleTableChange}
                                                                                remote={{
                                                                                    pagination: true,
                                                                                }}
                                                                                condensed
                                                                                striped
                                                                                hover
                                                                                loading={true}
                                                                />

                                                            </>)
                                                    }
                                                </ToolkitProvider>
                                            </div>
                                        </div>
                                    </>}
                                </div>

                            </CardContent>
                        </Card>
                    </Container>
                </Box>
            </div>

        )
            ;
    }
}

Search.propTypes = {
    classes: PropTypes.object.isRequired
};

const styledSearch = withStyles(useStyles)(Search);

function mapState(state) {
    const {deleted} = state.zones
    const {alert} = state
    return {deleted, alert}
}

const actionCreators = {
    alertClear: alertActions.clear,
}

const connectedZone = connect(mapState, actionCreators)(styledSearch);
export {connectedZone as Search};