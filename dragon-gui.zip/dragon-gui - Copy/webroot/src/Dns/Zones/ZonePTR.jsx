import React, {Component} from "react";
import {
    Backdrop,
    Button,
    Card,
    CardContent,
    CircularProgress,
    Dialog,
    DialogActions,
    DialogContent,
    DialogContentText,
    DialogTitle, FormControlLabel,
    Grid, Radio,
    RadioGroup,
} from "@material-ui/core";
import Container from "@material-ui/core/Container";
import Box from "@material-ui/core/Box";
import {Col, Row, Form} from "react-bootstrap";
import {Helmet} from "react-helmet";
import {zoneService} from "../../_services";
import Divider from "@material-ui/core/Divider";
import {Alert} from "@material-ui/lab";
import {alertActions, zoneActions} from "../../_actions";
import {withRouter} from "react-router-dom";
import {connect} from "react-redux";
import _ from "lodash";


class ZonePTR extends Component {
    constructor(props) {
        super(props);
        this.state = {
            zone: {},
            ip6: '',
            showFilterAlert: false,
            loading: false,
            alert:'',
            error:''
        }
        this.searchPtrZone = this.searchPtrZone.bind(this);
        this.getZoneFilterAlert = this.getZoneFilterAlert.bind(this);
        this.handleChange = this.handleChange.bind(this);
        this.handleClose = this.handleClose.bind(this);

        if ((this.props.location.state === null || this.props.location.state === undefined || !this.props.location.state.showAlerts) && !_.isEmpty(this.props.alert)) {
            this.props.alertClear()
        }

    }


    handleChange(e) {
        const {name, value} = e.target;
        this.setState({[name]: value})//ip6:2000 {ip6:'abc',}
    }

    async searchPtrZone() {
        if (this.state.ip6) {
            this.setState({loading: true})
            const resp = await zoneService.getZoneAndPtrByIp6(this.state.ip6)
            console.log(resp,"resp")
            if (resp.success) {
                this.setState({loading: false, zone: resp.zone})
            } else {
                this.setState({zone: {}, loading: false,error:resp.error.text})

            }

        }
        else {
            this.setState({showFilterAlert: true})
        }

    }

    handleClose() {
        this.setState({showFilterAlert: false})
    };

    getZoneFilterAlert() {
        return (
            <Dialog
                open={this.state.showFilterAlert}
                onClose={this.handleClose}>
                <DialogTitle>{"Zone PTR Search Alert"}</DialogTitle>
                <Divider/>
                <DialogContent>
                    <DialogContentText>
                        You must enter at least one search criteria.
                    </DialogContentText>
                </DialogContent>
                <DialogActions>
                    <Button autoFocus onClick={this.handleClose} className={"dns-blue-button text-white"}>
                        Ok
                    </Button>
                </DialogActions>
            </Dialog>
        )
    }


    getPTRForm() {
        const {json, zone} = this.state
        return (<>
            <p>Enter a valid IP6 address in compressed (i.e. 2001:1890:1111:0010::)
                or expanded address (i.e. 2001:1890:1111:0010:0000:0000:0000:0000)
                format.</p>
            <p className={"pb-4"}>This will return the longest zone that matches the address
                entered.
                It will also return a PTR record if it exists under that zone.</p>
            <Form>
                <Form.Group as={Row}>

                    <Form.Label column sm="2">
                        IP6 Address
                    </Form.Label>
                    <Col sm="4">

                        <Form.Control name="ip6" type="text" onChange={this.handleChange}
                                      value={this.state.ip6}/>
                    </Col>
                </Form.Group>
                <Button onClick={this.searchPtrZone} variant="contained"
                        className={"dns-blue-button text-white"}
                >Search</Button>
            </Form>
        </>)

    }


    render() {
        return (
            <>
                {this.getZoneFilterAlert()}
                <Backdrop className={"page-loading"} style={{'zIndex': '10000', 'color': '#fff'}}
                          open={this.state.loading}>
                    <CircularProgress color="inherit"/>
                </Backdrop>
                <Helmet>
                    <title>DNS Find Zone And PTR | Zones</title>
                </Helmet>
                <Box>
                    <Container maxWidth="lg">
                        <Card className={"mt-3 mr-0 p-3"}>
                            <CardContent>
                                <h6 className={"pb-3"}><strong>
                                    DNS Zone PTR Lookup Result</strong></h6>

                                {this.state.zone === '-' ? "no data " : _.isEmpty(this.state.zone) ?
                                    <div className="mt-3 pb-5">
                                        {(this.props.alert.message||this.state.error) &&
                                            <Alert severity={this.props.alert.type ? this.props.alert.type:"error"}>{this.props.alert.message ? this.props.alert.message:this.state.error}</Alert>}
                                        {this.getPTRForm()}



                                    </div> : <div>
                                        {this.state.zone}
                                    </div>
                                }
                            </CardContent>
                        </Card>

                    </Container>
                </Box>
            </>

        );
    }
}


function mapState(state) {
    const {alert, clear} = state
    return {alert, clear}

}

const actionCreators = {
    alertClear: alertActions.clear,
};


const connectedZonePTR = withRouter(connect(mapState, actionCreators)(ZonePTR));
export {connectedZonePTR as ZonePTR};




