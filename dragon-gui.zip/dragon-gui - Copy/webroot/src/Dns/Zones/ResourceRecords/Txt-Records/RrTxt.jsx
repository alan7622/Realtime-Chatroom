import React, {Component} from "react";
import Container from "@material-ui/core/Container";
import {withRouter} from "react-router-dom";
import {
    Backdrop,
    Button,
    Card,
    CardContent,
    CircularProgress,
    Dialog,
    DialogActions,
    DialogTitle,
} from "@material-ui/core";
import PropTypes from "prop-types";
import {alertActions} from "../../../../_actions";
import Form from 'react-bootstrap/Form'
import {Col} from "react-bootstrap";
import {Row} from "react-bootstrap";
import {Alert} from '@material-ui/lab';
import {connect} from "react-redux";
import {Helmet} from "react-helmet";
import {resourceRecordService} from "../../../../_services/resourceRecord.service";
import {resourceRecordActions} from "../../../../_actions/resourceRecords.actions";
import _ from "lodash";
import {zoneService} from "../../../../_services";


class RrTxt extends Component {
    constructor(props) {
        super(props);
        this.state = {
            loading: true,
            showDeleteConfirm: false,
            zoneData: {},
            rr: {
                rrGrp: this.props.match.params.zoneNum,
                rrStr: '',
                rrType: this.props.match.params.type,
                comments: '',
                recId: '',

            },
            alert: '',

        };
        this.isComponentMounted = false;
        this.saveRRTxt = this.saveRRTxt.bind(this);
        this.updateRRObj = this.updateRRObj.bind(this);
        this.deleteRR = this.deleteRR.bind(this);
        this.getDeleteConfirmDialog = this.getDeleteConfirmDialog.bind(this);

        if ((this.props.location.state === undefined || !this.props.location.state.showAlerts) && !_.isEmpty(this.props.alert)) {
            this.props.alertClear()
        }

    }


    saveRRTxt(e) {
        e.preventDefault()

        if (this.isComponentMounted) {
            // this.setState({loading: true})
            this.setState({loading: !this.props.isEmptyForm})//changed it so that it supports loading on create page

        }
        const {rrName, rrTtl, rrType, rrData, comments, rrGrp, ...rr} = this.state.rr
        const resourceRecord = {
            rrStr: rrName + (rrTtl ? (" " + rrTtl) : "") + " IN " + rrType.toUpperCase() + " " + (rrData ? rrData : ""),
            rrType: rrType.toUpperCase(),
            rrGrp,
            comments
        }
        if (this.props.isEmptyForm && this.props.isEditable) {
            //rrGrp:zoneNum,rrStr:rrName+rrData comes from user,rrType:type of RR from url,comments:from user
            this.props.create(resourceRecord);
        } else {
            this.props.update(this.props.match.params.id, resourceRecord, false);
        }

    }

    async componentDidMount() {
        this.isComponentMounted = true;
        const res = await zoneService.getZoneById(this.props.match.params.zoneNum)
        if (this.isComponentMounted) {
            this.setState({loading: !this.props.isEmptyForm, zoneData: res.zone});
        }
        if (!this.props.isEmptyForm && this.isComponentMounted) {
            const rr = await resourceRecordService.getByRecordId(this.props.match.params.id);
            if (!_.isEmpty(rr) && this.isComponentMounted) {
                this.setState({loading: false, rr: rr});

            } else {
                this.props.alertClear()
                this.props.history.push(`/dns/zones/details/${this.props.match.params.zoneNum}/rr/${this.props.match.params.type}`);
            }
        }
    }

    deleteRR() {
        if (this.isComponentMounted) {
            this.setState({showDeleteConfirm: false, loading: true})
        }
        this.props.delete(this.props.match.params.id);
    }

    componentWillUnmount() {
        this.isComponentMounted = false;
    }


    updateRRObj(e) {
        let {name, value} = e.target;
        const {rr} = this.state;
        if (this.isComponentMounted) {
            this.setState({rr: {...rr, [name]: value}})
        }
    }


    getRRPageButtons() {
        let pageElements = {
            pageTitle: '',
            pageButtons: [],
        }
        if (this.props.isEditable && this.props.isEmptyForm) {
            pageElements.pageTitle = "DNS Text Information (TXT) Record Creation"
            pageElements.pageButtons.push(<Button className={"dns-blue-button text-white mr-2"}
                //onClick={this.saveRRTxt}
                                                  type={"submit"}//using the submit form instead of click button
                                                  key={"insert"}>Insert</Button>)
            pageElements.pageButtons.push(<Button className={"dns-blue-button text-white mr-2 col-md-1"}
                                                  onClick={() => {
                                                      this.props.alertClear();
                                                      this.props.history.push(`/dns/zones/details/${this.props.match.params.zoneNum}/rr/${this.props.match.params.type}`)
                                                  }}
                                                  key={"cancel_update"}>Cancel</Button>)


        } else if (this.props.isEditable) {
            pageElements.pageTitle = "DNS TXT Record Update"
            pageElements.pageButtons.push(<Button className={"dns-blue-button text-white mr-2 col-md-1"}
                //onClick={this.saveRRTxt}
                                                  type={"submit"}
                                                  key={"update"}>Update</Button>)
            pageElements.pageButtons.push(<Button className={"dns-blue-button text-white mr-2 col-md-1"}
                                                  onClick={() => this.props.history.goBack()}
                                                  key={"cancel_update"}>Cancel</Button>)


        } else {
            pageElements.pageTitle = "DNS TXT Record Details"
            pageElements.pageButtons.push(<Button className={"dns-blue-button text-white mt-2 mr-4 mb-4"}
                                                  onClick={() => {
                                                      this.props.alertClear();
                                                      this.props.history.push(`/dns/zones/details/${this.props.match.params.zoneNum}/rr/${this.props.match.params.type}/edit/${this.props.match.params.id}`)
                                                  }} key={"edit"}>Go To Update</Button>)
            pageElements.pageButtons.push(<Button className={"dns-blue-button text-white mt-2 mr-4 mb-4"}
                                                  onClick={() => {
                                                      this.props.alertClear();
                                                      this.setState({showDeleteConfirm: true})
                                                  }} key={"delete"}>Delete</Button>)
            pageElements.pageButtons.push(<Button className={"dns-blue-button text-white mt-2 mb-4"}
                                                  onClick={() => {
                                                      this.props.alertClear();
                                                      this.props.history.push(`/dns/zones/details/${this.props.match.params.zoneNum}/rr/${this.props.match.params.type}`)
                                                  }}
                                                  key={"list_users"}>List Txt Records</Button>)


        }

        return pageElements;
    }

    getDeleteConfirmDialog() {
        return !this.props.isEditable && <Dialog
            onClose={(event, reason) => {
                if (reason === 'backdropClick' || reason === 'escapeKeyDown') {
                    return false;
                }
            }}
            maxWidth="xs"
            aria-labelledby="confirmation-dialog-title"
            open={this.state.showDeleteConfirm}
        >
            <DialogTitle id="confirmation_dialog_title">Are you sure you want to delete this
                record?</DialogTitle>
            <DialogActions>
                <Button autoFocus onClick={this.deleteRR} className={"dns-blue-button text-white"}>
                    Delete
                </Button>
                <Button onClick={() => this.setState({showDeleteConfirm: false})}
                        className={"dns-blue-button text-white"}>
                    Cancel
                </Button>
            </DialogActions>
        </Dialog>
    }


    getRRTXTForm() {
        const {rr, zoneData} = this.state
        let {pageButtons} = this.getRRPageButtons();

        return <form onSubmit={this.saveRRTxt}>
            <Form.Group as={Row} className={"align-items-center"}>
                {(this.props.isEmptyForm || !this.props.isEditable) && <><Form.Label column sm="2"
                                                                                     className={"font-weight-bold"}>
                    Zone ID
                </Form.Label>
                    <Col sm="4">
                        {rr.rrGrp}
                    </Col></>}
                {!this.props.isEmptyForm && !this.props.isEditable && <><Form.Label column sm="2"
                                                                                    className={"font-weight-bold"}>
                    Zone Name
                </Form.Label>
                    <Col sm="4">
                        {zoneData.zoneName}
                    </Col></>}
            </Form.Group>

            <Form.Group as={Row} className={"align-items-center"}>
                {!this.props.isEmptyForm &&
                <> <Form.Label column sm="2" className={"font-weight-bold"}>
                    Record ID
                </Form.Label>
                    <Col sm="4">
                        {rr.recId}
                    </Col></>}
                <Form.Label column sm="2" className={"font-weight-bold"}>
                    {this.props.isEditable ? "*" : ""}Resource Record Name
                </Form.Label>
                <Col sm="4">
                    {this.props.isEditable ?
                        <Form.Control name={"rrName"}
                                      onChange={this.updateRRObj}
                                      className={"w-50 d-inline"}
                                      defaultValue={rr.rrName ? rr.rrName : ''}
                                      required={true}/> : rr.rrName}
                    <span className={"d-inline"}>  {zoneData.zoneName}</span>
                </Col>

            </Form.Group>

            <Form.Group as={Row} className={"align-items-center"}>
                {!this.props.isEmptyForm && !this.props.isEditable && <> <Form.Label column sm="2"
                                                                                     className={"font-weight-bold"}>
                    Create Time
                </Form.Label>
                    <Col sm="4">
                        {rr.createTime}
                    </Col></>}


                {!this.props.isEmptyForm && !this.props.isEditable && <>  <Form.Label column sm="2"
                                                                                      className={"font-weight-bold"}>
                    Last Modified
                </Form.Label>
                    <Col sm="4">
                        {rr.modTime}
                    </Col></>}


            </Form.Group>
            <Form.Group as={Row} className={"align-items-center"}>
                {!this.props.isEmptyForm && !this.props.isEditable && <><Form.Label column sm="2"
                                                                                    className={"font-weight-bold"}>
                    Modified By
                </Form.Label>
                    <Col sm="4">
                        {rr.modBy}
                    </Col></>}
            </Form.Group>
            <Form.Group as={Row} className={"align-items-center"}>
                <Form.Label column sm="2" className={"font-weight-bold"}>
                    {this.props.isEditable ? "*" : ""}Text
                </Form.Label>
                <Col sm="4 text-break">
                    {this.props.isEditable ?
                        <Form.Control name={"rrData"}
                                      onChange={this.updateRRObj}
                                      defaultValue={rr.rrData ? rr.rrData : ''}
                                      required={true}/> : rr.rrData}
                </Col>
            </Form.Group>
            <Form.Group as={Row} className={"align-items-center"}>
                <Form.Label column sm="2" className={"font-weight-bold"}>
                    Time To Live
                </Form.Label>
                <Col sm="4">
                    {this.props.isEditable ?
                        <Form.Control name={"rrTtl"}
                                      onChange={this.updateRRObj}
                                      defaultValue={rr.rrTtl ? rr.rrTtl : ''}/> : rr.rrTtl}
                </Col>
                <Form.Label column sm="2" className={"font-weight-bold"}>
                    Comment
                </Form.Label>
                <Col sm="4">
                    {this.props.isEditable ?
                        <Form.Control name={"comments"}
                                      onChange={this.updateRRObj}
                                      defaultValue={rr.comments ? rr.comments : ''}/> : rr.comments}
                </Col>
            </Form.Group>


            <div className={"text-center"}>
                {pageButtons.map(buttonComp => buttonComp)}
            </div>

        </form>


    }


    componentWillUnmount() {
        this.isComponentMounted = false;
    }

    componentDidUpdate(prevProps, prevState, snapshot) {
        if(this.state.loading !== prevState.loading){
            this.setState({loading:false})

        }
        console.log(prevState)
    }

    render() {
        let {pageTitle} = this.getRRPageButtons();
        if (this.state.loading) {
            return <div>Loading....</div>
        }
        return (
            <>
                {this.getDeleteConfirmDialog()}
                <Backdrop className={"page-loading"} style={{'zIndex': '10000', 'color': '#fff'}}
                          open={this.state.loading}>
                    <CircularProgress color="inherit"/>
                </Backdrop>
                <div>
                    <Helmet>
                        <title>DNS Admin | DNS TXT Details Page</title>
                    </Helmet>
                    <Container maxWidth={false} className={"px-2"}>
                        <Card>
                            <CardContent>
                                <div className={'mt-3 ml-3 mr-3 mb-3'}>

                                    <h5 className="font-weight-bold  text-capitalize text-left pt-1 pl-2">{pageTitle}</h5>

                                    <div className={"pb-2"}>
                                        {this.props.alert.message && <Alert
                                            severity={this.props.alert.type}>{this.props.alert.message}</Alert>}</div>
                                    {this.getRRTXTForm()}
                                </div>
                            </CardContent>
                        </Card>

                    </Container>
                </div>
            </>
        )
    }

}

RrTxt.defaultProps = {
    isEditable: false,
};
RrTxt.propTypes = {
    isEditable: PropTypes.bool,
    isEmptyForm: PropTypes.bool
};
RrTxt.defaultProps = {
    isEditable: false,
    isEmptyForm: false
}

function mapState(state) {
    const {alert} = state
    return {alert}
    /* const {loading, saved, deleted, deleting} = state.rrs
     return {alert, loading, saved, deleted, deleting}*/
}

const actionCreators = {
    create: resourceRecordActions.create,
    delete: resourceRecordActions.delete,
    update: resourceRecordActions.update,
    alertClear: alertActions.clear,
};


const connectedRrTxt = withRouter(connect(mapState, actionCreators)(RrTxt));
export {connectedRrTxt as RrTxt};

