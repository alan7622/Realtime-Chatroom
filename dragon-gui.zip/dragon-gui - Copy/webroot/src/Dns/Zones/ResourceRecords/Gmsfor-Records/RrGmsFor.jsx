import React, {Component} from "react";
import Container from "@material-ui/core/Container";
import {withRouter} from "react-router-dom";
import {
    Backdrop,
    Button,
    Card,
    CardContent,
    CircularProgress,
    Dialog,
    DialogActions,
    DialogTitle,
    Paper
} from "@material-ui/core";
import PropTypes from "prop-types";
import {alertActions} from "../../../../_actions";
import Form from 'react-bootstrap/Form'
import {Col} from "react-bootstrap";
import {Row} from "react-bootstrap";
import {Alert} from '@material-ui/lab';
import {connect} from "react-redux";
import {Helmet} from "react-helmet";
import {resourceRecordService} from "../../../../_services/resourceRecord.service";
import {resourceRecordActions} from "../../../../_actions/resourceRecords.actions";
import _ from "lodash";
import {zoneService} from "../../../../_services";


class RrGmsFor extends Component {
    constructor(props) {
        super(props);
        this.state = {
            loading: false,
            //saving: false,
            showDeleteConfirm: false,
            zoneData: {},
            rr: {
                rrGrp: this.props.match.params.zoneNum,
                rrStr: 'GEN',
                rrType: this.props.match.params.type,
                comments: '',
                recId: '',
                rrJson:{},


            },
            alert: '',

        };
        this.isComponentMounted = false;
        this.saveGmsFor = this.saveGmsFor.bind(this);
        this.updateRRObj = this.updateRRObj.bind(this);
        this.deleteRR = this.deleteRR.bind(this);
        this.getDeleteConfirmDialog = this.getDeleteConfirmDialog.bind(this);


        if ((this.props.location.state === undefined || !this.props.location.state.showAlerts) && !_.isEmpty(this.props.alert)) {
            this.props.alertClear()
        }

    }


    saveGmsFor() {
        this.setState({loading: true})
        let res = null
        console.log(this.state.rr,"this.state.rr")

        if (this.props.isEmptyForm && this.props.isEditable) {
            this.props.create(this.state.rr);
        } else {
            let rrDetails = {}
            for (var key in this.state.rr) {
                console.log(this.state.rr,"this.state.rr")
                if (['rrType', 'rrStr ', 'comments', 'json'].includes(key)) {
                    if (key == 'rrType') {
                        rrDetails[key] = this.state.rr[key].toUpperCase()
                    } else {
                        rrDetails[key] = this.state.rr[key]
                    }
                }
            }
            rrDetails.rrJson = `${this.state.rhs0}-${this.state.rhs1}-${this.state.rhs2}-${this.state.rhs3}`
            this.props.update(this.props.match.params.id, rrDetails);
        }

    }

    async componentDidMount() {
        if (!this.props.isEmptyForm) {
            this.isComponentMounted = true;
            const zoneData = await zoneService.getZoneById(this.props.match.params.zoneNum)

            this.setState({zoneData: zoneData});
            if (this.isComponentMounted) {
                const rr = await resourceRecordService.getByRecordId(this.props.match.params.id);
                if (!_.isEmpty(rr)) {
                    const rrJson = JSON.parse(rr.rrJson)
                    const rhs = rrJson.rhs.split("-")
                    rr.rhs0 = rhs[0]
                    rr.rhs1 = rhs[1]
                    rr.rhs2 = rhs[2]
                    rr.rhs3 = rhs[3]
                    this.setState({loading: false, rr: rr});

                } else {
                    this.props.alertClear()
                    this.props.history.push(`/dns/zones/details/${this.props.match.params.zoneNum}/rr/${this.props.match.params.type}`);
                }
            }
        }
    }

    deleteRR() {
        this.setState({showDeleteConfirm: false, loading: true})
        this.props.delete(this.props.match.params.id);
    }


    componentWillUnmount() {
        this.isComponentMounted = false;
    }


    updateRRObj(e) {
        let {name, value} = e.target;
        const {rr} = this.state;
        const nameSplits = name.split('.')
        if(nameSplits.length > 1){
            rr[nameSplits[0]][nameSplits[1]] = value
        } else{
            rr[name]= value
        }

        this.setState({rr})
    }


    getRRPageButtons() {
        let pageElements = {
            pageTitle: '',
            pageButtons: [],
        }
        if (this.props.isEditable && this.props.isEmptyForm) {
            pageElements.pageTitle = "DNS Host Information (GMSFor) Record Creation"
            pageElements.pageButtons.push(<Button className={"dns-blue-button text-white mr-2"}
                                                  onClick={this.saveGmsFor}
                                                  key={"insert"}>Insert</Button>)
            pageElements.pageButtons.push(<Button className={"dns-blue-button text-white mr-2 col-md-1"}
                                                  onClick={() => this.props.history.push(`/dns/zones/details/${this.props.match.params.zoneNum}/rr/${this.props.match.params.type}`)}
                                                  key={"cancel_update"}>Cancel</Button>)


        } else if (this.props.isEditable) {
            pageElements.pageTitle = "DNS GMSFor Record Update"
            pageElements.pageButtons.push(<Button className={"dns-blue-button text-white mr-2 col-md-1"}
                                                  onClick={this.saveGmsFor}
                                                  key={"update"}>Update</Button>)
            pageElements.pageButtons.push(<Button className={"dns-blue-button text-white mr-2 col-md-1"}
                                                  onClick={() => this.props.history.goBack()}
                                                  key={"cancel_update"}>Cancel</Button>)


        } else {
            pageElements.pageTitle = "DNS GMSFor Record Details"
            pageElements.pageButtons.push(<Button className={"dns-blue-button text-white mt-2 mr-4 mb-4"}
                                                  onClick={() => this.props.history.push(`/dns/zones/details/${this.props.match.params.zoneNum}/rr/${this.props.match.params.type}/edit/${this.props.match.params.id}`)}
                                                  key={"edit"}>Go To Update</Button>)
            pageElements.pageButtons.push(<Button className={"dns-blue-button text-white mt-2 mr-4 mb-4"}
                                                  onClick={() => {
                                                      this.setState({showDeleteConfirm: true})
                                                  }} key={"delete"}>Delete</Button>)
            pageElements.pageButtons.push(<Button className={"dns-blue-button text-white mt-2 mb-4"}
                                                  onClick={() => this.props.history.push(`/dns/zones/details/${this.props.match.params.zoneNum}/rr/${this.props.match.params.type}`)}
                                                  key={"list_gmsfor"}>List GMSFor Records</Button>)


        }

        return pageElements;
    }

    getDeleteConfirmDialog() {
        return !this.props.isEditable && <Dialog
            onClose={(event, reason) => {
                if (reason === 'backdropClick' || reason === 'escapeKeyDown') {
                    return false;
                }
            }}
            maxWidth="xs"
            aria-labelledby="confirmation-dialog-title"
            open={this.state.showDeleteConfirm}
        >
            <DialogTitle id="confirmation_dialog_title">Are you sure you want to delete this
                record?</DialogTitle>
            <DialogActions>
                <Button autoFocus onClick={this.deleteRR} className={"dns-blue-button text-white"}>
                    Delete
                </Button>
                <Button onClick={() => this.setState({showDeleteConfirm: false})}
                        className={"dns-blue-button text-white"}>
                    Cancel
                </Button>
            </DialogActions>
        </Dialog>
    }


    getRrGmsForForm() {
        const {rr, zoneData} = this.state
        let {pageButtons} = this.getRRPageButtons();

        return <Form>
            <Form.Group as={Row} className={"align-items-center"}>

                {!this.props.isEmptyForm &&
                <> <Form.Label column sm="2" className={"font-weight-bold"}>
                    Zone ID
                </Form.Label>
                    <Col sm="4">
                        {rr.rrGrp}
                    </Col></>}
                {!this.props.isEmptyForm &&
                <> <Form.Label column sm="2" className={"font-weight-bold"}>
                    Record ID
                </Form.Label>
                    <Col sm="4">
                        {rr.recId}
                    </Col></>}


            </Form.Group>


            <Form.Group as={Row} className={"align-items-center"}>

                <Form.Label column sm="2" className={"font-weight-bold"}>
                    {this.props.isEditable ? "*" : ""}GMSFOR Record Name:
                </Form.Label>

                <Col sm="4">
                    {this.props.isEditable ?
                        <Form.Control name={"rrJson.lhs"}
                                      onChange={this.updateRRObj}
                                      className={"w-50 d-inline"}
                                      defaultValue={rr.rrName ? rr.rrName : ''}/> : rr.rrName}
                    <span className={"d-inline"}> {zoneData.zoneName}</span>
                </Col>

            </Form.Group>

            <Form.Group as={Row} className={"align-items-center"}>
                {!this.props.isEmptyForm && !this.props.isEditable && <> <Form.Label column sm="2"
                                                                                     className={"font-weight-bold"}>
                    Create Time
                </Form.Label>
                    <Col sm="4">
                        {rr.createTime}
                    </Col></>}

            </Form.Group>
            <Form.Group as={Row} className={"align-items-center"}>
                {!this.props.isEmptyForm && !this.props.isEditable && <>  <Form.Label column sm="2"
                                                                                      className={"font-weight-bold"}>
                    Last Modified
                </Form.Label>
                    <Col sm="4">
                        {rr.modTime}
                    </Col></>}

            </Form.Group>
            <Form.Group as={Row} className={"align-items-center"}>
                {!this.props.isEmptyForm && !this.props.isEditable && <><Form.Label column sm="2"
                                                                                    className={"font-weight-bold"}>
                    Modified By
                </Form.Label>
                    <Col sm="4">
                        {rr.modBy}
                    </Col></>}

            </Form.Group>


            <Form.Group as={Row} className={"align-items-center"}>
                <Form.Label column sm="2" className={"font-weight-bold"}>
                    {this.props.isEditable ? "*" : ""}Network Address
                </Form.Label>
                <Col sm="4">
                    {this.props.isEditable ?
                        <>
                            <Form.Control name={"rrRhs0"} className={"w-25 d-inline-block mr-2"}
                                          onChange={this.updateRRObj}
                                          defaultValue={rr.rhs0 ? rr.rhs0 : ''}/>
                            <Form.Control name={"rrRhs1"} className={"w-25 d-inline-block mr-2"}
                                          onChange={this.updateRRObj}
                                          defaultValue={rr.rhs1 ? rr.rhs1 : ''}/>
                            <Form.Control name={"rrRhs2"} className={"w-25 d-inline-block mr-2"}
                                          onChange={this.updateRRObj}
                                          defaultValue={rr.rhs2 ? rr.rhs2 : ''}/>
                        </>
                        : `${rr.rhs0}-${rr.rhs1}-${rr.rhs2}-${rr.rhs3}`}
                    {}
                    <span className={"d-inline"}> {".$"}</span>

                </Col>
                {this.props.isEmptyForm && this.props.isEditable && <><Form.Label column sm="2"
                                                                                  className={"font-weight-bold"}>
                    Start
                </Form.Label>
                    <Col sm="2">
                        {this.props.isEditable ?
                            <Form.Control name={"start"}
                                          className={"w-25"}
                                          onChange={this.updateRRObj}
                                          defaultValue={rr.lstart ? rr.lstart : ''}/> : rr.lstart}

                        <span>(valid range is 0 - 255) </span>
                    </Col>
                  </>}


            </Form.Group>

            <Form.Group as={Row} className={"align-items-center"}>
                {this.props.isEmptyForm && this.props.isEditable && <><Form.Label column sm="2"
                                                                                  className={"font-weight-bold"}>
                    Stop
                </Form.Label>
                    <Col sm="4">
                        {this.props.isEditable ?
                            <Form.Control name={"stop"}
                                          className={"w-25"}
                                          onChange={this.updateRRObj}
                                          defaultValue={rr.lstop ? rr.lstop : ''}/> : rr.lstop}

                    </Col></>}
                {(this.props.isEmptyForm || !this.props.isEditable) && <><Form.Label column sm="2"
                                                                                     className={"font-weight-bold"}>
                    Step </Form.Label>


                    <Col sm="4">
                        {this.props.isEditable ?
                            <Form.Control name={"step"}
                                          onChange={this.updateRRObj}
                                          className={"w-25"}
                                          defaultValue={rr.lstep ? rr.lstep : ''}/> : rr.lstep}

                    </Col></>}

            </Form.Group>


            <Form.Group as={Row} className={"align-items-center"}>
                {!this.props.isEmptyForm && !this.props.isEditable && <><Form.Label column sm="2"
                                                                                    className={"font-weight-bold"}>
                    Width
                </Form.Label>
                    <Col sm="4">
                        {this.props.isEditable ?
                            <Form.Control name={"width"}
                                          onChange={this.updateRRObj}
                                          className={"w-25"}
                                          defaultValue={rr.rwidth ? rr.rwidth : ''}/> : rr.rwidth}

                    </Col></>}


                {(this.props.isEmptyForm || !this.props.isEditable) && <><Form.Label column sm="2"
                                                                                     className={"font-weight-bold"}>
                    Offset </Form.Label>
                    <Col sm="4">
                        {this.props.isEditable ?
                            <Form.Control name={"offset"}
                                          onChange={this.updateRRObj}
                                          className={"w-25"}
                                          defaultValue={rr.loffset ? rr.loffset : ''}/> : rr.loffset}
                    </Col></>}
            </Form.Group>


            <Form.Group as={Row} className={"align-items-center"}>
                <Form.Label column sm="2" className={"font-weight-bold w-25"}>
                    Radix
                </Form.Label>
                <Col sm="4">
                    {this.props.isEditable ? <Form.Control as="select" name={"radix"}
                                                           onChange={this.updateRRObj}
                                                           value={rr.rtype}>
                            <option value={"d"}>d</option>
                            <option value={"X"}>X</option>
                            <option value={"o"}>o</option>
                            <option value={"x"}>x</option>
                        </Form.Control>
                        : rr.rtype}                    </Col>

                <Form.Label column sm="2" className={"font-weight-bold"}>
                    Collision </Form.Label>
                <Col sm="4">
                    {this.props.isEditable ? <Form.Control as="select" name={"radix"}
                                                           onChange={this.updateRRObj}
                                                           value={rr.rtype}>
                            <option value={"y"}>Y</option>
                            <option value={"n"}>N</option>
                        </Form.Control>
                        : rr.rtype}                    </Col>
            </Form.Group>


            <Form.Group as={Row} className={"align-items-center"}>
                <Form.Label column sm="2" className={"font-weight-bold"}>
                    Comment
                </Form.Label>
                <Col sm="4">
                    {this.props.isEditable ?
                        <Form.Control name={"comments"}
                                      onChange={this.updateRRObj}
                                      defaultValue={rr.comments ? rr.comments : ''}/> : rr.comments}
                </Col>
                <Form.Label column sm="2" className={"font-weight-bold"}>
                    Time To Live
                </Form.Label>
                <Col sm="4">
                    {this.props.isEditable ?
                        <Form.Control name={"rrTtl"}
                            //onChange={this.updateUserObj}
                                      defaultValue={rr.rrTtl ? rr.rrTtl : ''}/> : rr.rrTtl}
                </Col>
            </Form.Group>


            <div className={"text-center"}>
                {pageButtons.map(buttonComp => buttonComp)}
            </div>


            <h6 className={"font-weight-bold"}>How the GMSFOR Record Works</h6>
            <p>
                The <b>GMSFOR</b> record generates between 2 and 256 DNS <b>A</b> records. The <b>$</b> character in the
                record is replaced
                by an iterator, which is controlled by the <b>start</b>, <b>stop</b>, and <b>step</b> fields. These
                fields determine how many <b>A</b> records are created.
            </p>
            <h6 className={"font-weight-bold"}>NOTE:</h6> <p>The automatic generation of A records from GMSFOR records
            currently only works for IPv4 records.
        </p>
            <p>The <b>width</b>, <b>offset</b>, and <b>radix</b> fields are usually left at their default values; in
                more complex cases, they
                can be used to alter the names of the DNS <b>A</b> records.
            </p>
            <h6 className={"font-weight-bold"}> Examples</h6>
            <p><b>Record Name </b>= dallas<b>$</b>tx.<b>example.com</b>, <b>Network Address</b> = 12.13.14.$, <b>start,stop,
                step</b> = 20, 50, 1. The
                iterator will move from 20 to 50 in increments of 1 and generate 31 <b>A</b> records:
            </p>
            <p>dallas<b>20</b>tx.example.com. IN A 12.13.14.<b>20</b><br/>
                dallas<b>21</b>tx.example.com. IN A 12.13.14.<b>21</b><br/>
                ...<br/>
                dallas<b>50</b>tx.example.com. IN A 12.13.14.<b>50</b><br/>
            </p>
            <p>
                Changing the <b>step</b> field from 1 to 2 causes the iterator to advance in increments of 2, and
                generates 16 <b>A</b> records:<br/>
                <p></p>
                dallas<b>20</b>tx.example.com. IN A 12.13.14.<b>20</b><br/>
                dallas<b>22</b>tx.example.com. IN A 12.13.14.<b>22</b><br/>
                ...<br/>
                dallas<b>50</b>tx.example.com. IN A 12.13.14.<b>50</b><br/>
            </p>
            <p>
                Note: DRAGON will return an error if you try to create 2 <b>GMFOR</b> records in the same zone that have
                the
                same <b>Record Name</b> and whose IP addresses would overlap. When the <b>Collision</b> field is set to
                Y, DRAGON will
                return an error if the IP addresses of 2 records overlap, even if the <b>Record Name</b> fields are
                different.</p>
            <p></p>
            <p>The <b>width</b>, <b>offset</b>, and <b>radix</b> fields can be used to alter the name, but not the IP
                address, of the DNS <b>A</b> records.</p>
            <p></p>
            <p> Changing the <b>width</b> field from 1 to 4 will cause the iterator to be padded with leading zeros so
                that the
                field is 4 characters long:<br/>

                dallas<b>0020</b>tx.example.com. IN A 12.13.14.<b>20</b><br/>
                dallas<b>0021</b>tx.example.com. IN A 12.13.14.<b>21</b><br/>
                ...<br/>
                dallas<b>0050</b>tx.example.com. IN A 12.13.14.<b>50</b><br/>
                <p></p>
                Changing the <b>offset</b> field from 0 to 40 will add 40 to the value of the iterator:<br/>
                <p></p>
                dallas<b>60</b>tx.example.com. IN A 12.13.14.<b>20</b><br/>
                dallas<b>61</b>tx.example.com. IN A 12.13.14.<b>21</b><br/>
                ...<br/>
                dallas<b>90</b>tx.example.com. IN A 12.13.14.<b>50</b><br/>
                <p></p>
                Changing the <b>radix</b> field from <b>d</b> (decimal) to <b>X</b> (hexadecimal) will cause the
                iterator to be printed in
                hexadecimal notation:
                <p></p>
                dallas<b>14</b>tx.example.com. IN A 12.13.14.<b>20</b><br/>
                dallas<b>15</b>tx.example.com. IN A 12.13.14.<b>21</b><br/>
                ...<br/>
                dallas<b>2E</b>tx.example.com. IN A 12.13.14.<b>46</b><br/>
                dallas<b>2F</b>tx.example.com. IN A 12.13.14.<b>47</b><br/>
                dallas<b>30</b>tx.example.com. IN A 12.13.14.<b>48</b><br/>
                dallas<b>31</b>tx.example.com. IN A 12.13.14.<b>49</b><br/>
                dallas<b>32</b>tx.example.com. IN A 12.13.14.<b>50</b></p>

        </Form>
    }


    componentWillUnmount() {
        this.isComponentMounted = false;
    }

    render() {
        let {pageTitle} = this.getRRPageButtons();
        return (
            <>
                {this.getDeleteConfirmDialog()}
                <Backdrop className={"page-loading"} style={{'zIndex': '10000', 'color': '#fff'}}
                          open={this.state.loading && this.props.loading}>
                    <CircularProgress color="inherit"/>
                </Backdrop>
                <div>
                    <Helmet>
                        <title>DNS Admin | DNS GMSFor Details Page</title>
                    </Helmet>
                    <Container maxWidth={false} className={"px-2"}>
                        <Card>
                            <CardContent>
                                <div className={'mt-3 ml-3 mr-3 mb-3'}>
                                <h5 className="font-weight-bold  text-capitalize text-left pt-1 pl-2">{pageTitle}</h5>

                                <div className={"pb-2"}>
                                    {this.props.alert.message && <Alert
                                        severity={this.props.alert.type}>{this.props.alert.message}</Alert>}</div>
                                {this.getRrGmsForForm()}
                                </div>
                            </CardContent>
                        </Card>
                    </Container>
                </div>
            </>
        )
    }

}

RrGmsFor.defaultProps = {
    isEditable: false,
};
RrGmsFor.propTypes = {
    isEditable: PropTypes.bool,
    isEmptyForm: PropTypes.bool
};
RrGmsFor.defaultProps = {
    isEditable: false,
    isEmptyForm: false
}

function mapState(state) {
    const {alert} = state
    const {loading, saved, deleted, deleting} = state.rrs
    return {alert, loading, saved, deleted, deleting}
}

const actionCreators = {
    create: resourceRecordActions.create,
    delete: resourceRecordActions.delete,
    update: resourceRecordActions.update,
    alertClear: alertActions.clear,
};


const connectedRrGmsFor = withRouter(connect(mapState, actionCreators)(RrGmsFor));
export {connectedRrGmsFor as RrGmsFor};

