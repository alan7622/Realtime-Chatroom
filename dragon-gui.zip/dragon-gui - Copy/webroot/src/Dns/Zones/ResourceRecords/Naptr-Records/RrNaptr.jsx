import React, {Component} from "react";
import Container from "@material-ui/core/Container";
import {withRouter} from "react-router-dom";
import {
    Backdrop,
    Button,
    Card,
    CardContent,
    CircularProgress,
    Dialog,
    DialogActions,
    DialogTitle,
} from "@material-ui/core";
import PropTypes from "prop-types";
import {alertActions, zoneActions} from "../../../../_actions";
import Form from 'react-bootstrap/Form'
import {Col} from "react-bootstrap";
import {Row} from "react-bootstrap";
import {Alert} from '@material-ui/lab';
import {connect} from "react-redux";
import {Helmet} from "react-helmet";
import {resourceRecordService} from "../../../../_services/resourceRecord.service";
import {resourceRecordActions} from "../../../../_actions/resourceRecords.actions";
import _ from "lodash";
import {zoneService} from "../../../../_services";
import {replaceTemplateWithData, templatizedStringParser} from "../../../../_helpers";
import {isAuthorized} from "../../../../_components";


class RrNaptr extends Component {
    constructor(props) {
        super(props);
        this.state = {
            loading: true,
            //saving: false,
            showDeleteConfirm: false,
            zoneData: {},
            rr: {
                rrGrp: this.props.match.params.zoneNum,
                rrStr: '',
                pref: '',
                order: '',
                flags: '',
                replace: '',
                svc: '',
                regexp: '',
                rrType: this.props.match.params.type,
                comments: '',
                recId: '',

            },

            alert: '',

        };
        this.isComponentMounted = false;
        this.saveNaptr = this.saveNaptr.bind(this);
        this.updateRRObj = this.updateRRObj.bind(this);
        this.deleteRR = this.deleteRR.bind(this);
        this.getDeleteConfirmDialog = this.getDeleteConfirmDialog.bind(this);

        if ((this.props.location.state === undefined || !this.props.location.state.showAlerts) && !_.isEmpty(this.props.alert)) {
            this.props.alertClear()
        }

    }

    tmpl1 = '[rrName] IN [rrType] [order] [pref] [flags] [svc] [regexp] [replace]'
    tmpl = '[rrName] IN [rrType] [order] [pref] "[flags]" "[svc]" "[regexp]" [replace]'


    saveNaptr(e) {
        e.preventDefault()
        if (this.isComponentMounted) {
            this.setState({loading: true})
        }
        let res = this.state.rr
        if (_.isEmpty(this.state.rr.replace)) {
            res.replace = '.'

        }
        res.flags = res.flags.replace(/^"(.*)"$/, '$1');
        res.svc = res.svc?.replace(/^"(.*)"$/, '$1');
        res.regexp = res.regexp.replace(/^"(.*)"$/, '$1');
        const rrStr = replaceTemplateWithData(this.tmpl, res)
        console.log(rrStr, "rrstr")
        let resourceRecordNAPTR = {
            rrStr: rrStr,
            rrType: this.state.rr.rrType.toUpperCase(),
            rrGrp: this.state.rr.rrGrp,
            comments: this.state.rr.comments
        }

        //  resourceRecordNAPTR[`comments`] = tmpl.hasOwnProperty('comments') ? tmpl.comments : ''
        //resourceRecordNAPTR[`svc`] = tmpl.hasOwnProperty('svc') ? tmpl.svc : ''


        if (this.props.isEmptyForm && this.props.isEditable) {
            //console.log(rrStr, "rrstr")
            console.log(resourceRecordNAPTR, "resourceRecordNAPTR")

            /*    if(this.state.rr.replace !== null){

                }else{
                    this.props.create(resourceRecordNAPTR);

                }*/

            this.props.create(resourceRecordNAPTR);

        } else {
            console.log(resourceRecordNAPTR, "resourceRecordNAPTR update")


            this.props.update(this.props.match.params.id, resourceRecordNAPTR, false);
        }

    }

    async componentDidMount() {
        this.isComponentMounted = true;
        /*  const res = await zoneService.getZoneById(this.props.match.params.zoneNum)
          if (this.isComponentMounted) {
              this.setState({zoneData: res.zone});
          }*/
        this.props.getZoneById(this.props.match.params.zoneNum)

        if (!this.props.isEmptyForm && this.isComponentMounted) {
            const rr = await resourceRecordService.getByRecordId(this.props.match.params.id);
            console.log(rr, "rr")

            if (!_.isEmpty(rr) && this.isComponentMounted) {
                let rrStr = templatizedStringParser(this.tmpl1, rr.rrStr.replaceAll(/\"|'/g, ''))
                console.log(rrStr, "rrstr")

                this.setState({loading: false, rr: {...rr, ...rrStr}});


            }

        }
    }


    componentDidUpdate(prevProps, prevState, snapshot) {
        if (((this.state.loading && this.props.zone) || !_.isEqual(prevProps.zone, this.props.zone))) {

            this.setState({
                zoneData: _.omit(this.props.zone, ['soaTemplate']),
                loading: false
            }, () => {

                if (prevProps.zone?.zoneStatus != this.props.zone?.zoneStatus) {
                    this.props.updateMenu();
                }
            })
        }
    }


    deleteRR() {
        this.setState({showDeleteConfirm: false, loading: true})
        this.props.delete(this.props.match.params.id);
    }


    componentWillUnmount() {
        this.isComponentMounted = false;
    }


    updateRRObj(e) {
        if (e.keyCode === 8 && e.target.selectionStart === 0 && e.target.selectionEnd === e.target.value.length) {
            e.preventDefault(); // Prevent default backspace behavior
            e.target.value = ""; // Clear the input value
        }
        console.log("onchange test")

        let {name, value} = e.target;
        const {rr} = this.state;

        this.setState({rr: {...rr, [name]: value}})
    }


    getRRPageButtons() {
        let pageElements = {
            pageTitle: '',
            pageButtons: [],
        }
        if (this.props.isEditable && this.props.isEmptyForm) {
            pageElements.pageTitle = "DNS Host Information (NAPTR) Record Creation"
            pageElements.pageButtons.push(<Button className={"dns-blue-button text-white mr-2"}
                //onClick={this.saveNaptr}
                                                  type={"submit"}
                                                  key={"insert"}>Insert</Button>)
            pageElements.pageButtons.push(<Button className={"dns-blue-button text-white mr-2 col-md-1"}
                                                  onClick={() => this.props.history.push(`/dns/zones/details/${this.props.match.params.zoneNum}/rr/${this.props.match.params.type}`)}
                                                  key={"cancel_update"}>Cancel</Button>)


        } else if (this.props.isEditable) {
            pageElements.pageTitle = "DNS NAPTR Record Update"
            pageElements.pageButtons.push(<Button className={"dns-blue-button text-white mr-2 col-md-1"}
                //onClick={this.saveNaptr}
                                                  type={"submit"}
                                                  key={"update"}>Update</Button>)
            pageElements.pageButtons.push(<Button className={"dns-blue-button text-white mr-2 col-md-1"}
                                                  onClick={() => this.props.history.goBack()}
                                                  key={"cancel_update"}>Cancel</Button>)


        } else {
            if (isAuthorized('ru')) {

                pageElements.pageTitle = "DNS NAPTR Record Details"
                pageElements.pageButtons.push(<Button className={"dns-blue-button text-white mt-2 mr-4 mb-4"}
                                                      onClick={() => this.props.history.push(`/dns/zones/details/${this.props.match.params.zoneNum}/rr/${this.props.match.params.type}/edit/${this.props.match.params.id}`)}
                                                      key={"edit"}>Go To Update</Button>)
            }
            if (isAuthorized('rd')) {

                pageElements.pageButtons.push(<Button className={"dns-blue-button text-white mt-2 mr-4 mb-4"}
                                                      onClick={() => {
                                                          this.setState({showDeleteConfirm: true})
                                                      }} key={"delete"}>Delete</Button>)
            }
            pageElements.pageButtons.push(<Button className={"dns-blue-button text-white mt-2 mb-4"}
                                                  onClick={() => this.props.history.push(`/dns/zones/details/${this.props.match.params.zoneNum}/rr/${this.props.match.params.type}`)}
                                                  key={"naptr"}>List NAPTR Records</Button>)


        }

        return pageElements;
    }

    getDeleteConfirmDialog() {
        return !this.props.isEditable && <Dialog
            onClose={(event, reason) => {
                if (reason === 'backdropClick' || reason === 'escapeKeyDown') {
                    return false;
                }
            }}
            maxWidth="xs"
            aria-labelledby="confirmation-dialog-title"
            open={this.state.showDeleteConfirm}
        >
            <DialogTitle id="confirmation_dialog_title">Are you sure you want to delete this
                record?</DialogTitle>
            <DialogActions>
                <Button autoFocus onClick={this.deleteRR} className={"dns-blue-button text-white"}>
                    Delete
                </Button>
                <Button onClick={() => this.setState({showDeleteConfirm: false})}
                        className={"dns-blue-button text-white"}>
                    Cancel
                </Button>
            </DialogActions>
        </Dialog>
    }


    getRrNaptrForm() {
        const {rr, zoneData} = this.state
        console.log(this.state.rr, "RR")
        let {pageButtons} = this.getRRPageButtons();
        return <form onSubmit={this.saveNaptr}>
            <Form.Group as={Row} className={"align-items-center"}>
                {(this.props.isEmptyForm || !this.props.isEditable) && <><Form.Label column sm="2"
                                                                                     className={"font-weight-bold"}>
                    Zone ID
                </Form.Label>
                    <Col sm="2">
                        {rr.rrGrp}
                    </Col></>}

                <Form.Label column sm="2" className={"font-weight-bold"}>
                    {this.props.isEditable ? "*" : ""}Domain
                </Form.Label>
                <Col sm="2">
                    {this.props.isEditable ?
                        <Form.Control name={"rrName"}
                                      onChange={this.updateRRObj}
                                      onKeyDown={this.updateRRObj}
                                      defaultValue={rr.rrName ? rr.rrName : ''}
                                      required={true}/> : rr.rrName}
                </Col>
                {!this.props.isEmptyForm && !this.props.isEditable && <><Form.Label column sm="2"
                                                                                    className={"font-weight-bold"}>
                    Zone Name
                </Form.Label>
                    <Col sm="2">
                        {zoneData.zoneName}
                    </Col></>}

            </Form.Group>


            <Form.Group as={Row} className={"align-items-center"}>

                <Form.Label column sm="2" className={"font-weight-bold"}>
                    {this.props.isEditable ? "*" : ""}Order
                </Form.Label>
                <Col sm="2">
                    {this.props.isEditable ?
                        <Form.Control name={"order"}
                                      onChange={this.updateRRObj}
                                      onKeyDown={this.updateRRObj}
                                      defaultValue={rr.order ? rr.order : ''}
                                      required={true}
                        /> : rr.order}

                </Col>

                <Form.Label column sm="2" className={"font-weight-bold"}>
                    {this.props.isEditable ? "*" : ""}Pref
                </Form.Label>
                <Col sm="2">
                    {this.props.isEditable ?
                        <Form.Control name={"pref"}
                                      onChange={this.updateRRObj}
                                      onKeyDown={this.updateRRObj}
                                      defaultValue={rr.pref ? rr.pref : ''}
                                      required={true}

                        /> : rr.pref}
                </Col>
                <Form.Label column sm="2" className={"font-weight-bold"}>
                    {this.props.isEditable ? "*" : ""} Flags
                </Form.Label>
                <Col sm="2">
                    {this.props.isEditable ?
                        <Form.Control name={"flags"}
                                      onChange={this.updateRRObj}
                                      onKeyDown={this.updateRRObj}
                                      required={true}
                                      defaultValue={rr.flags ? rr.flags : ''}/> : rr.flags}
                </Col>
            </Form.Group>
            <Form.Group as={Row} className={"align-items-center"}>

                <Form.Label column sm="2" className={"font-weight-bold"}>
                    {this.props.isEditable ? "*" : ""}Service
                </Form.Label>
                <Col sm="2">
                    {this.props.isEditable ?
                        <Form.Control name={"svc"}
                                      onChange={this.updateRRObj}
                                      onKeyDown={this.updateRRObj}
                                      defaultValue={rr.svc ? rr.svc : ''}/> : rr.svc}
                </Col>
                <Form.Label column sm="2" className={"font-weight-bold"}>
                    {this.props.isEditable ? "*" : ""}Regular Expression
                </Form.Label>
                <Col sm="2">
                    {this.props.isEditable ?
                        <Form.Control name={"regexp"}
                                      onChange={this.updateRRObj}
                                      onKeyDown={this.updateRRObj}
                                      defaultValue={rr.regexp ? rr.regexp : ''}/> : rr.regexp}
                </Col>
                <Form.Label column sm="2" className={"font-weight-bold"}>
                    Replacement
                </Form.Label>
                <Col sm="2">
                    {this.props.isEditable ?
                        <Form.Control name={"replace"}
                                      onChange={this.updateRRObj}
                                      onKeyDown={this.updateRRObj}
                                      defaultValue={rr.replace ? rr.replace : ''}/> : rr.replace}
                </Col>
            </Form.Group>


            <Form.Group as={Row} className={"align-items-center"}>

                {!this.props.isEmptyForm && !this.props.isEditable && <><Form.Label column sm="2"
                                                                                    className={"font-weight-bold"}>
                    Modified By
                </Form.Label>
                    <Col sm="2">
                        {rr.modBy}
                    </Col></>}
                {!this.props.isEmptyForm && !this.props.isEditable && <> <Form.Label column sm="2"
                                                                                     className={"font-weight-bold"}>
                    Create Time
                </Form.Label>
                    <Col sm="2">
                        {rr.createTime}
                    </Col></>}

                {!this.props.isEmptyForm && !this.props.isEditable && <>  <Form.Label column sm="2"
                                                                                      className={"font-weight-bold"}>
                    Last Modified
                </Form.Label>
                    <Col sm="2">
                        {rr.modTime}
                    </Col></>}

            </Form.Group>
            <Form.Group as={Row} className={"align-items-center"}>
                <Form.Label column sm="2" className={"font-weight-bold"}>
                    Time To Live
                </Form.Label>
                <Col sm="2">
                    {this.props.isEditable ?
                        <Form.Control name={"rrTtl"}
                                      onChange={this.updateRRObj}
                                      onKeyDown={this.updateRRObj}

                                      defaultValue={rr.rrTtl ? rr.rrTtl : ''}/> : rr.rrTtl}
                </Col>
                <Form.Label column sm="2" className={"font-weight-bold"}>
                    Comment
                </Form.Label>
                <Col sm="2">
                    {this.props.isEditable ?
                        <Form.Control name={"comments"}
                                      onChange={this.updateRRObj}
                                      onKeyDown={this.updateRRObj}
                                      defaultValue={rr.comments ? rr.comments : ''}/> : rr.comments}
                </Col>
            </Form.Group>


            <div className={"text-center"}>
                {pageButtons.map(buttonComp => buttonComp)}
            </div>

        </form>


    }


    componentWillUnmount() {
        this.isComponentMounted = false;
    }

    render() {
        let {pageTitle} = this.getRRPageButtons();
        return (
            <>
                {this.getDeleteConfirmDialog()}
                <Backdrop className={"page-loading"} style={{'zIndex': '10000', 'color': '#fff'}}
                          open={this.state.loading && this.props.loading}>
                    <CircularProgress color="inherit"/>
                </Backdrop>
                <div>
                    <Helmet>
                        <title>DNS Admin | DNS NAPTR Details Page</title>
                    </Helmet>
                    <Container maxWidth={false} className={"px-2"}>
                        <Card>
                            <CardContent>
                                <h5 className="font-weight-bold  text-capitalize text-left pt-3 pb-1 pl-4">{pageTitle}</h5>
                                <div className={"pb-2 pl-4"}>

                                    <div className={"pb-2"}>
                                        {this.props.alert.message && <Alert
                                            severity={this.props.alert.type}>{this.props.alert.message}</Alert>}</div>
                                    {this.getRrNaptrForm()}
                                </div>
                            </CardContent>
                        </Card>
                    </Container>
                </div>
            </>
        )
    }

}

RrNaptr.defaultProps = {
    isEditable: false,
};
RrNaptr.propTypes = {
    isEditable: PropTypes.bool,
    isEmptyForm: PropTypes.bool
};
RrNaptr.defaultProps = {
    isEditable: false,
    isEmptyForm: false
}

function mapState(state) {
    const {loading, zone} = state.zones

    const {alert, clear} = state
    return {loading, alert, zone, clear}
}

const actionCreators = {
    create: resourceRecordActions.create,
    delete: resourceRecordActions.delete,
    update: resourceRecordActions.update,
    alertClear: alertActions.clear,
    getZoneById: zoneActions.getZoneById,

};


const connectedRrNaptr = withRouter(connect(mapState, actionCreators)(RrNaptr));
export {connectedRrNaptr as RrNaptr};

