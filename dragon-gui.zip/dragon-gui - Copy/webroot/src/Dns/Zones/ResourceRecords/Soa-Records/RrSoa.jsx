import React, {Component} from "react";
import Container from "@material-ui/core/Container";
import {withRouter} from "react-router-dom";
import {Backdrop, Button, Card, CardContent, CircularProgress, Paper} from "@material-ui/core";
import PropTypes from "prop-types";
import {alertActions, zoneActions} from "../../../../_actions";
import Form from 'react-bootstrap/Form'
import {Col} from "react-bootstrap";
import {Row} from "react-bootstrap";
import {Alert} from '@material-ui/lab';
import {connect} from "react-redux";
import {Helmet} from "react-helmet";
import {Zone} from "../../Zone"
import {zoneService} from "../../../../_services";
import {resourceRecordService} from "../../../../_services/resourceRecord.service";
import _ from "lodash";
import {resourceRecordActions} from "../../../../_actions/resourceRecords.actions";


class RrSoa extends Component {
    constructor(props) {
        super(props);
        this.state = {
            loading: false,
            zoneData: {},
            json: {},
            json1:{},
            rr: {
                rrGrp: this.props.match.params.zoneNum,
                rrStr: '',
                rrType: this.props.match.params.type,
                comments: '',
                recId: '',
                rrData: ''

            },
            alert: '',
            error: ''

        };
        this.isComponentMounted = false;
        this.updateRRSoa = this.updateRRSoa.bind(this);
        this.getRRPageButtons = this.getRRPageButtons.bind(this);
        this.updateRRObj = this.updateRRObj.bind(this);


        if ((this.props.location.state === null || this.props.location.state === undefined || !this.props.location.state.showAlerts) && !_.isEmpty(this.props.alert)) {
            this.props.alertClear()
        }

    }


    async componentDidMount() {
        if (!this.props.isEmptyForm) {
            this.isComponentMounted = true;
            const res = await zoneService.getZoneById(this.props.match.params.zoneNum)
            if (this.isComponentMounted) {
                this.setState({zoneData: res.zone});
            }
            if (this.isComponentMounted) {
                const resp = await resourceRecordService.getAllRecords({
                    zoneNum: this.state.zoneData.zoneNum,
                    rrType: this.props.match.params.type
                });
                if (!_.isEmpty(resp)) {
                    // const rr = await resourceRecordService.getByRecordId(resp.RRBOs[0].recId);
                    const data = await resourceRecordService.getByRecordId(resp.rr[0].recId);

                    if (!_.isEmpty(data)) {
                        const jsonArray = data.rrData.split(" ");
                        const json = {
                            soaSource: jsonArray[0],
                            soaEmail: jsonArray[1],
                            soaRefresh: jsonArray[3],
                            soaRetry: jsonArray[4],
                            soaExpire: jsonArray[5],
                            soaTtl: jsonArray[6]
                        }
                        if (this.isComponentMounted) {

                            this.setState({loading: false, rr: data, json1: json});
                        }

                    } else {
                        this.props.alertClear()
                        this.props.history.push(`/dns/zones/details/${this.props.match.params.zoneNum}/rr/${this.props.match.params.type}`);
                    }
                }
            }
        }
    }


    componentWillUnmount() {
        this.isComponentMounted = false;
    }

    componentWillMount() {
        console.log("mount")
    }

    async componentWillUpdate(nextProps, nextState, nextContext) {
        console.log("nextProps", nextProps)
    }


    updateRRSoa(e) {
        e.preventDefault()

        this.setState({loading: true})
        let res = null
        if (this.props.isEditable) {
            console.log(this.state.json, "json")

            this.props.update({json: JSON.stringify(this.state.json)}, this.props.match.params.zoneNum,false);
             console.log(this.props.match.params.id)
        }

    }


    updateRRObj(e) {
        let {name, value} = e.target;
        const {json} = this.state;

        this.setState({json: {...json, [name]: value}})
    }


    getRRPageButtons() {
        let pageElements = {
            pageTitle: '',
            pageButtons: [],
        }
        if (this.props.isEditable) {
            pageElements.pageTitle = "DNS SOA Update Page"
            pageElements.pageButtons.push(<Button className={"dns-blue-button text-white mr-2"}
                                                  onClick={this.updateRRSoa}
                                                  key={"update"}>Update</Button>)
            pageElements.pageButtons.push(<Button className={"dns-blue-button text-white mr-2 col-md-1"}
                                                  onClick={() => this.props.history.goBack()}
                                                  key={"cancel_update"}>Cancel</Button>)


        } else {
            pageElements.pageTitle = "DNS SOA Details Page"

            pageElements.pageButtons.push(<Button className={"dns-blue-button text-white mt-2 mr-4 mb-4"}

                                                  onClick={() => {
                                                      this.props.alertClear();
                                                      this.props.history.push(`/dns/zones/details/${this.props.match.params.zoneNum}/rr/${this.props.match.params.type}/edit/${this.state.rr.recId}`)
                                                  }}
                                                  key={"edit"}>Go To Update</Button>)
        }

        return pageElements;
    }


    getSOAForm() {
        const {json, rr, zoneData} = this.state
        let {pageButtons} = this.getRRPageButtons();
        console.log("NAME:", this.state)
        return <Form>
            {/* {this.props.alert.message &&
            <Alert severity={this.props.alert.type}>{this.props.alert.message}</Alert>}*/}
            <Form.Group as={Row} className={"align-items-center"}>
                <Form.Label column sm="2" className={"font-weight-bold"}>
                    Zone ID
                </Form.Label>
                <Col sm="4">
                    {zoneData.zoneNum}
                </Col>
                <Form.Label column sm="2" className={"font-weight-bold"}>
                    Source
                </Form.Label>
                <Col sm="4">
                    {this.props.isEditable ?
                        <Form.Control name={"soaSource"}
                                      onChange={this.updateRRObj}
                                      defaultValue={this.state.json1.soaSource ? this.state.json1.soaSource : ''}/> : this.state.json1.soaSource}
                </Col>

            </Form.Group>
            <Form.Group as={Row} className={"align-items-center"}>
                <Form.Label column sm="2" className={"font-weight-bold"}>
                    Create Time
                </Form.Label>
                <Col sm="4">
                    {this.props.isEditable ?
                        <Form.Control name={"createTime"}
                                      onChange={this.updateRRObj}
                                      defaultValue={zoneData.createTime ? zoneData.createTime : ''}/> : zoneData.createTime}
                </Col>
                <Form.Label column sm="2" className={"font-weight-bold"}>
                    Last Modified
                </Form.Label>
                <Col sm="4">
                    {this.props.isEditable ?
                        <Form.Control name={"modTime"}
                                      onChange={this.updateRRObj}
                                      defaultValue={zoneData.updateTime ? zoneData.updateTime : ''}/> : zoneData.updateTime}
                </Col>
            </Form.Group>
            <Form.Group as={Row} className={"align-items-center"}>
                <Form.Label column sm="2" className={"font-weight-bold"}>
                    Modified By
                </Form.Label>
                <Col sm="4">
                    {this.props.isEditable ?
                        <Form.Control name={"modBy"}
                                      onChange={this.updateRRObj}
                                      defaultValue={zoneData.modBy ? zoneData.modBy : ''}/> : zoneData.modBy}
                </Col>
                <Form.Label column sm="2" className={"font-weight-bold"}>
                    Email
                </Form.Label>
                <Col sm="4">
                    {this.props.isEditable ?
                        <Form.Control name={"soaEmail"}
                                      onChange={this.updateRRObj}
                                      defaultValue={this.state.json1.soaEmail ? this.state.json1.soaEmail : ''}/> : this.state.json1.soaEmail}
                </Col>
            </Form.Group>
            <Form.Group as={Row} className={"align-items-center"}>
                <Form.Label column sm="2" className={"font-weight-bold"}>
                    Refresh Time
                </Form.Label>
                <Col sm="4">
                    {this.props.isEditable ?
                        <Form.Control name={"soaRefresh"}
                                      onChange={this.updateRRObj}
                                      defaultValue={this.state.json1.soaRefresh ? this.state.json1.soaRefresh : ''}/> : this.state.json1.soaRefresh}
                </Col>
                <Form.Label column sm="2" className={"font-weight-bold"}>
                    Retry Time
                </Form.Label>
                <Col sm="4">
                    {this.props.isEditable ?
                        <Form.Control name={"soaRetry"}
                                      onChange={this.updateRRObj}
                                      defaultValue={this.state.json1.soaRetry ? this.state.json1.soaRetry : ''}/> : this.state.json1.soaRetry}
                </Col>


            </Form.Group>
            <Form.Group as={Row} className={"align-items-center"}>
                <Form.Label column sm="2" className={"font-weight-bold"}>
                    Expire Time
                </Form.Label>
                <Col sm="4">
                    {this.props.isEditable ?
                        <Form.Control name={"soaExpire"}
                                      onChange={this.updateRRObj}
                                      defaultValue={this.state.json1.soaExpire ? this.state.json1.soaExpire : ''}/> : this.state.json1.soaExpire}
                </Col>
                <Form.Label column sm="2" className={"font-weight-bold"}>
                    Minimum TTL
                </Form.Label>
                <Col sm="4">
                    {this.props.isEditable ?
                        <Form.Control name={"soaTtl"}
                                      onChange={this.updateRRObj}
                                      defaultValue={this.state.json1.soaTtl ? this.state.json1.soaTtl : ''}/> : this.state.json1.soaTtl}
                </Col>

            </Form.Group>
            <Form.Group as={Row} className={"align-items-center"}>
                <Form.Label column sm="2" className={"font-weight-bold"}>
                    Time To Live
                </Form.Label>
                <Col sm="4">
                    {this.props.isEditable ?
                        <Form.Control name={"TTL"}
                                      onChange={this.updateRRObj}
                                      defaultValue={this.state.json1.TTL ? this.state.json1.TTL : ''}/> : this.state.json1.TTL}
                </Col>
                <Form.Label column sm="2" className={"font-weight-bold"}>
                    Comment
                </Form.Label>
                <Col sm="4">
                    {this.props.isEditable ?
                        <Form.Control name={"comments"}
                                      onChange={this.updateRRObj}
                                      defaultValue={rr.comments ? rr.comments : ''}/> : rr.comments}
                </Col>
            </Form.Group>
            <div className={"text-center"}>
                {pageButtons.map(buttonComp => buttonComp)}
            </div>
        </Form>


    }


    componentWillUnmount() {
        this.isComponentMounted = false;
    }

    render() {
        return (
            <>
                <Backdrop className={"page-loading"} style={{'zIndex': '10000', 'color': '#fff'}}
                          open={this.state.loading && (this.props.saving == true)}>
                    <CircularProgress color="inherit"/>
                </Backdrop>
                <div>
                    <Helmet>
                        <title>DNS Admin | DNS SOA Details Page</title>
                    </Helmet>
                    <Container maxWidth={false} className={"px-2"}>
                        <Card>
                            <CardContent>
                                <div className={'mt-3 ml-3 mr-3 mb-3'}>

                                    <h5 className="font-weight-bold  text-capitalize text-left pt-1 pl-2">DNS SOA
                                        Details Page</h5>
                                    <div className={"pb-2"}>
                                        {this.props.alert.message && <Alert
                                            severity={this.props.alert.type}>{this.props.alert.message}</Alert>}</div>
                                    {this.getSOAForm()}
                                </div>
                            </CardContent>
                        </Card>

                    </Container>
                </div>
            </>
        )
    }

}

RrSoa.defaultProps = {
    isEditable: false,
};
RrSoa.propTypes = {
    isEditable: PropTypes.bool,
    isEmptyForm: PropTypes.bool
};
RrSoa.defaultProps = {
    isEditable: false,
    isEmptyForm: false
}

function mapState(state) {
    const {alert} = state
    console.log(state, "STATE")
    const {loading, saved} = state.rrs
    return {alert, loading, saved}
}

const actionCreators = {
    // update: resourceRecordActions.update,
   update: zoneActions.update,

    alertClear: alertActions.clear,
};


const connectedSoa = withRouter(connect(mapState, actionCreators)(RrSoa));
export {connectedSoa as RrSoa};

