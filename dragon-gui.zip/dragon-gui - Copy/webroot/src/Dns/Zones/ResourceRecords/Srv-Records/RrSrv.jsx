import React, {Component} from "react";
import Container from "@material-ui/core/Container";
import {withRouter} from "react-router-dom";
import {
    Backdrop,
    Button,
    Card,
    CardContent,
    CircularProgress,
    Dialog,
    DialogActions,
    DialogTitle,
} from "@material-ui/core";
import PropTypes from "prop-types";
import {alertActions, zoneActions} from "../../../../_actions";
import Form from 'react-bootstrap/Form'
import {Col} from "react-bootstrap";
import {Row} from "react-bootstrap";
import {Alert} from '@material-ui/lab';
import {connect} from "react-redux";
import {Helmet} from "react-helmet";
import {resourceRecordService} from "../../../../_services/resourceRecord.service";
import {resourceRecordActions} from "../../../../_actions/resourceRecords.actions";
import _ from "lodash";
import {isAuthorized} from "../../../../_components";


class RrSrv extends Component {
    constructor(props) {
        super(props);
        this.state = {
            loading: true,
            //saving: false,
            showDeleteConfirm: false,
            zoneData: {},
            json: {
                validate: ''
            },
            rr: {

                rrGrp: this.props.match.params.zoneNum,
                rrStr: '',
                rrType: this.props.match.params.type,
                comments: '',
                recId: '',
                /*   json: {
                       validate:'Y'
                   },*/

            },
            alert: '',

        };
        this.isComponentMounted = false;
        this.saveSrv = this.saveSrv.bind(this);
        this.updateRRObj = this.updateRRObj.bind(this);
        this.deleteRR = this.deleteRR.bind(this);
        this.getDeleteConfirmDialog = this.getDeleteConfirmDialog.bind(this);

        if ((this.props.location.state === undefined || !this.props.location.state.showAlerts) && !_.isEmpty(this.props.alert)) {
            this.props.alertClear()
        }

    }


    saveSrv(e) {
        e.preventDefault()
        if (this.isComponentMounted) {
            this.setState({loading: !this.props.isEmptyForm})//changed it so that it supports loading on create page
        }

        const {rrName, rrTtl, comments, priority, weight, port, server, rrGrp, rrType, ...rr} = this.state.rr
        const resourceRecordSRV = {
            rrStr: rrName.replace(/\.+$/, "") + (rrTtl ? (" " + rrTtl) : "") + " IN " + rrType.toUpperCase() + " " + priority + " " + weight + " " + port + " " + server,
            rrType: rrType.toUpperCase(),
            rrGrp,
            comments
        }
        let res = null


        if (this.props.isEmptyForm && this.props.isEditable) {
            this.props.create(resourceRecordSRV);

        } else {
            this.props.update(this.props.match.params.id, resourceRecordSRV, false);
        }

    }

    async componentDidMount() {
        this.isComponentMounted = true;
        this.props.getZoneById(this.props.match.params.zoneNum)

        if (!this.props.isEmptyForm && this.isComponentMounted) {
            const rr = await resourceRecordService.getByRecordId(this.props.match.params.id);
            if (!_.isEmpty(rr) && this.isComponentMounted) {
                rr.priority = rr.rrData.split(" ")[0]
                rr.weight = rr.rrData.split(" ")[1]
                rr.port = rr.rrData.split(" ")[2]
                rr.server = rr.rrData.split(" ")[3]
                this.setState({loading: false, rr: rr});

            }
        }
    }

    componentDidUpdate(prevProps, prevState, snapshot) {
        if (((this.state.loading && this.props.zone) || !_.isEqual(prevProps.zone, this.props.zone))) {

            this.setState({
                zoneData: _.omit(this.props.zone, ['soaTemplate']),
                loading: false
            }, () => {

                if (prevProps.zone?.zoneStatus != this.props.zone?.zoneStatus) {
                    this.props.updateMenu();
                }
            })
        }
    }


    deleteRR() {
        if (this.isComponentMounted) {
            this.setState({showDeleteConfirm: false, loading: true})
        }
        this.props.delete(this.props.match.params.id);
    }

    componentWillUnmount() {
        this.isComponentMounted = false;
    }


    updateRRObj(e) {
        let {name, value} = e.target;
        const {rr} = this.state;
        value = value.trim();
        this.setState({rr: {...rr, [name]: value}})

    }


    getRRPageButtons() {
        let pageElements = {
            pageTitle: '',
            pageButtons: [],
        }
        if (this.props.isEditable && this.props.isEmptyForm) {
            pageElements.pageTitle = "DNS Host Information (SRV) Record Creation"
            pageElements.pageButtons.push(<Button className={"dns-blue-button text-white mr-2"}
                //onClick={this.saveSrv}
                                                  type={"submit"}//using the submit form instead of click button
                                                  key={"insert"}>Insert</Button>)
            pageElements.pageButtons.push(<Button className={"dns-blue-button text-white mr-2 col-md-1"}
                                                  onClick={() => {
                                                      this.props.alertClear();
                                                      this.props.history.push(`/dns/zones/details/${this.props.match.params.zoneNum}/rr/${this.props.match.params.type}`)
                                                  }}
                                                  key={"cancel_update"}>Cancel</Button>)


        } else if (this.props.isEditable) {
            pageElements.pageTitle = "DNS SRV Record Update"
            pageElements.pageButtons.push(<Button className={"dns-blue-button text-white mr-2 col-md-1"}
                //onClick={this.saveSrv}
                                                  type={"submit"} key={"update"}>Update</Button>)
            pageElements.pageButtons.push(<Button className={"dns-blue-button text-white mr-2 col-md-1"}
                                                  onClick={() => {
                                                      this.props.alertClear();

                                                      this.props.history.goBack()
                                                  }}
                                                  key={"cancel_update"}>Cancel</Button>)


        } else {
            if (isAuthorized('ru')) {

                pageElements.pageTitle = "DNS SRV Record Details"
                pageElements.pageButtons.push(<Button className={"dns-blue-button text-white mt-2 mr-4 mb-4"}
                                                      onClick={() => {
                                                          this.props.alertClear();
                                                          this.props.history.push(`/dns/zones/details/${this.props.match.params.zoneNum}/rr/${this.props.match.params.type}/edit/${this.props.match.params.id}`)
                                                      }}
                                                      key={"edit"}>Go To Update</Button>)

            }
            if (isAuthorized('rd')) {

                pageElements.pageButtons.push(<Button className={"dns-blue-button text-white mt-2 mr-4 mb-4"}
                                                      onClick={() => {
                                                          this.props.alertClear();
                                                          this.setState({showDeleteConfirm: true})
                                                      }} key={"delete"}>Delete</Button>)
            }
            pageElements.pageButtons.push(<Button className={"dns-blue-button text-white mt-2 mb-4"}
                                                  onClick={() => {
                                                      this.props.alertClear();
                                                      this.props.history.push(`/dns/zones/details/${this.props.match.params.zoneNum}/rr/${this.props.match.params.type}`)
                                                  }}
                                                  key={"list_srv"}>List SRV Records</Button>)


        }

        return pageElements;
    }

    getDeleteConfirmDialog() {
        return !this.props.isEditable && <Dialog
            onClose={(event, reason) => {
                if (reason === 'backdropClick' || reason === 'escapeKeyDown') {
                    return false;
                }
            }}
            maxWidth="xs"
            aria-labelledby="confirmation-dialog-title"
            open={this.state.showDeleteConfirm}
        >
            <DialogTitle id="confirmation_dialog_title">Are you sure you want to delete this
                record?</DialogTitle>
            <DialogActions>
                <Button autoFocus onClick={this.deleteRR} className={"dns-blue-button text-white"}>
                    Delete
                </Button>
                <Button onClick={() => this.setState({showDeleteConfirm: false})}
                        className={"dns-blue-button text-white"}>
                    Cancel
                </Button>
            </DialogActions>
        </Dialog>
    }


    getRrSrvForm() {
        const {rr, zoneData} = this.state
        let {pageButtons} = this.getRRPageButtons();
        return <form onSubmit={this.saveSrv}>
            <Form.Group as={Row} className={"align-items-center"}>
                {(this.props.isEmptyForm || !this.props.isEditable) && <><Form.Label column sm="2"
                                                                                     className={"font-weight-bold"}>
                    Zone ID
                </Form.Label>
                    <Col sm="4">
                        {rr.rrGrp}
                    </Col></>}
                {!this.props.isEmptyForm && !this.props.isEditable && <><Form.Label column sm="2"
                                                                                    className={"font-weight-bold"}>
                    Zone Name
                </Form.Label>
                    <Col sm="4">
                        {zoneData.zoneName}
                    </Col></>}
            </Form.Group>
            <Form.Group as={Row} className={"align-items-center"}>
                {!this.props.isEmptyForm &&
                    <> <Form.Label column sm="2" className={"font-weight-bold"}>
                        Record ID
                    </Form.Label>
                        <Col sm="4">
                            {rr.recId}
                        </Col></>}
                <Form.Label column sm="2" className={"font-weight-bold"}>
                    {this.props.isEditable ? "*" : ""}Resource Record Name
                </Form.Label>
                <Col sm="4">
                    {this.props.isEditable ?
                        <Form.Control name={"rrName"}
                                      onChange={this.updateRRObj}
                                      className={"w-50 d-inline"}
                                      defaultValue={rr.rrName ? rr.rrName : ''}
                                      required={true}
                        /> : rr.rrName}
                    {/*  <span className={"d-inline"}>  {rr.rrGrp}</span>*/}
                    <span className={"d-inline"}>{`.${zoneData.zoneName}`}</span> {/*adding the trailing dot for lhs so
                     that user avoid adding dot after rrName.Need to updatte in git with iTrack number:[DRAGON3-343]*/}


                </Col>


                {/*        /**     {zoneData.zoneName} // need to append domainname to rrname not sure howit works here     **/}


            </Form.Group>
            <Form.Group as={Row} className={"align-items-center"}>
                {!this.props.isEmptyForm && !this.props.isEditable && <> <Form.Label column sm="2"
                                                                                     className={"font-weight-bold"}>
                    Create Time
                </Form.Label>
                    <Col sm="4">
                        {rr.createTime}
                    </Col></>}
                {!this.props.isEmptyForm && !this.props.isEditable && <>  <Form.Label column sm="2"
                                                                                      className={"font-weight-bold"}>
                    Last Modified
                </Form.Label>
                    <Col sm="4">
                        {rr.modTime}
                    </Col></>}

            </Form.Group>
            <Form.Group as={Row} className={"align-items-center"}>
                <Form.Label column sm="2" className={"font-weight-bold"}>
                    {this.props.isEditable ? "*" : ""}Priority
                </Form.Label>
                <Col sm="4">
                    {this.props.isEditable ?
                        <Form.Control name={"priority"}
                                      onChange={this.updateRRObj}
                                      defaultValue={rr.priority ? rr.priority : ''}
                                      required={true}
                        /> : rr.priority}
                </Col>
                <Form.Label column sm="2" className={"font-weight-bold"}>
                    {this.props.isEditable ? "*" : ""}Weight
                </Form.Label>
                <Col sm="4">
                    {this.props.isEditable ?
                        <Form.Control name={"weight"}
                                      onChange={this.updateRRObj}
                                      defaultValue={rr.weight ? rr.weight : ''}
                                      required={true}
                        /> : rr.weight}
                </Col>

            </Form.Group>

            <Form.Group as={Row} className={"align-items-center"}>
                <Form.Label column sm="2" className={"font-weight-bold"}>
                    {this.props.isEditable ? "*" : ""}Port
                </Form.Label>
                <Col sm="4">
                    {this.props.isEditable ?
                        <Form.Control name={"port"}
                                      onChange={this.updateRRObj}
                                      defaultValue={rr.port ? rr.port : ''}
                                      required={true}
                        /> : rr.port}
                </Col>
                <Form.Label column sm="2" className={"font-weight-bold"}>
                    {this.props.isEditable ? "*" : ""}Target Host's Full Name
                </Form.Label>
                <Col sm="4">
                    {this.props.isEditable ?
                        <Form.Control name={"server"}
                                      onChange={this.updateRRObj}
                                      defaultValue={rr.server ? rr.server : ''}
                                      required={true}
                        /> : rr.server}
                </Col>

            </Form.Group>


            <Form.Group as={Row} className={"align-items-center"}>

                <Form.Label column sm="2" className={"font-weight-bold"}>
                    {this.props.isEditable ? "*" : ""}Validate
                </Form.Label>
                <Col sm="4">
                    {this.props.isEditable ?
                        <Form.Control as="select" name={"json.validate"}
                                      onChange={this.updateRRObj}
                                      value={this.state.json.validate}
                                      required={true}
                        >
                            <option value={"Y"}>Y</option>
                            <option value={"N"}>N</option>
                        </Form.Control>
                        : this.state.json.validate}
                </Col>

                <Form.Label column sm="2" className={"font-weight-bold"}>
                    Time To Live
                </Form.Label>
                <Col sm="4">
                    {this.props.isEditable ?
                        <Form.Control name={"rrTtl"}
                                      onChange={this.updateRRObj}
                                      defaultValue={rr.rrTtl ? rr.rrTtl : ''}/> : rr.rrTtl}
                </Col>
            </Form.Group>

            <Form.Group as={Row} className={"align-items-center"}>
                {!this.props.isEmptyForm && !this.props.isEditable && <><Form.Label column sm="2"
                                                                                    className={"font-weight-bold"}>
                    Modified By
                </Form.Label>
                    <Col sm="4">
                        {rr.modBy}
                    </Col></>}
                <Form.Label column sm="2" className={"font-weight-bold"}>
                    Comment
                </Form.Label>
                <Col sm="4">
                    {this.props.isEditable ?
                        <Form.Control name={"comments"}
                                      onChange={this.updateRRObj}
                                      defaultValue={rr.comments ? rr.comments : ''}/> : rr.comments}
                </Col>
            </Form.Group>
            <div className={"text-center"}>
                {pageButtons.map(buttonComp => buttonComp)}
            </div>

        </form>


    }

    render() {
        let {pageTitle} = this.getRRPageButtons();
        if (this.state.loading) {
            return <div>Loading....</div>
        }
        return (

            <>
                {this.getDeleteConfirmDialog()}
                <Backdrop className={"page-loading"} style={{'zIndex': '10000', 'color': '#fff'}}
                          open={this.state.loading}>
                    <CircularProgress color="inherit"/>
                </Backdrop>
                <div>
                    <Helmet>
                        <title>DNS Admin | DNS SRV Details Page</title>
                    </Helmet>
                    <Container maxWidth={false} className={"px-2"}>
                        <Card>
                            <CardContent>
                                <div className={'mt-3 ml-3 mr-3 mb-3'}>

                                    <h5 className="font-weight-bold  text-capitalize text-left pt-1 pl-2">{pageTitle}</h5>
                                    <div className="pl-2 pr-2">

                                        <div className={"pb-2"}>
                                            {this.props.alert.message && <Alert
                                                severity={this.props.alert.type}>{this.props.alert.message}</Alert>}</div>
                                        {this.getRrSrvForm()}
                                    </div>
                                </div>
                            </CardContent>
                        </Card>

                    </Container>
                </div>
            </>
        )
    }

}

RrSrv.defaultProps = {
    isEditable: false,
};
RrSrv.propTypes = {
    isEditable: PropTypes.bool,
    isEmptyForm: PropTypes.bool
};
RrSrv.defaultProps = {
    isEditable: false,
    isEmptyForm: false
}

function mapState(state) {
    const {loading, zone} = state.zones

    const {alert, clear} = state
    return {loading, alert, zone, clear}

}

const actionCreators = {
    create: resourceRecordActions.create,
    delete: resourceRecordActions.delete,
    update: resourceRecordActions.update,
    alertClear: alertActions.clear,
    getZoneById: zoneActions.getZoneById,

};


const connectedRrSrv = withRouter(connect(mapState, actionCreators)(RrSrv));
export {connectedRrSrv as RrSrv};

