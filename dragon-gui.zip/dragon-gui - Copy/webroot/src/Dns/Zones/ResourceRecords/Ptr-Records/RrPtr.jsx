import React, {Component} from "react";
import Container from "@material-ui/core/Container";
import {withRouter} from "react-router-dom";
import {
    Backdrop,
    Button,
    Card,
    CardContent,
    CircularProgress,
    Dialog,
    DialogActions,
    DialogTitle,
} from "@material-ui/core";
import PropTypes from "prop-types";
import {alertActions} from "../../../../_actions";
import Form from 'react-bootstrap/Form'
import {Col} from "react-bootstrap";
import {Row} from "react-bootstrap";
import {Alert} from '@material-ui/lab';
import {connect} from "react-redux";
import {Helmet} from "react-helmet";
import {resourceRecordService} from "../../../../_services/resourceRecord.service";
import {resourceRecordActions} from "../../../../_actions/resourceRecords.actions";
import _ from "lodash";
import {zoneService} from "../../../../_services";


class RrPtr extends Component {
    constructor(props) {
        super(props);
        this.state = {
            loading: true,
            showDeleteConfirm: false,
            zoneData: {},
            rr: {
                rrGrp: this.props.match.params.zoneNum,
                rrStr: {},
                rrType: this.props.match.params.type,
                comments: '',
                recId: '',

            },
            alert: '',

        };
        this.isComponentMounted = false;
        this.saveRRPtr = this.saveRRPtr.bind(this);
        this.updateRRObj = this.updateRRObj.bind(this);
        this.deleteRR = this.deleteRR.bind(this);
        this.getDeleteConfirmDialog = this.getDeleteConfirmDialog.bind(this);

        if ((this.props.location.state === undefined || !this.props.location.state.showAlerts) && !_.isEmpty(this.props.alert)) {
            this.props.alertClear()
        }

    }


    saveRRPtr(e) {
        e.preventDefault()
        if (this.isComponentMounted) {
            // this.setState({loading: true, saving: true})
            this.setState({loading: !this.props.isEmptyForm, saving: true})

        }
        const {
            rrType,
            rrStr,
            rrGrp,
            ...rr
        } = this.state.rr
        const len = Object.keys(rrStr).length
        if (len < 1) {
        } else {
            let reqObj = {
                rrType: rrType.toUpperCase(),
                rrGrp,
            }
            let count = 1;
            for (const [key, val] of Object.entries(rrStr)) {
                let tmpStr = val.rrName + (val.rrTtl ? (" " + val.rrTtl) : "") + " IN " + rrType.toUpperCase() + " " + (val.rrData ? val.rrData : "")
                if (count == 1) {
                    reqObj.rrStr = tmpStr;
                    reqObj.comments = val.hasOwnProperty('comments') ? val.comments : ''
                } else {
                    reqObj[`rrStr${count}`] = tmpStr
                    reqObj[`comments${count}`] = val.hasOwnProperty('comments') ? val.comments : ''
                }
                count++;
            }

            if (this.props.isEmptyForm && this.props.isEditable) {
                this.props.create(reqObj);
            } else {
                this.props.update(this.props.match.params.id, reqObj, false);
            }
        }


    }


    async componentDidMount() {
        this.isComponentMounted = true;
        const zoneData = await zoneService.getZoneById(this.props.match.params.zoneNum)
        if (this.isComponentMounted && zoneData.success) {
            this.setState({loading: !this.props.isEmptyForm, zoneData: zoneData.zone});

        }
        if (!this.props.isEmptyForm && this.isComponentMounted) {
            let rr = await resourceRecordService.getByRecordId(this.props.match.params.id);
            if (!_.isEmpty(rr) && this.isComponentMounted) {
                rr.rrStr = [{rrName: rr.rrName, rrTtl: rr.rrTtl, rrData: rr.rrData, comments: rr.comments}]

                this.setState({loading: false, rr});
            } else {
                this.props.history.push(`/dns/zones/details/${this.props.match.params.zoneNum}/rr/${this.props.match.params.type}`);
            }

        }
    }

    deleteRR() {
        this.setState({showDeleteConfirm: false, loading: true})
        this.props.delete(this.props.match.params.id);
    }


    componentWillUnmount() {
        this.isComponentMounted = false;
    }


    updateRRObj(e) {
        let {name, value} = e.target;
        const {rr} = this.state;

        let i = name.slice(-1);
        name = name.slice(0, -1)
        if (['rrName', 'rrData', 'rrTtl', 'comments'].includes(name)) {
            if (!rr.rrStr.hasOwnProperty(i)) { //syntax to find the json key
                rr.rrStr[i] = {[name]: value}
            } else {
                rr.rrStr[i][name] = value
            }

            this.setState({rr: rr})
        } else {
            this.setState({rr: {...rr, [name]: {[i]: value}}})
        }

    }


    getRRPageButtons() {
        let pageElements = {
            pageTitle: '',
            pageButtons: [],
        }
        if (this.props.isEditable && this.props.isEmptyForm) {
            pageElements.pageTitle = "DNS PTR Insert Page"
            pageElements.pageButtons.push(<Button className={"dns-blue-button text-white mr-2"}
                //onClick={this.saveRRPtr}
                                                  type={"submit"}
                                                  key={"ptr_insert"}>Insert</Button>)
            pageElements.pageButtons.push(<Button className={"dns-blue-button text-white mr-2 col-md-1"}
                                                  onClick={() => this.props.history.push(`/dns/zones/details/${this.props.match.params.zoneNum}/rr/${this.props.match.params.type}`)}
                                                  key={"cancel_update"}>Cancel</Button>)


        } else if (this.props.isEditable) {
            pageElements.pageTitle = "DNS PTR Modification"
            pageElements.pageButtons.push(<Button className={"dns-blue-button text-white mr-2 col-md-1"}
                //onClick={this.saveRRPtr}
                                                  type={"submit"}
                                                  key={"update"}>Update</Button>)
            pageElements.pageButtons.push(<Button className={"dns-blue-button text-white mr-2 col-md-1"}
                                                  onClick={() => this.props.history.goBack()}
                                                  key={"cancel_update"}>Cancel</Button>)


        } else {
            pageElements.pageTitle = "DNS PTR Details"
            pageElements.pageButtons.push(<Button className={"dns-blue-button text-white mt-2 mr-4 mb-4"}
                                                  onClick={() => this.props.history.push(`/dns/zones/details/${this.props.match.params.zoneNum}/rr/${this.props.match.params.type}/edit/${this.props.match.params.id}`)}
                                                  key={"edit"}>Go To Update</Button>)
            pageElements.pageButtons.push(<Button className={"dns-blue-button text-white mt-2 mr-4 mb-4"}
                                                  onClick={() => {
                                                      this.setState({showDeleteConfirm: true})
                                                  }} key={"delete"}>Delete</Button>)
            pageElements.pageButtons.push(<Button className={"dns-blue-button text-white mt-2 mb-4"}
                                                  onClick={() => this.props.history.push(`/dns/zones/details/${this.props.match.params.zoneNum}/rr/${this.props.match.params.type}`)}
                                                  key={"list_users"}>List PTR Records</Button>)


        }

        return pageElements;
    }

    getDeleteConfirmDialog() {
        return !this.props.isEditable && <Dialog
            onClose={(event, reason) => {
                if (reason === 'backdropClick' || reason === 'escapeKeyDown') {
                    return false;
                }
            }}
            maxWidth="xs"
            aria-labelledby="confirmation-dialog-title"
            open={this.state.showDeleteConfirm}
        >
            <DialogTitle id="confirmation_dialog_title">Are you sure you want to delete this
                record?</DialogTitle>
            <DialogActions>
                <Button autoFocus onClick={this.deleteRR} className={"dns-blue-button text-white"}>
                    Delete
                </Button>
                <Button onClick={() => this.setState({showDeleteConfirm: false})}
                        className={"dns-blue-button text-white"}>
                    Cancel
                </Button>
            </DialogActions>
        </Dialog>
    }


    getRRPtrForm() {
        const {rr, zoneData} = this.state

        let {pageButtons} = this.getRRPageButtons();

        return <form onSubmit={this.saveRRPtr}>
            <Form.Group as={Row} className={"align-items-center pl-3 mb-0"}>
                {(this.props.isEmptyForm || !this.props.isEditable) && <><Form.Label column sm="2"
                                                                                     className={"font-weight-bold"}>
                    Zone ID
                </Form.Label>
                    <Col sm="4">
                        {rr.rrGrp}
                    </Col></>}
                {!this.props.isEmptyForm && !this.props.isEditable && <><Form.Label column sm="2"
                                                                                    className={"font-weight-bold"}>
                    Zone Name
                </Form.Label>
                    <Col sm="4">
                        {zoneData.zoneName}
                    </Col></>}
            </Form.Group>

            {[...Array(this.props.match.params.id == 'multiple' ? 5 : 1)].map((e, i) => {
                return <div key={i} className={"py-3 px-3"}>
                    {/*
                    {this.props.match.params.id == 'multiple' ? <h6>Address Record {i + 1}:</h6> : ''} //add if required as heading for each record
*/}
                    <Form.Group as={Row} key={`group1${i}`} className={"align-items-center"}>
                        {!this.props.isEmptyForm && <>  <Form.Label column sm="2" className={"font-weight-bold"}>
                            Record ID
                        </Form.Label>
                            <Col sm="4">
                                {rr.recId}
                            </Col></>}
                        <Form.Label column sm="2" className={"font-weight-bold"}>
                            {this.props.isEditable ? "*" : ""} Resource Record Name
                        </Form.Label>
                        <Col sm="4">
                            {this.props.isEditable ? <Form.Control name={`rrName${i}`}
                                                                   onChange={this.updateRRObj}
                                                                   defaultValue={rr.rrName ? rr.rrName : ''}
                                                                   required={true} //maybe avoid it while adding multiple records


                            /> : rr.rrName}
                            <span className={"d-inline"}>{`.${zoneData.zoneName}`}</span> {/*adding the trailing dot for lhs so
                     that user avoid adding dot after rrName.Need to updatte in git with iTrack number*/}
                        </Col>

                    </Form.Group>


                    <Form.Group as={Row} key={`group2${i}`} className={"align-items-center"}>
                        <Form.Label column sm="2" className={"font-weight-bold"}>
                            Full Host Name </Form.Label>


                        {/*
                            {this.props.isEditable ? "*" : ""}Full Host Name </Form.Label>

*/}
                        <Col sm="4">
                            {this.props.isEditable ? <Form.Control
                                name={`rrData${i}`}
                                onChange={this.updateRRObj}
                                defaultValue={rr.rrData ? rr.rrData : ''}
                                //required={true} maybe avoid it while adding multiple records

                            /> : rr.rrData}
                        </Col>

                        <Form.Label column sm="2" className={"font-weight-bold"}>
                            Validate
                        </Form.Label>
                        <Col sm="4">

                            {this.props.isEditable ?
                                <Form.Control as="select" name={`status${i}`}
                                              onChange={this.updateRRObj}
                                              value={rr.json}>
                                    <option value={"Y"}>Y</option>
                                    <option value={"N"}>N</option>
                                </Form.Control>
                                : rr.json}
                        </Col>

                    </Form.Group>

                    <Form.Group as={Row} key={`group3${i}`} className={"align-items-center"}>
                        {(!this.props.isEditable) && <>  <Form.Label column sm="2" className={"font-weight-bold"}>
                            Create Time
                        </Form.Label>
                            <Col sm="4">
                                {rr.createTime}
                            </Col></>}
                        {(!this.props.isEditable) && <> <Form.Label column sm="2" className={"font-weight-bold"}>
                            Last Modified
                        </Form.Label>
                            <Col sm="4">
                                {rr.modTime}
                            </Col></>}


                    </Form.Group>


                    <Form.Group as={Row} key={`group4${i}`} className={"align-items-center"}>
                        <Form.Label column sm="2" className={"font-weight-bold"}>
                            TTL
                        </Form.Label>
                        <Col sm="4">
                            {this.props.isEditable ?
                                <Form.Control name={`rrTtl${i}`}
                                              onChange={this.updateRRObj}
                                              defaultValue={rr.rrTtl ? rr.rrTtl : ''}/> : rr.rrTtl}
                        </Col>
                        <Form.Label column sm="2" className={"font-weight-bold"}>
                            Comment
                        </Form.Label>
                        <Col sm="2">
                            {this.props.isEditable ?
                                <Form.Control name={`comments${i}`}
                                              onChange={this.updateRRObj}
                                              defaultValue={rr.comments ? rr.comments : ''}/> : rr.comments}
                        </Col>

                    </Form.Group>
                    <Form.Group as={Row} key={`group5${i}`} className={"align-items-center"}>

                        {!this.props.isEditable && <>  <Form.Label column sm="2" className={"font-weight-bold"}>
                            Modified By
                        </Form.Label>
                            <Col sm="2">
                                {rr.modBy}
                            </Col></>}
                    </Form.Group>
                    <hr/>


                </div>
            })}
            <div className={"text-center"}>
                {pageButtons.map(buttonComp => buttonComp)}
            </div>

        </form>


    }


    componentDidUpdate(prevProps, prevState, snapshot) {
        if(this.state.loading !== prevState.loading){
            this.setState({loading:false})

        }
    }


    render() {
        if (this.state.loading) {
            return <div>Loading....</div>
        }
        return (
            <>
                {this.getDeleteConfirmDialog()}
                <Backdrop className={"page-loading"} style={{'zIndex': '10000', 'color': '#fff'}}
                          open={this.state.loading}>
                    <CircularProgress color="inherit"/>
                </Backdrop>
                <div>
                    <Helmet>
                        <title>DNS Admin | DNS Address (PTR) Records List</title>
                    </Helmet>
                    <Container maxWidth={false} className={"px-2"}>
                        <Card>
                            <CardContent>
                                <div className={'mt-3 ml-3 mr-3 mb-3'}>
                                    <h5 className="font-weight-bold  text-capitalize text-left pt-3 pb-3 pl-2">DNS
                                        Address
                                        (PTR) Records List

                                    </h5>
                                    <div className={"pb-2"}>
                                        {this.props.alert.message && <Alert
                                            severity={this.props.alert.type}>{this.props.alert.message}</Alert>}</div>
                                    {this.getRRPtrForm()}
                                </div>
                            </CardContent>
                        </Card>

                    </Container>
                </div>
            </>
        )
    }

}

RrPtr.defaultProps = {
    isEditable: false,
};
RrPtr.propTypes = {
    isEditable: PropTypes.bool,
    isEmptyForm: PropTypes.bool
};
RrPtr.defaultProps = {
    isEditable: false,
    isEmptyForm: false
}


function mapState(state) {
    const {alert} = state
    const {loading, saved, deleted, deleting} = state.rrs
    return {alert, loading, saved, deleted, deleting}
}

const actionCreators = {
    create: resourceRecordActions.create,
    delete: resourceRecordActions.delete,
    update: resourceRecordActions.update,
    alertClear: alertActions.clear,
};


const connectedRrPtr = withRouter(connect(mapState, actionCreators)(RrPtr));
export {connectedRrPtr as RrPtr};

