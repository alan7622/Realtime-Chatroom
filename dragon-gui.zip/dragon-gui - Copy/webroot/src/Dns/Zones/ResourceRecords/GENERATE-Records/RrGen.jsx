import React, {Component, useEffect} from "react";
import Container from "@material-ui/core/Container";
import {withRouter} from "react-router-dom";
import {
    Backdrop,
    Button,
    Card,
    CardContent,
    CircularProgress,
    Dialog,
    DialogActions,
    DialogTitle,
    Paper
} from "@material-ui/core";
import PropTypes from "prop-types";
import {alertActions, zoneActions} from "../../../../_actions";
import Form from 'react-bootstrap/Form'
import {Col} from "react-bootstrap";
import {Row} from "react-bootstrap";
import {Alert} from '@material-ui/lab';
import {connect} from "react-redux";
import {Helmet} from "react-helmet";
import {resourceRecordService} from "../../../../_services";
import {resourceRecordActions} from "../../../../_actions/resourceRecords.actions";
import _ from "lodash";
import {isAuthorized} from "../../../../_components";


class RrGen extends Component {
    constructor(props) {
        super(props);
        this.state = {
            loading: true,
            //saving: false,
            showDeleteConfirm: false,
            zoneData: {},
            rr: {
                rrGrp: this.props.match.params.zoneNum,
                rrStr: 'GEN',
                rrType: this.props.match.params.type,
                comments: '',
                recId: '',
                rrJson: {
                    rhs: [],
                    // rrType:'PTR',
                    rrtype: '',

                }
            },
            alert: '',

        };
        this.isComponentMounted = false;
        this.saveGen = this.saveGen.bind(this);
        this.updateRRObj = this.updateRRObj.bind(this);
        this.deleteRR = this.deleteRR.bind(this);
        this.getDeleteConfirmDialog = this.getDeleteConfirmDialog.bind(this);


        if ((this.props.location.state === undefined || !this.props.location.state.showAlerts) && !_.isEmpty(this.props.alert)) {
            this.props.alertClear()
        }

    }


    saveGen() {
        this.setState({loading: !this.props.isEmptyForm})
        let rrDetails = {}
        Object.entries(this.state.rr).forEach(([k, v]) => {
            if (['rrType', 'rrStr', 'rrGrp', 'rrTtl', 'comments', 'rrJson'].includes(k)) {
                //  if (['rrType', 'rrStr', 'rrGrp', 'rrTtl','comments', 'rrJson'].includes(k)) {

                if (k === 'rrJson') {
                    rrDetails.json = _.cloneDeep(v);
                    Object.entries(v).forEach(([jsonObj, jsonVal]) =>
                        rrDetails.json[jsonObj] = Array.isArray(jsonVal) ? jsonVal.join('.') : jsonVal)
                    rrDetails.json = JSON.stringify(rrDetails.json)
                } else {
                    rrDetails[k] = (k === 'rrType') ? v.toUpperCase() : v
                }
            }
        })
        this.props.createOrUpdate(rrDetails, _.get(this.props, 'match.params.id'), 'rr', false);

    }

    async componentDidMount() {
        this.isComponentMounted = true;
        let zoneData = this.state.zoneData;
        //const zoneData = await zoneService.getZoneById(this.props.match.params.zoneNum)
        this.props.getZoneById(this.props.match.params.zoneNum)

        let rr = this.state.rr
        if (!this.props.isEmptyForm && this.isComponentMounted) {
            rr = await resourceRecordService.getByRecordId(this.props.match.params.id);
            if (!_.isEmpty(rr) && this.isComponentMounted) {
                rr.rrJson.rhs = rr.rrJson.rhs.replace(".$", "").trim().split(".")
                    .concat(new Array(2).fill('')).slice(0, 3)
                rr.rrJson.rhs.push('$')
                // this.setState({loading: false, rr, zoneData})
                this.setState({loading: false, rr})


            }
            /*else {
                this.props.alertClear()
                this.props.history.push(`/dns/zones/details/${this.props.match.params.zoneNum}/rr/${this.props.match.params.type}`);
            }*/
        }
        /*  if (this.isComponentMounted) {
             // this.setState({loading: false, rr, zoneData})
              this.setState({loading: false, rr})

          }*/
    }

    componentDidUpdate(prevProps, prevState, snapshot) {
        if (((this.state.loading && this.props.zone) || !_.isEqual(prevProps.zone, this.props.zone))) {

            this.setState({
                zoneData: _.omit(this.props.zone, ['soaTemplate']),
                loading: false
            }, () => {

                if (prevProps.zone?.zoneStatus != this.props.zone?.zoneStatus) {
                    this.props.updateMenu();
                }
            })
        }
    }


    deleteRR() {
        this.setState({showDeleteConfirm: false, loading: true})
        this.props.delete(this.props.match.params.id);
    }


    componentWillUnmount() {
        this.isComponentMounted = false;
    }


    updateRRObj(e) {
        if (e.keyCode === 8 && e.target.selectionStart === 0 && e.target.selectionEnd === e.target.value.length) {
            e.preventDefault(); // Prevent default backspace behavior
            e.target.value = ""; // Clear the input value
        }
        console.log("onchange test")

        let {name, value} = e.target;
        let {rr} = this.state;
        rr = _.set(rr, name, value)
        this.setState({rr})
    }


    getRRPageButtons() {
        let pageElements = {
            pageTitle: '',
            pageButtons: [],
        }
        if (this.props.isEditable && this.props.isEmptyForm) {
            pageElements.pageTitle = "DNS Host Information (GEN) Record Creation"
            pageElements.pageButtons.push(<Button className={"dns-blue-button text-white mr-2"}
                                                  onClick={this.saveGen}
                                                  key={"insert"}>Insert</Button>)
            pageElements.pageButtons.push(<Button className={"dns-blue-button text-white mr-2 col-md-1"}
                                                  onClick={() => this.props.history.push(`/dns/zones/details/${this.props.match.params.zoneNum}/rr/${this.props.match.params.type}`)}
                                                  key={"cancel_update"}>Cancel</Button>)


        } else if (this.props.isEditable) {
            pageElements.pageTitle = "DNS GEN Record Update"
            pageElements.pageButtons.push(<Button className={"dns-blue-button text-white mr-2 col-md-1"}
                                                  onClick={this.saveGen}
                                                  key={"update"}>Update</Button>)
            pageElements.pageButtons.push(<Button className={"dns-blue-button text-white mr-2 col-md-1"}
                                                  onClick={() => this.props.history.goBack()}
                                                  key={"cancel_update"}>Cancel</Button>)


        } else {
            if (isAuthorized('ru')) {

                pageElements.pageTitle = "DNS GEN Record Details"
                pageElements.pageButtons.push(<Button className={"dns-blue-button text-white mt-2 mr-4 mb-4"}
                                                      onClick={() => this.props.history.push(`/dns/zones/details/${this.props.match.params.zoneNum}/rr/${this.props.match.params.type}/edit/${this.props.match.params.id}`)}
                                                      key={"edit"}>Go To Update</Button>)

            }

            if (isAuthorized('rd')) {

                pageElements.pageButtons.push(<Button className={"dns-blue-button text-white mt-2 mr-4 mb-4"}
                                                      onClick={() => {
                                                          this.setState({showDeleteConfirm: true})
                                                      }} key={"delete"}>Delete</Button>)
            }
            pageElements.pageButtons.push(<Button className={"dns-blue-button text-white mt-2 mb-4"}
                                                  onClick={() => this.props.history.push(`/dns/zones/details/${this.props.match.params.zoneNum}/rr/${this.props.match.params.type}`)}
                                                  key={"list_gen"}>List Records</Button>)


        }

        return pageElements;
    }

    getDeleteConfirmDialog() {
        return !this.props.isEditable && <Dialog
            onClose={(event, reason) => {
                if (reason === 'backdropClick' || reason === 'escapeKeyDown') {
                    return false;
                }
            }}
            maxWidth="xs"
            aria-labelledby="confirmation-dialog-title"
            open={this.state.showDeleteConfirm}
        >
            <DialogTitle id="confirmation_dialog_title">Are you sure you want to delete this
                record?</DialogTitle>
            <DialogActions>
                <Button autoFocus onClick={this.deleteRR} className={"dns-blue-button text-white"}>
                    Delete
                </Button>
                <Button onClick={() => this.setState({showDeleteConfirm: false})}
                        className={"dns-blue-button text-white"}>
                    Cancel
                </Button>
            </DialogActions>
        </Dialog>
    }


    getRrGenForm() {
        const {rr, zoneData} = this.state

        let {pageButtons} = this.getRRPageButtons();


        return <Form>
            <Form.Group as={Row} className={"align-items-center"}>

                {!this.props.isEmptyForm &&
                    <> <Form.Label column sm="2" className={"font-weight-bold"}>
                        Zone ID
                    </Form.Label>
                        <Col sm="4">
                            {rr.rrGrp}
                        </Col></>}
                {!this.props.isEmptyForm &&
                    <> <Form.Label column sm="2" className={"font-weight-bold"}>
                        Record ID
                    </Form.Label>
                        <Col sm="4">
                            {rr.recId}
                        </Col></>}


            </Form.Group>


            <Form.Group as={Row} className={"align-items-center"}>

                <Form.Label column sm="2" className={"font-weight-bold"}>
                    {this.props.isEditable ? "*" : ""}GEN Record Name:
                </Form.Label>

                <Col sm="4">
                    {this.props.isEditable ?
                        <Form.Control name={"rrJson.lhs"}
                                      onChange={this.updateRRObj}
                                      onKeyDown={this.updateRRObj}

                                      className={"w-50 d-inline"}
                                      defaultValue={rr.rrJson.lhs ? rr.rrJson.lhs : ''}/> : rr.rrJson.lhs}
                    <span className={"d-inline"}>{`.${zoneData.zoneName}`}</span> {/*adding the trailing dot for lhs so
                     that user avoid adding dot after rrName.Need to updatte in git with iTrack number:[DRAGON3-343]*/}
                </Col>

            </Form.Group>

            <Form.Group as={Row} className={"align-items-center"}>
                {!this.props.isEmptyForm && !this.props.isEditable && <> <Form.Label column sm="2"
                                                                                     className={"font-weight-bold"}>
                    Create Time
                </Form.Label>
                    <Col sm="4">
                        {rr.createTime}
                    </Col></>}
                {!this.props.isEmptyForm && !this.props.isEditable && <>  <Form.Label column sm="2"
                                                                                      className={"font-weight-bold"}>
                    Last Modified
                </Form.Label>
                    <Col sm="4">
                        {rr.modTime}
                    </Col></>}

            </Form.Group>
            <Form.Group as={Row} className={"align-items-center"}>
                <Form.Label column sm="2" className={"font-weight-bold"}>
                    Type
                </Form.Label>
                <Col sm="4">
                    {this.props.isEditable ?
                        <Form.Control name={"rrJson.rrtype"}
                                      onChange={this.updateRRObj}
                                      onKeyDown={this.updateRRObj}
                                      defaultValue={rr.rrJson.rrtype ? rr.rrJson.rrtype : ''}/> : rr.rrJson.rrtype}
                </Col>

                {!this.props.isEmptyForm && !this.props.isEditable && <><Form.Label column sm="2"
                                                                                    className={"font-weight-bold"}>
                    Modified By
                </Form.Label>
                    <Col sm="4">
                        {rr.modBy}
                    </Col></>}

            </Form.Group>
            <Form.Group as={Row} className={"align-items-center"}>
                <Form.Label column sm="2" className={"font-weight-bold"}>
                    {this.props.isEditable ? "*" : ""}Network Address
                </Form.Label>
                <Col sm="4">
                    {this.props.isEditable ?
                        <>
                            {[0, 1, 2].map(k => <Form.Control name={`rrJson.rhs[${k}]`}
                                                              className={"w-25 d-inline-block mr-2"}
                                                              onChange={this.updateRRObj}
                                                              onKeyDown={this.updateRRObj}

                                                              key={`rrJson.rhs[${k}]`}
                                                              value={rr.rrJson.rhs[k]}/>)}.$
                        </>
                        : `${rr.rrJson.rhs.join('.')}`}

                </Col>
                <Form.Label column sm="2"
                            className={"font-weight-bold"}>Start
                </Form.Label>
                <Col sm="4">
                    {this.props.isEditable ?
                        <Form.Control name={"rrJson.lstart"}
                                      className={"w-25"}
                                      onChange={this.updateRRObj}
                                      onKeyDown={this.updateRRObj}

                                      defaultValue={rr.rrJson.lstart ? rr.rrJson.lstart : ''}/> : rr.rrJson.lstart}

                    {/*
                    {this.props.isEditable ? <span>valid range is 0 - 255</span> : ""}
*/}
                </Col>

            </Form.Group>

            <Form.Group as={Row} className={"align-items-center"}>
                <Form.Label column sm="2" className={"font-weight-bold"}>
                    Stop
                </Form.Label>
                <Col sm="4">
                    {this.props.isEditable ?
                        <Form.Control name={"rrJson.lstop"}
                                      className={"w-25"}
                                      onChange={this.updateRRObj}
                                      onKeyDown={this.updateRRObj}
                                      defaultValue={rr.rrJson.lstop ? rr.rrJson.lstop : ''}/> : rr.rrJson.lstop}

                </Col>
                <Form.Label column sm="2"
                            className={"font-weight-bold"}>
                    Step </Form.Label>


                <Col sm="4">
                    {this.props.isEditable ?
                        <Form.Control name={"rrJson.lstep"}
                                      onChange={this.updateRRObj}
                                      onKeyDown={this.updateRRObj}
                                      className={"w-25"}
                                      defaultValue={rr.rrJson.lstep ? rr.rrJson.lstep : ''}/> : rr.rrJson.lstep}

                </Col>

            </Form.Group>


            <Form.Group as={Row} className={"align-items-center"}>
                {!this.props.isEmptyForm && !this.props.isEditable && <><Form.Label column sm="2"
                                                                                    className={"font-weight-bold"}>
                    Width
                </Form.Label>
                    <Col sm="4">
                        {this.props.isEditable ?
                            <Form.Control name={"rrJson.width"}
                                          onChange={this.updateRRObj}
                                          onKeyDown={this.updateRRObj}
                                          className={"w-25"}
                                          defaultValue={rr.rrJson.rwidth ? rr.rrJson.rwidth : ''}/> : rr.rrJson.rwidth}

                    </Col></>}


                {(this.props.isEmptyForm || !this.props.isEditable) && <><Form.Label column sm="2"
                                                                                     className={"font-weight-bold"}>
                    Offset </Form.Label>
                    <Col sm="4">
                        {this.props.isEditable ?
                            <Form.Control name={"rrJson.loffset"}
                                          onChange={this.updateRRObj}
                                          onKeyDown={this.updateRRObj}
                                          className={"w-25"}
                                          defaultValue={rr.rrJson.loffset ? rr.rrJson.loffset : ''}/> : rr.rrJson.loffset}
                    </Col></>}
            </Form.Group>


            <Form.Group as={Row} className={"align-items-center"}>
                <Form.Label column sm="2" className={"font-weight-bold w-25"}>
                    Radix
                </Form.Label>
                <Col sm="4">
                    {this.props.isEditable ? <Form.Control as="select" name={"rrJson.radix"}
                                                           onChange={this.updateRRObj}
                                                           onKeyDown={this.updateRRObj}
                                                           value={rr.rrJson.rtype}>
                            <option value={"d"}>d</option>
                            <option value={"X"}>X</option>
                            <option value={"o"}>o</option>
                            <option value={"x"}>x</option>
                        </Form.Control>
                        : rr.rrJson.rtype}                    </Col>

                <Form.Label column sm="2" className={"font-weight-bold"}>
                    Collision </Form.Label>
                <Col sm="4">
                    {this.props.isEditable ? <Form.Control as="select" name={"rrJson.collision"}
                                                           onChange={this.updateRRObj}
                                                           onKeyDown={this.updateRRObj}
                                                           value={rr.rrJson.ltype}>
                            <option value={"y"}>Y</option>
                            <option value={"n"}>N</option>
                        </Form.Control>
                        : rr.rrJson.ltype}                    </Col>
            </Form.Group>


            <Form.Group as={Row} className={"align-items-center"}>
                <Form.Label column sm="2" className={"font-weight-bold"}>
                    Comment
                </Form.Label>
                <Col sm="4">
                    {this.props.isEditable ?
                        <Form.Control name={"comments"}
                                      onChange={this.updateRRObj}
                                      onKeyDown={this.updateRRObj}
                                      defaultValue={rr.comments ? rr.comments : ''}/> : rr.comments}
                </Col>
                <Form.Label column sm="2" className={"font-weight-bold"}>
                    Time To Live
                </Form.Label>
                <Col sm="4">
                    {this.props.isEditable ?
                        <Form.Control name={"rrTtl"}
                                      onChange={this.updateRRObj}
                                      onKeyDown={this.updateRRObj}
                                      defaultValue={rr.rrTtl ? rr.rrTtl : ''}/> : rr.rrTtl}
                </Col>
            </Form.Group>


            <div className={"text-center"}>
                {pageButtons.map(buttonComp => buttonComp)}
            </div>


            <h6 className={"font-weight-bold"}>How the GEN Record Works</h6>
            <p>
                The <b>GEN</b> record generates between 2 and 256 DNS <b>A</b> records. The <b>$</b> character in the
                record is replaced
                by an iterator, which is controlled by the <b>start</b>, <b>stop</b>, and <b>step</b> fields. These
                fields determine how many <b>A</b> records are created.
            </p>
            <h6 className={"font-weight-bold"}>NOTE:</h6> <p>The automatic generation of A records from GEN records
            currently only works for IPv4 records.
        </p>
            <p>The <b>width</b>, <b>offset</b>, and <b>radix</b> fields are usually left at their default values; in
                more complex cases, they
                can be used to alter the names of the DNS <b>A</b> records.
            </p>
            <h6 className={"font-weight-bold"}> Examples</h6>
            <p><b>Record Name </b>= dallas<b>$</b>tx.<b>example.com</b>, <b>Network Address</b> = 12.13.14.$, <b>start,stop,
                step</b> = 20, 50, 1. The
                iterator will move from 20 to 50 in increments of 1 and generate 31 <b>A</b> records:
            </p>
            <p>dallas<b>20</b>tx.example.com. IN A 12.13.14.<b>20</b><br/>
                dallas<b>21</b>tx.example.com. IN A 12.13.14.<b>21</b><br/>
                ...<br/>
                dallas<b>50</b>tx.example.com. IN A 12.13.14.<b>50</b><br/>
            </p>
            <p>
                Changing the <b>step</b> field from 1 to 2 causes the iterator to advance in increments of 2, and
                generates 16 <b>A</b> records:<br/>
                <p></p>
                dallas<b>20</b>tx.example.com. IN A 12.13.14.<b>20</b><br/>
                dallas<b>22</b>tx.example.com. IN A 12.13.14.<b>22</b><br/>
                ...<br/>
                dallas<b>50</b>tx.example.com. IN A 12.13.14.<b>50</b><br/>
            </p>
            <p>
                Note: DRAGON will return an error if you try to create 2 <b>GEN</b> records in the same zone that have
                the
                same <b>Record Name</b> and whose IP addresses would overlap. When the <b>Collision</b> field is set to
                Y, DRAGON will
                return an error if the IP addresses of 2 records overlap, even if the <b>Record Name</b> fields are
                different.</p>
            <p></p>
            <p>The <b>width</b>, <b>offset</b>, and <b>radix</b> fields can be used to alter the name, but not the IP
                address, of the DNS <b>A</b> records.</p>
            <p></p>
            <p> Changing the <b>width</b> field from 1 to 4 will cause the iterator to be padded with leading zeros so
                that the
                field is 4 characters long:<br/>

                dallas<b>0020</b>tx.example.com. IN A 12.13.14.<b>20</b><br/>
                dallas<b>0021</b>tx.example.com. IN A 12.13.14.<b>21</b><br/>
                ...<br/>
                dallas<b>0050</b>tx.example.com. IN A 12.13.14.<b>50</b><br/>
                <p></p>
                Changing the <b>offset</b> field from 0 to 40 will add 40 to the value of the iterator:<br/>
                <p></p>
                dallas<b>60</b>tx.example.com. IN A 12.13.14.<b>20</b><br/>
                dallas<b>61</b>tx.example.com. IN A 12.13.14.<b>21</b><br/>
                ...<br/>
                dallas<b>90</b>tx.example.com. IN A 12.13.14.<b>50</b><br/>
                <p></p>
                Changing the <b>radix</b> field from <b>d</b> (decimal) to <b>X</b> (hexadecimal) will cause the
                iterator to be printed in
                hexadecimal notation:
                <p></p>
                dallas<b>14</b>tx.example.com. IN A 12.13.14.<b>20</b><br/>
                dallas<b>15</b>tx.example.com. IN A 12.13.14.<b>21</b><br/>
                ...<br/>
                dallas<b>2E</b>tx.example.com. IN A 12.13.14.<b>46</b><br/>
                dallas<b>2F</b>tx.example.com. IN A 12.13.14.<b>47</b><br/>
                dallas<b>30</b>tx.example.com. IN A 12.13.14.<b>48</b><br/>
                dallas<b>31</b>tx.example.com. IN A 12.13.14.<b>49</b><br/>
                dallas<b>32</b>tx.example.com. IN A 12.13.14.<b>50</b></p>

        </Form>
    }


    componentWillUnmount() {
        this.isComponentMounted = false;
    }

    render() {
        let {pageTitle} = this.getRRPageButtons();

        if (this.state.loading) {
            return <div>Loading....</div>
        }
        console.log(this.state, "state")
        return (
            <>
                {this.getDeleteConfirmDialog()}
                <Backdrop className={"page-loading"} style={{'zIndex': '10000', 'color': '#fff'}}
                          open={this.state.loading}>
                    <CircularProgress color="inherit"/>
                </Backdrop>
                <div>
                    <Helmet>
                        <title>DNS Admin | DNS GEN Records Details Page</title>
                    </Helmet>
                    <Container maxWidth={false} className={"px-2"}>
                        <Card>
                            <CardContent>
                                <div className={'mt-3 ml-3 mr-3 mb-3'}>
                                    <h5 className="font-weight-bold  text-capitalize text-left pt-1 pl-2">{pageTitle}</h5>

                                    <div className={"pb-2"}>
                                        {this.props.alert.message && <Alert
                                            severity={this.props.alert.type}>{this.props.alert.message}</Alert>}</div>
                                    {this.getRrGenForm()}
                                </div>
                            </CardContent>
                        </Card>
                    </Container>
                </div>
            </>
        )
    }

}

RrGen.defaultProps = {
    isEditable: false,
};
RrGen.propTypes = {
    isEditable: PropTypes.bool,
    isEmptyForm: PropTypes.bool
};
RrGen.defaultProps = {
    isEditable: false,
    isEmptyForm: false
}

function mapState(state) {
    const {loading, zone} = state.zones

    const {alert, clear} = state
    return {loading, alert, zone, clear}
}

const actionCreators = {
    createOrUpdate: resourceRecordActions.createOrUpdate,
    delete: resourceRecordActions.delete,
    alertClear: alertActions.clear,
    getZoneById: zoneActions.getZoneById,

};


const connectedRrGen = withRouter(connect(mapState, actionCreators)(RrGen));
export {connectedRrGen as RrGen};

