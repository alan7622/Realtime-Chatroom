import React from "react";
import {alertActions, zoneActions} from "../../../../_actions";
import {connect} from "react-redux";
import {
    CardContent,
    Card,
    Dialog,
    DialogTitle,
    DialogContent,
    FormControl,
    InputLabel,
    Select,
    MenuItem,
    RadioGroup,
    FormControlLabel,
    Radio, DialogActions, Button
} from "@material-ui/core";
import {Helmet} from "react-helmet";
import Container from "@material-ui/core/Container";
import Box from "@material-ui/core/Box";
import BootstrapTable from 'react-bootstrap-table-next';
import {Comparator} from 'react-bootstrap-table2-filter';
import paginationFactory from 'react-bootstrap-table2-paginator';
import _ from "lodash";
import {Alert} from "@material-ui/lab";
import {Link, withRouter} from "react-router-dom";
import {zoneService} from "../../../../_services";
import {resourceRecordService} from "../../../../_services/resourceRecord.service";
import {isAuthorized, pageRenderer, SizePerPageRenderer} from "../../../../_components";
import Form from "react-bootstrap/Form";
import {Col, Row} from "react-bootstrap";
import {ComparatorHelper} from "../../../../_helpers";

const defaultFilters = {
    rrData: {comparator: 'Eq', value: ''},
    name: {comparator: 'Eq', value: ''},
    order: {
        by: "name",
        dir: "asc"
    },
    rrType: "",
}

class Search extends React.Component {

    constructor(props) {
        super(props);
        this.state = {
            data: [],
            zoneName: '',
            zoneData: '',
            rrType: '',
            loading: true,
            comparator: Comparator.EQ,
            filters: _.cloneDeep(defaultFilters),
            showDeleteConfirm: false,
            showAdvanceSearch: false,
            showInfo: false,
            error: '',
            rrSearchParams: {},
            page: 1,
            sizePerPage: 10,
            totalSize: 0,
        }

        console.log("test")


        this.isComponentMounted = false;
        this.getAdvanceSearchDialog = this.getAdvanceSearchDialog.bind(this);
        // this.getInfoDialog=this.getInfoDialog.bind(this);
        this.handleFilterChange = this.handleFilterChange.bind(this)
        this.handleTableChange = this.handleTableChange.bind(this);
        this.updateRRObj = this.updateRRObj.bind(this);


        if ((this.props.location.state === null || this.props.location.state === undefined || !this.props.location.state.showAlerts) && !_.isEmpty(this.props.alert)) {
            this.props.alertClear()
        }
    }


    async componentDidMount() {
        console.log("inside mount")

        this.isComponentMounted = true;
      /*  setTimeout(() => {
            this.props.alertClear()
        }, 10000)*/
        await this.loadTableData({
            zoneNum: this.props.match.params.zoneNum,
            rrType: this.props.match.params.type,
            numberOfRows: this.state.sizePerPage,
            pageNumber: this.state.page
        });

        this.props.getZoneById(this.props.match.params.zoneNum)
    }


    async loadTableData(data) {

        this.setState({loading: true})

        for (var key in this.state.filters) {
            if (this.state.filters.hasOwnProperty(key) &&
                this.state.filters[key].value) {
                data[key +
                this.state.filters[key].comparator] = this.state.filters[key].value;
            }
        }
        data = {
            ...data,
            zoneNum: this.props.match.params.zoneNum,
            rrType: this.props.match.params.type
        }


        const res = await resourceRecordService.getAllRecords(data);
        if (this.isComponentMounted) {
            //   this.setState({loading: false, data: res.rr, error: res.error});
            this.setState({
                loading: false, data: res.rr, error: res.error, totalSize: res.totalRecords,
                page: data.pageNumber ? data.pageNumber : this.state.page,
                sizePerPage: data.numberOfRows ?
                    data.numberOfRows :
                    this.state.sizePerPage,
            });
        }
    }

    componentDidUpdate(prevProps, prevState, snapshot) {
        console.log(_.isEqual(prevProps.zone, this.props.zone),"this.props - Zone.jsx")
        if( ((this.state.loading && this.props.zone)|| !_.isEqual(prevProps.zone, this.props.zone))) {

            this.setState({
                zoneData: _.omit(this.props.zone, ['soaTemplate']),
                loading: false
            }, () => {

                if( prevProps.zone?.zoneStatus != this.props.zone?.zoneStatus) {
                    console.log("this.props - Zone.jsx")
                    this.props.updateMenu();
                }})
        }
    }


    componentWillUnmount() {
        this.isComponentMounted = false;
    }


    handleFilterChange(e) {
        const {name, value} = e.target;
        const {filters} = this.state;
        const filterInfo = name.split('.');
        if (filterInfo.length === 3) {
            var t = filters[filterInfo[0]][filterInfo[1]].split('.')
            t[filterInfo[2]] = value
            filters[filterInfo[0]][filterInfo[1]] = t.join('.');
        } else {
            filters[filterInfo[0]][filterInfo[1]] = value;
        }
        this.setState({filters: filters});
    }


    async handleTableChange(type, {filters, page, sortOrder, sortField, sizePerPage, totalSize}) {
        const currentIndex = (page - 1) * sizePerPage;
        let rrSearchParams = {};
        if (sortField && sortOrder) {
            rrSearchParams.orderDir = sortOrder;
            rrSearchParams.orderBy = sortField;
        }

        rrSearchParams.numberOfRows = sizePerPage;
        rrSearchParams.pageNumber = page;
        await this.loadTableData(rrSearchParams);

    }


    getRrGenForTableColumns() {

        return [

            {
                text: 'GEN Record',
                dataField: 'rrJson.lhs',
                headerAlign: 'center',
                //   sort: true,
                headerStyle: {
                    width: "30%",
                },
                //formatter: (cell, row) => row.rrJson.split(" ")[0],
                classes: 'text-left p-0',
                style: {
                    'wordWrap': 'break-word'
                },
            },
            {
                text: 'Network Address',
                dataField: 'rrJson.rhs',
                headerAlign: 'center',
                headerStyle: {
                    width: "30%",
                },
                classes: 'text-left p-0',
                style: {
                    'wordWrap': 'break-word'
                },
            },
            {
                text: 'Last Modified',
                dataField: 'modTime',
                showHideSelection: true,
                headerAlign: 'center',
                headerStyle: {
                    width: "30%"
                },
                classes: 'text-left p-0',
                style: {
                    'wordWrap': 'break-word'
                },
            },
            {
                text: "Action",
                dataField: "",
                headerAlign: 'center',
                headerStyle: {
                    width: "10%"
                },

                formatter: (cell, row, rowIndex) => <>
                    <Link
                        to={`/dns/zones/details/${this.props.match.params.zoneNum}/rr/${this.props.match.params.type}/details/${row.recId}`}
                        key={"details_record" + rowIndex}
                        className={"color-dragon-blue mr-2"}
                    >Details</Link>
                    {isAuthorized('ru') && <Link
                        to={`/dns/zones/details/${this.props.match.params.zoneNum}/rr/${this.props.match.params.type}/edit/${row.recId}`}
                        key={"edit_record" + rowIndex}
                        className={"color-dragon-blue"}
                    >Edit</Link>}
                </>
            },


        ];
    }

    updateRRObj(e) {
        let {name, value} = e.target;
        const {rr} = this.state;

        this.setState({rr: {...rr, [name]: value}})
    }

    getAdvanceSearchDialog() {
        const {zoneData, rr} = this.state

        return <Dialog
            fullWidth={true}
            onClose={(event, reason) => {
                if (reason === 'backdropClick' || reason === 'escapeKeyDown') {
                    return false;
                }
            }}
            maxWidth="lg"
            open={this.state.showAdvanceSearch}
        >
            <DialogTitle id="form-dialog-title" className={"dialog-text-font-size"}> DNS Search Resource Records Page
            </DialogTitle>
            <h6 className={"ml-4"}>Search for GEN Records

            </h6>

            <DialogContent>
                <Form>
                    <Form.Group as={Row} className={'align-items-center'}>
                        <Form.Label column sm="2" className={'font-weight-bold'}>
                            Resource Record Name </Form.Label>
                        <Col sm={2}>
                            <FormControl variant="outlined">
                                <InputLabel htmlFor="wildcard-name-search">Resource Record Name </InputLabel>
                                <Select
                                    autoWidth={true}
                                    className={'w-100'}
                                    name={'name.comparator'}
                                    value={this.state.filters.name.comparator}
                                    onChange={this.handleFilterChange}
                                    label="Resource Record Name"
                                >
                                    {ComparatorHelper.getComparators.map(obj => (
                                        <MenuItem value={obj.value}
                                                  key={obj.value}>{obj.label}</MenuItem>
                                    ))}

                                </Select>
                            </FormControl>

                        </Col>
                        <Col sm={4}>
                            <Form.Control name={'name.value'}
                                          value={this.state.filters.name.value}
                                          className={"w-75 d-inline"}

                                          onChange={this.handleFilterChange}
                            />
                            <span className={"d-inline"}> {zoneData.zoneName}</span>
                        </Col>

                    </Form.Group>

                    <Form.Group as={Row} className={'align-items-center'}>
                        <Form.Label column sm="2" className={'font-weight-bold'}>
                            Ip Address: </Form.Label>


                        {/*
                        <Col sm="4">

                                    <Form.Control name={"rrRhs0"} className={"w-25 d-inline-block mr-2"}
                                                  onChange={this.updateRRObj}
                                                  defaultValue={rr.rhs0 ? rr.rhs0 : ''}/>
                                    <Form.Control name={"rrRhs1"} className={"w-25 d-inline-block mr-2"}
                                                  onChange={this.updateRRObj}
                                                  defaultValue={rr.rhs1 ? rr.rhs1 : ''}/>
                                    <Form.Control name={"rrRhs2"} className={"w-25 d-inline-block mr-2"}
                                                  onChange={this.updateRRObj}
                                                  defaultValue={rr.rhs2 ? rr.rhs2 : ''}/>

                            {}
                            <span className={"d-inline"}> {".$"}</span>

                        </Col>
*/}


                        {/*
                        <Col sm={2}>
                            <FormControl variant="outlined">
                                <InputLabel htmlFor="wildcard-name-search">Canonical Name </InputLabel>
                                <Select
                                    autoWidth={true}
                                    className={'w-100'}
                                    name={'rrData.comparator'}
                                    value={this.state.filters.rrData.comparator}
                                    onChange={this.handleFilterChange}
                                    label="Canonical Name"
                                >
                                    {CnameRecordHelper.getCanonicalComparators.map(obj => (
                                        <MenuItem value={obj.value}
                                                  key={obj.value}>{obj.label}</MenuItem>
                                    ))}

                                </Select>
                            </FormControl>

                        </Col>
*/}
                        <Col sm={4}>
                            <Form.Control name={'rrData.value'}
                                          value={this.state.filters.rrData.value}
                                          className={"w-75 d-inline"}

                                          onChange={this.handleFilterChange}
                            />
                        </Col>

                    </Form.Group>


                    <Form.Group as={Row} className={"align-items-center"}>
                        <Form.Label column sm="3" className={'font-weight-bold'}>
                            Ordered By </Form.Label>
                        <Col sm={9}>
                            <RadioGroup value={this.state.filters.order.by} name={"order.by"}
                                        onChange={this.handleFilterChange} row={true}>

                                <FormControlLabel value="name"
                                                  control={<Radio color="primary"/>}
                                                  label="Resource Record Name"/>

                            </RadioGroup>
                        </Col>
                    </Form.Group>
                    <Form.Group as={Row} className={"align-items-center"}>
                        <Form.Label column sm="3" className={'font-weight-bold'}>
                            Ordered Direction </Form.Label>
                        <Col sm={9}>
                            <RadioGroup value={this.state.filters.order.dir} name={"order.dir"}
                                        onChange={this.handleFilterChange} row={true}>

                                <FormControlLabel value="asc"
                                                  control={<Radio color="primary"/>}
                                                  label="Ascending"/>
                                <FormControlLabel value="desc" control={<Radio color="primary"/>}
                                                  label="Descending"/>


                            </RadioGroup>
                        </Col>
                    </Form.Group>

                </Form>
            </DialogContent>

            <DialogActions>
                <Button onClick={async (e) => {
                    await this.loadTableData({numberOfRows: this.state.sizePerPage, pageNumber: this.state.page});
                    this.setState(
                        {showAdvanceSearch: false});
                }
                } color="primary" className={'dns-blue-button text-white'}
                >
                    Search RRs
                </Button>
                <Button onClick={() => this.setState(
                    {showAdvanceSearch: false})}
                        color="primary" className={'dns-blue-button text-white'}>
                    Close
                </Button>
                <Button type={"reset"} onClick={() => {
                    this.setState({filters: _.cloneDeep(defaultFilters)}, () => {
                        this.loadTableData({numberOfRows: 10, pageNumber: 1})
                    });
                }} variant="contained"
                        className={"dns-blue-button text-white ml-2"}
                        disabled={JSON.stringify(this.state.filters) === JSON.stringify(defaultFilters)}>clear</Button>

            </DialogActions>


        </Dialog>
    }

    /*
        getInfoDialog() {
            const {zoneData, rr} = this.state

            return <Dialog
                fullWidth={true}
                onClose={(event, reason) => {
                    if (reason === 'backdropClick' || reason === 'escapeKeyDown') {
                        return false;
                    }
                }}
                maxWidth="lg"
                open={this.state.showInfo}
            >
                <DialogTitle id="form-dialog-title" className={"dialog-text-font-size font-weight-bold"}> How the GMSFOR Record Works
                </DialogTitle>

                <DialogContent>
                    <p>
                        The <b>GMSFOR</b> record generates between 2 and 256 DNS <b>A</b> records. The <b>$</b> character in the
                        record is replaced
                        by an iterator, which is controlled by the <b>start</b>, <b>stop</b>, and <b>step</b> fields. These
                        fields determine how many <b>A</b> records are created.
                    </p>
                    <h6 className={"font-weight-bold"}>NOTE:</h6> <p>The automatic generation of A records from GMSFOR records
                    currently only works for IPv4 records.
                </p>
                    <p>The <b>width</b>, <b>offset</b>, and <b>radix</b> fields are usually left at their default values; in
                        more complex cases, they
                        can be used to alter the names of the DNS <b>A</b> records.
                    </p>
                    <h6 className={"font-weight-bold"}> Examples</h6>
                    <p><b>Record Name </b>= dallas<b>$</b>tx.<b>example.com</b>, <b>Network Address</b> = 12.13.14.$, <b>start,stop,
                        step</b> = 20, 50, 1. The
                        iterator will move from 20 to 50 in increments of 1 and generate 31 <b>A</b> records:
                    </p>
                    <p>dallas<b>20</b>tx.example.com. IN A 12.13.14.<b>20</b><br/>
                        dallas<b>21</b>tx.example.com. IN A 12.13.14.<b>21</b><br/>
                        ...<br/>
                        dallas<b>50</b>tx.example.com. IN A 12.13.14.<b>50</b><br/>
                    </p>
                    <p>
                        Changing the <b>step</b> field from 1 to 2 causes the iterator to advance in increments of 2, and
                        generates 16 <b>A</b> records:<br/>
                        <p></p>
                        dallas<b>20</b>tx.example.com. IN A 12.13.14.<b>20</b><br/>
                        dallas<b>22</b>tx.example.com. IN A 12.13.14.<b>22</b><br/>
                        ...<br/>
                        dallas<b>50</b>tx.example.com. IN A 12.13.14.<b>50</b><br/>
                    </p>
                    <p>
                        Note: DRAGON will return an error if you try to create 2 <b>GMFOR</b> records in the same zone that have
                        the
                        same <b>Record Name</b> and whose IP addresses would overlap. When the <b>Collision</b> field is set to
                        Y, DRAGON will
                        return an error if the IP addresses of 2 records overlap, even if the <b>Record Name</b> fields are
                        different.</p>
                    <p></p>
                    <p>The <b>width</b>, <b>offset</b>, and <b>radix</b> fields can be used to alter the name, but not the IP
                        address, of the DNS <b>A</b> records.</p>
                    <p></p>
                    <p> Changing the <b>width</b> field from 1 to 4 will cause the iterator to be padded with leading zeros so
                        that the
                        field is 4 characters long:<br/>

                        dallas<b>0020</b>tx.example.com. IN A 12.13.14.<b>20</b><br/>
                        dallas<b>0021</b>tx.example.com. IN A 12.13.14.<b>21</b><br/>
                        ...<br/>
                        dallas<b>0050</b>tx.example.com. IN A 12.13.14.<b>50</b><br/>
                        <p></p>
                        Changing the <b>offset</b> field from 0 to 40 will add 40 to the value of the iterator:<br/>
                        <p></p>
                        dallas<b>60</b>tx.example.com. IN A 12.13.14.<b>20</b><br/>
                        dallas<b>61</b>tx.example.com. IN A 12.13.14.<b>21</b><br/>
                        ...<br/>
                        dallas<b>90</b>tx.example.com. IN A 12.13.14.<b>50</b><br/>
                        <p></p>
                        Changing the <b>radix</b> field from <b>d</b> (decimal) to <b>X</b> (hexadecimal) will cause the
                        iterator to be printed in
                        hexadecimal notation:
                        <p></p>
                        dallas<b>14</b>tx.example.com. IN A 12.13.14.<b>20</b><br/>
                        dallas<b>15</b>tx.example.com. IN A 12.13.14.<b>21</b><br/>
                        ...<br/>
                        dallas<b>2E</b>tx.example.com. IN A 12.13.14.<b>46</b><br/>
                        dallas<b>2F</b>tx.example.com. IN A 12.13.14.<b>47</b><br/>
                        dallas<b>30</b>tx.example.com. IN A 12.13.14.<b>48</b><br/>
                        dallas<b>31</b>tx.example.com. IN A 12.13.14.<b>49</b><br/>
                        dallas<b>32</b>tx.example.com. IN A 12.13.14.<b>50</b></p>
                </DialogContent>


                <DialogActions>
                    <Button onClick={async (e) => {
                        await this.loadTableData({numberOfRows: this.state.sizePerPage, pageNumber: this.state.page});
                        this.setState(
                            {showAdvanceSearch: false});
                    }
                    } color="primary" className={'dns-blue-button text-white'}
                    >
                        Search RRs
                    </Button>
                    <Button onClick={() => this.setState(
                        {showAdvanceSearch: false})}
                            color="primary" className={'dns-blue-button text-white'}>
                        Close
                    </Button>
                    <Button type={"reset"} onClick={() => {
                        this.setState({filters: _.cloneDeep(defaultFilters)}, () => {
                            this.loadTableData({numberOfRows: 10, pageNumber: 1})
                        });
                    }} variant="contained"
                            className={"dns-blue-button text-white ml-2"}
                            disabled={JSON.stringify(this.state.filters) === JSON.stringify(defaultFilters)}>clear</Button>

                </DialogActions>


            </Dialog>
        }
    */


    paginationOptions() {
        return {
            sizePerPage: this.state.sizePerPage,
            page: this.state.page,
            totalSize: this.state.totalSize,
            alwaysShowAllBtns: true,
            withFirstAndLast: true,
            firstPageText: 'First',
            prePageText: 'Back',
            nextPageText: 'Next',
            lastPageText: 'Last',
            nextPageTitle: 'First page',
            prePageTitle: 'Pre page',
            firstPageTitle: 'Next page',
            lastPageTitle: 'Last page',
            showTotal: false,
            sizePerPageList: [
                {
                    text: '10', value: 10
                }, {
                    text: '20', value: 20
                },
                {
                    text: '50', value: 50
                },],
            pageButtonRenderer: pageRenderer,
            sizePerPageRenderer: ({
                                      options,
                                      currSizePerPage,
                                      onSizePerPageChange
                                  }) => <SizePerPageRenderer options={options}
                                                             currSizePerPage={currSizePerPage}
                                                             onSizePerPageChange={onSizePerPageChange}/>,

            disablePageTitle: true,
        };
    }


    render() {
        const paginationOptions = this.paginationOptions();
        const {data} = this.state;
        console.log(data, "data")

        const columns = this.getRrGenForTableColumns();
        return (

            <div>
                <Helmet>
                    <title>DNS Resource Records|GEN Record</title>
                </Helmet>
                <Box>
                    <Container maxWidth={false} className={"px-2"}>
                        <Card>
                            <CardContent className={"px-0"}>
                                <div className={'mt-3 ml-3 mr-3 mb-3'}>
                                    <h5 className="font-weight-bold  text-capitalize text-left pt-1  pl-2">
                                        DNS Host Information (GEN) Records List
                                    </h5>
                                    {this.getAdvanceSearchDialog()}
                                    {/*
                                    {this.getInfoDialog()}
*/}

                                    <div>
                                        {(!_.isEmpty(this.state.error) || !_.isEmpty(this.props.alert.message)) &&
                                            <Alert
                                                severity={!_.isEmpty(this.state.error) ? "error" : this.props.alert.type}>{(this.state.error && this.state.error.text) || this.props.alert.message}</Alert>}
                                        <div className="pl-2 pr-2">
                                            <div className={"col text-right mt-2 mb-1"}>
                                                {isAuthorized('ri') && <Link
                                                    className={"d-inline-block btn btn-primary dns-blue-button mr-1"}
                                                    to={"/dns/zones/details/" + this.props.match.params.zoneNum + "/rr/" + this.props.match.params.type + "/create"}
                                                >Insert Record</Link>}
                                                {/*  <Button aria-controls="simple-menu"
                                                        aria-haspopup="true"
                                                        color="primary"
                                                        className={'dns-blue-button mr-2'}
                                                        variant={'contained'}
                                                        onClick={() => {
                                                            this.setState(
                                                                {showInfo: true});
                                                        }} key={"info_gen"}>How it works</Button>*/}

                                                <Button aria-controls="simple-menu"
                                                        aria-haspopup="true"
                                                        color="primary"
                                                        className={'dns-blue-button'}
                                                        variant={'contained'}
                                                        onClick={() => {
                                                            this.props.alertClear();
                                                            this.setState(
                                                                {showAdvanceSearch: true});
                                                        }} key={'advance_search'}>Search</Button>
                                                {(JSON.stringify(this.state.filters) !== JSON.stringify(defaultFilters)) &&
                                                    <Button type={"reset"} onClick={() => {
                                                        this.setState({filters: _.cloneDeep(defaultFilters)}, () => {
                                                            this.loadTableData({numberOfRows: 10, pageNumber: 1})
                                                        });
                                                    }} variant="contained"
                                                            className={"dns-blue-button text-white ml-2"}


                                                    >clear</Button>
                                                }

                                            </div>

                                            <div className={"pt-2 pb-2"}>
                                            <span
                                                className={'font-weight-bold'}>Zone Name</span>: {this.state.zoneData.zoneName}

                                                <span
                                                    className={'font-weight-bold  pl-5'}>Zone ID</span> : {this.state.zoneData.zoneNum}<br/>
                                            </div>

                                            <BootstrapTable bootstrap4
                                                            keyField="recId"
                                                            data={data}
                                                            remote={{
                                                                pagination: true,
                                                            }}
                                                            onTableChange={this.handleTableChange}
                                                            columns={columns}
                                                            pagination={paginationFactory(paginationOptions)}
                                                            noDataIndication="Table is Empty"
                                                            id={"rr_genfor_table"}
                                                            condensed
                                            />
                                        </div>
                                    </div>
                                </div>
                            </CardContent>
                        </Card>
                    </Container>
                </Box>
            </div>);
    }
}


function mapState(state) {
    const { loading,  zone} = state.zones

    const {alert, clear} = state
    return { loading, alert, zone, clear}
}


const actionCreators =
    {
        alertClear: alertActions.clear,
        getZoneById: zoneActions.getZoneById,

    }

const connectedRrGen = withRouter(connect(mapState, actionCreators)(Search));
export {connectedRrGen as Search};