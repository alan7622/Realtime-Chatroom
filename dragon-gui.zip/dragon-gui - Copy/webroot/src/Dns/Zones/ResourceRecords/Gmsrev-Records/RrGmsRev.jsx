import React, {Component} from "react";
import Container from "@material-ui/core/Container";
import {withRouter} from "react-router-dom";
import {
    Backdrop,
    Button,
    Card,
    CardContent,
    CircularProgress,
    Dialog,
    DialogActions,
    DialogTitle,
    Paper
} from "@material-ui/core";
import PropTypes from "prop-types";
import {alertActions} from "../../../../_actions";
import Form from 'react-bootstrap/Form'
import {Col} from "react-bootstrap";
import {Row} from "react-bootstrap";
import {Alert} from '@material-ui/lab';
import {connect} from "react-redux";
import {Helmet} from "react-helmet";
import {resourceRecordService} from "../../../../_services/resourceRecord.service";
import {resourceRecordActions} from "../../../../_actions/resourceRecords.actions";
import _ from "lodash";
import {zoneService} from "../../../../_services";


class RrGmsRev extends Component {
    constructor(props) {
        super(props);
        this.state = {
            loading: false,
            //saving: false,
            showDeleteConfirm: false,
            zoneData: {},
            rr: {
                rrGrp: this.props.match.params.zoneNum,
                rrStr: '',
                rrType: this.props.match.params.type,
                comments: '',
                recId: '',

            },
            alert: '',

        };
        this.isComponentMounted = false;
        this.saveGmsRev = this.saveGmsRev.bind(this);
        this.updateRRObj = this.updateRRObj.bind(this);
        this.deleteRR = this.deleteRR.bind(this);
        this.getDeleteConfirmDialog = this.getDeleteConfirmDialog.bind(this);


        console.log(this.props)
        if ((this.props.location.state === undefined || !this.props.location.state.showAlerts) && !_.isEmpty(this.props.alert)) {
            this.props.alertClear()
        }

    }


    saveGmsRev() {
        this.setState({loading: true})

        let res = null
        if (this.props.isEmptyForm && this.props.isEditable) {
            console.log("Resource Record Text", this.state.rr)
            //rrGrp			same as zoneNum for now
            // rrStr 			entire RR record comes from user
            // rrType			type of RR from url
            // comments		comments from user

            this.props.create(this.state.rr);
        } else {

            let rrDetails = {}
            for (var key in this.state.rr) {
                if (['rrType', 'rrStr ', 'comments', 'json'].includes(key)) {
                    if (key == 'rrType') {
                        rrDetails[key] = this.state.rr[key].toUpperCase()
                    } else {
                        rrDetails[key] = this.state.rr[key]
                    }
                }
            }
            rrDetails.rrJson = `${this.state.rhs0}-${this.state.rhs1}-${this.state.rhs2}-${this.state.rhs3}`


            /*    let rrDetails = {}
                for (var key in this.state.rr) {
                    if (['rrType', 'rrStr ', 'comments', 'json'].includes(key)) {
                        if (key == 'rrType') {
                            rrDetails[key] = this.state.rr[key].toUpperCase()
                        } else {
                            rrDetails[key] = this.state.rr[key]
                        }
                    }
                }*/
            this.props.update(this.props.match.params.id, rrDetails, false);
            console.log(res)
        }

    }

    async componentDidMount() {
        if (!this.props.isEmptyForm) {
            this.isComponentMounted = true;
            const zoneData = await zoneService.getZoneById(this.props.match.params.zoneNum)
            this.setState({zoneData: zoneData});
            if (this.isComponentMounted) {
                const rr = await resourceRecordService.getByRecordId(this.props.match.params.id);
                if (!_.isEmpty(rr)) {
                    console.log(this.props.match.params.zoneNum, "ZONE API-RR-RrGmsRev")
                    this.setState({loading: false, rr: rr});

                } else {
                    this.props.alertClear()
                    this.props.history.push(`/dns/zones/details/${this.props.match.params.zoneNum}/rr/${this.props.match.params.type}`);
                }
            }
        }
    }

    deleteRR() {
        this.setState({showDeleteConfirm: false, loading: true})
        this.props.delete(this.props.match.params.id);
    }


    componentWillUnmount() {
        this.isComponentMounted = false;
    }


    updateRRObj(e) {
        let {name, value} = e.target;
        const {rr} = this.state;

        this.setState({rr: {...rr, [name]: value}})
    }


    getRRPageButtons() {
        let pageElements = {
            pageTitle: '',
            pageButtons: [],
        }
        if (this.props.isEditable && this.props.isEmptyForm) {
            pageElements.pageTitle = "DNS Host Information (GMSRev) Record Creation"
            pageElements.pageButtons.push(<Button className={"dns-blue-button text-white mr-2"}
                                                  onClick={this.saveGmsRev}
                                                  key={"insert"}>Insert</Button>)
            pageElements.pageButtons.push(<Button className={"dns-blue-button text-white mr-2 col-md-1"}
                                                  onClick={() => this.props.history.push(`/dns/zones/details/${this.props.match.params.zoneNum}/rr/${this.props.match.params.type}`)}
                                                  key={"cancel_update"}>Cancel</Button>)


        } else if (this.props.isEditable) {
            pageElements.pageTitle = "DNS GMSRev Record Update"
            pageElements.pageButtons.push(<Button className={"dns-blue-button text-white mr-2 col-md-1"}
                                                  onClick={this.saveGmsRev}
                                                  key={"update"}>Update</Button>)
            pageElements.pageButtons.push(<Button className={"dns-blue-button text-white mr-2 col-md-1"}
                                                  onClick={() => this.props.history.goBack()}
                                                  key={"cancel_update"}>Cancel</Button>)


        } else {
            pageElements.pageTitle = "DNS GMSRev Record Details"
            pageElements.pageButtons.push(<Button className={"dns-blue-button text-white mt-2 mr-4 mb-4"}
                                                  onClick={() => this.props.history.push(`/dns/zones/details/${this.props.match.params.zoneNum}/rr/${this.props.match.params.type}/edit/${this.props.match.params.id}`)}
                                                  key={"edit"}>Go To Update</Button>)
            pageElements.pageButtons.push(<Button className={"dns-blue-button text-white mt-2 mr-4 mb-4"}
                                                  onClick={() => {
                                                      this.setState({showDeleteConfirm: true})
                                                  }} key={"delete"}>Delete</Button>)
            pageElements.pageButtons.push(<Button className={"dns-blue-button text-white mt-2 mb-4"}
                                                  onClick={() => this.props.history.push(`/dns/zones/details/${this.props.match.params.zoneNum}/rr/${this.props.match.params.type}`)}
                                                  key={"list_gmsrev"}>List GMSRev Records</Button>)


        }

        return pageElements;
    }

    getDeleteConfirmDialog() {
        return !this.props.isEditable && <Dialog
            onClose={(event, reason) => {
                if (reason === 'backdropClick' || reason === 'escapeKeyDown') {
                    return false;
                }
            }}
            maxWidth="xs"
            aria-labelledby="confirmation-dialog-title"
            open={this.state.showDeleteConfirm}
        >
            <DialogTitle id="confirmation_dialog_title">Are you sure you want to delete this
                record?</DialogTitle>
            <DialogActions>
                <Button autoFocus onClick={this.deleteRR} className={"dns-blue-button text-white"}>
                    Delete
                </Button>
                <Button onClick={() => this.setState({showDeleteConfirm: false})}
                        className={"dns-blue-button text-white"}>
                    Cancel
                </Button>
            </DialogActions>
        </Dialog>
    }


    getRrGmsRevForm() {
        const {rr, zoneData} = this.state
        let {pageButtons} = this.getRRPageButtons();

        return <Form>

            <span>NOTE: The Record Name field must begin with '$.'</span>
            <Form.Group as={Row} className={"align-items-center mb-2"}>
                {(this.props.isEmptyForm || !this.props.isEditable) && <><Form.Label column sm="2"
                                                                                     className={"font-weight-bold"}>
                    Zone ID
                </Form.Label>
                    <Col sm="4">
                        {rr.rrGrp}
                    </Col></>}
                {!this.props.isEmptyForm &&
                <> <Form.Label column sm="2" className={"font-weight-bold"}>
                    Record ID
                </Form.Label>
                    <Col sm="4">
                        {rr.recId}
                    </Col></>}
            </Form.Group>
            <Form.Group as={Row} className={"align-items-center mb-2"}>
                <Form.Label column sm="2" className={"font-weight-bold"}>
                    *GMSREV Record Name:
                </Form.Label>
                <Col sm="4">
                    {this.props.isEditable ?
                        <Form.Control name={"rrName"}
                                      onChange={this.updateRRObj}
                                      className={"w-75 d-inline"}
                                      defaultValue={rr.rrName ? rr.rrName : ''}/> : rr.rrName}
                    <span className={"d-inline"}> {zoneData.zoneName}</span>
                </Col>
                <Form.Label column sm="2" className={"font-weight-bold"}>
                    *Network Name:
                </Form.Label>
                <Col sm="4">
                    {this.props.isEditable ?
                        <Form.Control name={"rrData"}
                                      onChange={this.updateRRObj}
                                      className={"w-75"}
                                      defaultValue={rr.rrData ? rr.rrData : ''}/> : rr.rrData}
                </Col>
            </Form.Group>
            <Form.Group as={Row} className={"align-items-center mb-2"}>

                {this.props.isEmptyForm && this.props.isEditable && <><Form.Label column sm="2"
                                                                                  className={"font-weight-bold"}>
                    Start
                </Form.Label>
                    <Col sm="4">
                        {this.props.isEditable ?
                            <Form.Control name={"start"}
                                          className={"w-50"}
                                          onChange={this.updateRRObj}
                                          defaultValue={rr.lstart ? rr.lstart : ''}/> : rr.lstart}

                    </Col></>}

                {this.props.isEmptyForm && this.props.isEditable && <><Form.Label column sm="2"
                                                                                  className={"font-weight-bold"}>
                    Stop
                </Form.Label>
                    <Col sm="4">
                        {this.props.isEditable ?
                            <Form.Control name={"stop"}
                                          className={"w-50"}
                                          onChange={this.updateRRObj}
                                          defaultValue={rr.lstop ? rr.lstop : ''}/> : rr.lstop}

                    </Col></>}

            </Form.Group>
            <Form.Group as={Row} className={"align-items-center mb-2"}>
                {(this.props.isEmptyForm || !this.props.isEditable) && <><Form.Label column sm="2"
                                                                                     className={"font-weight-bold"}>
                    Step </Form.Label>
                    <Col sm="4">
                        {this.props.isEditable ?
                            <Form.Control name={"step"}
                                          onChange={this.updateRRObj}
                                          className={"w-50"}
                                          defaultValue={rr.lstep ? rr.lstep : ''}/> : rr.lstep}

                    </Col></>}

                {(this.props.isEmptyForm || !this.props.isEditable) && <><Form.Label column sm="2"
                                                                                     className={"font-weight-bold"}>
                    Width
                </Form.Label>
                    <Col sm="4">
                        {this.props.isEditable ?
                            <Form.Control name={"width"}
                                          onChange={this.updateRRObj}
                                          className={"w-50"}
                                          defaultValue={rr.rwidth ? rr.rwidth : ''}/> : rr.rwidth}

                    </Col></>}

            </Form.Group>
            <Form.Group as={Row} className={"align-items-center mb-2"}>
                {(this.props.isEmptyForm || !this.props.isEditable) && <><Form.Label column sm="2"
                                                                                     className={"font-weight-bold"}>
                    Offset </Form.Label>
                    <Col sm="4">
                        {this.props.isEditable ?
                            <Form.Control name={"offset"}
                                          onChange={this.updateRRObj}
                                          className={"w-50"}
                                          defaultValue={rr.loffset ? rr.loffset : ''}/> : rr.loffset}
                    </Col></>}
                <Form.Label column sm="2" className={"font-weight-bold w-50"}>
                    *Radix
                </Form.Label>
                <Col sm="4">
                    {this.props.isEditable ? <Form.Control as="select" name={"radix"}
                                                           onChange={this.updateRRObj}
                                                           className={"w-50"}

                                                           value={rr.rtype}>
                            <option value={"d"}>d</option>
                            <option value={"X"}>X</option>
                            <option value={"o"}>o</option>
                            <option value={"x"}>x</option>
                        </Form.Control>
                        : rr.rtype}                    </Col>
            </Form.Group>
            <Form.Group as={Row} className={"align-items-center mb-2"}>

                <Form.Label column sm="2" className={"font-weight-bold"}>
                    Collision </Form.Label>
                <Col sm="4">
                    {this.props.isEditable ? <Form.Control as="select" name={"radix"}
                                                           onChange={this.updateRRObj}
                                                           className={"w-50"}

                                                           value={rr.rtype}>
                            <option value={"y"}>Y</option>
                            <option value={"n"}>N</option>
                        </Form.Control>
                        : rr.rtype}                    </Col>

                <Form.Label column sm="2" className={"font-weight-bold"}>
                    {this.props.isEditable ? "*" : ""}Validate
                </Form.Label>
                <Col sm="4">
                    {this.props.isEditable ?
                        <Form.Control as="select" name={"rr.validate"}
                                      onChange={this.updateRRObj}
                                      className={"w-50"}
                                      value={rr.validate}
                                      required={true}
                        >
                            <option value={"Y"}>Y</option>
                            <option value={"N"}>N</option>
                        </Form.Control>
                        : rr.validate}
                </Col>


            </Form.Group>
            <Form.Group as={Row} className={"align-items-center mb-2"}>
                {!this.props.isEmptyForm && !this.props.isEditable && <><Form.Label column sm="2"
                                                                                    className={"font-weight-bold"}>
                    Modified By
                </Form.Label>
                    <Col sm="4">
                        {rr.modBy}
                    </Col></>}
            </Form.Group>
            <Form.Group as={Row} className={"align-items-center mb-2"}>


                {!this.props.isEmptyForm && !this.props.isEditable && <> <Form.Label column sm="2"
                                                                                     className={"font-weight-bold"}>
                    Create Time
                </Form.Label>
                    <Col sm="4">
                        {rr.createTime}
                    </Col></>}
                {!this.props.isEmptyForm && !this.props.isEditable && <>  <Form.Label column sm="2"
                                                                                      className={"font-weight-bold"}>
                    Last Modified
                </Form.Label>
                    <Col sm="4">
                        {rr.modTime}
                    </Col></>}

            </Form.Group>
            <Form.Group as={Row} className={"align-items-center"}>
                <Form.Label column sm="2" className={"font-weight-bold"}>
                    Time To Live
                </Form.Label>
                <Col sm="4">
                    {this.props.isEditable ?
                        <Form.Control name={"rrTtl"}
                                      onChange={this.updateRRObj}
                                      className={"w-50"}
                                      defaultValue={rr.rrTtl ? rr.rrTtl : ''}/> : rr.rrTtl}
                </Col>
                <Form.Label column sm="2" className={"font-weight-bold"}>
                    Comment
                </Form.Label>
                <Col sm="4">
                    {this.props.isEditable ?
                        <Form.Control name={"comments"}
                                      onChange={this.updateRRObj}
                                      className={"w-50"}
                                      defaultValue={rr.comments ? rr.comments : ''}/> : rr.comments}
                </Col>

            </Form.Group>
            <div className={"text-center"}>
                {pageButtons.map(buttonComp => buttonComp)}
            </div>


            <div>
                <h6 className={"font-weight-bold"}>How the GMSREV Record Works</h6>
                The <b>GMSREV</b> record generates between 2 and 256 DNS <b>PTR</b> records. The <b>$</b> character
                in the record is replaced is replaced by an iterator, which is controlled by the
                <b>start</b>, <b>stop</b>, and <b>step</b> fields. These
                fields determine how many <b>PTR</b> records are created.

                <p>
                </p>
                <h6 className={"font-weight-bold"}>NOTE:</h6>
                The automatic generation of A records from GMSFOR records currently only works for IPv4 records.<br/>


                <p>The <b>width</b>,<b>offset</b>, and <b>radix</b> fields are usually left at their default
                    values; in more complex cases, they can be used to alter the <b>Network Names </b> of the
                    DNS <b>PTR</b> records.
                </p><br/>


                <h6 className={"font-weight-bold"}> Examples</h6>


                <b>Record Name</b> = $.<b>14.13.12.in-addr.arpa.</b>, <b>Network Name</b> =
                dallas<b>$</b>tx.example.com., <b>start,stop, step </b> = 20, 50, 1. The iterator will move from 20
                to 50 in increments of 1 and generate 31 <b>PTR</b> records:
                <p></p>


                <b>20</b>.14.13.12.in-addr.arpa. IN PTR dallas<b>20</b>tx.example.com.<br/>
                <b>21</b>.14.13.12.in-addr.arpa. IN PTR dallas<b>21</b>tx.example.com.<br/>
                <b>...</b><br/>
                <b>50</b>.14.13.12.in-addr.arpa. IN PTR dallas<b>50</b>tx.example.com.<br/>


                <span>
                    Changing the <b>step</b> field from 1 to 2 causes the iterator to advance in increments of 2, and
                    generates 16 <b>PTR</b> records:<br/>
                    <p></p>

                    20.14.13.12.in-addr.arpa. IN PTR dallas20tx.example.com.
                    22.14.13.12.in-addr.arpa. IN PTR dallas22tx.example.com.
                    ...
                    50.14.13.12.in-addr.arpa. IN PTR dallas50tx.example.com.


                </span>
                <span>
                    Note: DRAGON will return an error if you try to create 2 <b>GMSREV</b> records in the same zone
                    whose IP addresses would overlap. Note that the <b>Collision</b> field is not currently used by
                    DRAGON.
                </span>


                <span>The <b>width</b>, <b>offset</b>, and <b>radix</b> fields can be used to alter the <b>Network Name</b>,
                    but not the <b>Record Name</b>, of the DNS <b>PTR</b> records.

                    Changing the <b>width</b> field from 1 to 4 will cause the iterator to be padded with leading zeros
                    so
                    that the field is 4 characters long:<br/>
                                    <p></p>


                    20.14.13.12.in-addr.arpa. IN PTR dallas0020tx.example.com.<br/>
                    21.14.13.12.in-addr.arpa. IN PTR dallas0021tx.example.com.<br/>
                    <b>...</b><br/>
                    50.14.13.12.in-addr.arpa. IN PTR dallas0050tx.example.com.<br/>


                </span>
                Changing the <b>offset</b> field from 0 to 40 will add 40 to the value of the iterator:<br/>

                <p></p>

                Changing the radix field from <b>d</b> (decimal) to <b>X</b> (hexadecimal) will cause the iterator
                to be
                printed in hexadecimal notation:
                <p></p>


                20.14.13.12.in-addr.arpa. IN PTR dallas14tx.example.com.<br/>
                21.14.13.12.in-addr.arpa. IN PTR dallas15tx.example.com.<br/>
                <b>...</b><br/>
                46.14.13.12.in-addr.arpa. IN PTR dallas2Etx.example.com.<br/>
                47.14.13.12.in-addr.arpa. IN PTR dallas2Ftx.example.com.<br/>
                48.14.13.12.in-addr.arpa. IN PTR dallas30tx.example.com.<br/>
                49.14.13.12.in-addr.arpa. IN PTR dallas31tx.example.com.<br/>
                50.14.13.12.in-addr.arpa. IN PTR dallas32tx.example.com.<br/>


            </div>
        </Form>


    }


    componentWillUnmount() {
        this.isComponentMounted = false;
    }

    render() {
        let {pageTitle} = this.getRRPageButtons();
        return (
            <>
                {this.getDeleteConfirmDialog()}
                <Backdrop className={"page-loading"} style={{'zIndex': '10000', 'color': '#fff'}}
                          open={this.state.loading && this.props.loading}>
                    <CircularProgress color="inherit"/>
                </Backdrop>
                <div>
                    <Helmet>
                        <title>DNS Admin | DNS GMSRev Details Page</title>
                    </Helmet>
                    <Container maxWidth={false} className={"px-2"}>
                        <Card>
                            <CardContent>
                                <div className={'mt-3 ml-3 mr-3 mb-3'}>
                                    <h5 className="font-weight-bold  text-capitalize text-left pt-1 pl-2">{pageTitle}</h5>

                                    <div className={"pb-2"}>
                                        {this.props.alert.message && <Alert
                                            severity={this.props.alert.type}>{this.props.alert.message}</Alert>}</div>
                                    {this.getRrGmsRevForm()}
                                </div>
                            </CardContent>
                        </Card>

                    </Container>
                </div>
            </>
        )
    }

}

RrGmsRev.defaultProps =
    {
        isEditable: false,
    };
RrGmsRev.propTypes =
    {
        isEditable: PropTypes.bool,
        isEmptyForm: PropTypes.bool
    }
;
RrGmsRev.defaultProps =
    {
        isEditable: false,
        isEmptyForm: false
    }

function mapState(state) {
    const {alert} = state
    console.log(state, "STATE")
    const {loading, saved, deleted, deleting} = state.rrs
    return {alert, loading, saved, deleted, deleting}
}

const actionCreators =
    {
        create: resourceRecordActions.create,
        delete: resourceRecordActions.delete,
        update: resourceRecordActions.update,
        alertClear: alertActions.clear,
    }
;


const connectedRrGmsRev = withRouter(connect(mapState, actionCreators)(RrGmsRev));
export
{
    connectedRrGmsRev
        as
            RrGmsRev
}
    ;

