import React from "react";
import {alertActions} from "../../../../_actions";
import {connect} from "react-redux";
import {
    CardContent,
    withStyles,
    Card,
    Button,
    Dialog,
    DialogTitle,
    DialogContent,
    FormControl,
    InputLabel,
    Select,
    MenuItem,
    RadioGroup,
    FormControlLabel, Radio, DialogActions, Backdrop, CircularProgress
} from "@material-ui/core";
import {Helmet} from "react-helmet";
import Container from "@material-ui/core/Container";
import Box from "@material-ui/core/Box";
import BootstrapTable from 'react-bootstrap-table-next';
import filterFactory, {Comparator, customFilter, textFilter} from 'react-bootstrap-table2-filter';
import paginationFactory from 'react-bootstrap-table2-paginator';
import _ from "lodash";
import {Alert} from "@material-ui/lab";
import {Link, withRouter} from "react-router-dom";
import {zoneService} from "../../../../_services";
import {resourceRecordService} from "../../../../_services/resourceRecord.service";
import PropTypes from "prop-types";
import {pageRenderer, SizePerPageRenderer} from "../../../../_components";
import Form from "react-bootstrap/Form";
import {Col, Row} from "react-bootstrap";
import {ComparatorHelper} from "../../../../_helpers";


const useStyles = theme => ({
    root: {},
    searchButton: {
        /*
                backgroundColor: '#3f75b2',
        */
        backgroundColor: '#4789b6',
        marginBottom: '-10px',
        opacity: '1',
        color: '#FFF',
        width: '50%',
        '&:hover': {backgroundColor: '#3f6bb5', opacity: '1'}
    },
    filterContainer: {
        padding: '20px',
        marginBottom: '30px'
    },

    createAccountButton: {
        backgroundColor: '#4789b6',
        '&:hover': {
            backgroundColor: '#3f75b5',
        },
    },

    searchContainer: {
        textAlign: 'left'
    }
});


const defaultFilters = {
    rdata: {comparator: 'Eq', value: ''},
    name: {comparator: 'Eq', value: ''},
    orderBy: {comparator: '', value: 'hostname'},
    orderDir: {comparator: '', value: 'asc'},
    rrType: "",
}

class Search extends React.Component {

    constructor(props) {
        super(props);
        this.state = {
            data: [],
            zoneName: '',
            zoneData: '',
            rrType: '',
            loading: true,
            filters: _.cloneDeep(defaultFilters),
            comparator: Comparator.EQ,
            showDeleteConfirm: false,
            showAdvanceSearch: false,
            error: '',
            rrSearchParams: {},
            page: 1,
            sizePerPage: 10,
            totalSize: 0,

        }

        this.isComponentMounted = false;
        this.getAdvanceSearchDialog = this.getAdvanceSearchDialog.bind(this)
        this.handleFilterChange = this.handleFilterChange.bind(this)
        this.handleTableChange = this.handleTableChange.bind(this);


        if ((this.props.location.state === null || this.props.location.state === undefined || !this.props.location.state.showAlerts) && !_.isEmpty(this.props.alert)) {
            this.props.alertClear()
        }
    }


    async componentDidMount() {
        this.isComponentMounted = true;
        setTimeout(() => {
            this.props.alertClear()
        }, 10000)
        await this.loadTableData({
            zoneNum: this.props.match.params.zoneNum,
            rrType: this.props.match.params.type,
            numberOfRows: this.state.sizePerPage,
            pageNumber: this.state.page
        });
        // await this.loadTableData({zoneNum: this.props.match.params.zoneNum, rrType: this.props.match.params.type});
        const res = await zoneService.getZoneById(this.props.match.params.zoneNum)
        if (this.isComponentMounted) {

            this.setState({zoneData: res.zone});
        }
    }


    async loadTableData(data) {
        this.setState({loading: true})
        for (var key in this.state.filters) {
            if (this.state.filters.hasOwnProperty(key) &&
                this.state.filters[key].value) {
                data[key +
                this.state.filters[key].comparator] = this.state.filters[key].value;
            }
        }

        data = {...data, zoneNum: this.props.match.params.zoneNum, rrType: this.props.match.params.type}

        const res = await resourceRecordService.getAllRecords(data);
        if (this.isComponentMounted) {
            //this.setState({loading: false, data: res.rr, error: res.error});
            this.setState({
                loading: false, data: res.rr, error: res.error, totalSize: res.totalRecords,
                page: data.pageNumber ? data.pageNumber : this.state.page,
                sizePerPage: data.numberOfRows ?
                    data.numberOfRows :
                    this.state.sizePerPage,
            });

        }
    }

    componentWillUnmount() {
        this.isComponentMounted = false;
    }


    async handleTableChange(type, {filters, page, sortOrder, sortField, sizePerPage, totalSize}) {
        const currentIndex = (page - 1) * sizePerPage;
        let rrSearchParams = {};
        if (sortField && sortOrder) {
            rrSearchParams.orderDir = sortOrder;
            rrSearchParams.orderBy = sortField;
        }

        rrSearchParams.numberOfRows = sizePerPage;
        rrSearchParams.pageNumber = page;
        await this.loadTableData(rrSearchParams);

    }

    getRRMxTableColumns() {

        return [
            {
                text: 'Resource Record Name',
                dataField: 'rrName',
                headerAlign: 'center',
                sort: true,
                headerStyle: {
                    width: "35%",
                },
                headerClasses: 'p-1',
                classes: 'text-left p-0',
                style: {
                    'wordWrap': 'break-word'
                },
            },
            {
                text: "Mail Host's Full Name",
                dataField: 'rrData',
                headerAlign: 'center',
                sort: true,
                headerStyle: {
                    width: "25%",
                },
                headerClasses: 'p-1',
                classes: 'text-left p-0',
                style: {
                    'wordWrap': 'break-word'
                },
                formatter: (cell, row) => row.rrData.split(" ")[1],
                /*  filter: customFilter({comparator: this.state.comparator}),
                  headerEvents: {
                      onClick: (e, column, columnIndex) => {
                          return false
                          e.preventDefault()
                      }
                  },
                  filterRenderer: (onFilter, column) => {
                      return (<>
                          <div><select
                              key="select"
                              ref={node => this.select = node}
                              className="form-control"
                              onClick={(e) => {
                                  this.setState({com: true});
                                  e.preventDefault();
                                  return false
                              }}
                              onChange={(e) => this.setState({comparator: e.target.value})}
                          >
                              <option value={Comparator.EQ}>Equals to</option>
                              <option value={"contains"}>Contains</option>
                              <option value={"beg"}>Begins with</option>
                          </select>
                          </div>
                          <div>
                              <input
                                  className={"form-control"}
                                  placeholder={"Search"}
                                  onChange={(e) => onFilter({value: e.target.value, comparator: this.state.comparator})}
                              /></div>
                      </>)
                  }*/
            },
            {
                text: 'Preference',
                dataField: 'pref',
                headerAlign: 'center',
                sort: true,
                formatter: (cell, row) => row.rrData.split(" ")[0],
                headerStyle: {
                    width: "15%",
                },
                headerClasses: 'p-1',
                classes: 'text-left p-0',
                style: {
                    'wordWrap': 'break-word'
                },
            },
            {
                text: 'Last Modified',
                dataField: 'modTime',
                showHideSelection: true,
                headerAlign: 'center',
                headerStyle: {
                    width: "15%"
                },
                headerClasses: 'p-1',
                classes: 'text-center p-0',
                style: {
                    'wordWrap': 'break-word'
                },
            },
            {
                text: "Action",
                dataField: "",
                headerAlign: 'center',
                headerStyle: {
                    width: "10%"
                },
                headerClasses: 'p-1',
                classes: 'text-center p-0',
                style: {
                    'wordWrap': 'break-word'
                },
                formatter: (cell, row, rowIndex) => <>
                    <Link
                        to={`/dns/zones/details/${this.props.match.params.zoneNum}/rr/${this.props.match.params.type}/details/${row.recId}`}
                        key={"details_mx_record"}
                        className={"color-dragon-blue mr-2"}
                    >Details</Link>
                    <Link
                        to={`/dns/zones/details/${this.props.match.params.zoneNum}/rr/${this.props.match.params.type}/edit/${row.recId}`}
                        key={"edit_mx_record"}
                        className={"color-dragon-blue"}
                    >Edit</Link>
                </>
            },

        ];
    }

    paginationOptions() {
        return {
            //     paginationSize: 4,
            //    pageStartIndex: 0,
            sizePerPage: this.state.sizePerPage,
            page: this.state.page,
            totalSize: this.state.totalSize,
            alwaysShowAllBtns: true,
            withFirstAndLast: true,
            firstPageText: 'First',
            prePageText: 'Back',
            nextPageText: 'Next',
            lastPageText: 'Last',
            nextPageTitle: 'First page',
            prePageTitle: 'Pre page',
            firstPageTitle: 'Next page',
            lastPageTitle: 'Last page',
            showTotal: false,
            sizePerPageList: [
                {
                    text: '10', value: 10
                }, {
                    text: '20', value: 20
                },
                {
                    text: '50', value: 50
                },],
            pageButtonRenderer: pageRenderer,
            sizePerPageRenderer: ({
                                      options,
                                      currSizePerPage,
                                      onSizePerPageChange
                                  }) => <SizePerPageRenderer options={options}
                                                             currSizePerPage={currSizePerPage}
                                                             onSizePerPageChange={onSizePerPageChange}/>,

            disablePageTitle: true,
        };
    }

    handleFilterChange(e) {
        const {name, value} = e.target;
        const {filters} = this.state;
        const filterInfo = name.split('.');
        filters[filterInfo[0]][filterInfo[1]] = value;
        this.setState({filters: filters});
    }

    getAdvanceSearchDialog() {
        const {zoneData} = this.state

        return <Dialog
            fullWidth={true}
            onClose={(event, reason) => {
                if (reason === 'backdropClick' || reason === 'escapeKeyDown') {
                    return false;
                }
            }}
            maxWidth="lg"
            open={this.state.showAdvanceSearch}
        >
            <DialogTitle id="form-dialog-title" className={"dialog-text-font-size"}> DNS Search Resource Records Page
            </DialogTitle>
            <DialogContent>
                <Form>
                    <Form.Group as={Row} className={'align-items-center'}>
                        <Form.Label column sm="2" className={'font-weight-bold'}>
                            Resource Record Name : </Form.Label>
                        <Col sm={2}>
                            <FormControl variant="outlined">
                                <InputLabel htmlFor="wildcard-name-search">Resource Record Name </InputLabel>
                                <Select
                                    autoWidth={true}
                                    className={'w-100'}
                                    name={'name.comparator'}
                                    value={this.state.filters.name.comparator}
                                    onChange={this.handleFilterChange}
                                    label="Resource Record Name"
                                >
                                    {ComparatorHelper.getComparators.map(obj => (
                                        <MenuItem value={obj.value}
                                                  key={obj.value}>{obj.label}</MenuItem>
                                    ))}

                                </Select>
                            </FormControl>

                        </Col>
                        <Col sm={4}>
                            <Form.Control name={'name.value'}
                                          value={this.state.filters.name.value}
                                          className={"w-75 d-inline"}

                                          onChange={this.handleFilterChange}
                            />
                            <span className={"d-inline"}> {zoneData.zoneName}</span>
                        </Col>

                    </Form.Group>

                    <Form.Group as={Row} className={'align-items-center'}>
                        <Form.Label column sm="2" className={'font-weight-bold'}>
                            Mail Host Full Name :</Form.Label>
                        <Col sm={2}>
                            <FormControl variant="outlined">
                                <InputLabel htmlFor="wildcard-name-search">Mail Host Full Name</InputLabel>
                                <Select
                                    autoWidth={true}
                                    className={'w-100'}
                                    name={'rdata.comparator'}
                                    value={this.state.filters.rdata.comparator}
                                    onChange={this.handleFilterChange}
                                    label="Mail Host Full Name"
                                >
                                    {ComparatorHelper.getComparators.map(obj => (
                                        <MenuItem value={obj.value}
                                                  key={obj.value}>{obj.label}</MenuItem>
                                    ))}

                                </Select>
                            </FormControl>

                        </Col>
                        <Col sm={4}>
                            <Form.Control name={'rdata.value'}
                                          value={this.state.filters.rdata.value}
                                          className={"w-75 d-inline"}
                                          onChange={this.handleFilterChange}
                            />
                        </Col>

                    </Form.Group>


                    <Form.Group as={Row} className={"align-items-center"}>
                        <Form.Label column sm="3" className={'font-weight-bold'}>
                            Ordered By </Form.Label>
                        <Col sm={9}>
                            <RadioGroup value={this.state.filters.orderBy.value} name={"orderBy.value"}
                                        onChange={this.handleFilterChange} row={true}>

                                <FormControlLabel value="hostname"
                                                  control={<Radio color="primary"/>}
                                                  label="Resource Record Name"/>
                                <FormControlLabel value="rdata"
                                                  control={<Radio color="primary"/>}
                                                  label="Mail Host Full Name"/>

                            </RadioGroup>
                        </Col>
                    </Form.Group>
                    <Form.Group as={Row} className={"align-items-center"}>
                        <Form.Label column sm="3" className={'font-weight-bold'}>
                            Ordered Direction </Form.Label>
                        <Col sm={9}>
                            <RadioGroup value={this.state.filters.orderDir.value} name={"orderDir.value"}
                                        onChange={this.handleFilterChange} row={true}>

                                <FormControlLabel value="asc"
                                                  control={<Radio color="primary"/>}
                                                  label="Ascending"/>
                                <FormControlLabel value="desc" control={<Radio color="primary"/>}
                                                  label="Descending"/>


                            </RadioGroup>
                        </Col>
                    </Form.Group>

                </Form>
            </DialogContent>

            <DialogActions>
                <Button onClick={async (e) => {
                    await this.loadTableData({numberOfRows: this.state.sizePerPage, pageNumber: this.state.page});
                    this.setState(
                        {showAdvanceSearch: false});
                }
                } color="primary" className={'dns-blue-button text-white'}
                >
                    Search RRs
                </Button>
                <Button onClick={() => this.setState(
                    {showAdvanceSearch: false})}
                        color="primary" className={'dns-blue-button text-white'}>
                    Close
                </Button>
                <Button type={"reset"} onClick={() => {
                    this.setState({filters: _.cloneDeep(defaultFilters)}, () => {
                        this.loadTableData({numberOfRows: 10, pageNumber: 1})
                    });
                }} variant="contained"
                        className={"dns-blue-button text-white ml-2"}
                        disabled={JSON.stringify(this.state.filters) === JSON.stringify(defaultFilters)}>clear</Button>

            </DialogActions>


        </Dialog>
    }

    render() {
        const {classes} = this.props;
        const paginationOptions = this.paginationOptions();
        const {loading, data} = this.state;
        const columns = this.getRRMxTableColumns();
        return (<>
            {this.props.loading && <Backdrop className={"page-loading"} style={{'zIndex': '10000', 'color': '#fff'}}
                                             open={this.state.loading}>
                <CircularProgress color="inherit"/>
            </Backdrop>}

            <div>
                <Helmet>
                    <title>DNS Resource Records|TXT Record</title>
                </Helmet>
                <Box>
                    <Container maxWidth={false} className={"px-2"}>
                        <Card>
                            <CardContent className={"px-0"}>
                                <div className={'mt-3 ml-3 mr-3 mb-3'}>

                                    <h5 className="font-weight-bold  text-capitalize text-left pt-1  pl-2">
                                        DNS Host Information (Mx) Records List
                                    </h5>
                                    {this.getAdvanceSearchDialog()}
                                    <div>
                                        {(!_.isEmpty(this.state.error) || !_.isEmpty(this.props.alert.message)) &&
                                        <Alert
                                            severity={!_.isEmpty(this.state.error) ? "error" : this.props.alert.type}>{(this.state.error && this.state.error.text) || this.props.alert.message}</Alert>}
                                        <div className="pl-4 pr-2">
                                            <div className={"col text-right mt-2 mb-1"}>
                                                <Link
                                                    className={"d-inline-block btn btn-primary dns-blue-button mr-1"}
                                                    to={"/dns/zones/details/" + this.props.match.params.zoneNum + "/rr/" + this.props.match.params.type + "/create"}
                                                >Insert Record</Link>
                                                <Button aria-controls="simple-menu"
                                                        aria-haspopup="true"
                                                        color="primary"
                                                        className={'dns-blue-button'}
                                                        variant={'contained'}
                                                        onClick={() => {
                                                            this.setState(
                                                                {showAdvanceSearch: true});
                                                        }} key={'advance_search'}>Search</Button>
                                                {(JSON.stringify(this.state.filters) !== JSON.stringify(defaultFilters)) &&
                                                <Button type={"reset"} onClick={() => {
                                                    this.setState({filters: _.cloneDeep(defaultFilters)}, () => {
                                                        this.loadTableData({numberOfRows: 10, pageNumber: 1})
                                                    });
                                                }} variant="contained"
                                                        className={"dns-blue-button text-white ml-2"}


                                                >clear</Button>}
                                            </div>

                                            <div className={"pt-3 pb-3"}>
                                            <span
                                                className={'font-weight-bold'}>Zone Name</span>: {this.state.zoneData.zoneName}

                                                <span
                                                    className={'font-weight-bold  pl-5'}>Zone ID</span> : {this.state.zoneData.zoneNum}<br/>
                                            </div>

                                            <BootstrapTable bootstrap4
                                                            keyField="recId"
                                                            data={data}
                                                            remote={{pagination: true}}
                                                            onTableChange={this.handleTableChange}
                                                            columns={columns}
                                                            filter={filterFactory()}
                                                            filterPosition={"top"}
                                                            pagination={paginationFactory(paginationOptions)}
                                                            noDataIndication="Table is Empty"
                                                            id={"rr_mx_table"}
                                                            condensed
                                            />
                                        </div>
                                    </div>
                                </div>
                            </CardContent>
                        </Card>
                    </Container>
                </Box>
            </div>
        </>);
    }
}


Search.propTypes = {
    classes: PropTypes.object.isRequired
};
const styledSearch = withStyles(useStyles)(Search);

function mapState(state) {
    //const {deleted} = state.rrs
    const {alert} = state
    return {alert}
}


const actionCreators =
    {
        alertClear: alertActions.clear,
    }

const connectedRrMx = withRouter(connect(mapState, actionCreators)(styledSearch));
export {connectedRrMx as Search};