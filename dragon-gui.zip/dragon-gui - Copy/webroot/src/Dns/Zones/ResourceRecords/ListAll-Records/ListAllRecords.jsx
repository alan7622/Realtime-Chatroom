import React from "react";
import {alertActions} from "../../../../_actions";
import {connect} from "react-redux";
import {
    CardContent,
    Card
} from "@material-ui/core";
import {Helmet} from "react-helmet";
import Container from "@material-ui/core/Container";
import BootstrapTable from 'react-bootstrap-table-next';
import filterFactory, {Comparator, customFilter, textFilter} from 'react-bootstrap-table2-filter';
import {Alert} from "@material-ui/lab";
import {withRouter} from "react-router-dom";
import {resourceRecordService} from "../../../../_services/resourceRecord.service";
import {zoneService} from "../../../../_services";
import _ from "lodash";


class ListAllRecords extends React.Component {

    constructor(props) {
        super(props);
        this.state = {
            data: [],
            zoneName: '',
            zoneData: '',
            rrType: '',
            loading: true,
            comparator: Comparator.EQ,
            showDeleteConfirm: false,
            showAdvanceSearchConfirm: false,
            error: ''

        }

        this.isComponentMounted = false;
    }

    async componentDidMount() {
        this.isComponentMounted = true;
        const res = await zoneService.getZoneById(this.props.match.params.zoneNum)
        if (this.isComponentMounted) {
            console.log(this.state.rrType,"rrType")

            this.setState({zoneData: res.zone});
        }
        console.log(this.state.rrType,"rrType")
        await this.loadTableData({zoneNum: this.props.match.params.zoneNum, rrType: this.props.match.params.type});

    }


    async loadTableData(data) {
        if (this.isComponentMounted) {
            this.setState({loading: true})
        }
        const res = await resourceRecordService.getAllRecords(data);
        if (this.isComponentMounted) {
            //this.setState({loading: false, data: res.RRBOs,error: res.error});
          this.setState({loading: false, data: res.rr, error: res.error});


        }
    }


    componentWillUnmount() {
        this.isComponentMounted = false;
    }

    getListAllTableColumns() {

        return [
            {

                text: 'Resource Records',
                dataField: 'rrStr',
                headerAlign: 'center',
                headerStyle: {
                    width: "85%"
                },
                onFilter: (filterValue) => {
                    console.log(filterValue)
                }
            },


        ];
    }


    render() {
        const {data} = this.state;
        const columns = this.getListAllTableColumns();
        return (

            <div>
                <Helmet>
                    <title>DNS Resource Records|A Record</title>
                </Helmet>
                <Container maxWidth={false} className={"px-2"}>
                    <Card>
                        <CardContent className={"px-0"}>
                            <div className={'mt-2 ml-3 mr-3 mb-2'}>

                                <h5 className="font-weight-bold  text-capitalize text-left mt-5 pb-2 pl-4">
                                    Dragon Provisioning Zone List Page
                                </h5>

                                <h6 className="text-capitalize text-left pt-1 pb-1 pl-4">
                                    Resource Records for {this.state.zoneData.zoneName}
                                </h6>
                                <div>
                                    {/*          {this.props.alert.message && <Alert
                                        severity={this.props.alert.type}>{this.props.alert.message}</Alert>}*/}
                                    <div className={"ml-3"}>

                                    {(!_.isEmpty(this.state.error) || !_.isEmpty(this.props.alert.message)) && <Alert
                                        severity={!_.isEmpty(this.state.error) ? "error" : this.props.alert.type}>{this.state.error.text || this.props.alert.message}</Alert>}
                                    </div>
                                    <div className="pl-3 pr-2 pt-1 border-top border-bottom w-100">
<pre className={"mt-2"}>
                               {/*         <BootstrapTable bootstrap4
                                                        keyField="recId"
                                                        data={data}
                                                        columns={columns}
                                                        noDataIndication="Table is Empty"
                                                        id={"rr_listall_table"}
                                                        condensed
                                                        //striped
                                        />*/}
    {data.map((v,k)=>{
        return <div key={k} >
            {v.rrStr}
        </div>
    })}
                                        </pre>

                                    </div>
                                </div>
                            </div>
                        </CardContent>
                    </Card>
                </Container>
            </div>

        );
    }
}


function mapState(state) {
    const {alert} = state
    return {alert}
}


const actionCreators =
    {
        alertClear: alertActions.clear,
    }

const connectedListAllRecords = withRouter(connect(mapState, actionCreators)(ListAllRecords));
export {connectedListAllRecords as ListAllRecords};