import React, {Component} from "react";
import Container from "@material-ui/core/Container";
import {withRouter} from "react-router-dom";
import {
    Backdrop,
    Button,
    Card,
    CardContent,
    CircularProgress,
    Dialog,
    DialogActions,
    DialogTitle,
} from "@material-ui/core";
import PropTypes from "prop-types";
import {alertActions} from "../../../../_actions";
import Form from 'react-bootstrap/Form'
import {Col} from "react-bootstrap";
import {Row} from "react-bootstrap";
import {Alert} from '@material-ui/lab';
import {connect} from "react-redux";
import {Helmet} from "react-helmet";
import {resourceRecordActions} from "../../../../_actions/resourceRecords.actions";
import _ from "lodash";
import {zoneService, resourceRecordService} from "../../../../_services";


class RrA extends Component {
    constructor(props) {
        super(props);
        this.state = {
            loading: true,
            showDeleteConfirm: false,
            zoneData: {},
            formCount: 1,
            rr: {
                rrGrp: this.props.match.params.zoneNum,
                rrStr: {},
                rrType: this.props.match.params.type,
                // comments: [],
                comments: '',

                recId: '',

            },
            alert: '',

        };
        this.isComponentMounted = false;
        this.saveRRA = this.saveRRA.bind(this);
        this.updateRRObj = this.updateRRObj.bind(this);
        this.deleteRR = this.deleteRR.bind(this);
        this.getDeleteConfirmDialog = this.getDeleteConfirmDialog.bind(this);
        this.getForms = this.getForms.bind(this);

        if ((this.props.location.state === undefined || !this.props.location.state.showAlerts) && !_.isEmpty(this.props.alert)) {
            this.props.alertClear()
        }

    }

    saveRRA(e) {
        e.preventDefault()
        // this.setState({loading: true})
        this.setState({loading: !this.props.isEmptyForm})//changed it so that it supports loading on create page
        const {
            rrType,
            rrStr,
            rrGrp,
            comments,
            ...rr
        } = this.state.rr
        const len = Object.keys(rrStr).length
        if (len < 1) {
            alert("We need atleast one RR record")
        } else {
            let reqObj = {
                rrType: rrType.toUpperCase(),
                rrGrp
            }

            let count = 1;
            for (const [key, val] of Object.entries(rrStr)) {
                if(count > this.state.formCount) {
break;

                }
                let tmpStr = val.rrName + (val.rrTtl ? (" " + val.rrTtl) : "") + " IN " + rrType.toUpperCase() + " " + (val.rrData ? val.rrData : "")
                if (count == 1) {
                    reqObj.rrStr = tmpStr;
                    reqObj.comments = val.hasOwnProperty('comments') ? val.comments : '' //hasOwnProperty is to find the json key and if we give empty commets use this condition
                } else {
                    reqObj[`rrStr${count}`] = tmpStr
                    reqObj[`comments${count}`] = val.hasOwnProperty('comments') ? val.comments : ''
                }
                count++;


            }
            if (this.props.isEmptyForm && this.props.isEditable) {
                //rrGrp:same as zoneNum for now,rrStr:entire RR record comes from user,rrType:type of RR from url,comments:comments from user
                this.props.create(reqObj);
            } else {
                //If api is not fixed for rrStr we need to remove rrStr key from resourceRecordA from json object
                this.props.update(this.props.match.params.id, reqObj, false);//false is for excludeRRStr(in resourcerecordactions file) condition is not true in which it allows  user to update rrStr
            }

        }
    }

    async componentDidMount() {
        console.log("loading")
        this.isComponentMounted = true;
        const res = await zoneService.getZoneById(this.props.match.params.zoneNum)
        if (this.isComponentMounted) {
            this.setState({loading: !this.props.isEmptyForm, zoneData: res.zone});
        }
        if (!this.props.isEmptyForm && this.isComponentMounted) {
            let rr = await resourceRecordService.getByRecordId(this.props.match.params.id);
            if (!_.isEmpty(rr) && this.isComponentMounted) {
                rr.rrStr = [{rrName: rr.rrName, rrTtl: rr.rrTtl, rrData: rr.rrData, comments: rr.comments}]
                this.setState({loading: false, rr});

            } else {
                this.props.history.push(`/dns/zones/details/${this.props.match.params.zoneNum}/rr/${this.props.match.params.type}`);
            }

        }

    }

    deleteRR() {
        if (this.isComponentMounted) {
            this.setState({showDeleteConfirm: false, loading: true})
        }
        this.props.delete(this.props.match.params.id);
    }

    componentWillUnmount() {
        this.isComponentMounted = false;
    }

    updateRRObj(e) {
        let {name, value} = e.target;
        const {rr} = this.state;
        let i = name.slice(-1);
        name = name.slice(0, -1)
        if (['rrName', 'rrData', 'rrTtl', 'comments'].includes(name)) {
            if (!rr.rrStr.hasOwnProperty(i)) { //syntax to find the json key
                rr.rrStr[i] = {[name]: value}
            }
            else {
                rr.rrStr[i][name] = value
            }

            this.setState({rr: rr})
        } else {
            this.setState({rr: {...rr, [name]: {[i]: value}}})
        }

    }

    getRRPageButtons() {
        let pageElements = {
            pageTitle: '',
            pageButtons: [],
        }
        if (this.props.isEditable && this.props.isEmptyForm) {
            pageElements.pageTitle = "DNS A Insert Page"
            pageElements.pageButtons.push(<Button className={"dns-blue-button text-white mr-2"}
                //onClick={this.saveRRA}
                                                  type={"submit"}
                                                  key={"insert"}>Insert</Button>)
            pageElements.pageButtons.push(<Button className={"dns-blue-button text-white mr-2 col-md-1"}
                                                  onClick={() => {
                                                      this.props.alertClear();
                                                      this.props.history.push(`/dns/zones/details/${this.props.match.params.zoneNum}/rr/${this.props.match.params.type}`)
                                                  }}
                                                  key={"cancel_update"}>Cancel</Button>)
            if(this.props.match.params.id == 'multiple'  ) {
                if(this.state.formCount < 5){
                    pageElements.pageButtons.push(<Button className={"dns-blue-button text-white mr-2 col-md-1"}
                                                          onClick={() => {
                                                              this.setState({formCount: this.state.formCount + 1}) }}
                                                          key={"add"}>Add</Button>)
                }
                if(this.state.formCount > 1){
                    pageElements.pageButtons.push(<Button className={"dns-blue-button text-white mr-2 col-md-1"}
                                                          onClick={() => {
                                                              this.setState({formCount: this.state.formCount - 1}) }}
                                                          key={"remove"}>Remove</Button>)
                }

            }

        } else if (this.props.isEditable) {
            pageElements.pageTitle = "DNS A Modification"
            pageElements.pageButtons.push(<Button className={"dns-blue-button text-white mr-2 col-md-1"}
                //onClick={this.saveRRA}
                                                  type={"submit"}
                                                  key={"update"}>Update</Button>)
            pageElements.pageButtons.push(<Button className={"dns-blue-button text-white mr-2 col-md-1"}
                                                  onClick={() => {
                                                      this.props.alertClear();
                                                      this.props.history.goBack()
                                                  }}
                                                  key={"cancel_update"}>Cancel</Button>)


        } else {
            pageElements.pageTitle = "DNS A Details"
            pageElements.pageButtons.push(<Button className={"dns-blue-button text-white mt-2 mr-4 mb-4"}
                                                  onClick={() => this.props.history.push(`/dns/zones/details/${this.props.match.params.zoneNum}/rr/${this.props.match.params.type}/edit/${this.props.match.params.id}`)}
                                                  key={"edit"}>Go To Update</Button>)
            pageElements.pageButtons.push(<Button className={"dns-blue-button text-white mt-2 mr-4 mb-4"}
                                                  onClick={() => {
                                                      if (this.isComponentMounted) {
                                                          this.setState({showDeleteConfirm: true})
                                                      }
                                                  }} key={"delete"}>Delete</Button>)
            pageElements.pageButtons.push(<Button className={"dns-blue-button text-white mt-2 mb-4"}
                                                  onClick={() => this.props.history.push(`/dns/zones/details/${this.props.match.params.zoneNum}/rr/${this.props.match.params.type}`)}
                                                  key={"list_a_records"}>List A Records</Button>)


        }

        return pageElements;
    }

    getDeleteConfirmDialog() {
        return !this.props.isEditable && <Dialog
            onClose={(event, reason) => {
                if (reason === 'backdropClick' || reason === 'escapeKeyDown') {
                    return false;
                }
            }}
            maxWidth="xs"
            aria-labelledby="confirmation-dialog-title"
            open={this.state.showDeleteConfirm}
        >
            <DialogTitle id="confirmation_dialog_title">Are you sure you want to delete this
                record?</DialogTitle>
            <DialogActions>
                <Button autoFocus onClick={this.deleteRR} className={"dns-blue-button text-white"}>
                    Delete
                </Button>
                <Button onClick={() => {
                    if (this.isComponentMounted) {
                        this.setState({showDeleteConfirm: false})
                    }
                }}
                        className={"dns-blue-button text-white"}>
                    Cancel
                </Button>
            </DialogActions>
        </Dialog>
    }

    getRRAForm() {
        const {rr, zoneData} = this.state
        let {pageButtons} = this.getRRPageButtons();
        return <form onSubmit={this.saveRRA}>

            <Form.Group as={Row} className={"align-items-center pl-3 mb-0"}>
                {(this.props.isEmptyForm || !this.props.isEditable) && <><Form.Label column sm="2"
                                                                                     className={"font-weight-bold"}>
                    Zone ID
                </Form.Label>
                    <Col sm="2">
                        {rr.rrGrp}
                    </Col></>}
                {!this.props.isEmptyForm && !this.props.isEditable && <><Form.Label column sm="2"
                                                                                    className={"font-weight-bold"}>
                    Zone Name
                </Form.Label>
                    <Col sm="2">
                        {zoneData.zoneName}
                    </Col></>}
            </Form.Group>

            {this.getForms(this.state.formCount)}

            <div className={"text-center"}>
                {pageButtons.map(buttonComp => buttonComp)}
            </div>
        </form>
    }

    getForms(count) {
        const {rr, zoneData} = this.state
        return [...Array( count)].map((e, i) => {
            return <div key={i} className={"py-3 px-3"}>

                <Form.Group as={Row} key={`group1${i} a1`} className={"align-items-center mb-1"}>

                    {!this.props.isEmptyForm && <>  <Form.Label column sm="2" className={"font-weight-bold"}>
                        Record Id
                    </Form.Label>
                        <Col sm="2">
                            {rr.recId}
                        </Col></>}
                    {!this.props.isEditable && <>  <Form.Label column sm="2" className={"font-weight-bold"}>
                        Modified By
                    </Form.Label>
                        <Col sm="2">
                            {rr.modBy}
                        </Col></>}
                </Form.Group>

                <Form.Group as={Row} key={`group2${i}`} className={"align-items-center mb-1"}>
                    <Form.Label column sm="2" className={"font-weight-bold"}>
                        {this.props.isEditable ? "*" : ""}Host Name
                    </Form.Label>
                    <Col sm="4">
                        {this.props.isEditable ?
                            <Form.Control name={`rrName${i}`}
                                          onChange={this.updateRRObj}
                                          className={"w-50 d-inline"}
                                          defaultValue={rr.rrName ? rr.rrName : ''} required={true}/> : rr.rrName}
                        {/*
                            <span className={"d-inline"}> {zoneData.zoneName}</span>
*/}
                        <span className={"d-inline"}>{`.${zoneData.zoneName}`}</span>

                    </Col>
                </Form.Group>

                <Form.Group as={Row} key={`group3${i}`} className={"align-items-center mb-1"}>
                    <Form.Label column sm="2" className={"font-weight-bold"}>
                        {this.props.isEditable ? "*" : ""}IP Address
                    </Form.Label>
                    <Col sm="2">
                        {this.props.isEditable ?
                            <Form.Control name={`rrData${i}`}
                                          onChange={this.updateRRObj}
                                          defaultValue={rr.rrData ? rr.rrData : ''} required={true}/> : rr.rrData}
                    </Col>

                </Form.Group>


                <Form.Group as={Row} key={`group4${i}`} className={"align-items-center mb-1"}>
                    <Form.Label column sm="2" className={"font-weight-bold"}>
                        Time To Live
                    </Form.Label>
                    <Col sm="2">
                        {this.props.isEditable ?
                            <Form.Control name={`rrTtl${i}`}
                                          onChange={this.updateRRObj}
                                          defaultValue={rr.rrTtl ? rr.rrTtl : ''}/> : rr.rrTtl}
                    </Col>

                    {(!this.props.isEditable) && <>  <Form.Label column sm="2" className={"font-weight-bold"}>
                        CreateTime
                    </Form.Label>
                        <Col sm="2">
                            {rr.createTime}
                        </Col></>}

                </Form.Group>
                <Form.Group as={Row} key={`group5${i}`} className={"align-items-center mb-1"}>
                    <Form.Label column sm="2" className={"font-weight-bold"}>
                        Comment
                    </Form.Label>
                    <Col sm="2">
                        {this.props.isEditable ?
                            <Form.Control name={`comments${i}`}
                                          onChange={this.updateRRObj}
                                          defaultValue={rr.comments ? rr.comments : ''}/> : rr.comments}
                    </Col>
                    {(!this.props.isEditable) && <> <Form.Label column sm="2" className={"font-weight-bold"}>
                        Modified Time
                    </Form.Label>
                        <Col sm="2">
                            {rr.modTime}
                        </Col></>}
                </Form.Group>
                <hr/>
            </div>
        })
    }
    componentDidUpdate(prevProps, prevState, snapshot) {
        if(this.state.loading !== prevState.loading){
            this.setState({loading:false})

        }
    }

    render() {
        if (this.state.loading) {
            return <div>Loading....</div>
        }
        return (
            <>
                {this.getDeleteConfirmDialog()}
                 <Backdrop className={"page-loading"} style={{'zIndex': '10000', 'color': '#fff'}}
                                                 open={this.state.loading}>
                    <CircularProgress color="inherit"/>
                </Backdrop>
                <div>
                    <Helmet>
                        <title>DNS Admin | DNS Address (A) Records List</title>
                    </Helmet>
                    <Container maxWidth={false} className={"px-2"}>
                        <Card>
                            <CardContent>
                                <div className={'mt-3 ml-3 mr-3 mb-3'}>

                                    <h5 className="font-weight-bold  text-capitalize text-left pt-2 pl-2">DNS Address
                                        (A) Records List
                                    </h5>

                                    <div className={"pb-2"}>
                                        {this.props.alert.message && <Alert
                                            severity={this.props.alert.type}>{this.props.alert.message}</Alert>}</div>
                                    {this.getRRAForm()}
                                </div>
                            </CardContent>
                        </Card>
                    </Container>
                </div>
            </>
        )
    }
}

RrA.defaultProps = {
    isEditable: false,
};
RrA.propTypes = {
    isEditable: PropTypes.bool,
    isEmptyForm: PropTypes.bool
};
RrA.defaultProps = {
    isEditable: false,
    isEmptyForm: false
}

function mapState(state) {
    const {alert} = state
    return {alert}
}

const actionCreators = {
    create: resourceRecordActions.create,
    update: resourceRecordActions.update,
    delete: resourceRecordActions.delete,
    alertClear: alertActions.clear,
};
const connectedRrA = withRouter(connect(mapState, actionCreators)(RrA));
export {connectedRrA as RrA};

