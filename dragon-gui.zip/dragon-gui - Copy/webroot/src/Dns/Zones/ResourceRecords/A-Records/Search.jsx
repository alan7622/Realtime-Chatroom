import React from "react";
import {
    Backdrop, Card, FormControl,
    CardContent, CircularProgress, Button, Dialog,
    InputLabel,
    Select,
    MenuItem,
    DialogTitle,
    DialogContent,
    RadioGroup,
    FormControlLabel, Radio, DialogActions
} from "@material-ui/core";
import BootstrapTable from 'react-bootstrap-table-next';
import Container from "@material-ui/core/Container";
import {Helmet} from "react-helmet";
import {Link, withRouter} from "react-router-dom";
import {resourceRecordService, zoneService} from "../../../../_services";
import {alertActions} from "../../../../_actions";
import {connect} from "react-redux";
import {pageRenderer, SizePerPageRenderer} from "../../../../_components";
import paginationFactory from 'react-bootstrap-table2-paginator';
import {Form, Col, Row} from "react-bootstrap";
import _ from "lodash";
import {Comparator} from 'react-bootstrap-table2-filter';
import {Alert} from "@material-ui/lab";
import {ComparatorHelper} from "../../../../_helpers";


const defaultFilters = {
    rdata: {comparator: 'Eq', value: '...'},
    name: {comparator: 'Eq', value: ''},
    orderBy: {comparator: '', value: 'hostname'},
    orderDir: {comparator: '', value: 'asc'},
    rrType: "",
}

class Search extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            data: [],
            zoneName: '',
            zoneData: '',
            loading: true,
            rrType: '',
            filters: _.cloneDeep(defaultFilters),
            comparator: Comparator.EQ,
            showDeleteConfirm: false,
            showAdvanceSearch: false,
            error: '',
            rrSearchParams: {},
            page: 1,
            sizePerPage: 10,
            totalSize: 0,

        }
        this.isComponentMounted = false;
        this.handleTableChange = this.handleTableChange.bind(this);
        this.handleFilterChange = this.handleFilterChange.bind(this);
        this.getAdvanceSearchDialog = this.getAdvanceSearchDialog.bind(this);


        if ((this.props.location.state === null || this.props.location.state === undefined || !this.props.location.state.showAlerts) && !_.isEmpty(this.props.alert)) {
            this.props.alertClear()
        }

    }

    async componentDidMount() {
        this.isComponentMounted = true;
        setTimeout(() => {
            this.props.alertClear()
        }, 10000)//this clears alert message on listing or search page after 10 seconds
        //await this.loadTableData({zoneNum: this.props.match.params.zoneNum, rrType: this.props.match.params.rrType});
        await this.loadTableData({numberOfRows: this.state.sizePerPage, pageNumber: this.state.page});

        const res = await zoneService.getZoneById(this.props.match.params.zoneNum)
        if (this.isComponentMounted) {
            this.setState({zoneData: res.zone});
        }
    }

    async loadTableData(data) {
        if (this.isComponentMounted) {
            this.setState({loading: true})
        }
        for (var key in this.state.filters) {
            if (this.state.filters.hasOwnProperty(key) &&
                this.state.filters[key].value && this.state.filters[key].value != "...") {
                data[key +
                this.state.filters[key].comparator] = this.state.filters[key].value;
            }
        }
        data = {
            ...data,
            zoneNum: this.props.match.params.zoneNum,
            rrType: this.props.match.params.type,
        }
        const res = await resourceRecordService.getAllRecords(data);
        if (this.isComponentMounted) {
            this.setState({
                loading: false, data: res.rr, error: res.error, totalSize: res.totalRecords,
                page: data.pageNumber ? data.pageNumber : this.state.page,
                sizePerPage: data.numberOfRows ?
                    data.numberOfRows :
                    this.state.sizePerPage,
            });//will uncomment once I chnage in all RR's the same format and this ternary condition is for sizeperpage change in pagination
            //  this.setState({loading: false,  data: res.RRBOs, error: res.error});
        }
    }

    componentWillUnmount() {
        this.isComponentMounted = false;
    }

    handleFilterChange(e) {
        const {name, value} = e.target;
        const {filters} = this.state;
        const filterInfo = name.split('.');
        if (filterInfo.length === 3) {
            var t = filters[filterInfo[0]][filterInfo[1]].split('.')
            t[filterInfo[2]] = value
            filters[filterInfo[0]][filterInfo[1]] = t.join('.');
        } else {
            filters[filterInfo[0]][filterInfo[1]] = value;
        }
        this.setState({filters: filters});
    }


    async handleTableChange(type, {filters, page, sortOrder, sortField, sizePerPage, totalSize}) {
        const currentIndex = (page - 1) * sizePerPage;
        let rrSearchParams = {};
        if (sortField && sortOrder) {
            rrSearchParams.orderDir = sortOrder;
            rrSearchParams.orderBy = sortField;
        }

        rrSearchParams.numberOfRows = sizePerPage;
        rrSearchParams.pageNumber = page;
        await this.loadTableData(rrSearchParams);

    }

    paginationOptions() {
        return {
            sizePerPage: this.state.sizePerPage,
            page: this.state.page,
            totalSize: this.state.totalSize,
            alwaysShowAllBtns: true,
            withFirstAndLast: true,
            firstPageText: 'First',
            prePageText: 'Back',
            nextPageText: 'Next',
            lastPageText: 'Last',
            nextPageTitle: 'First page',
            prePageTitle: 'Pre page',
            firstPageTitle: 'Next page',
            lastPageTitle: 'Last page',
            showTotal: false,
            sizePerPageList: [
                {
                    text: '10', value: 10
                }, {
                    text: '20', value: 20
                },
                {
                    text: '50', value: 50
                },],
            pageButtonRenderer: pageRenderer,
            sizePerPageRenderer: ({
                                      options,
                                      currSizePerPage,
                                      onSizePerPageChange
                                  }) => <SizePerPageRenderer options={options}
                                                             currSizePerPage={currSizePerPage}
                                                             onSizePerPageChange={onSizePerPageChange}/>,

            disablePageTitle: true,
        };
    }

    getAdvanceSearchDialog() {
        const {zoneData} = this.state
        return <Dialog
            fullWidth={true}
            onClose={(event, reason) => {
                if (reason === 'backdropClick' || reason === 'escapeKeyDown') {
                    return false;
                }
            }}
            maxWidth="lg"
            open={this.state.showAdvanceSearch}
        >
            <DialogTitle id="form-dialog-title" className={"dialog-text-font-size"}> DNS Search Resource Records Page
            </DialogTitle>
            <DialogContent>
                <Form>

                    <Form.Group as={Row} className={'align-items-center'}>
                        <Form.Label column sm="2" className={'font-weight-bold'}>
                            Full Host Name
                        </Form.Label>
                        <Col sm={2}>
                            <FormControl variant="outlined">
                                <InputLabel htmlFor="wildcard-name-search">Full Host Name</InputLabel>
                                <Select
                                    autoWidth={true}
                                    className={'w-100'}
                                    name={'name.comparator'}
                                    value={this.state.filters.name.comparator}
                                    onChange={this.handleFilterChange}
                                    label="Full Host Name">
                                    {ComparatorHelper.getComparators.map(obj => (
                                        <MenuItem value={obj.value}
                                                  key={obj.value}>{obj.label}</MenuItem>
                                    ))}
                                </Select>
                            </FormControl>
                        </Col>
                        <Col sm={4}>
                            <Form.Control name={'name.value'}
                                          value={this.state.filters.name.value}
                                          className={"w-75 d-inline"}
                                          onChange={this.handleFilterChange}
                            />
                            <span className={"d-inline"}> {zoneData.zoneName}</span>
                        </Col>
                    </Form.Group>


                    <Form.Group as={Row} className={'align-items-center'}>
                        <Form.Label column sm="2" className={'font-weight-bold'}>
                            IP Address
                        </Form.Label>
                        {this.state.filters.rdata.value.split('.').map((v, k) => <Col sm={2} key={k}>
                                <Form.Control name={`rdata.value.${k}`} key={k}
                                              value={v}
                                              maxLength="2"
                                              type={"number"}
                                              onChange={this.handleFilterChange}/>
                            </Col>
                        )}
                    </Form.Group>


                    <Form.Group as={Row} className={"align-items-center"}>
                        <Form.Label column sm="3" className={'font-weight-bold'}>
                            Ordered By </Form.Label>
                        <Col sm={9} key={"orderBy"}>
                            <RadioGroup value={this.state.filters.orderBy.value} name={"orderBy.value"}
                                        onChange={this.handleFilterChange} row={true}>

                                <FormControlLabel value="hostname"
                                                  control={<Radio color="primary"/>}
                                                  label="Full Host Name"/>

                            </RadioGroup>
                        </Col>
                    </Form.Group>
                    <Form.Group as={Row} className={"align-items-center"}>
                        <Form.Label column sm="3" className={'font-weight-bold'}>
                            Ordered Direction </Form.Label>
                        <Col sm={9} key={"orderDir"}>
                            <RadioGroup value={this.state.filters.orderDir.value} name={"orderDir.value"}
                                        onChange={this.handleFilterChange} row={true}>

                                <FormControlLabel value="asc"
                                                  control={<Radio color="primary"/>}
                                                  label="Ascending"/>
                                <FormControlLabel value="desc" control={<Radio color="primary"/>}
                                                  label="Descending"/>


                            </RadioGroup>
                        </Col>
                    </Form.Group>

                </Form>
            </DialogContent>

            <DialogActions>
                <Button onClick={async (e) => {
                    await this.loadTableData({numberOfRows: this.state.sizePerPage, pageNumber: this.state.page});
                    this.setState(
                        {showAdvanceSearch: false});
                }
                } color="primary" className={'dns-blue-button text-white'}
                >
                    Search RRs
                </Button>
                <Button onClick={() => this.setState(
                    {showAdvanceSearch: false})}
                        color="primary" className={'dns-blue-button text-white'}>
                    Close
                </Button>
                <Button type={"reset"} onClick={() => {
                    this.setState({filters: _.cloneDeep(defaultFilters)}, () => {
                        this.loadTableData({numberOfRows: 10, pageNumber: 1})
                    });
                }} variant="contained"
                        className={"dns-blue-button text-white ml-2"}
                        disabled={JSON.stringify(this.state.filters) === JSON.stringify(defaultFilters)}>clear</Button>

            </DialogActions>


        </Dialog>
    }

    getRRATableColumns() {

        return [
            {
                text: 'Host Full Name',
                dataField: 'rrName',
                // sort: true,
                headerAlign: 'center',
                headerStyle: {
                    width: "45%"
                },
                classes: 'text-left p-0',
                style: {
                    'wordWrap': 'break-word'
                },
            },


            {

                text: 'IP Address',
                dataField: 'rrData',
                showHideSelection: true,
                headerAlign: 'center',
                headerStyle: {
                    width: "30%"
                },
                classes: 'text-left p-0',
                style: {
                    'wordWrap': 'break-word'
                },
            },
            {
                text: 'Last Modified',
                dataField: 'modTime',
                showHideSelection: true,
                headerAlign: 'center',
                headerStyle: {
                    width: "15%"
                },
                classes: 'text-center p-0',
                style: {
                    'wordWrap': 'break-word'
                },
            },
            {
                text: "Action",
                dataField: "",
                headerAlign: 'center',
                headerStyle: {
                    width: "10%"
                },
                classes: 'text-center p-0',
                style: {
                    'wordWrap': 'break-word'
                },
                formatter: (cell, row, rowIndex) => <>
                    <Link
                        to={`/dns/zones/details/${this.props.match.params.zoneNum}/rr/${this.props.match.params.type}/details/${row.recId}`}

                        key={"details_record"}
                        className={"color-dragon-blue mr-2"}
                    >Details</Link>
                    <Link
                        to={`/dns/zones/details/${this.props.match.params.zoneNum}/rr/${this.props.match.params.type}/edit/${row.recId}`}

                        key={"edit_record"}
                        className={"color-dragon-blue"}
                    >Edit</Link>
                </>
            },


        ];
    }

    render() {
        const {data} = this.state;
        const columns = this.getRRATableColumns();
        const paginationOptions = this.paginationOptions();
        return (<>
                {this.props.loading && <Backdrop className={"page-loading"} style={{'zIndex': '10000', 'color': '#fff'}}
                                                 open={this.state.loading}>
                    <CircularProgress color="inherit"/>
                </Backdrop>}

                <div>
                    <Helmet>
                        <title>DNS Resource Records|A Record</title>
                    </Helmet>
                    <Container maxWidth={false} className={"px-2"}>
                        <Card>
                            <CardContent>
                                <h5 className="font-weight-bold  text-capitalize text-left pt-3 pb-1 pl-4">
                                    DNS Address (A) Records List
                                </h5>
                                {this.getAdvanceSearchDialog()}
                                <div>

                                    {(!_.isEmpty(this.state.error) || !_.isEmpty(this.props.alert.message)) &&
                                    <Alert
                                        severity={!_.isEmpty(this.state.error) ? "error" : this.props.alert.type}>{(this.state.error && this.state.error.text) || this.props.alert.message}</Alert>}

                                    <div className="pl-4 pr-2">
                                        <div className={"col text-right mt-2 mb-2"}>
                                            <Link
                                                className={"d-inline-block btn btn-primary dns-blue-button mr-1"}
                                                to={"/dns/zones/details/" + this.props.match.params.zoneNum + "/rr/" + this.props.match.params.type + "/create"}
                                            >Insert Record</Link>
                                            <Link
                                                className={"d-inline-block btn btn-primary dns-blue-button mr-1"}
                                                to={"/dns/zones/details/" + this.props.match.params.zoneNum + "/rr/" + this.props.match.params.type + "/create/multiple"}
                                            >Insert Multiple A Records</Link>
                                            <Button aria-controls="simple-menu"
                                                    aria-haspopup="true"
                                                    color="primary"
                                                    className={'dns-blue-button'}
                                                    variant={'contained'}
                                                    onClick={() => {
                                                        this.setState(
                                                            {showAdvanceSearch: true});
                                                    }} key={'advance_search'}>Search</Button>
                                            {(JSON.stringify(this.state.filters) !== JSON.stringify(defaultFilters)) &&
                                            <Button type={"reset"} onClick={() => {
                                                this.props.alertClear();
                                                this.setState({filters: _.cloneDeep(defaultFilters),error:''}, () => {
                                                    this.loadTableData({numberOfRows: 10, pageNumber: 1})
                                                });
                                            }} variant="contained"
                                                    className={"dns-blue-button text-white ml-2"}


                                            >clear</Button>
                                            }
                                        </div>
                                        <div className={"pt-4 pb-4"}>
                                            <span
                                                className={'font-weight-bold'}
                                                key={"zoneName"}>Zone Name</span>: {this.state.zoneData.zoneName}

                                            <span
                                                className={'font-weight-bold  pl-5'}
                                                key={"zoneNum"}>Zone ID</span> : {this.state.zoneData.zoneNum}<br/>

                                        </div>


                                    </div>


                                </div>

                                <BootstrapTable bootstrap4
                                                keyField="recId"
                                                data={data}
                                                remote={{
                                                    pagination: true,
                                                }}
                                                columns={columns}
                                                onTableChange={this.handleTableChange}
                                                pagination={paginationFactory(paginationOptions)}
                                                noDataIndication="Table is Empty"
                                                id={"rr_a_table"}
                                                condensed
                                />

                            </CardContent>
                        </Card>
                    </Container>
                </div>
            </>
        )
    }

}

function mapState(state) {
    const {alert} = state
    return {alert}
}

const actionCreators =
    {
        alertClear: alertActions.clear,
    }
const connectedRrA = withRouter(connect(mapState, actionCreators)(Search));
export {connectedRrA as Search};
