import React, {Component} from "react";
import Container from "@material-ui/core/Container";
import {withRouter} from "react-router-dom";
import {
    Backdrop,
    Button,
    Card,
    CardContent,
    CircularProgress,
    Dialog,
    DialogActions,
    DialogTitle,
    Paper
} from "@material-ui/core";
import PropTypes from "prop-types";
import {alertActions} from "../../../../_actions";
import Form from 'react-bootstrap/Form'
import {Col} from "react-bootstrap";
import {Row} from "react-bootstrap";
import {Alert} from '@material-ui/lab';
import {connect} from "react-redux";
import {Helmet} from "react-helmet";
import {resourceRecordService} from "../../../../_services/resourceRecord.service";
import {resourceRecordActions} from "../../../../_actions/resourceRecords.actions";
import _ from "lodash";
import {history, replaceTemplateWithData, templatizedStringParser} from "../../../../_helpers";
import {zoneService} from "../../../../_services";
import {rrs} from "../../../../_reducers/rrs.reducer";


class RrHinfo extends Component {
    constructor(props) {
        super(props);
        this.state = {
            loading: true,
            showDeleteConfirm: false,
            zoneData: {},
            rr: {
                rrGrp: this.props.match.params.zoneNum,
                rrStr: '',
                rrType: this.props.match.params.type,
                comments: '',
                recId: '',
                rrTtl: ''

            },
            alert: '',

        };
        console.log('load')


        this.isComponentMounted = false;
        this.saveHinfo = this.saveHinfo.bind(this);
        this.updateRRObj = this.updateRRObj.bind(this);
        this.deleteRR = this.deleteRR.bind(this);
        this.getDeleteConfirmDialog = this.getDeleteConfirmDialog.bind(this);

        if ((this.props.location.state === null || this.props.location.state === undefined || !this.props.location.state.showAlerts) && !_.isEmpty(this.props.alert)) {
            this.props.alertClear()
        }

    }

    tmpl1 = "[rrName] [rrTtl] [class] [rrType] [cpu] [os]"
    tmpl2 = "[rrName] [class] [rrType] [cpu] [os]"

    saveHinfo(e) {
        e.preventDefault()
        if (this.isComponentMounted) {
            //  this.setState({loading: true})
            this.setState({loading: !this.props.isEmptyForm})//changed it so that it supports loading on create page
        }

        const {rrName, rrTtl, classN, rrType, cpu, os} = this.state.rr
        let rrStrTmp = {
            rrName,
            rrTtl,
            class: "IN",
            rrType,
            // cpu,
            cpu: `"${cpu}"`,/*[DRAGON3-349]:Adding quotes for Hardware(cpu) field, if space exists it is enclosed in quotes and sp will remove
            the quotes if there is no space in the field*/
            os: `"${os}"`
        }, resourceRecordHinfo;
        if (this.state.rr.hasOwnProperty('rrTtl')) {
            resourceRecordHinfo = {
                rrStr: replaceTemplateWithData(this.tmpl1, rrStrTmp),
                rrType: this.state.rr.rrType.toUpperCase(),
                rrGrp: this.state.rr.rrGrp,
                rrTtl: rrTtl && rrTtl != undefined ? rrTtl : '',
                comments: this.state.rr.comments
            }

        } else {
            delete rrStrTmp['rrTtl']
            resourceRecordHinfo = {
                rrStr: replaceTemplateWithData(this.tmpl2, rrStrTmp),
                rrType: this.state.rr.rrType.toUpperCase(),
                rrGrp: this.state.rr.rrGrp,
                comments: this.state.rr.comments
            }
        }

        if (this.props.isEmptyForm && this.props.isEditable) {
            this.props.create(resourceRecordHinfo);
        } else {
            this.props.update(this.props.match.params.id, resourceRecordHinfo, false,);
        }

    }

    async componentDidMount() {
        this.isComponentMounted = true;
        const res = await zoneService.getZoneById(this.props.match.params.zoneNum)
        this.setState({loading: !this.props.isEmptyForm, zoneData: res.zone});


        if (!this.props.isEmptyForm && this.isComponentMounted) {
            const rr = await resourceRecordService.getByRecordId(this.props.match.params.id);
            if (!_.isEmpty(rr) && this.isComponentMounted) {
                let rrStr
                //  rr.os = rr.rrData.split(" ")[0]
                //rr.cpu = rr.rrData.split(" ")[1]
                if (rr.hasOwnProperty('rrTtl')) {
                    rrStr = templatizedStringParser(this.tmpl1, rr.rrStr.replaceAll(/\"|'/g, ''))
                } else {
                    rrStr = templatizedStringParser(this.tmpl2, rr.rrStr.replaceAll(/\"|'/g, ''))

                }
                this.setState({loading: false, rr: {...rr, ...rrStr}});


            } else {
                this.props.alertClear()
                this.props.history.push(`/dns/zones/details/${this.props.match.params.zoneNum}/rr/${this.props.match.params.type}`);
            }

        }
    }

    deleteRR() {
        this.setState({showDeleteConfirm: false, loading: true})
        this.props.delete(this.props.match.params.id);
    }


    componentWillUnmount() {
        this.isComponentMounted = false;
    }

    componentDidUpdate(prevProps, prevState, snapshot) {
        if (this.state.loading !== prevState.loading) {
            this.setState({loading: false})

        }
    }


    updateRRObj(e) {
        let {name, value} = e.target;
        const {rr} = this.state;

        this.setState({rr: {...rr, [name]: value}})
    }


    getRRPageButtons() {
        let pageElements = {
            pageTitle: '',
            pageButtons: [],
        }
        if (this.props.isEditable && this.props.isEmptyForm) {
            pageElements.pageTitle = "DNS Host Information (HINFO) Record Creation"
            pageElements.pageButtons.push(<Button
                className={"dns-blue-button text-white mr-2"} //onClick={this.saveHinfo}
                type={"submit"}
                key={"insert"}>Insert</Button>)
            pageElements.pageButtons.push(<Button className={"dns-blue-button text-white mr-2 col-md-1"}
                                                  onClick={() => {
                                                      this.props.history.push(`/dns/zones/details/${this.props.match.params.zoneNum}/rr/${this.props.match.params.type}`)
                                                  }}
                                                  key={"cancel_update"}>Cancel</Button>)


        } else if (this.props.isEditable) {
            pageElements.pageTitle = "DNS HINFO Record Update"
            pageElements.pageButtons.push(<Button className={"dns-blue-button text-white mr-2 col-md-1"}
                //onClick={this.saveHinfo}
                                                  type={"submit"}
                                                  key={"update"}>Update</Button>)
            pageElements.pageButtons.push(<Button className={"dns-blue-button text-white mr-2 col-md-1"}
                                                  onClick={() => {
                                                      this.props.alertClear();

                                                      this.props.history.goBack()
                                                  }}
                                                  key={"cancel_update"}>Cancel</Button>)


        } else {
            pageElements.pageTitle = "DNS HINFO Record Details"
            pageElements.pageButtons.push(<Button className={"dns-blue-button text-white mt-2 mr-4 mb-4"}
                                                  onClick={() => this.props.history.push(`/dns/zones/details/${this.props.match.params.zoneNum}/rr/${this.props.match.params.type}/edit/${this.props.match.params.id}`)}
                                                  key={"edit"}>Go To Update</Button>)
            pageElements.pageButtons.push(<Button className={"dns-blue-button text-white mt-2 mr-4 mb-4"}
                                                  onClick={() => {
                                                      this.setState({showDeleteConfirm: true})
                                                  }} key={"delete"}>Delete</Button>)
            pageElements.pageButtons.push(<Button className={"dns-blue-button text-white mt-2 mb-4"}
                                                  onClick={() => this.props.history.push(`/dns/zones/details/${this.props.match.params.zoneNum}/rr/${this.props.match.params.type}`)}
                                                  key={"list_hinfo"}>List Hinfo Records</Button>)


        }

        return pageElements;
    }

    getDeleteConfirmDialog() {
        return !this.props.isEditable && <Dialog
            onClose={(event, reason) => {
                if (reason === 'backdropClick' || reason === 'escapeKeyDown') {
                    return false;
                }
            }}
            maxWidth="xs"
            aria-labelledby="confirmation-dialog-title"
            open={this.state.showDeleteConfirm}
        >
            <DialogTitle id="confirmation_dialog_title">Are you sure you want to delete this
                record?</DialogTitle>
            <DialogActions>
                <Button autoFocus onClick={this.deleteRR} className={"dns-blue-button text-white"}>
                    Delete
                </Button>
                <Button onClick={() => this.setState({showDeleteConfirm: false})}
                        className={"dns-blue-button text-white"}>
                    Cancel
                </Button>
            </DialogActions>
        </Dialog>
    }


    getHinfoForm() {
        const {rr, zoneData} = this.state
        let {pageButtons} = this.getRRPageButtons();

        return <form onSubmit={this.saveHinfo}>
            <Form.Group as={Row} className={"align-items-center"}>
                {(this.props.isEmptyForm || !this.props.isEditable) && <><Form.Label column sm="2"
                                                                                     className={"font-weight-bold"}>
                    Zone ID
                </Form.Label>
                    <Col sm="4">
                        {rr.rrGrp}
                    </Col></>}
                {!this.props.isEmptyForm && !this.props.isEditable && <><Form.Label column sm="2"
                                                                                    className={"font-weight-bold"}>
                    Zone Name
                </Form.Label>
                    <Col sm="4">
                        {zoneData.zoneName}
                    </Col></>}
            </Form.Group>
            <Form.Group as={Row} className={"align-items-center"}>
                {!this.props.isEmptyForm &&
                <> <Form.Label column sm="2" className={"font-weight-bold"}>
                    Record ID
                </Form.Label>
                    <Col sm="4">
                        {rr.recId}
                    </Col></>}
                <Form.Label column sm="2" className={"font-weight-bold"}>
                    {this.props.isEditable ? "*" : ""}Resource Record Name
                </Form.Label>
                <Col sm="4">
                    {this.props.isEditable ?
                        <Form.Control name={"rrName"}
                                      onChange={this.updateRRObj}
                                      className={"w-50 d-inline"}
                                      defaultValue={rr.rrName ? rr.rrName : ''}
                                      required={true}/> : rr.rrName}
                    <span className={"d-inline"}>{`.${zoneData.zoneName}`}</span> {/*adding the trailing dot for lhs so
                     that user avoid adding dot after rrName.*/}
                </Col>
            </Form.Group>
            <Form.Group as={Row} className={"align-items-center"}>
                <Form.Label column sm="2" className={"font-weight-bold"}>
                    {this.props.isEditable ? "*" : ""}CPU
                </Form.Label>
                <Col sm="4">
                    {this.props.isEditable ?
                        <Form.Control name={"cpu"}
                                      onChange={this.updateRRObj}
                                      defaultValue={rr.cpu ? rr.cpu : ''}
                                      required={true}/> : rr.cpu}
                </Col>
                <Form.Label column sm="2" className={"font-weight-bold"}>
                    {this.props.isEditable ? "*" : ""}Operating System
                </Form.Label>
                <Col sm="4">
                    {this.props.isEditable ?
                        <Form.Control name={"os"}
                                      onChange={this.updateRRObj}
                                      defaultValue={rr.os ? rr.os : ''}
                                      required={true}/> : rr.os}
                </Col>

            </Form.Group>
            {/*
            <Form.Group as={Row} className={"align-items-center"}>
                <Form.Label column sm="2" className={"font-weight-bold"}>
                    *Operating System
                </Form.Label>
                <Col sm="4">
                    {this.props.isEditable ?
                        <Form.Control name={"rrData2"}
                                      onChange={this.updateRRObj}
                                      defaultValue={rr.rrData2 ? rr.rrData2 : ''}/> : rr.rrData2}
                </Col>

            </Form.Group>
*/}
            <Form.Group as={Row} className={"align-items-center"}>
                <Form.Label column sm="2" className={"font-weight-bold"}>
                    Time To Live
                </Form.Label>
                <Col sm="4">
                    {this.props.isEditable ?
                        <Form.Control name={"rrTtl"}
                                      onChange={this.updateRRObj}
                                      defaultValue={rr.rrTtl && rr.rrTtl != undefined ? rr.rrTtl : ''}/> : rr.rrTtl}
                    {console.log(rr.rrTtl, "rr.rrTtl")}
                </Col>
                <Form.Label column sm="2" className={"font-weight-bold"}>
                    Comment
                </Form.Label>
                <Col sm="4">
                    {this.props.isEditable ?
                        <Form.Control name={"comments"}
                                      onChange={this.updateRRObj}
                                      defaultValue={rr.comments ? rr.comments : ''}/> : rr.comments}
                </Col>
            </Form.Group>
            <Form.Group as={Row} className={"align-items-center"}>
                {!this.props.isEmptyForm && !this.props.isEditable && <> <Form.Label column sm="2"
                                                                                     className={"font-weight-bold"}>
                    Create Time
                </Form.Label>
                    <Col sm="4">
                        {rr.createTime}
                    </Col></>}

                {!this.props.isEmptyForm && !this.props.isEditable && <>  <Form.Label column sm="2"
                                                                                      className={"font-weight-bold"}>
                    Last Modified
                </Form.Label>
                    <Col sm="4">
                        {rr.modTime}
                    </Col></>}

            </Form.Group>
            <Form.Group as={Row} className={"align-items-center"}>
                {!this.props.isEmptyForm && !this.props.isEditable && <><Form.Label column sm="2"
                                                                                    className={"font-weight-bold"}>
                    Modified By
                </Form.Label>
                    <Col sm="4">
                        {rr.modBy}
                    </Col></>}

            </Form.Group>
            <div className={"text-center"}>
                {pageButtons.map(buttonComp => buttonComp)}
            </div>

        </form>


    }


    render() {
        let {pageTitle} = this.getRRPageButtons();
        if (this.state.loading) {
            return <div>Loading....</div>
        }
        return (

            <>
                {this.getDeleteConfirmDialog()}
                <Backdrop className={"page-loading"} style={{'zIndex': '10000', 'color': '#fff'}}
                          open={this.state.loading}>
                    <CircularProgress color="inherit"/>
                </Backdrop>
                <div>
                    <Helmet>
                        <title>DNS Admin | DNS Hinfo Details Page</title>
                    </Helmet>
                    <Container maxWidth={false} className={"px-2"}>
                        <Card>
                            <CardContent>
                                <div className={'mt-3 ml-3 mr-3 mb-3'}>

                                    <h5 className="font-weight-bold  text-capitalize text-left pt-1 pl-1">{pageTitle}</h5>

                                    <div className={"pb-2"}>
                                        {this.props.alert.message && <Alert
                                            severity={this.props.alert.type}>{this.props.alert.message}</Alert>}</div>
                                    {this.getHinfoForm()}
                                </div>
                            </CardContent>
                        </Card>
                    </Container>

                </div>

            </>
        )
    }

}

RrHinfo.defaultProps = {
    isEditable: false,
};
RrHinfo.propTypes = {
    isEditable: PropTypes.bool,
    isEmptyForm: PropTypes.bool
};
RrHinfo.defaultProps = {
    isEditable: false,
    isEmptyForm: false
}

function mapState(state) {
    const {alert} = state
    const {loading, saved, deleted, deleting} = state.rrs
    return {alert, loading, saved, deleted, deleting}
}

const actionCreators = {
    create: resourceRecordActions.create,
    delete: resourceRecordActions.delete,
    update: resourceRecordActions.update,
    alertClear: alertActions.clear,
};


const connectedRrHinfo = withRouter(connect(mapState, actionCreators)(RrHinfo));
export {connectedRrHinfo as RrHinfo};

