import {alertActions} from './index';
import {history} from '../_helpers';
import {serverGroupService} from "../_services/serverGroup.service";
import {serverGroupsConstants} from "../_constants/serverGroups.constant";
import {resourceRecordConstants} from "../_constants";
import {resourceRecordService} from "../_services";

export const serverGroupActions = {
    get: _get,
    post: _post,
    create: _create,

};


function _get(params) {
    return dispatch => {
        dispatch(request());

        serverGroupService.get(params)
            .then(
                records => dispatch(success(record)),
                error => dispatch(failure(error.toString()))
            );
    };

    function request() {
        return {type: serverGroupsConstants.GETALL_REQUEST}
    }

    function success(records) {
        return {type: serverGroupsConstants.GETALL_SUCCESS, records}
    }

    function failure(error) {
        return {type: serverGroupsConstants.GETALL_FAILURE, error}
    }
}


function _post(params) {
    return dispatch => {
        dispatch({type: serverGroupsConstants.UPDATE_REQUEST})
        console.log("record res1", params)
        serverGroupService.saveSrvrGrp(params)
            .then(
                res => {
                    console.log("record res delete", params)
                    if (res.success && params.action =="D") {
                        console.log("record res after delete", res)
                        dispatch({type: serverGroupsConstants.UPDATE_SUCCESS})
                     dispatch(alertActions.success("zone_grp record updated with action : " +params.action));

                        history.push({
                            pathname: `/dns/zones/details/${params.zoneNum}/servers/SRVRGRP`,
                            state: {showAlerts: true}
                        })
                    }
                    else
                        {
                            dispatch({type: serverGroupsConstants.UPDATE_SUCCESS})
                            dispatch(alertActions.success("zone_grp record updated with action : " +params.action));
                            history.push({
                                pathname: `/dns/zones/details/${params.zoneNum}/servers/SRVRGRP/details/${params.groupName}`,
                             //   pathname: `/dns/zones/details/${params.zoneNum}/servers/SRVRGRP/details/${params.zoneNum}`,
                                state: {showAlerts: true}
                            })
                        }


                },
                error => {
                    console.log(" error", error)
                    dispatch({type: serverGroupsConstants.UPDATE_FAILURE})
                    dispatch(alertActions.error(error.text));
                }
            );
    };
}

function _create(servers) {
    return dispatch => {
        dispatch({type: resourceRecordConstants.CREATE_REQUEST})
        resourceRecordService.saveRecord("", servers)
            .then(
                res => {
                    if (res.success) {
                        dispatch({type: resourceRecordConstants.CREATE_SUCCESS})
                       dispatch(alertActions.success("The  record has been successfully inserted"));
                      //  dispatch(alertActions.success(res.text));

                        let rrNS = res.servers.split("-")[1]
                        if (rrNS.split(" ").length > 1) {
                            history.push({
                                pathname: `/dns/zones/details/${servers.rrGrp}/servers/${servers.rrType}`,
                                state: {showAlerts: true}
                            })

                        } else {
                            // history.push({pathname: `/dns/zones/details/${rr.rrGrp}/rr/${rr.rrType}/details/${idRes}`, state: {showAlerts: true}})

                            history.push({
                                pathname: `/dns/zones/details/${servers.rrGrp}/servers/${servers.type}/details/${rrNS}`,
                                state: {showAlerts: true}
                            })
                        }


                        /* const rrNS = this.props.match.params.type.split("-")
                         rrType: rrNS[1],
                         dispatch({type: resourceRecordConstants.CREATE_SUCCESS})
                         dispatch(alertActions.success("The  record has been successfully inserted"));


                             history.push({
                                 pathname: `/dns/zones/details/${servers.rrGrp}/servers/${servers.rrType}`,
                                 state: {showAlerts: true}
                             })*/
                    }

                },
                error => {
                    dispatch({type: resourceRecordConstants.CREATE_FAILURE})
                    dispatch(alertActions.error(error.text));
                }
            );
    };
}



