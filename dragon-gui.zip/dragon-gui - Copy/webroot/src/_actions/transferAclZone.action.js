import {transferAclZone as transferAclZoneService, transferAclZone} from "../_services";
import {xferAclZoneConstants, zoneConstants} from "../_constants";
import {alertActions} from "./alert.actions";
import {history} from '../_helpers';


export const transferAclZones = {

    getAclZone: _getAclZone,
    update: _update,
    delete: _delete,

};


function _getAclZone(data) {
    return dispatch => {
        dispatch(request());

        transferAclZone.getAclXfer()
            .then(
                aclZones => dispatch(success(data)),
                error => dispatch(failure(error.toString()))
            );
    };

    function request() {
        return {type: xferAclZoneConstants.GETALL_REQUEST}
    }

    function success(aclZones) {
        return {type: xferAclZoneConstants.GETALL_SUCCESS, aclZones}
    }

    function failure(error) {
        return {type: xferAclZoneConstants.GETALL_FAILURE, error}
    }
}

function _update(zoneNum, acldata,type) {
    return dispatch => {
        dispatch({type: xferAclZoneConstants.UPDATE_REQUEST})
        transferAclZoneService.aclsUpdate(zoneNum, acldata)
            .then(
                res => {
                    console.log("zone add response", res)
                    dispatch({type: xferAclZoneConstants.UPDATE_SUCCESS})
                    dispatch(alertActions.success(res));
                    history.push({pathname: `/dns/zones/details/${zoneNum}/xferzones/${type}`, state: {showAlerts: true}})

                },
                error => {
                    console.log(" add error", error)
                    dispatch({type: xferAclZoneConstants.UPDATE_FAILURE})
                    dispatch(alertActions.error(error.text));
                }
            );
    };
}

function _delete(zoneNum, id,type) {
    return dispatch => {
        dispatch(request(id));
        console.log("delete action")

        transferAclZoneService.aclsDelete(zoneNum)
            .then(
                res => {
                    console.log("delete action")
                    dispatch(success(id));
                    dispatch(alertActions.success(res));

                    history.push({
                        pathname: `/dns/zones/details/${zoneNum}/xferzones/${type}`,
                        state: {showAlerts: true}
                    })
                },
                error => {
                    dispatch(failure(id, error.text));
                    dispatch(alertActions.error(error.text));
                }
            );
    };

    function request(id) {
        return {type: xferAclZoneConstants.DELETE_REQUEST, id}
    }

    function success(id) {
        return {type: xferAclZoneConstants.DELETE_SUCCESS, id}
    }

    function failure(id, error) {
        return {type: xferAclZoneConstants.DELETE_FAILURE, id, error}
    }
}