import {zoneService} from "../_services";
import {zoneConstants} from "../_constants";
import {alertActions} from "./alert.actions";
import {history} from '../_helpers';



export const zoneActions = {

    getZones: _getZones,
    create:_create,
    update: _update,
    delete: _delete,
    updateStatus: _updateStatus,
    clearStack : _clearStack
};


function _getZones(zoneNum) {
    return dispatch => {
        dispatch(request());

        zoneService.getAll()
            .then(
                filters => dispatch(success(zoneNum)),
                error => dispatch(failure(error.toString()))
            );
    };

    function request() {
        return {type: zoneConstants.GETALL_REQUEST}
    }

    function success(zones) {
        return {type: zoneConstants.GETALL_SUCCESS, zones}
    }

    function failure(error) {
        return {type: zoneConstants.GETALL_FAILURE, error}
    }
}
function _updateStatus(zoneNum, status) {
    return dispatch => {
        dispatch(request(zoneNum, status));
        zoneService.updateStatus(zoneNum, status).then(
            resp => {
                zoneService.getZoneById(zoneNum).then(res  => {
                    dispatch(success(res.zone, status))
                    dispatch(alertActions.success(resp))
                    history.push({pathname: `/dns/zones/details/${zoneNum}`, state: {showAlerts: true}})
                });

            },
            error => {
                dispatch(failure(zoneNum, error.text));
                dispatch(alertActions.error(error.text));
            }
        )
    }
    function request(id,status) {
        return {type: zoneConstants.UPDATE_REQUEST, id, status}
    }

    function success(zone,status) {
        return {type: zoneConstants.UPDATE_SUCCESS, zone, status}
    }

    function failure(id, error) {
        return {type: zoneConstants.UPDATE_FAILURE, id, error}
    }
}
function _create(zone) {
    return dispatch => {
        dispatch({type: zoneConstants.CREATE_REQUEST})
        zoneService.saveZone(zone)
            .then(
                res => {
                    console.log("zone create response1", res)

                    if (res.success) {
                        console.log("zone create response", res)
                        zoneService.getZoneById(res.zone.split("=")[1]).then(res  => {
                            dispatch({type: zoneConstants.CREATE_SUCCESS, zone: res.zone})
                            dispatch(alertActions.success("Zone created Successfully"));
                            history.push({
                                pathname: `/dns/zones/details/${res.zone.zoneNum}`,
                                state: {showAlerts: true}
                            })
                        });
                    }

                },
                error => {
                    console.log("zone error", error)
                    dispatch({type: zoneConstants.CREATE_FAILURE})
                    dispatch(alertActions.error(error.text));
                }
            );
    };
}
 function  _update(zone, zoneNum) {
    return dispatch => {
        dispatch({type: zoneConstants.UPDATE_REQUEST})
        console.log("zone update response1", zone)
         zoneService.saveZone(zone, zoneNum)
            .then(
                res => {
                    console.log(zone,"zone.comments")
                    if (res.success) {
                        console.log("zone update response1", zone)
                        zoneService.getZoneById(zoneNum).then(res  => {
                            dispatch(alertActions.success("The Zone has been updated Successfully"));
                            dispatch({type: zoneConstants.UPDATE_SUCCESS, zone: res.zone})
                            history.push({pathname: `/dns/zones/details/${zoneNum}`, state: {showAlerts: true}})
                        });

                    }

                },
                error => {
                    console.log(" update error", error)
                    dispatch({type: zoneConstants.UPDATE_FAILURE})
                    dispatch(alertActions.error(error.text));
                }
            );
    };
}

function _clearStack() {
    return dispatch => {
        dispatch({type: zoneConstants.CLEAR_ZONE_STORE})
    }
}
function _delete(id) {
    return dispatch => {
        dispatch(request(id));

        zoneService.deleteZone(id)
            .then(
                zone => {
                    dispatch(success(id));
                    dispatch(alertActions.success("Zone Deleted Successfully"));
                    history.push({pathname:"/dns/zones/search", state: {showAlerts: true}})
                },
                error => {
                    dispatch(failure(id, error.text));
                    dispatch(alertActions.error(error.text));
                }
            );
    };

    function request(id) {
        return {type: zoneConstants.DELETE_REQUEST, id}
    }

    function success(id) {
        return {type: zoneConstants.DELETE_SUCCESS, id}
    }

    function failure(id, error) {
        return {type: zoneConstants.DELETE_FAILURE, id, error}
    }
}
