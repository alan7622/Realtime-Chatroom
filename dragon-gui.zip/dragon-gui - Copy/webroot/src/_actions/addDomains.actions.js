import {newDomainService, zoneService} from "../_services";
import {accountConstants as addDomainConstants, Constants, zoneConstants} from "../_constants";
import {alertActions} from "./alert.actions";
import {history} from '../_helpers';



export const addDomainsActions = {

    getDomains: _getDomains,
    delete: _delete,

};


function _getDomains(searchParams) {
    return dispatch => {
        dispatch(request());

        newDomainService.getDomains()
            .then(
                filters => dispatch(success(searchParams)),
                error => dispatch(failure(error.toString()))
            );
    };

    function request() {
        return {type: addDomainConstants.GETALL_REQUEST}
    }

    function success(addDomains) {
        return {type: addDomainConstants.GETALL_SUCCESS, addDomains}
    }

    function failure(error) {
        return {type: addDomainConstants.GETALL_FAILURE, error}
    }
}

function _delete(id) {
    return dispatch => {
        dispatch(request(id));

        zoneService.deleteZone(id)
            .then(
                zone => {
                    dispatch(success(id));
                    dispatch(alertActions.success("Zone Deleted Successfully"));
                    history.push({pathname:"/dns/zones/search", state: {showAlerts: true}})
                },
                error => {
                    dispatch(failure(id, error.text));
                    dispatch(alertActions.error(error.text));
                }
            );
    };

    function request(id) {
        return {type: zoneConstants.DELETE_REQUEST, id}
    }

    function success(id) {
        return {type: zoneConstants.DELETE_SUCCESS, id}
    }

    function failure(id, error) {
        return {type: zoneConstants.DELETE_FAILURE, id, error}
    }
}
