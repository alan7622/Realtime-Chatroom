import {delegationNSService} from "../_services";
import {delegateNameserverConstants, delegationConstants, userConstants} from "../_constants";
import {alertActions} from "./alert.actions";
import {history} from "../_helpers";

export const delegateNameserverActions = {
    getDelegations: _getDelegations,
    create: _create,
    update: _update,
    delete: _delete,

};

function _getDelegations(nameserver) {
    return dispatch => {
        dispatch(request());

        delegationNSService.getAllDelegationNameServers()
            .then(
                nameservers => dispatch(success(nameserver)),
                error => dispatch(failure(error.toString()))
            );
    };
}

function _create(nameserver,zoneNum) {
    return dispatch => {
        dispatch({type: delegateNameserverConstants.CREATE_REQUEST})

        delegationNSService.saveDelegationNameServer("", nameserver)
            .then(
                res => {
                    console.log("delegation create response2", res)

                    if (res.success) {
                        dispatch({type: delegateNameserverConstants.CREATE_SUCCESS})
                        dispatch(alertActions.success("delegation created Successfully"));
                        history.push({
                            //pathname: `/dns/zones/details/${zoneNum}/zoneDelegation/${res.nameserver.delegationId}/delg/nameserver/${recId}`,

                           pathname: `/dns/zones/search/details/${zoneNum}/zoneDelegation/${nameserver.delegationId}/delg/nameserver`,

                                state: {showAlerts: true}
                            }
                        );
                    }

                },
                error => {
                    dispatch({type: delegateNameserverConstants.CREATE_FAILURE})
                    dispatch(alertActions.error(error.text));
                }
            );
    };
}

function _update(recId, zoneNum, nameserver) {
    return dispatch => {
        dispatch({type: delegateNameserverConstants.UPDATE_REQUEST})
        delegationNSService.saveDelegationNameServer(recId, nameserver)
            .then(
                res => {
                    if (res.success) {
                        delegationNSService.getByDelegationId(recId).then(res => {
                            dispatch(alertActions.success("Delegation Updated Successfully"));

                            dispatch({type: delegationConstants.UPDATE_SUCCESS, nameserver: res.nameserver})

                            history.push({
                                //pathname: `/dns/zones/details/${zoneNum}/zoneDelegation/${res.nameserver.delegationId}/delg/nameserver`,

                                pathname: `/dns/zones/search/details/${zoneNum}/zoneDelegation/${res.nameserver.delegationId}/delg/nameserver/${recId}`,
                                state: {showAlerts: true}


                            })
                        });

                    }

                },
                error => {
                    console.log(" update error", error)
                    dispatch({type: delegateNameserverConstants.UPDATE_FAILURE})
                    dispatch(alertActions.error(error.text));
                }
            );
    };
}

/*
function request() {
    return {type: delegateNameserverConstants.GETALLRECORDS_REQUEST}
}

function success(delegations) {
    return {type: delegateNameserverConstants.GETALLRECORDS_SUCCESS, delegations}
}

function failure(error) {
    return {type: delegateNameserverConstants.GETALLRECORDS_FAILURE, error}
}*/

function _delete(id,zoneNum,delegationId) {
    return dispatch => {
        dispatch(request(id));

        delegationNSService.deleteDelegationNameServer(id)
            .then(
                delegationNS => {
                    dispatch(success(id));

                    dispatch(alertActions.success("Deleted Successfully"));

                    history.push({
                        pathname: `/dns/zones/search/details/${zoneNum}/zoneDelegation/${delegationId}/delg/nameserver`,
                        state: {showAlerts: true}
                    })
                },
/*
                error => {
                    dispatch(failure(id, error.text));
                    dispatch(alertActions.error(error.text));
                }
*/

        error => {
            console.log("error")

            dispatch(failure(id, error.text));
            dispatch(alertActions.error(error.text));
            history.push({pathname: `/dns/zones/search/details/${zoneNum}/zoneDelegation/${delegationId}/delg/nameserver`, state: {showAlerts: true}})

        }




    );
    };

    function request(id) {
        return {type: delegateNameserverConstants.DELETE_REQUEST, id}
    }

    function success(id) {
        return {type: delegateNameserverConstants.DELETE_SUCCESS, id}
    }

    function failure(id, error) {
        return {type: delegateNameserverConstants.DELETE_FAILURE, id, error}
    }
}