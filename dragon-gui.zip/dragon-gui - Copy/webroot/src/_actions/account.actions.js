import {alertActions} from './index';
import {history} from '../_helpers';
import {accountService} from "../_services";
import {accountConstants} from "../_constants";

export const accountActions = {

    getAccounts: _getAccounts,
    create: _create,
    update: _update,
    delete: _delete,
    updateStatus: _updateStatus
};


function _updateStatus(accountId, status) {
    return dispatch => {
        dispatch(request(accountId, status));
        accountService.updateStatus(accountId, status).then(
            resp => {
                dispatch(success(accountId, status))
                dispatch(alertActions.success(resp))
            },
            error => {
                dispatch(failure(accountId, error.text));
                dispatch(alertActions.error(error.text));
            }
        )
    }
    function request(id) {
        return {type: accountConstants.UPDATE_REQUEST, id, status}
    }

    function success(id) {
        return {type: accountConstants.UPDATE_SUCCESS, id, status}
    }

    function failure(id, error) {
        return {type: accountConstants.UPDATE_FAILURE, id, error}
    }
}


function _getAccounts(accountId) {
    return dispatch => {
        dispatch(request());

        accountService.getAll()
            .then(
                filters => dispatch(success(accountId)),
                error => dispatch(failure(error.toString()))
            );
    };

    function request() {
        return {type: accountConstants.GETALL_REQUEST}
    }

    function success(accounts) {
        return {type: accountConstants.GETALL_SUCCESS, accounts}
    }

    function failure(error) {
        return {type: accountConstants.GETALL_FAILURE, error}
    }
}

function _create(account) {
    return dispatch => {
        dispatch({type: accountConstants.CREATE_REQUEST})
        accountService.saveAccount(account)
            .then(
                res => {
                    if (res.success) {
                        console.log("account create response", res)
                        dispatch({type: accountConstants.CREATE_SUCCESS})
                        dispatch(alertActions.success("Account created Successfully"));
                        history.push({pathname: `/dns/accounts/details/${res.account.accountId}`, state: {showAlerts: true}})
                    }

                },
                error => {
                    console.log("account error", error)
                    dispatch({type: accountConstants.CREATE_FAILURE})
                    dispatch(alertActions.error(error.text));
                }
            );
    };
}

function _update(account, accountId) {
    return dispatch => {
        dispatch({type: accountConstants.UPDATE_REQUEST})
        accountService.saveAccount(account, accountId)
            .then(
                res => {
                    if (res.success) {
                        console.log("account update response", res)
                        dispatch(alertActions.success("The Account has been updated Successfully"));
                        dispatch({type: accountConstants.UPDATE_SUCCESS})
                        history.push({pathname: `/dns/accounts/details/${res.account.accountId}`, state: {showAlerts: true}})
                    }

                },
                error => {
                    console.log(" update error", error)
                    dispatch({type: accountConstants.UPDATE_FAILURE})
                    dispatch(alertActions.error(error.text));
                }
            );
    };
}


function _delete(id) {
    return dispatch => {
        dispatch(request(id));

        accountService.deleteAccount(id)
            .then(
                account => {
                    dispatch(success(id));
                    dispatch(alertActions.success("Account Deleted Successfully"));
                    history.push({pathname:"/dns/accounts/search", state: {showAlerts: true}})
                },
                error => {
                    dispatch(failure(id, error.text));
                    dispatch(alertActions.error(error.text));
                }
            );
    };

    function request(id) {
        return {type: accountConstants.DELETE_REQUEST, id}
    }

    function success(id) {
        return {type: accountConstants.DELETE_SUCCESS, id}
    }

    function failure(id, error) {
        return {type: accountConstants.DELETE_FAILURE, id, error}
    }
}

/*
function _activatesuspend(account,accountId) {
    return dispatch => {
        dispatch(request(id));

        accountService.activateorsuspendAccount(account,accountId)
            .then(
                account => {
                    dispatch(success(id));
                    dispatch(alertActions.success("Account Suspended Successfully"));
                    history.push("/dns/accounts/search")
                },
                error => {
                    dispatch(failure(id, error.text));
                    dispatch(alertActions.error(error.text));
                }
            );
    };

    function request(id) {
        return {type: accountConstants.DELETE_REQUEST, id}
    }

    function success(id) {
        return {type: accountConstants.DELETE_SUCCESS, id}
    }

    function failure(id, error) {
        return {type: accountConstants.DELETE_FAILURE, id, error}
    }
}*/
