import {delegationService, zoneService} from "../_services";
import {delegationConstants, zoneConstants} from "../_constants";
import {alertActions} from "./alert.actions";
import {history} from "../_helpers";

export const delegationActions = {

    getDelegations: _getDelegations,
    create: _create,
    update: _update,
    delete: _delete,

};

function _getDelegations(delegation) {
    return dispatch => {
        dispatch(request());

        delegationService.getAllDelegations()
            .then(
                obj => {
                    dispatch(success(obj));
                    console.log("hello", obj)
                },
                error => {
                    console.log("hello", error)
                    dispatch(failure(error))
                    history.push({
                        pathname: `/dns/zones/search/details/${delegation.zoneNum}/zoneDelegation`,

                        state: {showAlerts: true}
                    })

                }
            );
    };
}

function _create(delegation) {
    return dispatch => {
        dispatch({type: delegationConstants.CREATE_REQUEST})

        delegationService.saveDelegation("", delegation)
            .then(
                res => {
                    console.log("delegation create response2", res)

                    if (res.success) {
                        dispatch({type: delegationConstants.CREATE_SUCCESS, delegation: res.delegation})

                        dispatch(alertActions.success("Delegation created Successfully"));
                        history.push({
                                pathname: `/dns/zones/search/details/${delegation.zoneNum}/zoneDelegation`,

                                state: {showAlerts: true}
                            }
                        );
                    }

                },
                error => {
                    dispatch({type: delegationConstants.CREATE_FAILURE})
                    dispatch(alertActions.error(error.text));
                }
            );
    };
}

function _update(delegationNum, delegation) {
    return dispatch => {
        dispatch({type: delegationConstants.UPDATE_REQUEST})
        delegationService.saveDelegation(delegationNum, delegation)
            .then(
                res => {
                    if (res.success) {
                        delegationService.getByDelegationId(delegationNum).then(res => {
                            dispatch(alertActions.success("Delegation Updated Successfully"));

                            dispatch({type: delegationConstants.UPDATE_SUCCESS, delegation: res.delegation})

                            history.push({
                                pathname: `/dns/zones/search/details/${res.delegation.zoneNum}/zoneDelegation/${delegationNum}`,
                                state: {showAlerts: true}
                            })

                        });

                    }

                },
                error => {
                    console.log(" update error", error)
                    dispatch({type: delegationConstants.UPDATE_FAILURE})
                    dispatch(alertActions.error(error.text));
                }
            );
    };
}


/*function request() {
    return {type: delegationConstants.GETALL_REQUEST}
}

function success(delegations) {
    return {type: delegationConstants.GETALL_SUCCESS, delegations}
}

function failure(error) {
    return {type: delegationConstants.GETALL_FAILURE, error}
}*/

function _delete(id, zoneNum) {
    console.log(id, "id")
    return dispatch => {
        dispatch(request(id));

        delegationService.deleteDelegation(id)
            .then(
                delegation => {
                    console.log(id, "id1")
                    dispatch(success(id));

                    dispatch(alertActions.success(" Deleted Successfully"));
                    history.push({pathname: `/dns/zones/search/details/${zoneNum}/zoneDelegation`, state: {showAlerts: true}})
                },
                error => {
                    console.log("error")

                    dispatch(failure(id, error.text));
                    dispatch(alertActions.error(error.text));
                    history.push({pathname: `/dns/zones/search/details/${zoneNum}/zoneDelegation`, state: {showAlerts: true}})

                }
            );
    };

    function request(id) {
        return {type: delegationConstants.DELETE_REQUEST, id}
    }

    function success(id) {
        return {type: delegationConstants.DELETE_SUCCESS, id}
    }

    function failure(id, error) {
        return {type: delegationConstants.DELETE_FAILURE, id, error}
    }
}
