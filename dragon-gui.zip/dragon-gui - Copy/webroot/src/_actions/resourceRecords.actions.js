import {alertActions} from './index';
import {history} from '../_helpers';
import {resourceRecordService} from "../_services";
import {resourceRecordConstants} from "../_constants";

export const resourceRecordActions = {
    getRecords: _getRecords,
    delete: _delete,
    createOrUpdate,
    update: _update,
    create: _create,


};


function _getRecords() {
    return dispatch => {
        dispatch(request());

        resourceRecordService.getAllRecords()
            .then(
                records => dispatch(success(record)),
                error => dispatch(failure(error.toString()))
            );
    };

    function request() {
        return {type: resourceRecordConstants.GETALL_REQUEST}
    }

    function success(records) {
        return {type: resourceRecordConstants.GETALL_SUCCESS, records}
    }

    function failure(error) {
        return {type: resourceRecordConstants.GETALL_FAILURE, error}
    }
}

// prefixed function name with underscore because delete is a reserved word in javascript
function createOrUpdate(rr, id = '', dns = 'rr', excludeRRStr = true) {
    if (excludeRRStr) {
        delete rr['rrStr']; //adding it for one  particular rr  in which rrStr cannot be updated
    }
    return dispatch => {
        dispatch({type: resourceRecordConstants.CREATE_UPDATE_REQUEST})
        resourceRecordService.saveRecord(id, rr)
            .then(
                res => {
                    let rrType = rr.rrType
                    if (dns === 'servers') {
                        rrType = rr.nsType + "-" + rr.rrType
                    }
                    if (res.success) {
                        dispatch({type: resourceRecordConstants.CREATE_UPDATE_SUCCESS})
                        dispatch(alertActions.success(res.rr));
                        let url = `/dns/zones/details/${rr.rrGrp}/${dns}/${rrType}`;
                        if(id) {
                            url += `/details/${id}`;
                        }else{
                            let idRes = res.rr.split(":")[1]
                            if (idRes.split(" ").length == 1) {
                                url += `/details/${idRes}`;
                            }
                        }
                        history.push({
                            pathname: url,
                            state: {showAlerts: true}
                        })

                    }

                },
                error => {
                    dispatch({type: resourceRecordConstants.CREATE_UPDATE_FAILURE})
                    dispatch(alertActions.error(error.text));
                }
            );
    };
}

function _create(rr, dns = 'rr') {

    return dispatch => {
        dispatch({type: resourceRecordConstants.CREATE_REQUEST})
        resourceRecordService.saveRecord("", rr)
            .then(
                res => {
                    let rrType = rr.rrType
                    if (dns == 'servers') {

                        rrType = rr.nsType + "-" + rr.rrType
                    }
                    if (res.success) {
                        dispatch({type: resourceRecordConstants.CREATE_SUCCESS})
                        dispatch(alertActions.success("The  record has been successfully inserted"));
                        let idRes = res.rr.split(" = ")[1]
                        if (idRes.split(" ").length > 1) {
                            history.push({
                                pathname: `/dns/zones/details/${rr.rrGrp}/${dns}/${rrType}`,

                                state: {showAlerts: true}
                            })

                        } else {
                            // history.push({pathname: `/dns/zones/details/${rr.rrGrp}/rr/${rr.rrType}/details/${idRes}`, state: {showAlerts: true}})

                            history.push({
                                pathname: `/dns/zones/details/${rr.rrGrp}/${dns}/${rr.type}/details/${idRes}`,


                                state: {showAlerts: true}
                            })
                        }
                    }

                },
                error => {
                    console.log(" error", error)
                    dispatch({type: resourceRecordConstants.CREATE_FAILURE})
                    dispatch(alertActions.error(error.text));
                }
            );
    };
}

function _update(recId, rrDetails, excludeRRStr = true) {
    return dispatch => {
        dispatch({type: resourceRecordConstants.UPDATE_REQUEST})
        if (excludeRRStr) {
            delete rrDetails['rrStr']; //adding it for one  particular rr  in which rrStr cannot be updated
        }
        resourceRecordService.saveRecord(recId, rrDetails)
            .then(
                res => {
                    if (res.success) {
                        console.log(" update response 1", res)
                        console.log("rrDetails 1", rrDetails)

                        dispatch({type: resourceRecordConstants.UPDATE_SUCCESS})
                        dispatch(alertActions.success("The  record has been  successfully updated"));
                        const path = history.location.pathname.replace('edit', 'details')
                        console.log("rrDetails 3", rrDetails)

                        history.push({pathname: path, state: {showAlerts: true}})

                    }

                },
                error => {
                    dispatch({type: resourceRecordConstants.UPDATE_FAILURE})
                    dispatch(alertActions.error(error.text));
                }
            );
    };
}

function _delete(id) {
    //  const pathArr= history.location.pathname.split("/")

    //  console.log(pathArr.slice(0,pathArr.length-2).join("/"),"PATHNAME")

    return dispatch => {
        dispatch(request(id));
        resourceRecordService.deleteRecord(id)
            .then(
                rr => {
                    dispatch(success(id));
                    dispatch(alertActions.success("The resource record has been successfully deleted"));
                    const pathArr = history.location.pathname.split("/")

                    history.push({pathname: pathArr.slice(0, pathArr.length - 2).join("/"), state: {showAlerts: true}})
                },
                error => {
                    dispatch(failure(id, error.text));
                    dispatch(alertActions.error(error.text));
                }
            );
    };

    function request(id) {
        return {type: resourceRecordConstants.DELETE_REQUEST, id}
    }

    function success(id) {
        return {type: resourceRecordConstants.DELETE_SUCCESS, id}
    }

    function failure(id, error) {
        return {type: resourceRecordConstants.DELETE_FAILURE, id, error}
    }
}


