import {userConstants} from '../_constants';
import {userService} from '../_services';
import {alertActions} from './index';
import {deleteAllCookies, history} from '../_helpers';

export const userActions = {
    login,
    logout,
    register,
    getUsers: _getUsers,
    delete: _delete,
    create: _create,
    update: _update,
    loginWithAttuid
};

function loginWithAttuid(attuid) {
    return dispatch => {
        dispatch({type: userConstants.LOGIN_REQUEST, user: {attUid: attuid }});
        userService.getUsers({attUidEq:attuid }).then(
            res => {
                if(res.totalRecords && !_.isEmpty(res.userBOs)){
                    dispatch( {type: userConstants.LOGIN_SUCCESS, user: res.userBOs[0]});
                    localStorage.setItem('user', JSON.stringify(res.userBOs[0]))
                    history.push('/');
                }else{
                    dispatch({type: userConstants.LOGIN_FAILURE,error: res.error});
                    dispatch(alertActions.error(JSON.stringify(res.error)));
                    //history.push('/dragondev2');
                    history.push('/error');

                    // window.location = "/error"

                }
            },
            error => {
                dispatch({type: userConstants.LOGIN_FAILURE,error: error.text});
                dispatch(alertActions.error(error.text));
            }
        )
    }
}

function login(username,attuid, password) {
    return dispatch => {
        dispatch(request({username}));
//userService.userAuthentication(params)
        userService.login(username, attuid,password)
            .then(
                user => {
                    dispatch(success(user));
                    localStorage.setItem('user', JSON.stringify(user))
                    history.push('/');
                },
                error => {
                    dispatch(failure(error.text));
                    dispatch(alertActions.error(error.text));
                }
            );
    };

    function request(user) {
        return {type: userConstants.LOGIN_REQUEST, user}
    }

    function success(user) {
        return {type: userConstants.LOGIN_SUCCESS, user}
    }

    function failure(error) {
        return {type: userConstants.LOGIN_FAILURE, error}
    }
}

function logout() {
    return dispatch => {
        dispatch({type: userConstants.LOGOUT});
       deleteAllCookies()
        localStorage.removeItem('user')
    }
}

function register(user) {
    return dispatch => {
        dispatch(request(user));

        userService.register(user)
            .then(
                user => {
                    dispatch(success());
                    history.push('/login');
                    dispatch(alertActions.success('Registration successful'));
                },
                error => {
                    dispatch(failure(error.toString()));
                    dispatch(alertActions.error(error.toString()));
                }
            );
    };

    function request(user) {
        return {type: userConstants.REGISTER_REQUEST, user}
    }

    function success(user) {
        return {type: userConstants.REGISTER_SUCCESS, user}
    }

    function failure(error) {
        return {type: userConstants.REGISTER_FAILURE, error}
    }
}

function _getUsers(user) {
    return dispatch => {
        dispatch(request());

        userService.getAll()
            .then(
                users => dispatch(success(users)),
                error => dispatch(failure(error.toString()))
            );
    };

    function request() {
        return {type: userConstants.GETALL_REQUEST}
    }

    function success(users) {
        return {type: userConstants.GETALL_SUCCESS, users}
    }

    function failure(error) {
        return {type: userConstants.GETALL_FAILURE, error}
    }
}

// prefixed function name with underscore because delete is a reserved word in javascript
function _delete(id) {
    return dispatch => {
        dispatch(request(id));

        userService.deleteUser(id)
            .then(
                user => {
                    dispatch(success(id));
                    dispatch(alertActions.success("The user record has been successfully deleted"));
                    history.push({pathname:"/sys/users", state: {showAlerts: true}})
                },
                error => {
                    dispatch(failure(id, error.text));
                    dispatch(alertActions.error(error.text));
                }
            );
    };

    function request(id) {
        return {type: userConstants.DELETE_REQUEST, id}
    }

    function success(id) {
        return {type: userConstants.DELETE_SUCCESS, id}
    }

    function failure(id, error) {
        return {type: userConstants.DELETE_FAILURE, id, error}
    }
}

function _create(user) {
    return dispatch => {
        dispatch({type: userConstants.CREATE_REQUEST})
        userService.saveUser(user)
            .then(
                res => {
                    if (res.success) {
                        console.log("user res", res)
                        dispatch({type: userConstants.CREATE_SUCCESS})
                        dispatch(alertActions.success("The User record has been successfully inserted"));
                        history.push({pathname: `/sys/users/details/${res.user.userId}`, state: {showAlerts: true}})
                    }

                },
                error => {
                    console.log("user error", error)
                    dispatch({type: userConstants.CREATE_FAILURE})
                    dispatch(alertActions.error(error.text));
                }
            );
    };
}

function _update(user, userId) {
    return dispatch => {
        dispatch({type: userConstants.UPDATE_REQUEST})
        userService.saveUser(user, userId)
            .then(
                res => {
                    if (res.success) {
                        console.log("user update response", res)
                        dispatch({type: userConstants.UPDATE_SUCCESS})
                        dispatch(alertActions.success("The User record has been  successfully updated"));
                    //    history.push({pathname: `/sys/users`, state: {showAlerts: true}})
                        history.push({pathname: `/sys/users/details/${res.user.userId}`, state: {showAlerts: true}})

                    }

                },
                error => {
                    console.log("user update error", error)
                    dispatch({type: userConstants.UPDATE_FAILURE})
                    dispatch(alertActions.error(error.text));
                }
            );
    };
}

