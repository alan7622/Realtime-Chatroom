import {alertActions} from './index';
import {history} from '../_helpers';
import {zoneService} from "../_services";
import {nameServerConstants} from "../_constants";

export const nameServerActions = {
    create: _create,
    update: _update,
    deleteNS


};


function _create(nsDetails) {

    return dispatch => {
        dispatch({type: nameServerConstants.CREATE_REQUEST})
        zoneService.saveNameServers(nsDetails)
            .then(
                res => {
                    if (res.success) {
                        console.log("sucess action")
                        dispatch({type: nameServerConstants.CREATE_SUCCESS})
                        dispatch(alertActions.success("The  record has been successfully inserted"));
                        history.push({
                            pathname: `/dns/zones/search/details/${nsDetails.zoneNum}/servers/NONATT-NS`,


                            state: {showAlerts: true}
                        })
                    }


                },
                error => {
                    console.log(" error", error)
                    dispatch({type: nameServerConstants.CREATE_FAILURE})
                    dispatch(alertActions.error(error.text));
                }
            );
    };
}

function _update(recId,nsDetails) {
    console.log("in update action")

    return dispatch => {
        dispatch({type: nameServerConstants.UPDATE_REQUEST})
        zoneService.updateNameServers(recId,nsDetails)
            .then(
                res => {
                    if (res.success) {
                        console.log("in update action success")
                        dispatch({type: nameServerConstants.UPDATE_SUCCESS})
                        dispatch(alertActions.success("The  record has been  successfully updated"));

                        history.push({
                           // pathname: `/dnsprov/dnsAdmin/zones/${nsDetails.zoneNum}`,
                            pathname: `/dns/zones/search/details/${nsDetails.zoneNum}/servers/NONATT-NS`,

                            state: {showAlerts: true}
                        })


                    }

                },
                error => {
                    console.log("in update action failure")
                    dispatch({type: nameServerConstants.UPDATE_FAILURE})
                    dispatch(alertActions.error(error));
                }
            );
    };
}

function deleteNS(id, zoneNum) {
    return dispatch => {
        dispatch(request(id));
        zoneService.deleteNSRecord(id, zoneNum)
            .then(
                res => {
                    dispatch(success(id));
                    dispatch(alertActions.success(res));
                 /*   history.push({
                        pathname: `/dns/zones/details/${zoneNum}/servers/NONATT-NS`,

                        state: {showAlerts: true}
                    })*/


                },
                error => {
                    dispatch(failure(id, error.text));
                    dispatch(alertActions.error(error.text));
                }
            );
    };

    function request(id) {
        return {type: nameServerConstants.DELETE_REQUEST, id}
    }

    function success(id) {
        return {type: nameServerConstants.DELETE_SUCCESS, id}
    }

    function failure(id, error) {
        return {type: nameServerConstants.DELETE_FAILURE, id, error}
    }
}





