
import {tldService, userService} from "../_services"
import {tldConstants, userConstants} from "../_constants";
import {alertActions} from "./alert.actions";
import {history} from "../_helpers";
import {trim} from "lodash";

export const tldActions = {

    getTlds: _getTlds,
    create:_create,
    delete:_delete

};


function _getTlds(tld) {
    return dispatch => {
        dispatch(request());

        tldService.getTlds()
            .then(
                tlds => dispatch(success(tld)),
                error => dispatch(failure(error.toString()))
            );
    };

    function request() {
        return {type: tldConstants.GETALL_REQUEST}
    }

    function success(tlds) {
        return {type: tldConstants.GETALL_SUCCESS, tlds}
    }

    function failure(error) {
        return {type: tldConstants.GETALL_FAILURE, error}
    }
}
function _create(tld) {
    return dispatch => {
        dispatch({type: tldConstants.CREATE_REQUEST})
        tldService.saveTld(tld)
            .then(
                res => {
                    if (res.success) {
                        console.log("tld create response", res)
                        dispatch({type: tldConstants.CREATE_SUCCESS})
                        dispatch(alertActions.success("TLD created Successfully"));
                        history.push({pathname: `/sys/tlds/details/`+trim(res.tld.split("=")[1]), state: {showAlerts: true}})
                    }

                },
                error => {
                    console.log("tld error", error)
                    dispatch({type: tldConstants.CREATE_FAILURE})
                    dispatch(alertActions.error(error.text));
                }
            );
    };
}

function _delete(tld) {
    return dispatch => {
        dispatch(request(tld));

        tldService.deleteTLD(tld)
            .then(
                tld => {
                    dispatch(success(tld));
                    dispatch(alertActions.success("Tld Deleted Successfully"));
                    history.push({pathname:"/sys/tlds", state: {showAlerts: true}})
                },
                error => {
                    dispatch(failure(tld, error.text));
                    dispatch(alertActions.error(error.text));
                }
            );
    };

    function request(tld) {
        return {type: tldConstants.DELETE_REQUEST, tld}
    }

    function success(tld) {
        return {type: tldConstants.DELETE_SUCCESS, tld}
    }

    function failure(tld, error) {
        return {type: tldConstants.DELETE_FAILURE, tld, error}
    }
}


