import {delegationNSService, delegationService} from "../_services";
import {acctDelegationConstants, delegateNameserverConstants, delegationConstants} from "../_constants";
import {alertActions} from "./alert.actions";
import {history} from "../_helpers";

export const acctDelegationActions = {

    getDelegations: _getDelegations,
    getDelegationsNS: _getDelegationsNS,
    create: _create,
    createNS: _createNS,
    update: _update,
    updateNS: _updateNS,
    delete: _delete,
    deleteNS: _deleteNS,

};

function _getDelegations(nameserver) {
    return dispatch => {
        dispatch(request());

        delegationService.getAllDelegations()
            .then(
                obj => {
                    dispatch(success(obj));
                    console.log("hello", obj)
                },
                error => {
                    console.log("hello", error)
                    dispatch(failure(error))
                    history.push({
                        pathname: `/dns/accounts/details/${nameserver.accountId}/acctDelg`,

                        state: {showAlerts: true}
                    })

                }
            );
    };
}

function _create(delegation) {
    return dispatch => {
        dispatch({type: acctDelegationConstants.CREATE_REQUEST})

        delegationService.saveDelegation("", delegation)
            .then(
                res => {
                   // console.log("delegation create response2", res)

                    if (res.success) {
                        dispatch({type: acctDelegationConstants.CREATE_SUCCESS, delegation: res.delegation})

                        dispatch(alertActions.success("Delegation created Successfully"));

                        history.push({
                                pathname: `/dns/accounts/details/${delegation.accountId}/acctDelg`,

                                state: {showAlerts: true}
                            }
                        );
                    }

                },
                error => {
                    dispatch({type: acctDelegationConstants.CREATE_FAILURE})
                    dispatch(alertActions.error(error.text));
                }
            );
    };
}


/*
function _create(delegation, serviceName) {
    return dispatch => {
        dispatch({type: acctDelegationConstants.CREATE_REQUEST})

        delegationService.saveDelegation("", delegation)
            .then(
                res => {
                    console.log("delegation create response2", res)

                    if (res.success) {
                        console.log("delegation inside res.success")
                        console.log("delegation serviceName", serviceName)

                        if (serviceName ==! "NETWORK") {

                            console.log("delegation serviceName inside block")

                            dispatch({type: acctDelegationConstants.CREATE_SUCCESS, delegation: res.delegation})

                            dispatch(alertActions.success("Delegation created Successfully"));

                            history.push({
                                    pathname: `/dns/zones/details/${delegation.zoneNum}/zoneDelegation/${recId}`,
                                    state: {showAlerts: true}
                                }
                            );
                        }
                        else {
                            dispatch({type: acctDelegationConstants.CREATE_SUCCESS, delegation: res.delegation})

                            dispatch(alertActions.success("Delegation created Successfully"));

                            history.push({
                                    pathname: `/dns/accounts/details/${delegation.accountId}/acctDelg`,

                                    state: {showAlerts: true}
                                }
                            );
                        }
                    }


                },
                error => {
                    dispatch({type: acctDelegationConstants.CREATE_FAILURE})
                    dispatch(alertActions.error(error.text));
                }
            );
    };
}
*/


function _update(delegationNum, delegation) {
    return dispatch => {
        dispatch({type: acctDelegationConstants.UPDATE_REQUEST})
        delegationService.saveDelegation(delegationNum, delegation)
            .then(
                res => {
                    if (res.success) {
                        delegationService.getByDelegationId(delegationNum).then(res => {
                            dispatch(alertActions.success("Delegation Updated Successfully"));

                            dispatch({type: acctDelegationConstants.UPDATE_SUCCESS, delegation: res.delegation})

                            history.push({
                                pathname: `/dns/accounts/details/${res.delegation.accountId}/acctDelg/${delegationNum}`,
                                state: {showAlerts: true}
                            })

                        });

                    }

                },
                error => {
                    console.log(" update error", error)
                    dispatch({type: acctDelegationConstants.UPDATE_FAILURE})
                    dispatch(alertActions.error(error.text));
                }
            );
    };
}


/*function request() {
    return {type: acctDelegationConstants.GETALL_REQUEST}
}

function success(delegations) {
    return {type: delegationConstants.GETALL_SUCCESS, delegations}
}

function failure(error) {
    return {type: acctDelegationConstants.GETALL_FAILURE, error}
}*/

function _delete(id, accountId) {
    console.log(id, "id")
    return dispatch => {
        dispatch(request(id));

        delegationService.deleteDelegation(id)
            .then(
                delegation => {
                    console.log(id, "id1")
                    dispatch(success(id));

                    dispatch(alertActions.success(" Deleted Successfully"));
                    history.push({pathname: `/dns/accounts/details/${accountId}/acctDelg`, state: {showAlerts: true}})
                },
                error => {
                    console.log("error")

                    dispatch(failure(id, error.text));
                    dispatch(alertActions.error(error.text));
                    history.push({pathname: `/dns/accounts/details/${accountId}/acctDelg`, state: {showAlerts: true}})

                }
            );
    };

    function request(id) {
        return {type: acctDelegationConstants.DELETE_REQUEST, id}
    }

    function success(id) {
        return {type: acctDelegationConstants.DELETE_SUCCESS, id}
    }

    function failure(id, error) {
        return {type: acctDelegationConstants.DELETE_FAILURE, id, error}
    }
}


function _getDelegationsNS(nameserver) {
    return dispatch => {
        dispatch(request());

        delegationNSService.getAllDelegationNameServers()
            .then(
                nameservers => dispatch(success(nameserver)),
                error => dispatch(failure(error.toString()))
            );
    };
}


function _createNS(nameserver, accountId) {
    return dispatch => {
        dispatch({type: delegateNameserverConstants.CREATE_REQUEST})

        delegationNSService.saveDelegationNameServer("", nameserver)
            .then(
                res => {
                    console.log("nameserver create response2", res)

                    if (res.success) {
                        dispatch({type: delegateNameserverConstants.CREATE_SUCCESS, nameserver: res.nameserver})

                        dispatch(alertActions.success("Delegation created Successfully"));

                        history.push({
                                pathname: `/dns/accounts/details/${accountId}/acctDelg/${nameserver.delegationId}/nameServers/acctDelgNS`,
                                state: {showAlerts: true}
                            }
                        );
                    }

                },
                error => {
                    dispatch({type: acctDelegationConstants.CREATE_FAILURE})
                    dispatch(alertActions.error(error.text));
                }
            );
    };
}

function _updateNS(recId, accountId, nameserver) {
    return dispatch => {
        dispatch({type: delegationConstants.UPDATE_REQUEST})
        delegationNSService.saveDelegationNameServer(recId, nameserver)
            .then(
                res => {
                    if (res.success) {
                        delegationNSService.getByDelegationId(recId).then(res => {
                            dispatch(alertActions.success("Delegation Updated Successfully"));

                            dispatch({type: delegationConstants.UPDATE_SUCCESS, nameserver: res.nameserver})

                            history.push({
                                pathname: `/dns/accounts/details/${accountId}/acctDelg/${res.nameserver.delegationId}/nameServers/acctDelgNS`,
                                state: {showAlerts: true}
                            })

                        });

                    }

                },
                error => {
                    console.log(" update error", error)
                    dispatch({type: delegationConstants.UPDATE_FAILURE})
                    dispatch(alertActions.error(error.text));
                }
            );
    };
}


function _deleteNS(id, accountId, delegationId) {
    console.log(id, "id")
    return dispatch => {
        dispatch(request(id));

        delegationNSService.deleteDelegationNameServer(id)
            .then(
                delegation => {
                    console.log(id, "id1")
                    dispatch(success(id));

                    dispatch(alertActions.success("Deleted Successfully"));
                    history.push({
                        pathname: `/dns/accounts/details/${accountId}/acctDelg/${delegationId}/nameServers/acctDelgNS`,
                        state: {showAlerts: true}

                    })
                },
                error => {
                    console.log("error")

                    dispatch(failure(id, error.text));
                    dispatch(alertActions.error(error.text));
                }
            );
    };

    function request(id) {
        return {type: acctDelegationConstants.DELETE_REQUEST, id}
    }

    function success(id) {
        return {type: acctDelegationConstants.DELETE_SUCCESS, id}
    }

    function failure(id, error) {
        return {type: acctDelegationConstants.DELETE_FAILURE, id, error}
    }
}

