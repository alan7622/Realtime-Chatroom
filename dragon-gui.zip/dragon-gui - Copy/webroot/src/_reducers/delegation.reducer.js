import {delegationConstants} from "../_constants";

export function delegations(state={},action){
    switch (action.type) {
        case delegationConstants.GETALL_REQUEST:
            return {
                loading: true
            };
        case delegationConstants.GETALL_SUCCESS:
            return {
                loading:false,
                items: action.delegations
            };
        case delegationConstants.GETALL_FAILURE:
            return {
                loading:false,
                error: action.error
            };
        case delegationConstants.DELETE_REQUEST:
            // add 'deleting:true' property to record being deleted
            return {
                ...state,
                loading:true,
                deleting: true
            };
        case delegationConstants.DELETE_SUCCESS:
            // remove deleted record from state
            return {
                loading:false,
                deleted: true
            };
        case delegationConstants.DELETE_FAILURE:
            // remove 'deleting:true' property and add 'deleteError:[error]' property to resource record
            return {
                loading:false,
                deleted: false
            };
        case delegationConstants.CREATE_REQUEST:
        case delegationConstants.UPDATE_REQUEST:
            return {loading: true};
        case delegationConstants.CREATE_SUCCESS:
        case delegationConstants.UPDATE_SUCCESS:
            return {loading: false, saved: true};
        case delegationConstants.CREATE_FAILURE:
        case delegationConstants.UPDATE_FAILURE:
            return {loading: false, saved: false};
        default:
            return state
    }


}