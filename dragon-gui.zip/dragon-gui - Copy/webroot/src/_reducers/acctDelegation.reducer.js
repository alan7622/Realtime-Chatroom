import {acctDelegationConstants} from "../_constants";

export function acctDelegations(state={},action){
    switch (action.type) {
        case acctDelegationConstants.GETALL_REQUEST:
            return {
                loading: true
            };
        case acctDelegationConstants.GETALL_SUCCESS:
            return {
                loading:false,
                items: action.acctDelegations
            };
        case acctDelegationConstants.GETALL_FAILURE:
            return {
                loading:false,
                error: action.error
            };
        case acctDelegationConstants.DELETE_REQUEST:
            // add 'deleting:true' property to record being deleted
            return {
                ...state,
                loading:true,
                deleting: true
            };
        case acctDelegationConstants.DELETE_SUCCESS:
            // remove deleted record from state
            return {
                loading:false,
                deleted: true
            };
        case acctDelegationConstants.DELETE_FAILURE:
            // remove 'deleting:true' property and add 'deleteError:[error]' property to resource record
            return {
                loading:false,
                deleted: false
            };
        case acctDelegationConstants.CREATE_REQUEST:
        case acctDelegationConstants.UPDATE_REQUEST:
            return {loading: true};
        case acctDelegationConstants.CREATE_SUCCESS:
        case acctDelegationConstants.UPDATE_SUCCESS:
            return {loading: false, saved: true};
        case acctDelegationConstants.CREATE_FAILURE:
        case acctDelegationConstants.UPDATE_FAILURE:
            return {loading: false, saved: false};
        default:
            return state
    }


}