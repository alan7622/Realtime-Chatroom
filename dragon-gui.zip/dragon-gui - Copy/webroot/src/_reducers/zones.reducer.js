
import {zoneConstants} from '../_constants';

export function zones(state = {}, action) {
    switch (action.type) {
        case zoneConstants.GETALL_REQUEST:
            return {
                loading: true
            };
        case zoneConstants.GETALL_SUCCESS:
            return {
                loading: false,
                items: action.zones
            };
        case zoneConstants.GETALL_FAILURE:
            return {
                loading: false,
                error: action.error
            };
        case zoneConstants.DELETE_REQUEST:
            // add 'deleting:true' property to user being deleted
            return {
                ...state,
                loading: true,
                deleting: true
            };
        case zoneConstants.DELETE_SUCCESS:
            // remove deleted zone from state
            return {
                loading: false,
                deleted: true
            };
        case zoneConstants.DELETE_FAILURE:
            return {
                loading: false,
                deleted: false
            };
        case zoneConstants.CREATE_REQUEST:
        case zoneConstants.UPDATE_REQUEST:
            return { loading: true, saving: true};
        case zoneConstants.CREATE_SUCCESS:
        case zoneConstants.UPDATE_SUCCESS:
            return { loading: false, saving: false, saved: true, zone: action.zone};
        case zoneConstants.CREATE_FAILURE:
        case zoneConstants.UPDATE_FAILURE:
            return { loading: false, saving: false, saved: false};
        case zoneConstants.CLEAR_ZONE_STORE:
                return {clear:true};
        default:
            return state
    }
}