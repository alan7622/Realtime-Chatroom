import {combineReducers} from 'redux';

import {authentication} from './authentication.reducer';
import {registration} from './registration.reducer';
import {users} from './users.reducer';
import {accounts} from './accounts.reducer';
import {zones} from './zones.reducer';
import {tlds} from './tlds.reducer';
import {rrs} from './rrs.reducer';
import {srvrGrp} from './serverGroups.reducer';
import {addDomains} from "./addDomains.reducer";
import {delegationServers} from "./delegateNameserver.reducer"
import {delegations} from "./delegation.reducer"
import {acctDelegations} from "./acctDelegation.reducer"


import {transferAclZones} from "./transferAclZones.reducer"

import {alert} from './alert.reducer';

const rootReducer = combineReducers({
    authentication,
    registration,
    users,
    accounts,
    zones,
    tlds,
    rrs,
    srvrGrp,
    addDomains,
    delegationServers,
    delegations,
    acctDelegations,
    transferAclZones,
    alert
});

export default rootReducer;