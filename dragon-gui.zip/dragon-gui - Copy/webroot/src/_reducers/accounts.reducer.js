import {accountConstants} from '../_constants';

export function accounts(state = {}, action) {
    switch (action.type) {
        case accountConstants.GETALL_REQUEST:
            return {
                loading: true
            };
        case accountConstants.GETALL_SUCCESS:
            return {
                items: action.accounts
            };
        case accountConstants.GETALL_FAILURE:
            return {
                error: action.error
            };
        case accountConstants.DELETE_REQUEST:
            // add 'deleting:true' property to user being deleted
            return {
                ...state,
                deleting: true
            };
        case accountConstants.DELETE_SUCCESS:
            // remove deleted user from state
            return {
                deleted: true
            };
        case accountConstants.DELETE_FAILURE:
            return {
                deleted: false
            };
        case accountConstants.CREATE_REQUEST:
        case accountConstants.UPDATE_REQUEST:
            return {saving: true};
        case accountConstants.CREATE_SUCCESS:
        case accountConstants.UPDATE_SUCCESS:
            return {saving: false, saved: true};
        case accountConstants.CREATE_FAILURE:
        case accountConstants.UPDATE_FAILURE:
            return {saving: false, saved: false};
        default:
            return state
    }
}