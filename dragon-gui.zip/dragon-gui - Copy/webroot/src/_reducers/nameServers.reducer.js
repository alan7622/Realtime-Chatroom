import {nameServerConstants} from "../_constants";

export function nameservers(state = {}, action) {
    switch (action.type) {
        case nameServerConstants.DELETE_REQUEST:
            // add 'deleting:true' property to record being deleted
            return {
                ...state,
                loading:true,
                deleted:false
            };
        case nameServerConstants.DELETE_SUCCESS:
            // remove deleted record from state
            return {
                loading:false,
                deleted: true,

            };
        case nameServerConstants.DELETE_FAILURE:
            // remove 'deleting:true' property and add 'deleteError:[error]' property to resource record
            return {
                loading:false,
                deleted: false
            };
        case nameServerConstants.CREATE_REQUEST:
        case nameServerConstants.UPDATE_REQUEST:
            return {loading: true};
        case nameServerConstants.CREATE_SUCCESS:
        case nameServerConstants.UPDATE_SUCCESS:
            return {loading: false, saved: true};
        case nameServerConstants.CREATE_FAILURE:
        case nameServerConstants.UPDATE_FAILURE:
            return {loading: false, saved: false};
        default:
            return state
    }
}