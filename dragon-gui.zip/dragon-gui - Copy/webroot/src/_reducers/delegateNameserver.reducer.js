import {delegateNameserverConstants} from "../_constants";

export function delegationServers(state={},action){
    switch (action.type) {
        case delegateNameserverConstants.GETALLRECORDS_REQUEST:
            return {
                loading: true
            };
        case delegateNameserverConstants.GETALLRECORDS_SUCCESS:
            return {
                loading:false,
                items: action.delegationServers
            };
        case delegateNameserverConstants.GETALLRECORDS_FAILURE:
            return {
                loading:false,
                error: action.error
            };
        case delegateNameserverConstants.DELETE_REQUEST:
            // add 'deleting:true' property to record being deleted
            return {
                ...state,
                loading:true,
                deleting: true
            };
        case delegateNameserverConstants.DELETE_SUCCESS:
            // remove deleted record from state
            return {
                loading:false,
                deleted: true
            };
        case delegateNameserverConstants.DELETE_FAILURE:
            // remove 'deleting:true' property and add 'deleteError:[error]' property to resource record
            return {
                loading:false,
                deleted: false
            };
        case delegateNameserverConstants.CREATE_REQUEST:
        case delegateNameserverConstants.UPDATE_REQUEST:
            return {loading: true};
        case delegateNameserverConstants.CREATE_SUCCESS:
        case delegateNameserverConstants.UPDATE_SUCCESS:
            return {loading: false, saved: true};
        case delegateNameserverConstants.CREATE_FAILURE:
        case delegateNameserverConstants.UPDATE_FAILURE:
            return {loading: false, saved: false};
        default:
            return state
    }


}