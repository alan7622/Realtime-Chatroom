import {addDomainsConstants} from '../_constants';

export function addDomains(state = {}, action) {
    switch (action.type) {
        case addDomainsConstants.GETALL_REQUEST:
            return {
                loading: true
            };
        case addDomainsConstants.GETALL_SUCCESS:
            return {
                items: action.accounts
            };
        case addDomainsConstants.GETALL_FAILURE:
            return {
                error: action.error
            };
        case addDomainsConstants.DELETE_REQUEST:
            // add 'deleting:true' property to user being deleted
            return {
                ...state,
                deleting: true
            };
        case addDomainsConstants.DELETE_SUCCESS:
            // remove deleted user from state
            return {
                deleted: true
            };
        case addDomainsConstants.DELETE_FAILURE:
            return {
                deleted: false
            };
        case addDomainsConstants.CREATE_REQUEST:
        case addDomainsConstants.UPDATE_REQUEST:
            return {saving: true};
        case addDomainsConstants.CREATE_SUCCESS:
        case addDomainsConstants.UPDATE_SUCCESS:
            return {saving: false, saved: true};
        case addDomainsConstants.CREATE_FAILURE:
        case addDomainsConstants.UPDATE_FAILURE:
            return {saving: false, saved: false};
        default:
            return state
    }
}