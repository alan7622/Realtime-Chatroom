import {tldConstants} from '../_constants';

export function tlds(state = {}, action) {
    switch (action.type) {
        case tldConstants.GETALL_REQUEST:
            return {
                loading: true
            };
        case tldConstants.GETALL_SUCCESS:
            return {
                items: action.tlds
            };
        case tldConstants.GETALL_FAILURE:
            return {
                error: action.error
            };
        case tldConstants.DELETE_REQUEST:
            return {
                ...state,
                deleting: true
            };
        case tldConstants.DELETE_SUCCESS:
            // remove deleted tld from state
            return {
                deleted: true
            };
        case tldConstants.DELETE_FAILURE:
            // remove 'deleting:true' property and add 'deleteError:[error]' property to tld
            return {
                deleted: false
            };
        case tldConstants.CREATE_REQUEST:
            return {saving: true};
        case tldConstants.CREATE_SUCCESS:
            return {saving: false, saved: true};
        case tldConstants.CREATE_FAILURE:
            return {saving: false, saved: false};
        default:
            return state
    }
}