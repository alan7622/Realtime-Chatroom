import {serverGroupsConstants} from "../_constants";

export function srvrGrp(state = {}, action) {
    switch (action.type) {
        case serverGroupsConstants.GETALL_REQUEST:
            return {
                loading: true
            };
        case serverGroupsConstants.GETALL_SUCCESS:
            return {
                loading:false,
                items: action.srvrGrp
            };
        case serverGroupsConstants.GETALL_FAILURE:
            return {
                loading:false,
                error: action.error
            };
        case serverGroupsConstants.UPDATE_REQUEST:
            return {loading: true};
        case serverGroupsConstants.UPDATE_SUCCESS:
            return {loading: false, saved: true};
        case serverGroupsConstants.UPDATE_FAILURE:
            return {loading: false, saved: false};
        default:
            return state
    }
}