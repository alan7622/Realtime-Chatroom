
import {xferAclZoneConstants} from '../_constants';

export function transferAclZones(state = {}, action) {
    switch (action.type) {
        case xferAclZoneConstants.GETALL_REQUEST:
            return {
                loading: true
            };
        case xferAclZoneConstants.GETALL_SUCCESS:
            return {
                items: action.transferAclZones
            };
        case xferAclZoneConstants.GETALL_FAILURE:
            return {
                error: action.error
            };
        case xferAclZoneConstants.DELETE_REQUEST:
            // add 'deleting:true' property to record being deleted
            return {
                ...state,
                deleted: false
            };
        case xferAclZoneConstants.DELETE_SUCCESS:
            // remove deleted  from state
            return {
                deleted: true
            };
        case xferAclZoneConstants.DELETE_FAILURE:
            return {
                deleted: false
            };
        case xferAclZoneConstants.CREATE_REQUEST:
        case xferAclZoneConstants.UPDATE_REQUEST:
            return {saving: true};
        case xferAclZoneConstants.CREATE_SUCCESS:
        case xferAclZoneConstants.UPDATE_SUCCESS:
            return {saving: false, saved: true};
        case xferAclZoneConstants.CREATE_FAILURE:
        case xferAclZoneConstants.UPDATE_FAILURE:
            return {saving: false, saved: false};
        default:
            return state
    }
}