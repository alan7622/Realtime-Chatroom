import {resourceRecordConstants} from "../_constants";

export function rrs(state = {}, action) {
    switch (action.type) {
        case resourceRecordConstants.GETALL_REQUEST:
            return {
                loading: true
            };
        case resourceRecordConstants.GETALL_SUCCESS:
            return {
                loading:false,
                items: action.rrs
            };
        case resourceRecordConstants.GETALL_FAILURE:
            return {
                loading:false,
                error: action.error
            };
        case resourceRecordConstants.DELETE_REQUEST:
            // add 'deleting:true' property to record being deleted
            return {
                ...state,
                loading:true,
                deleting: true
            };
        case resourceRecordConstants.DELETE_SUCCESS:
            // remove deleted record from state
            return {
                loading:false,
                deleted: true
            };
        case resourceRecordConstants.DELETE_FAILURE:
            // remove 'deleting:true' property and add 'deleteError:[error]' property to resource record
            return {
                loading:false,
                deleted: false
            };
        case resourceRecordConstants.CREATE_REQUEST:
        case resourceRecordConstants.UPDATE_REQUEST:
            return {loading: true};
        case resourceRecordConstants.CREATE_SUCCESS:
        case resourceRecordConstants.UPDATE_SUCCESS:
            return {loading: false, saved: true};
        case resourceRecordConstants.CREATE_UPDATE_SUCCESS:
            return {loading: false, saved: true};
        case resourceRecordConstants.CREATE_FAILURE:
        case resourceRecordConstants.UPDATE_FAILURE:
            return {loading: false, saved: false};
        default:
            return state
    }
}