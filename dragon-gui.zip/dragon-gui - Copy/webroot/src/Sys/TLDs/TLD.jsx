import React from "react";
import {
    Backdrop,
    Button,
    Card,
    CardContent,
    CircularProgress,
    Dialog,
    DialogActions,
    DialogTitle,
} from "@material-ui/core";
import Form from "react-bootstrap/Form";
import {Row} from "@material-ui/data-grid";//Using it as react-bootstrap table did not work
import Container from "@material-ui/core/Container";
import PropTypes from "prop-types";
import {withRouter} from "react-router-dom";
import {connect} from "react-redux";
import {tldService} from "../../_services";
import {alertActions, tldActions} from "../../_actions";
import {Col} from "react-bootstrap";
import {Alert} from "@material-ui/lab";

class TLD extends React.Component {

    constructor(props) {
        super(props);
        this.state = {
            loading: true,
            saving: false,
            tld: {},
            showDeleteConfirm: false,
        };
        this.isComponentMounted = false;
        this.deleteTLD = this.deleteTLD.bind(this);
        this.saveTLD = this.saveTLD.bind(this);
        this.getTLDForm = this.getTLDForm.bind(this);
        this.updateTldObj = this.updateTldObj.bind(this);
        if ((this.props.location.state === undefined || !this.props.location.state.showAlerts) && !_.isEmpty(this.props.alert)) {
            this.props.alertClear()
        }
    }

    saveTLD() {
        this.setState({loading: true, saving: true})
        let res = null
        if (this.props.isTLDEmptyForm) {
            this.props.create(this.state.tld);
        } else {
            this.props.update(this.state.tld, this.props.match.params.id);
        }

    }

    async componentDidMount() {
        if (!this.props.isTLDEmptyForm) {
            this.isComponentMounted = true;
            if (this.isComponentMounted) {
                const tld = await tldService.getByTlDomain(this.props.match.params.tlDomain)
                this.setState({loading: false, tld: tld.totalRecords ? tld.tlDomainBOs[0] : false});
            }
        }
    }

    deleteTLD() {
        if (this.isComponentMounted) {
            this.setState({showDeleteConfirm: false, loading: true})
        }
        this.props.delete(this.props.match.params.tlDomain);
    }

    componentWillUnmount() {
        this.isComponentMounted = false;
    }

    updateTldObj(e) {
        let {name, value} = e.target;
        const {tld} = this.state;
        if (!_.isEmpty(this.props.alert)) {
            this.props.alertClear()
        }

        this.setState({tld: {...tld, [name]: value}})
    }

    getTldPageInfoElementsAndButtons() {
        let tldPageElements = {
            pageTitle: '',
            pageButtons: [],
        }
        if (this.props.isTLDEmptyForm) {
            tldPageElements.pageTitle = "Top Level Domain Name Creation"
            tldPageElements.pageButtons.push(<Button className={"dns-blue-button text-white  mr-2 text-center col-md-1"}
                                                     onClick={this.saveTLD} key={"insert"}>Insert</Button>)
            tldPageElements.pageButtons.push(<Button className={"dns-blue-button text-white mr-2 text-center col-md-1"}
                                                     onClick={() => this.props.history.push(`/sys/tlds`)}
                                                     key={"cancel_insert"}>Cancel</Button>)
        } else {
            tldPageElements.pageTitle = "DNS TLD Record Details"
            tldPageElements.pageButtons.push(<Button className={"dns-blue-button text-white mt-2 mr-4 mb-4"}
                                                     onClick={() => {
                                                         this.setState({showDeleteConfirm: true})
                                                     }} key={"delete"}>Delete</Button>)
            tldPageElements.pageButtons.push(<Button className={"dns-blue-button text-white mt-2 mb-4"}
                                                     onClick={() => {
                                                         this.props.alertClear();
                                                         this.props.history.push(`/sys/tlds`)
                                                     }}
                                                     key={"list_tlds"}>List TLDs</Button>)
        }

        return tldPageElements;
    }

    getDialogConfirm() {
        return !this.props.isEditable && <Dialog
            onClose={(event, reason) => {
                if (reason === 'backdropClick' || reason === 'escapeKeyDown') {
                    return false;
                }
            }}
            maxWidth="xs"
            aria-labelledby="confirmation-dialog-title"
            open={this.state.showDeleteConfirm}
        >
            <DialogTitle id="confirmation-dialog-title">Are you sure you want to delete this
                record?</DialogTitle>
            <DialogActions>
                <Button autoFocus onClick={this.deleteTLD} color="primary">
                    Delete
                </Button>
                <Button onClick={() => this.setState({showDeleteConfirm: false})} color="primary">
                    Cancel
                </Button>
            </DialogActions>
        </Dialog>
    }

    getTLDForm() {
        const {tld} = this.state
        let {pageButtons, pageTitle} = this.getTldPageInfoElementsAndButtons();
        return (<> <h5 className="font-weight-bold  text-capitalize text-left mt-5 mb-4 pl-3">{pageTitle} </h5>

            {this.state.tld ? <Form>
                {this.props.alert.message &&
                <Alert severity={this.props.alert.type}>{this.props.alert.message}</Alert>}
                <Form.Group as={Row} className={'align-items-center'}>
                    <Form.Label column sm="2" className={"font-weight-bold"}>
                        {this.props.isTLDEmptyForm ? "*" : ""}Top Level Domain
                    </Form.Label>
                    <Col sm="4">
                        {this.props.isTLDEmptyForm ?
                            <Form.Control required name={"tlDomain"} onChange={this.updateTldObj}
                                          defaultValue={tld.tlDomain ? tld.tlDomain : ''}/> : tld.tlDomain}
                    </Col>
                </Form.Group>
                <div className={"text-center"}>
                    {pageButtons.map(buttonComp => buttonComp)}
                </div>

            </Form> : " TLD Not Found"}</>)
    }

    render() {
        return (
            <>
                {this.getDialogConfirm()}
                {this.props.loading && <Backdrop className={"page-loading"} style={{'zIndex': '10000', 'color': '#fff'}}
                                                 open={this.state.loading && this.props.saving}>
                    <CircularProgress color="inherit"/>
                </Backdrop>}
                <Container maxWidth={false} className={"px-2"}>
                    <Card>
                        <CardContent>
                            <div className={'mt-3 ml-3 mr-3 mb-3'}>
                                {this.getTLDForm()}
                            </div>
                        </CardContent>
                    </Card>
                </Container>
            </>
        )
    }
}

TLD.defaultProps = {
    isTLDEditable: false,
};

TLD.propTypes = {
    isTLDEditable: PropTypes.bool.isRequired,
    isTLDEmptyForm: PropTypes.bool

};

function mapState(state) {
    const {deleted, saving, saved} = state.tlds
    const {alert} = state
    return {deleted, saving, saved, alert}
}

const actionCreators = {
    delete: tldActions.delete,
    create: tldActions.create,
    update: tldActions.update,
    alertClear: alertActions.clear
};

const connectedTLD = withRouter(connect(mapState, actionCreators)(TLD));
export {connectedTLD as TLD};
