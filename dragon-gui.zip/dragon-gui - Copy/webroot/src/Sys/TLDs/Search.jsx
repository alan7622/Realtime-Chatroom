import React, {Component} from "react";
import {
    Card,
    CardContent,
    withStyles,
    Box,
    Container,
    createTheme,
    Button,
    Dialog,
    DialogTitle,
    DialogContent,
    FormControl,
    InputLabel,
    Select,
    MenuItem,
    DialogActions
} from "@material-ui/core";
import BootstrapTable from 'react-bootstrap-table-next';
import filterFactory, {Comparator, customFilter, textFilter} from 'react-bootstrap-table2-filter';
import paginationFactory from 'react-bootstrap-table2-paginator';
import 'react-bootstrap-table2-paginator/dist/react-bootstrap-table2-paginator.min.css';
import {tldService} from "../../_services";
import {Helmet} from "react-helmet";
import {Link} from 'react-router-dom';
import {Alert} from "@material-ui/lab";
import _ from "lodash";
import {alertActions} from "../../_actions";
import {connect} from "react-redux";
import {TldHelper} from "../../_helpers";
import {pageRenderer, SizePerPageRenderer} from "../../_components";
import Form from "react-bootstrap/Form";
import {Col, Row} from "react-bootstrap";


const theme = createTheme({palette: {dragonBlue: '#3f75b5'}})
const useStyles = theme => ({
    root: {},
    editButton: {
        backgroundColor: '#3f75b2',
        '&:hover': {
            backgroundColor: '#3f75b5',
        },

    },

    insertButton: {
        backgroundColor: '#4789b6',
        '&:hover': {
            backgroundColor: '#3f75b5',
        },
    },
    visibilityButton: {

        backgroundColor: '#4789b6',
        paddingRight: 2,
        '&:hover': {
            backgroundColor: '#3f75b5',

        },


    },
    actionContainer: {
        textAlign: 'left'
    }
});
const defaultFilters = {

    tld: {comparator: 'Eq', value: ''},
}

class Search extends Component {

    constructor(props) {
        super(props);
        this.state = {
            data: [],
            loading: true,
            openPgMenu: null,
            page: 1,
            sizePerPage: 10,
            totalSize: 0,
            comparator: Comparator.EQ,
            filters: _.cloneDeep(defaultFilters),
            showZoneInfoDialog: false,
            showDeleteConfirm: false,
            showAdvanceSearch: false,
            tldSearchParams: {},
            error:''

        }
        this.isComponentMounted = false;

        /*if ((this.props.location.state === null || this.props.location.state === undefined || !this.props.location.state.showAlerts) && !_.isEmpty(this.props.alert)) {
            this.props.alertClear()
        }*/

        if ((!this.props.showAlerts) && !_.isEmpty(this.props.alert)) {
            this.props.alertClear()
        }
        this.handleTableChange = this.handleTableChange.bind(this);
        this.getAdvanceSearchDialog = this.getAdvanceSearchDialog.bind(this)
        this.handleFilterChange = this.handleFilterChange.bind(this)

    }


    async componentDidMount() {
        this.isComponentMounted = true;
        setTimeout(() => {
            this.props.alertClear()
        }, 10000)//this clears alert message on listing page after 10 seconds
        const params = {numberOfRows: this.state.sizePerPage, pageNumber: this.state.page}
        await this.loadTableData(params)
    }

    async loadTableData(params) {
        /*    if(this.props.alert){
                this.props.alertClear()
            }*/ //this clears alert message before loading the data on the page
        this.setState({loading: true});
        for (var key in this.state.filters) {
            if (this.state.filters.hasOwnProperty(key) &&
                this.state.filters[key].value) {
                params[key +
                this.state.filters[key].comparator] = this.state.filters[key].value;
            }
        }
        const res = await tldService.getTlds(params);
        if (this.isComponentMounted) {
            const data = res.tlDomains.map((obj, key) => {
                obj.key = key;
                return obj
            })
            this.setState({
                loading: false,
                data: res.tlDomains,
                showZoneInfoDialog: false,
                error: res.error,
                page: params.pageNumber ? params.pageNumber : this.state.page,
                sizePerPage: params.numberOfRows ?
                    params.numberOfRows :
                    this.state.sizePerPage,
                totalSize: res.totalRecords
            });

        }
    }

    componentWillUnmount() {
        this.isComponentMounted = false;
    }

    getTldTableColumns() {
        return [
            {
                text: 'Top Level Domain',
                dataField: 'tlDomain',
                //sort: true,
                headerAlign: 'center',
                headerStyle: {
                    width: "70%",
                },
                headerClasses: 'p-1',
                classes: 'p-0',
                // filter: textFilter(),
            },
            {
                text: "Action",
                dataField: "",
                headerAlign: 'center',
                headerClasses: 'p-1',
                classes: 'text-center p-0',
                headerStyle: {
                    width: "30%",
                },
                formatter: (cell, row, rowIndex) => <>
                    <Link
                        to={`/sys/tlds/details/${row.tlDomain}`}
                        key={"details_dns_zone"}
                        className={"color-dragon-blue"}
                    >Details</Link>
                </>

            }];
    }

    handleFilterChange(e) {
        const {name, value} = e.target;
        const {filters} = this.state;
        const filterInfo = name.split('.');
        filters[filterInfo[0]][filterInfo[1]] = value;
        this.setState({filters: filters});
    }


    paginationOptions() {
        return {
            //paginationSize: 4,
            sizePerPage: this.state.sizePerPage,
            page: this.state.page,
            totalSize: this.state.totalSize,
            pageStartIndex: 1,
            alwaysShowAllBtns: true,
            withFirstAndLast: true,
            firstPageText: 'First',
            prePageText: 'Back',
            nextPageText: 'Next',
            lastPageText: 'Last',
            nextPageTitle: 'First page',
            prePageTitle: 'Pre page',
            firstPageTitle: 'Next page',
            lastPageTitle: 'Last page',
            showTotal: false,
            sizePerPageList: [
                {
                    text: '10', value: 10
                }, {
                    text: '20', value: 20
                },
                {
                    text: '50', value: 50
                },],

            pageButtonRenderer: pageRenderer,
            sizePerPageRenderer: ({
                                      options,
                                      currSizePerPage,
                                      onSizePerPageChange
                                  }) => <SizePerPageRenderer options={options}
                                                             currSizePerPage={currSizePerPage}
                                                             onSizePerPageChange={onSizePerPageChange}/>,

            disablePageTitle: true,
        };
    }

    async handleTableChange(type, {filters, page, sortOrder, sortField, sizePerPage, totalSize}) {
        let tldSearchParams = {};
        if (sortField && sortOrder) {
            tldSearchParams.orderDir = sortOrder;
            tldSearchParams.orderBy = sortField;
        }

        tldSearchParams.numberOfRows = sizePerPage;
        tldSearchParams.pageNumber = page;
        await this.loadTableData(tldSearchParams);

    }

    getAdvanceSearchDialog() {
        return <Dialog
            fullWidth={true}
            onClose={(event, reason) => {
                if (reason === 'backdropClick' || reason === 'escapeKeyDown') {
                    return false;
                }
            }}
            maxWidth="lg"
            open={this.state.showAdvanceSearch}
        >
            <DialogTitle id="form-dialog-title">DNS New Domains Search</DialogTitle>

            <DialogContent>
                <Form>
                    <Form.Group as={Row} className={'align-items-center'}>
                        <Form.Label column sm="2" className={'font-weight-bold'}>
                            Top Level Domains </Form.Label>
                        <Col sm={2}>
                            <FormControl variant="outlined">
                                <InputLabel htmlFor="wildcard-tld-search">Zone
                                    Name</InputLabel>
                                <Select
                                    autoWidth={true}
                                    className={'w-100'}
                                    name={'tld.comparator'}
                                    value={this.state.filters.tld.comparator}
                                    onChange={this.handleFilterChange}
                                    label="Top Level Domains"
                                >
                                    {TldHelper.getTldComparators.map(obj => (
                                        <MenuItem value={obj.value}
                                                  key={obj.value}>{obj.label}</MenuItem>
                                    ))}

                                </Select>
                            </FormControl>
                        </Col>
                        <Col sm={4}>
                            <Form.Control name={'tld.value'}
                                          value={this.state.filters.tld.value}
                                          onChange={this.handleFilterChange}
                            />
                        </Col>

                    </Form.Group>

                    <span><b>NOTE:</b> If you want to list all top level domain names, you can leave the following fields empty and click the 'Search' button directly

</span>
                </Form>
            </DialogContent>

            <DialogActions>
                <Button onClick={async (e) => {
                    await this.loadTableData({numberOfRows: 10, pageNumber: 1});
                    this.setState(
                        {showAdvanceSearch: false});
                }
                } color="primary" className={'dns-blue-button text-white'}
                >
                    Search
                </Button>
                <Button onClick={() => this.setState(
                    {showAdvanceSearch: false})}
                        color="primary" className={'dns-blue-button text-white'}>
                    Close
                </Button>
                <Button type={"reset"} onClick={() => {
                    this.setState({filters: _.cloneDeep(defaultFilters)}, () => {
                        this.loadTableData({numberOfRows: 10, pageNumber: 1})
                    });
                }} variant="contained"
                        className={"dns-blue-button text-white ml-2"}
                        disabled={JSON.stringify(this.state.filters) === JSON.stringify(defaultFilters)}>clear</Button>

            </DialogActions>

        </Dialog>
    }


    render() {
        const paginationOptions = this.paginationOptions();
        const {loading, data} = this.state;
        const columns = this.getTldTableColumns();
        return (<div>
                <Helmet>
                    <title>List TLDs | Home</title>
                </Helmet>
                <Box>
                    <Container maxWidth={false} className={"px-2"}>
                        <Card>
                            <CardContent className={"px-0"}>
                                <div className={"text-center"}>
                                    <div className={"row mb-2"}>
                                        <h5 className={"col-9 font-weight-bold mt-5 pt-3  mr-auto ml-auto"}>Top Level
                                            Domain Names
                                            List</h5>
                                        {this.getAdvanceSearchDialog()}

                                        {(!_.isEmpty(this.state.error) || !_.isEmpty(this.props.alert.message)) &&
                                        <Alert
                                            severity={!_.isEmpty(this.state.error) ? "error" : this.props.alert.type}>{(this.state.error && this.state.error.text) || this.props.alert.message}</Alert>}
                                        <div className={"col-3"}>
                                            <Link
                                                className={"d-inline-block btn btn-primary dns-blue-button mt-5 mr-1"}
                                                to="/sys/tlds/create"
                                            >Insert TLD</Link>
                                            <Button aria-controls="simple-menu"
                                                    aria-haspopup="true"
                                                    color="primary"
                                                    className={'d-inline-block btn btn-primary dns-blue-button mt-5 mr-1'}
                                                    variant={'contained'}
                                                    onClick={() => {
                                                        this.setState(
                                                            {showAdvanceSearch: true});
                                                    }} key={'advance_search'}>Search</Button>
                                            {(JSON.stringify(this.state.filters) !== JSON.stringify(defaultFilters)) &&
                                            <Button type={"reset"} onClick={() => {
                                                this.setState({filters: _.cloneDeep(defaultFilters)}, () => {
                                                    this.loadTableData({numberOfRows: 10, pageNumber: 1})
                                                });
                                            }} variant="contained"
                                                    className={'d-inline-block dns-blue-button  text-white mt-5 mr-1'}
                                            >clear</Button>}
                                        </div>

                                    </div>

                                   {/* {this.props.alert.message && <Alert
                                        severity={this.props.alert.type}>{this.props.alert.message}</Alert>}*/}

                                    <div className="pt-1 pb-5 w-50 mr-auto ml-auto">

                                        <BootstrapTable bootstrap4
                                                        keyField={"key"}
                                                        data={data}
                                                        columns={columns}
                                                        remote={{
                                                            pagination: true,
                                                        }}
                                                        onTableChange={this.handleTableChange}
                                                        //filter={filterFactory()}
                                                       // filterPosition={"top"}
                                                        pagination={paginationFactory(paginationOptions)}
                                                        noDataIndication="Table is Empty"
                                                        id={"tld_table"}
                                                        striped
                                                        //hover
                                                        condensed

                                        />
                                    </div>
                                </div>

                            </CardContent>
                        </Card>
                    </Container>
                </Box>
            </div>

        );
    }
}

const styledSearch = withStyles(useStyles)(Search);

function mapState(state) {
    const {deleted} = state.tlds
    const {alert} = state
    return {deleted, alert}
}

const actionCreators = {
    alertClear: alertActions.clear,
}

const connectedTLD = connect(mapState, actionCreators)(styledSearch);
export {connectedTLD as Search};
