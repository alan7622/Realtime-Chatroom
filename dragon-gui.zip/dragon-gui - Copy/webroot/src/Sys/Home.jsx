import React from 'react';
import {DragonRoute, Layout, SysAdminMenu, ZoneMenu} from "../_components";
import {CardContent, Paper} from "@material-ui/core";
import Container from "@material-ui/core/Container";
import Typography from "@material-ui/core/Typography";
import Box from "@material-ui/core/Box";
import {Route, Switch} from "react-router-dom";
import {User, UserSearch} from "./Users";

const {Component} = require("react");
import {connect} from 'react-redux';
import Card from "@material-ui/core/Card";
import {TLD, TldSearch} from "./TLDs";
import {AccountLogSearch} from "./AccountLogs";
import {HistoryLogSearch} from "../Common/HistoryLogs";
import {Account} from "../Dns/Accounts";

class Home extends Component {
    constructor(props) {
        super(props);
        this.state = {
            loading: true,
            user: {},
            alertBox: {
                show: false,
                text: '',
                type: ''
            }
        };
        this.isComponentMounted = false;
    }

    getMenu() {

        let menuItems = [...SysAdminMenu, {path: '/sys/users/edit/:userId', label: '', breadcrumb: ""},
            {path: '/sys/users/details/:userId', label: '', breadcrumb: ""}, {
                path: '/sys/users/create',
                label: '',
                breadcrumb: "Create"
            }, {path: '/sys/tlds/details/:tlDomain', label: '', breadcrumb: "Details"}]

        return menuItems;
    }

    render() {

        return (
            <>
                <Layout menuItems={this.getMenu()}>
                    <Switch>

                        {/*  <Route path="/sys/users" component={UserSearch}/>

                      */}
                        {/*  <Route path="/sys/users/create"
                               component={() => <User isEmptyForm={true} isEditable={true}/>} exact/>*/}

                        {/*  <Route path="/sys/users/details/:id" component={User} exact/>

                        <Route path="/sys/users/edit/:id" component={() => <User isEditable={true}/>} exact/>*/}

                        <DragonRoute path="/sys/users"
                                     unauthorizedMsg={"You must have Super User privilege to administer Sys admin."}
                                     title={"Dragon Provisioning Error Page"}
                                     priv={"su"}
                                     component={<UserSearch/>} exact/>
                        <DragonRoute path="/sys/users/create"
                                     unauthorizedMsg="You must have Super User privilege to administer Sys admin."
                                     title={"Dragon Provisioning Error Page"}
                                     priv={"su"}
                                     component={<User isEmptyForm={true} isEditable={true}/>} exact/>

                        <DragonRoute path="/sys/users/edit/:id"
                                     unauthorizedMsg="You must have Super User privilege to administer Sys admin."
                                     title={"Dragon Provisioning Error Page"}
                                     priv={"su"}
                                     component={<User isEditable={true}/>} exact/>
                        <DragonRoute path="/sys/users/details/:id"
                                     unauthorizedMsg="You must have Super User privilege to administer Sys admin."
                                     title={"Dragon Provisioning Error Page"}
                                     priv={"su"} component={<User/>} exact/>


                        {/*         <Route path="/sys/tlds/details/:tlDomain" component={TLD}/>
                        <Route path="/sys/tlds/create" component={() => <TLD isTLDEmptyForm={true}/>}/>
                        <Route path="/sys/tlds" component={TldSearch}/>*/}

                        <DragonRoute path="/sys/tlds"
                                     unauthorizedMsg={"You must have Super User privilege to administer Sys admin."}
                                     title={"Dragon Provisioning Error Page"}
                                     priv={"su"}
                                     component={<TldSearch/>} exact/>
                        <DragonRoute path="/sys/tlds/details/:tlDomain"
                                     unauthorizedMsg={"You must have Super User privilege to administer Sys admin."}
                                     title={"Dragon Provisioning Error Page"}
                                     priv={"su"}
                                     component={<TLD/>} exact/>
                        <DragonRoute path="/sys/tlds/create"
                                     unauthorizedMsg={"You must have Super User privilege to administer Sys admin."}
                                     title={"Dragon Provisioning Error Page"}
                                     priv={"su"}
                                     component={<TLD isTLDEmptyForm={true}/>} exact/>


                        {/*
                        <Route path="/sys/accountlogs" component={AccountLogSearch}/>
*/}

                        <DragonRoute path="/sys/accountlogs"
                                     unauthorizedMsg={"You must have Super User privilege to administer Sys admin."}
                                     title={"Dragon Provisioning Error Page"}
                                     priv={"su"} component={<AccountLogSearch/>}/>


                        <Route path="/sys/historylogs" component={HistoryLogSearch}/>

                        <Route path="/sys" component={() => {
                            return (<Container maxWidth={false} className={"px-2"}>
                                <Paper>
                                    <Box p={15}>
                                        <h6 className={"font-weight-bold text-center"}>DNS
                                            System Administration Page</h6>

                                        <Typography component={"div"} variant="inherit" align={"left"}>
                                            <p className={"text-wrap"}>
                                                From System Administration page you can administer Users and Top Level
                                                Domains.
                                                You can view Account Logs and History Logs by clicking on the
                                                appropriate menu bar
                                            </p>
                                        </Typography>
                                    </Box>
                                </Paper>
                            </Container>)
                        }}/>


                    </Switch>

                </Layout>
            </>
        )
    }
}

function mapState(state) {
    return {}
}

const actionCreators = {};

const connectedHome = connect(mapState, actionCreators)(Home);
export {connectedHome as Home};
