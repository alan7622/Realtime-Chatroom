import React from "react";
import {alertActions} from "../../_actions";
import {connect} from "react-redux";
import {
    CardContent,
    withStyles,
    Card,
    Dialog,
    DialogTitle,
    DialogContent,
    FormControl,
    Select,
    MenuItem,
    TextField,
    DialogActions,
    Button,
    InputLabel,
    RadioGroup,
    FormControlLabel, Radio
} from "@material-ui/core";
import {accountLogService} from "../../_services/accountLog.service";
import {Helmet} from "react-helmet";
import Container from "@material-ui/core/Container";
import BootstrapTable from 'react-bootstrap-table-next';
import filterFactory, {Comparator, selectFilter, textFilter} from 'react-bootstrap-table2-filter';
import paginationFactory from 'react-bootstrap-table2-paginator';
import _ from "lodash";
import {AccountLogHelper, HistoryLogHelper, Utility} from "../../_helpers";
import {Alert} from "@material-ui/lab";
import {pageRenderer, SizePerPageRenderer} from "../../_components";
import Box from "@material-ui/core/Box";
import Form from "react-bootstrap/Form";
import {Col, Row} from "react-bootstrap";


const useStyles = theme => ({
    root: {},
    editButton: {
        backgroundColor: '#3f75b2',
        '&:hover': {
            backgroundColor: '#3f75b5',
        },

    },

    insertButton: {
        backgroundColor: '#4789b6',
        '&:hover': {
            backgroundColor: '#3f75b5',
        },
    },
    visibilityButton: {

        backgroundColor: '#4789b6',
        paddingRight: 2,
        '&:hover': {
            backgroundColor: '#3f75b5',

        },


    },
    actionContainer: {
        textAlign: 'left'
    }
});
const defaultFilters = {
    lastModTIme: {comparator: 'GtEq', value: ''},
    accountId: {comparator: '', value: ''},
    modBy: {comparator: 'Eq', value: ''},
    action: {comparator: '', value: ''},
    order: {
        by: "accountId",
        dir: "desc"
    }
}


class Search extends React.Component {

    constructor(props) {
        super(props);
        this.state = {
            data: [],
            page: 1,
            loading: true,
            sizePerPage: 10,
            totalSize: 0,
            // comparator: Comparator.EQ,
            accountLogSearchParams: {},
            filters: _.cloneDeep(defaultFilters),
            advanceSearchApplied: false,
            // modTimeFilter: {operation: "lastModTImeGtEq", value: ""},
            alert: '',
            openPgMenu: null,
            showDeleteConfirm: false,
            showAdvanceSearch: false,

        }
        this.isComponentMounted = false;
        this.handleAccountLogTableChange = this.handleAccountLogTableChange.bind(this)
        this.getAdvanceSearchDialog = this.getAdvanceSearchDialog.bind(this)
        this.handleFilterChange = this.handleFilterChange.bind(this);
        this.handleChange = this.handleChange.bind(this);

        /*     if ((this.props.location.state === null || this.props.location.state === undefined || !this.props.location.state.showAlerts) && !_.isEmpty(this.props.alert)) {
                 this.props.alertClear()
             }
     */
        if ((!this.props.showAlerts) && !_.isEmpty(this.props.alert)) {
            this.props.alertClear()
        }
    }


    async componentDidMount() {
        this.isComponentMounted = true;
        await this.loadTableData({numberOfRows: this.state.sizePerPage, pageNumber: this.state.page});

    }


    async loadTableData(params) {
        this.setState({loading: true})

        for (var key in this.state.filters) {
            if (this.state.filters.hasOwnProperty(key) &&
                this.state.filters[key].value) {
                {
                    var value = this.state.filters[key].value
                    if (key == 'lastModTIme') {
                        value = this.getFormattedModTime(value);
                    }

                    params[key +
                    this.state.filters[key].comparator] = value;
                }
            }

        }

        const res = await accountLogService.getAccountLogs(params);
        if (this.isComponentMounted) {
            this.setState({
                alert: res.error,
                data: res.accountLogs,
                loading: false,
                page: params.pageNumber ? params.pageNumber : this.state.page,
                sizePerPage: params.numberOfRows ?
                    params.numberOfRows :
                    this.state.sizePerPage,
                totalSize: res.totalRecords
            });

        }
    }

    componentWillUnmount() {
        this.isComponentMounted = false;
    }


    handleChange(e) {
        const {name, value} = e.target;
        this.setState({target: {[name]: value}})
    }

    handleFilterChange(e) {
        let {name, value} = e.target;
        const {filters} = this.state;
        const filterInfo = name.split('.');
        filters[filterInfo[0]][filterInfo[1]] = value;
        this.setState({filters: filters});
    }


    getAccountLogTableColumns() {
        return [
            {
                dataField: 'sequence',
                text: 'Sequence',
                headerAlign: 'center',
                headerStyle: {
                    width: "14%"
                },
                headerClasses: 'p-1',
                classes: 'text-center p-0',
                style: {
                    'wordWrap': 'break-word'
                },
            },
            {
                dataField: 'createTime',
                text: 'Time',
                headerAlign: 'center',
                headerStyle: {
                    width: "16%"
                },
                headerClasses: 'p-1',
                classes: 'text-center p-0',
                style: {
                    'wordWrap': 'break-word'
                },
            },
            {
                dataField: 'modBy',
                text: 'Last Modified By',
                //  filter: textFilter({placeholder: 'Search', comparator: Comparator.LIKE}),
                sort: true,
                headerAlign: 'center',
                headerStyle: {
                    width: "16%"
                },
                headerClasses: 'p-1',
                classes: 'text-center p-0',
                style: {
                    'wordWrap': 'break-word'
                },
            },

            {
                dataField: 'action',
                text: 'Action',
                //formatter: cell => selectOptions[cell],
                /*
                                filter: selectFilter({
                                    options: selectOptions,
                                    placeholder: "Select",// selectOptions:this.state.sizePerPage  to limit the sizeperpage from api?
                                }),
                */
                headerAlign: 'center',
                headerStyle: {
                    width: "10%"
                },
                headerClasses: 'p-1',
                classes: 'text-center p-0',
                style: {
                    'wordWrap': 'break-word'
                },
            },
            {
                dataField: 'accountId',
                text: 'Account ID',
                //  filter: textFilter({placeholder: 'Search', comparator: Comparator.EQ}),
                //sort: true,
                headerAlign: 'center',
                headerStyle: {
                    width: "12%"
                },
                headerClasses: 'p-1',
                classes: 'text-center p-0',
                style: {
                    'wordWrap': 'break-word'
                },

            },

            {
                dataField: 'comment',
                text: 'Comments',
                headerAlign: 'center',
                headerStyle: {
                    width: "32%"
                },
                headerClasses: 'p-1',
                classes: 'text-center p-0',
                style: {
                    'wordWrap': 'break-word'
                },
            },

        ];
    }


    getAdvanceSearchDialog() {
        return <Dialog
            fullWidth={true}
            onClose={(event, reason) => {
                if (reason === 'backdropClick' || reason === 'escapeKeyDown') {
                    return false;
                }
            }}
            maxWidth="lg"
            open={this.state.showAdvanceSearch}
        >
            <DialogTitle id="form-dialog-title">
                Search Account Logs</DialogTitle>
            <DialogContent>
                <Form>
                    <Form.Group as={Row} className={'align-items-center'}>
                        <Form.Label column sm="2" className={'font-weight-bold'}>
                            Account Id
                        </Form.Label>
                        <Col sm={6}>
                            <Form.Control name={'accountId.value'}
                                //defaultValue={this.state.filters.accountId.value}
                                          value={this.state.filters.accountId.value}
                                          onChange={this.handleFilterChange}
                            />
                        </Col>
                    </Form.Group>
                    <Form.Group as={Row} className={"align-items-center"}>

                        <Form.Label column sm="2" className={"font-weight-bold"}>
                            Action Type
                        </Form.Label>
                        <Col sm={2}>
                            <Form.Control name={"action.value"}
                                          className={"w-25"}
                                          value={this.state.filters.action.value}
                                          onChange={this.handleFilterChange}
                            />

                        </Col>

                    </Form.Group>
                    <Form.Group as={Row} className={'align-items-center'}>
                        <Form.Label column sm="2" className={'font-weight-bold'}>
                            Last Modified Time:

                        </Form.Label>
                        <Col sm="2">
                            <FormControl variant="outlined">
                                <Select
                                    id="mod_time_operation_filter"
                                    value={this.state.filters.lastModTIme.comparator}
                                    onChange={this.handleFilterChange}
                                    name={'lastModTIme.comparator'}>
                                    <MenuItem value={'GtEq'}
                                              key={0}> {'>='} </MenuItem>
                                    <MenuItem value={'Lt'} key={1}> {'<'} </MenuItem>
                                </Select>
                            </FormControl>
                        </Col>
                        <Col sm={4}>
                            <TextField
                                id="mod_time"
                                type="datetime-local"
                                variant="outlined"
                                name={'lastModTIme.value'}
                                onChange={this.handleFilterChange}
                                value={this.state.filters.lastModTIme.value}
                            />
                        </Col>
                    </Form.Group>
                    <Form.Group as={Row} className={'align-items-center'}>

                        <Form.Label column sm="2" className={"font-weight-bold"}>
                            Modified By
                        </Form.Label>
                        <Col sm={2}>
                            <FormControl variant="outlined">
                                <InputLabel htmlFor="wildcard-modifiedBy-search"
                                            className={'w-75'}
                                >
                                    ModifiedBy
                                </InputLabel>
                                <Select
                                    autoWidth={true}
                                    className={'w-100'}
                                    name={'modBy.comparator'}
                                    value={this.state.filters.modBy.comparator}
                                    onChange={this.handleFilterChange}
                                    label="Modified By"
                                >
                                    {AccountLogHelper.getModifiedByComparators.map(obj => (
                                        <MenuItem value={obj.value}
                                                  key={obj.value}>{obj.label}</MenuItem>
                                    ))}

                                </Select>
                            </FormControl>
                        </Col>
                        <Col sm={4}>
                            <Form.Control name={'modBy.value'}
                                          value={this.state.filters.modBy.value}
                                          onChange={this.handleFilterChange}
                            />
                        </Col>
                    </Form.Group>
                    <Form.Group as={Row} className={"align-items-center"}>
                        <Form.Label column sm="3" className={'font-weight-bold'}>
                            Ordered By </Form.Label>
                        <Col sm={9}>
                            <RadioGroup value={this.state.filters.order.by} name={"order.by"}
                                        onChange={this.handleFilterChange} row={true}>

                                <FormControlLabel value="accountId"
                                                  control={<Radio color="primary"/>}
                                                  label="Account Id"/>
                                <FormControlLabel value="modBy"
                                                  control={<Radio color="primary"/>}
                                                  label="Modified By"/>

                                <FormControlLabel value="modTime"
                                                  control={<Radio color="primary"/>}
                                                  label="Modified Time"/>

                            </RadioGroup>
                        </Col>
                    </Form.Group>
                    <Form.Group as={Row} className={"align-items-center"}>
                        <Form.Label column sm="3" className={'font-weight-bold'}>
                            Ordered Direction </Form.Label>
                        <Col sm={9}>
                            <RadioGroup value={this.state.filters.order.dir} name={"order.dir"}
                                        onChange={this.handleFilterChange} row={true}>

                                <FormControlLabel value="asc"
                                                  control={<Radio color="primary"/>}
                                                  label="Ascending"/>
                                <FormControlLabel value="desc" control={<Radio color="primary"/>}
                                                  label="Descending"/>


                            </RadioGroup>
                        </Col>
                    </Form.Group>


                </Form>
            </DialogContent>

            <DialogActions>
                <Button onClick={async (e) => {
                    await this.loadTableData({numberOfRows: this.state.sizePerPage, pageNumber: this.state.page});
                    this.setState(
                        {showAdvanceSearch: false});
                }
                } color="primary" className={'dns-blue-button text-white'}
                >
                    Search
                </Button>
                <Button onClick={() => this.setState(
                    {showAdvanceSearch: false})}
                        color="primary" className={'dns-blue-button text-white'}>
                    Close
                </Button>
                <Button type={"reset"} onClick={() => {
                    this.setState({filters: _.cloneDeep(defaultFilters)}, () => {
                        this.loadTableData({numberOfRows: 10, pageNumber: 1})
                    });
                }} variant="contained"
                        className={"dns-blue-button text-white ml-2"}
                        disabled={JSON.stringify(this.state.filters) === JSON.stringify(defaultFilters)}>clear</Button>
            </DialogActions>
        </Dialog>
    }


    paginationOptions() {
        return {
            sizePerPage: this.state.sizePerPage,
            page: this.state.page,
            totalSize: this.state.totalSize,
            alwaysShowAllBtns: true, // Always show next and previous button
            withFirstAndLast: true, // Hide the going to First and Last page button
            firstPageText: 'First',
            prePageText: 'Back',
            nextPageText: 'Next',
            lastPageText: 'Last',
            nextPageTitle: 'First page',
            prePageTitle: 'Pre page',
            firstPageTitle: 'Next page',
            lastPageTitle: 'Last page',
            showTotal: false,
            sizePerPageList: [
                {
                    text: '10', value: 10
                }, {
                    text: '20', value: 20
                },
                {
                    text: '50', value: 50
                },],
            pageButtonRenderer: pageRenderer,
            sizePerPageRenderer: ({
                                      options,
                                      currSizePerPage,
                                      onSizePerPageChange
                                  }) => <SizePerPageRenderer options={options}
                                                             currSizePerPage={currSizePerPage}
                                                             onSizePerPageChange={onSizePerPageChange}/>,
            disablePageTitle: true,
        };
    }


    async handleAccountLogTableChange(type, {filters, page, sortOrder, sortField, sizePerPage, totalSize}) {
        const currentIndex = (page - 1) * sizePerPage;
        let accountLogSearchParams = {}

        if (sortField && sortOrder) {
            accountLogSearchParams.orderDir = sortOrder;
            accountLogSearchParams.orderBy = sortField;
        }

        accountLogSearchParams.numberOfRows = sizePerPage;
        accountLogSearchParams.pageNumber = page;
        await this.loadTableData(accountLogSearchParams);
    }


    getFormattedModTime(dateTime) {
        let modDate = new Date(dateTime)
        const [year, month, date, hour, minutes, seconds] = [modDate.getFullYear(), modDate.getMonth() + 1, modDate.getDate(), modDate.getHours(), modDate.getMinutes(), modDate.getSeconds()];
        return `${year}-${month}-${date} ${hour}:${minutes}:${seconds}`
    }


    render() {
        const {classes} = this.props;
        const {loading, data} = this.state;
        //const paginationOptions = this.paginationOptions();
        const columns = this.getAccountLogTableColumns();
        return (

            <div>
                <Helmet>
                    <title>DNS Account Logs | Sys Admin</title>
                </Helmet>
                <Box>
                    <Container maxWidth={false} className={"px-2"}>
                        <Card>
                            <CardContent>
                                <div className={"mt-3 ml-4 mr-4 mb-3"}>
                                    <div className={"row mb-2"}>

                                        <h5 className="font-weight-bold  text-capitalize text-left pt-3 pl-3">DNS
                                            Account
                                            Logs
                                        </h5>
                                        {this.getAdvanceSearchDialog()}
                                        <div className={'col text-right mt-2 mb-2'}>
                                            <Button aria-controls="simple-menu"
                                                    aria-haspopup="true"
                                                    color="primary"
                                                    className={'d-inline-block dns-blue-button mt-3 mr-1'}
                                                    variant={'contained'}
                                                    onClick={() => {
                                                        this.setState(
                                                            {showAdvanceSearch: true});
                                                    }} key={'advance_search'}>Search</Button>


                                            {(JSON.stringify(this.state.filters) !== JSON.stringify(defaultFilters)) &&
                                            <Button type={"reset"} onClick={() => {
                                                this.setState({filters: _.cloneDeep(defaultFilters)}, () => {
                                                    this.loadTableData({numberOfRows: 10, pageNumber: 1})
                                                });
                                            }} variant="contained"
                                                    className={'d-inline-block text-white dns-blue-button mt-3 mr-1'}
                                            >clear</Button>}

                                        </div>
                                        {this.state.alert &&
                                        <Alert severity={'error'}>{this.state.alert.text}</Alert>}
                                        <div className="pl-2 pr-2 mt-2">

                                            <BootstrapTable bootstrap4
                                                            keyField="sequence"
                                                            data={data}
                                                            remote={{
                                                                pagination: true,
                                                            }}
                                                            onTableChange={this.handleAccountLogTableChange}
                                                            columns={columns}
                                                            noDataIndication="Table is Empty"
                                                            pagination={paginationFactory(this.paginationOptions())}
                                                            id={"accountLog_table"}
                                                            loading={this.state.loading}
                                                //loading={true}
                                                            striped
                                                            hover
                                                            condensed

                                            />
                                        </div>
                                    </div>
                                </div>
                            </CardContent>
                        </Card>
                    </Container>
                </Box>
            </div>

        );
    }
}

const styledSearch = withStyles(useStyles)(Search);

function mapState(state) {
    const {alert} = state
    return {alert}
}

const actionCreators = {
    alertClear: alertActions.clear,
}

const connectedAccountLog = connect(mapState, actionCreators)(styledSearch);
export {connectedAccountLog as Search};