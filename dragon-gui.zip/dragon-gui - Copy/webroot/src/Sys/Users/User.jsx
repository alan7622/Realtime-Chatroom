import React from 'react';
import {
    Backdrop, Box,
    Button, Card, CardContent,
    CircularProgress,
    Dialog,
    DialogActions,
    DialogTitle, FormControl,
    Paper
} from '@material-ui/core';
import Container from '@material-ui/core/Container';
import {dropDownService, userService} from '../../_services';
import PropTypes from 'prop-types';
import {withRouter} from 'react-router-dom';
import {Col, Row, InputGroup, Form} from 'react-bootstrap';
import {alertActions, userActions} from '../../_actions';
import {connect} from 'react-redux';
import {Alert, AlertTitle} from '@material-ui/lab';
import _ from 'lodash';
import {FontAwesomeIcon} from '@fortawesome/react-fontawesome';
import {faEye, faEyeSlash} from '@fortawesome/free-solid-svg-icons';
import {
    Formik,
    Field as FormikField,
    Form as FormikForm,
    ErrorMessage
} from 'formik';
import * as Yup from 'yup';

import {
    FORM_ELEMENT_TYPES,
    USER_RESPONSE_TO_REQUEST_MAP
} from '../../_helpers';


class User extends React.Component {

    constructor(props) {
        super(props);
        this.state = {
            loading: !this.props.isEmptyForm,
            saving: false,
            dropdownValues: {
                stateCodes: [],
                countryCodes: [],
            },
            user: {
                privileges: "su,ab,ai,au,ad,zb,zi,zu,zd,ri,ru,rd",
                enabled: "Y",
                // serviceId: '',
                //accountId: ''
            },
            showPass: false,
            showDeleteConfirm: false,
            error: '',

        };
        this.isComponentMounted = false;
        this.deleteUser = this.deleteUser.bind(this);
        this.saveUser = this.saveUser.bind(this);
        this.getUserForm = this.getUserForm.bind(this);
        this.getProfileView = this.getProfileView.bind(this);
        this.updateUserObj = this.updateUserObj.bind(this);
        this.getFormGroupElement = this.getFormGroupElement.bind(this);
        this.togglePasswordView = this.togglePasswordView.bind(this);
        if ((this.props.location.state === undefined ||
                !this.props.location.state.showAlerts) &&
            !_.isEmpty(this.props.alert)) {
            this.props.alertClear();
        }
    }

    saveUser(values) {
        console.log(this.state.user)

        //this.setState({loading:true,saving: true})
        //const {createTime, modTime, serviceName, ...data} = values//adding serviceName to exclude serviceName in update request
        const {createTime, modTime, ...data} = values
        console.log(data, "DATA")

        if (this.props.isEmptyForm && this.props.isEditable) {
            this.props.create(data);
        } else {
            console.log(data, "data12")
            this.props.update(
                data
                , this.props.match.params.id);
        }


    }

    async getDropdownValues() {
        const stateResponse = await dropDownService.getByStates()
        const countryResponse = await dropDownService.getByCountries()

        if (stateResponse.success && countryResponse.success && this.isComponentMounted) {

            const stateCodes = [{
                value: "",
                // label: "select State"
                label: "Select"


            }, ...stateResponse.states.map(v => ({value: v.code, label: v.name}))]
            const countryCodes = [{
                value: "",
                //  label: "select country"
                label: "Select Country"


            }, ...countryResponse.countries.map(v => ({value: v.code, label: v.name}))]
            this.setState({
                dropdownValues: {stateCodes, countryCodes}
            })
        }
    }

    async componentDidMount() {
        let res = null;

        this.isComponentMounted = true;
        await this.getDropdownValues();
        if (!this.props.isEmptyForm) {
            const auth = JSON.parse(localStorage.getItem('user'));
            const userId = this.props.componentName == 'profile' ?
                auth.userId :
                this.props.match.params.id;
            const resp = await userService.getByUserId(userId);
            if (this.isComponentMounted) {
                //  console.log(resp.user,"USER")
                this.setState({loading: false, user: resp.user, error: resp.error});
            }
        }
    }

    deleteUser() {
        this.setState({showDeleteConfirm: false, loading: true});
        this.props.delete(this.props.match.params.id);
    }

    componentWillUnmount() {
        this.isComponentMounted = false;
    }

    updateUserObj(e) {
        let {name, value} = e.target;
        const {user} = this.state;
        if (USER_RESPONSE_TO_REQUEST_MAP.hasOwnProperty(name)) {
            delete user[name];
            name = USER_RESPONSE_TO_REQUEST_MAP[name];
        }

        if (!_.isEmpty(this.props.alert)) {
            this.props.alertClear();
        }

        this.setState({user: {...user, [name]: value}});
    }

    getPageInfoElementsAndButtons() {
        let pageElements = {
            pageTitle: '',
            pageButtons: []
        };
        if (this.props.isEditable && this.props.isEmptyForm) {
            pageElements.pageTitle = 'DNS User Creation';
            pageElements.pageButtons.push(<Button
                className={'dns-blue-button text-white mr-2 text-center col-md-1'}
                type="submit" key={'insert'}>Insert</Button>);
            pageElements.pageButtons.push(<Button
                className={'dns-blue-button text-white mr-2 text-center col-md-1'}
                onClick={() => this.props.history.push(`/sys/users`)}
                key={'cancel_insert'}>Cancel</Button>);
        } else if (this.props.isEditable) {
            pageElements.pageTitle = 'DNS Users Modification';
            pageElements.pageButtons.push(<Button
                className={'dns-blue-button text-white mr-2 col-md-1'}
                // onClick={this.saveUser}
                type={"submit"}
                key={'update'}>Update</Button>);
            pageElements.pageButtons.push(<Button
                className={'dns-blue-button text-white mr-2 col-md-1'}
                onClick={() => {
                    this.props.alertClear();
                    this.props.history.goBack()}}
                key={'cancel_update'}>Cancel</Button>);

        } else {

            pageElements.pageTitle = 'DNS User';
            pageElements.pageButtons.push(<Button
                className={'dns-blue-button text-white mt-2 mr-4 mb-4'}
                onClick={() => this.props.history.push(
                    `/sys/users/edit/${this.props.match.params.id}`)}
                key={'edit'}>Go To Update</Button>);

            pageElements.pageButtons.push(<Button
                className={'dns-blue-button text-white mt-2 mr-4 mb-4'}
                onClick={() => {
                    this.setState({showDeleteConfirm: true});
                }} key={'delete'}>Delete</Button>);

            pageElements.pageButtons.push(<Button
                className={'dns-blue-button text-white mt-2 mb-4'}
                onClick={() => this.props.history.push(`/sys/users`)}
                key={'list_users'}>List Users</Button>);

        }

        return pageElements;
    }

    getDialogConfirm() {
        return !this.props.isEditable && <Dialog
            onClose={(event, reason) => {
                if (reason === 'backdropClick' || reason === 'escapeKeyDown') {
                    return false;
                }
            }}
            maxWidth="xs"
            aria-labelledby="confirmation-dialog-title"
            open={this.state.showDeleteConfirm}
        >
            <DialogTitle id="confirmation-dialog-title">Are you sure you want to
                delete this
                record?</DialogTitle>
            <DialogActions>
                <Button autoFocus onClick={this.deleteUser} color="primary">
                    Delete
                </Button>
                <Button onClick={() => this.setState({showDeleteConfirm: false})}
                        color="primary">
                    Cancel
                </Button>
            </DialogActions>
        </Dialog>;
    }

    togglePasswordView() {
        this.setState({showPass: !this.state.showPass});

    }

    getFormGroupElement(
        label, isEditable, elemType, elemName, elemVal, elemError, handleChange, placeholder, selectOptions = "", isRequired = false, disabled = false) {
        switch (elemType) {
            case FORM_ELEMENT_TYPES.Password:
                return <><Form.Label column sm="2" className={'font-weight-bold'}>
                    {isRequired && isEditable ? "*" + label : label}

                </Form.Label><Col sm="2" className={'position-relative'}>
                    {isEditable ? <> <InputGroup>
                        <Form.Control

                            type={this.state.showPass ?
                                'text' :
                                'password'}
                            placeholder={placeholder}
                            aria-describedby="inputGroupPrepend"
                            name={elemName}
                            value={elemVal}
                            isInvalid={!!elemError}
                            onChange={handleChange}>
                        </Form.Control>
                        <InputGroup.Append>
                            <InputGroup.Text>
                                <FontAwesomeIcon
                                    icon={this.state.showPass ? faEye : faEyeSlash}
                                    onClick={this.togglePasswordView}/>
                            </InputGroup.Text>
                        </InputGroup.Append>
                        <Form.Control.Feedback type="invalid">
                            {elemError}
                        </Form.Control.Feedback>

                    </InputGroup> <em style={{'fontSize': '11px'}}
                                      className={'position-absolute color-dragon-blue '}>

                        Note: Password must have at
                        least 8 characters,2 non-alphanumerics
                    </em>


                    </> : '********'}
                </Col></>;
            case FORM_ELEMENT_TYPES.Select:
                return <>  <Form.Label column sm="2" className={'font-weight-bold'}>
                    {isRequired && isEditable ? "*" + label : label}
                </Form.Label>
                    <Col sm="2">
                        {isEditable ?
                            <>   <Form.Control as="select"
                                               name={elemName}
                                               value={elemVal}
                                               onChange={handleChange}
                                               isInvalid={!!elemError}

                            >

                                {/*    <option value={""}>choose</option>*/}


                                {selectOptions.map((obj, key) => <option key={key}
                                                                         value={obj.value}>{obj.label}</option>)}
                            </Form.Control>
                                <Form.Control.Feedback type="invalid">
                                    {elemError}
                                </Form.Control.Feedback>

                            </> : elemVal}

                    </Col>
                </>

            default:
                return <><Form.Label column sm="2" className={'font-weight-bold'}>
                    {isRequired && isEditable ? "*" + label : label}
                </Form.Label>
                    <Col sm="2">
                        {isEditable ?
                            <><Form.Control
                                type={elemType}
                                placeholder={placeholder}
                                aria-describedby="inputGroupPrepend"
                                name={elemName}
                                value={elemVal}
                                isInvalid={!!elemError}
                                onChange={handleChange}
                                disabled={disabled}

                            />
                                <Form.Control.Feedback type="invalid">
                                    {elemError}
                                </Form.Control.Feedback>
                            </> : elemVal}

                    </Col></>;
        }

    }

    getUserForm() {
        const {user} = this.state;
        const schema = Yup.object().shape({
            userName: Yup.string().min(2, 'Too Short!').max(50, 'Too Long!').required('Required Field'),
            attUid: Yup.string().required('Required Field'),
            addrEmail: Yup.string().email('required').required('Required Field'),
            password: Yup.string().required('Required Field').min(8, 'Minimum 8 chars Required').matches(/(?:[^`!@#$%^&*\-_=+'\/.,]*[`!@#$%^&*\-_=+'\/.,]){2}/, '2 alphanumerics are required'),
            enabled: Yup.string().required('Select one option'),
            privs: Yup.string().required('Select one option'),
            fName: Yup.string().required('Required Field'),
            lName: Yup.string().required('Required Field'),
            /*
                        serviceName: Yup.string().when("privs", {
                            is: (p) => p != "su,ab,ai,au,ad,zb,zi,zu,zd,ri,ru,rd",
                            then: Yup.string().required('Required field')
                        }),
            */
            /*
                        accountId: Yup.string().when("privs", {
                            is: (p) => p != "su,ab,ai,au,ad,zb,zi,zu,zd,ri,ru,rd",
                            then: Yup.string().required('Required field')
                        })
            */ // according to [DRAGON3-314] it says next level (ab,ai,au,ad,zb,zi,zu,zd,ri,ru,rd) can have just a service id,
            // cannot have an account id (i.e. would not limit the accounts they can access).So commenting  the required field accountId
        });
        let {pageButtons} = this.getPageInfoElementsAndButtons();
        console.log(schema.fields.addrEmail.exclusiveTests.required, "SCHEMA")
        return <Formik
            initialValues={{
                userName: user.userName ? user.userName : '',
                attUid: user.attUid ? user.attUid : '',
                addrEmail: user.addrEmail ? user.addrEmail : '',
                password: user.password ? user.password : '',
                enabled: user.enabled ? user.enabled : '',
                privs: user.privileges ? user.privileges : '',
                fName: user.fName ? user.fName : '',
                lName: user.lName ? user.lName : '',
                mName: user.mName ? user.mName : '',
                accountId: user.accountId ? user.accountId : '',
                serviceName: user.serviceId ? user.serviceId : '',
                comments: user.comment ? user.comment : '',
                createTime: user.createTime ? user.createTime : '',
                modTime: user.modTime,
                phoneCountryCode: user.phoneCountryCode ? user.phoneCountryCode : '',
                phoneNum: user.phoneNum ? user.phoneNum : '',
                addrLine1: user.addrLine1 ? user.addrLine1 : '',
                addrLine2: user.addrLine2 ? user.addrLine2 : '',
                addrCity: user.addrCity ? user.addrCity : '',
                addrStateCode: user.addrStateCode ? user.addrStateCode : '',
                addrCountryCode: user.addrCountryCode ? user.addrCountryCode : '',
                addrZip: user.addrZip ? user.addrZip : '',

            }}
            validationSchema={schema}
            onSubmit={(values, {setSubmitting}) => {
                setSubmitting(true);
                this.saveUser(values);
                /*
                                setSubmitting(false)
                */
            }}
            /*validateOnChange={false}
            validateOnBlur={false}*/
            /*
                        onSubmit={this.saveUser}
            */
        >
            {({
                  values,
                  errors,
                  touched,
                  handleChange,
                  handleBlur,
                  handleSubmit,
                  isSubmitting,
                  meta,
              }) => (<Form noValidate onSubmit={handleSubmit} /*onChange={this.updateUserObj}*/
            >
                {console.log(meta, "META")}
                {console.log(values, "META")}
                {console.log(errors, "META")}

                {this.props.alert.message &&
                    <Alert
                        severity={this.props.alert.type}>{this.props.alert.message}</Alert>}
                <Form.Group as={Row} className={'align-items-center'}>
                    {this.getFormGroupElement('Login Id', this.props.isEmptyForm && this.props.isEditable,
                        FORM_ELEMENT_TYPES.Text, 'userName', values.userName,
                        touched.userName && errors.userName, handleChange, 'Login Id', '', schema.fields.userName.exclusiveTests.required)}
                    {this.getFormGroupElement('ATT_UID', this.props.isEditable,
                        FORM_ELEMENT_TYPES.Text, 'attUid', values.attUid, touched.attUid && errors.attUid,
                        handleChange, '', '', schema.fields.attUid.exclusiveTests.required)}
                    {this.getFormGroupElement('Password', this.props.isEditable,
                        FORM_ELEMENT_TYPES.Password, 'password', values.password,
                        touched.password && errors.password, handleChange, '', '', schema.fields.password.exclusiveTests.required)}
                </Form.Group>
                <Form.Group as={Row} className={'align-items-center pt-3 mb-1'}>

                    {this.getFormGroupElement('Login Enabled', this.props.isEditable, FORM_ELEMENT_TYPES.Select, 'enabled', values.enabled, touched.enabled && errors.enabled, handleChange, '', [{
                        value: 'Y',
                        label: 'Yes'
                    }, {value: 'N', label: 'No'}], schema.fields.enabled.exclusiveTests.required)}

                    {this.getFormGroupElement('Privileges', this.props.isEditable, FORM_ELEMENT_TYPES.Select, 'privs', values.privs, touched.privs && errors.privs, handleChange, '', [
                        {
                            value: 'su,ab,ai,au,ad,zb,zi,zu,zd,ri,ru,rd',
                            label: 'su,ab,ai,au,ad,zb,zi,zu,zd,ri,ru,rd'
                        },
                        {value: 'ab,ai,au,ad,zb,zi,zu,zd,ri,ru,rd', label: 'ab,ai,au,ad,zb,zi,zu,zd,ri,ru,rd'},
                        {value: 'ab,zb,ri,ru,rd', label: 'ab,zb,ri,ru,rd'},
/*
                        {value: 'ab,zb,pu', label: 'ab,zb,pu'},
*/
                        {
                            value: 'ab,zb',
                            label: 'ab,zb'
                        }], values.accountId ? false : schema.fields.privs.exclusiveTests.required)}


                </Form.Group>

                <Form.Group as={Row} className={'align-items-center mb-1'}>
                    {this.getFormGroupElement('First Name', this.props.isEditable,
                        FORM_ELEMENT_TYPES.Text, 'fName', values.fName,
                        touched.fName && errors.fName, handleChange, 'First Name', '', schema.fields.fName.exclusiveTests.required)}
                    {this.getFormGroupElement('Middle Name', this.props.isEditable,
                        FORM_ELEMENT_TYPES.Text, 'mName', values.mName,
                        errors.mName, handleChange, 'Middle Name')}
                    {/*  <p>Note: the password must have at least 8 characters, and contain at least 2 non-alphanumerics. This
                    password will be stored in the database and used for internal purposes. It is required, but only has to
                    be entered this one time, and the user will not have to use it to sign on to Dragon.
                </p>*/}
                    {this.getFormGroupElement('Last Name', this.props.isEditable,
                        FORM_ELEMENT_TYPES.Text, 'lName', values.lName,
                        touched.lName && errors.lName, handleChange, 'Last Name', '', schema.fields.lName.exclusiveTests.required)}
                </Form.Group>
                <Form.Group as={Row} className={'align-items-center mb-1'}>

                    {this.getFormGroupElement('Service ID', this.props.isEditable,
                        FORM_ELEMENT_TYPES.Text, 'serviceName', values.serviceName,
                        '', handleChange, 'Service Id', '', '', values.privs == "su,ab,ai,au,ad,zb,zi,zu,zd,ri,ru,rd")}

                    {this.getFormGroupElement('Account ID', this.props.isEditable,
                        FORM_ELEMENT_TYPES.Text, 'accountId', values.accountId,
                        '', handleChange, 'accountId', '', '', values.privs == "su,ab,ai,au,ad,zb,zi,zu,zd,ri,ru,rd")}
                    {this.getFormGroupElement('Email', this.props.isEditable,
                        FORM_ELEMENT_TYPES.Text, 'addrEmail', values.addrEmail,
                        touched.addrEmail && errors.addrEmail, handleChange, 'email', '', schema.fields.addrEmail.exclusiveTests.required)}


                </Form.Group>
                {!this.props.isEditable &&
                    <Form.Group as={Row} className={'align-items-center mb-1'}>
                        {this.getFormGroupElement('Create Time', false,
                            FORM_ELEMENT_TYPES.Text, '', values.createTime, '', '', '')}
                        {this.getFormGroupElement('Last Modified', false,
                            FORM_ELEMENT_TYPES.Text, '', values.modTime)}
                        {this.getFormGroupElement('Phone-CountryCode', this.props.isEditable,
                            FORM_ELEMENT_TYPES.Text, 'phoneCountryCode', values.phoneCountryCode,
                            errors.phoneCountryCode, handleChange, 'CountryCode')}

                    </Form.Group>}
                <Form.Group as={Row} className={'align-items-center mb-1'}>

                    {this.getFormGroupElement('Phone Number', this.props.isEditable,
                        FORM_ELEMENT_TYPES.Text, 'phoneNum', values.phoneNum,
                        errors.phoneNum, handleChange, 'Phone Number')}
                    {this.getFormGroupElement('Address Line1', this.props.isEditable,
                        FORM_ELEMENT_TYPES.Text, 'addrLine1', values.addrLine1,
                        errors.addrLine1, handleChange, 'Address line1')}
                    {this.getFormGroupElement('Address Line2', this.props.isEditable,
                        FORM_ELEMENT_TYPES.Text, 'addrLine2', values.addrLine2,
                        errors.addrLine2, handleChange, 'Address line2')}
                </Form.Group>
                <Form.Group as={Row} className={'align-items-center mb-1'}>
                    {this.getFormGroupElement('City', this.props.isEditable,
                        FORM_ELEMENT_TYPES.Text, 'addrCity', values.addrCity,
                        errors.addrCity, handleChange, 'City')}
                    {this.getFormGroupElement('State Code', this.props.isEditable,
                        FORM_ELEMENT_TYPES.Select, 'addrStateCode', values.addrStateCode,
                        errors.addrStateCode, handleChange, 'State Code', this.state.dropdownValues.stateCodes)}

                    {this.getFormGroupElement('Country Code', this.props.isEditable,
                        FORM_ELEMENT_TYPES.Select, 'addrCountryCode', values.addrCountryCode,
                        errors.addrCountryCode, handleChange, 'Country Code', this.state.dropdownValues.countryCodes)}
                </Form.Group>
                <Form.Group as={Row} className={'align-items-center mb-1'}>
                    {this.getFormGroupElement('Zip Code', this.props.isEditable,
                        FORM_ELEMENT_TYPES.Text, 'addrZip', values.addrZip,
                        errors.addrZip, handleChange, 'Zip Code')}
                    {this.getFormGroupElement('Comment', this.props.isEditable,
                        FORM_ELEMENT_TYPES.Text, 'comments', values.comments,
                        '', handleChange, 'comment')}
                </Form.Group>
                <div className={'text-center'}>
                    {pageButtons.map(buttonComp => buttonComp)}
                </div>
            </Form>)}
        </Formik>;

    }

    getProfileView() {
        const {user} = this.state;
        return <div>

            <Form.Group as={Row} className={'align-items-center'}>
                <Form.Label column sm="2">
                    Login Id
                </Form.Label>
                <Col sm="4">
                    {user.userName}
                </Col>
                <Form.Label column sm="2">
                    ATT_UID
                </Form.Label>
                <Col sm="4">
                    {user.attUid}
                </Col>
            </Form.Group>
            <Form.Group as={Row} className={'align-items-center'}>
                <Form.Label column sm="2">
                    First Name
                </Form.Label>
                <Col sm="4">
                    {user.fName}
                </Col>
                <Form.Label column sm="2">
                    Last Name
                </Form.Label>
                <Col sm="4">
                    {user.lName}
                </Col>
            </Form.Group>

            <Form.Group as={Row} className={'align-items-center'}>
                <Form.Label column sm="2">
                    Privileges
                </Form.Label>
                <Col sm="4">
                    {this.props.isEditable ? <Form.Control as="select" name={'privs'}
                                                           value={user.privileges}>
                        <option>choose</option>
                        <option>su,ab,ai,au,ad,zb,zi,zu,zd,ri,ru,rd</option>
                        <option>ab,ai,au,ad,zb,zi,zu,zd,ri,ru,rd</option>
                        <option>ab,zb,ri,ru,rd</option>
{/*
                        <option>ab,zb,pu</option>
*/}
                        <option>ab,zb</option>
                    </Form.Control> : user.privileges}
                </Col>
                <Form.Label column sm="2">
                    Email Address
                </Form.Label>
                <Col sm="4">
                    {user.addrEmail}
                </Col>
            </Form.Group>

        </div>;
    }

    render() {
        let {pageTitle} = this.getPageInfoElementsAndButtons();

        if (this.state.loading) {
            return <div>Loading....</div>
        }
        return (
            <>
                {this.getDialogConfirm()}
                {this.props.loading && <Backdrop className={'page-loading'} style={{
                    'zIndex': '10000',
                    'color': '#fff'
                }}
                                                 open={this.state.loading &&
                                                     this.props.saving}>
                    <CircularProgress color="inherit"/>
                </Backdrop>}
                <Container maxWidth={false} className={"px-2"}>
                    <Card>
                        <CardContent>
                            <div className={'mt-3 ml-3 mr-3 mb-3'}>
                                <h5 className="font-weight-bold  text-capitalize text-left mt-3 pl-4">{pageTitle}
                                </h5>
                                {/*
                                {(!_.isEmpty(this.state.error) || !_.isEmpty(this.props.alert.message)) &&
                                <Alert
                                    severity={!_.isEmpty(this.state.error) ? "error" : this.props.alert.type}>{(this.state.error && this.state.error.text) || this.props.alert.message}</Alert>}*/}
                                {!this.state.loading && (_.isEmpty(this.state.error)) &&  //user will not be allowed to access profile or userform if it is an error scenario
                                    <div className="pt-3 pl-4 pr-5">

                                        {this.props.componentName == 'profile' ?
                                            this.getProfileView() :
                                            this.getUserForm()}

                                    </div>}
                            </div>

                        </CardContent>
                    </Card>
                </Container>
            </>
        );
    }
}

User.defaultProps = {
    isEditable: false
};
User.propTypes = {
    isEditable: PropTypes.bool,
    isEmptyForm: PropTypes.bool
};
User.defaultProps = {
    isEditable: false,
    isEmptyForm: false
};

function mapState(state) {
    const {deleted, saving, saved} = state.users;
    const {alert} = state;
    return {deleted, saving, saved, alert};
}

const actionCreators = {
    delete: userActions.delete,
    create: userActions.create,
    update: userActions.update,
    alertClear: alertActions.clear
};

const connectedUser = withRouter(connect(mapState,
    actionCreators)(User));
export {connectedUser as User};

