import React, {Component} from "react";
import {
    Card,
    CardContent,
    withStyles,
    Box,
    Button,
    Container,
    MenuItem,
    Dialog,
    DialogTitle,
    DialogContent,
    FormControl,
    Select,
    InputLabel,
    DialogActions, RadioGroup, FormControlLabel, Radio
} from "@material-ui/core";
import BootstrapTable from 'react-bootstrap-table-next';
import filterFactory, {
    textFilter,
    Comparator,
    customFilter,
} from 'react-bootstrap-table2-filter';
import paginationFactory from 'react-bootstrap-table2-paginator';
import 'react-bootstrap-table2-paginator/dist/react-bootstrap-table2-paginator.min.css';
import ToolkitProvider from 'react-bootstrap-table2-toolkit';
import {userService} from "../../_services";
import {Helmet} from "react-helmet";
import {Link} from 'react-router-dom';
import {history,UserHelper, Utility} from "../../_helpers";
import {alertActions} from "../../_actions";
import {connect} from "react-redux";
import {Alert} from "@material-ui/lab";
import {
    pageRenderer,
    ShowHideButton,
    SizePerPageRenderer,
} from "../../_components";
import './user.scss';
import 'react-bootstrap-table-next/dist/react-bootstrap-table2.css';
import _ from "lodash";
import AddIcon from '@material-ui/icons/Add';
import Form from "react-bootstrap/Form";
import {Col, Row} from "react-bootstrap";

const useStyles = theme => ({
    root: {},
    editButton: {
        backgroundColor: '#3f75b2',
        '&:hover': {
            backgroundColor: '#3f75b5',
        },

    },

    insertButton: {
        backgroundColor: '#4789b6',
        '&:hover': {
            backgroundColor: '#3f75b5',
        },
    },
    visibilityButton: {

        backgroundColor: '#4789b6',
        paddingRight: 2,
        '&:hover': {
            backgroundColor: '#3f75b5',

        },


    },
    actionContainer: {
        textAlign: 'left'
    }
});

const defaultFilters = {
    lName: {comparator: 'Eq', value: ''},
    userName: {comparator: 'Eq', value: ''},
    attUid: {comparator: 'Eq', value: ''},
    emailAddr1: {comparator: 'Eq', value: ''},
    order:{
        by:"userName",
        dir:"desc"
    }

}

class Search extends Component {

    constructor(props) {
        super(props);
        this.state = {
            data: [],
            page: 1,
            sizePerPage: 10,
            totalSize: 0,
            loading: true,
            openPgMenu: null,
            userSearchParams: {},
            comparator: Comparator.EQ,
            filters: _.cloneDeep(defaultFilters),
            showAdvanceSearch: false,
        }
        this.isComponentMounted = false;
        this.handleTableChange = this.handleTableChange.bind(this)
        this.getTableColumns = this.getTableColumns.bind(this);
        this.getAdvanceSearchDialog = this.getAdvanceSearchDialog.bind(this)
        this.handleFilterChange = this.handleFilterChange.bind(this);

        if ((!this.props.showAlerts) && !_.isEmpty(this.props.alert)) {
            this.props.alertClear()
        }
    }


    async componentDidMount() {
        this.isComponentMounted = true;
        const params = {numberOfRows: this.state.sizePerPage, pageNumber: this.state.page}
        await this.loadTableData(params)


    }


    async loadTableData(params) {
        this.setState({loading: true})
        for (var key in this.state.filters) {
            if (this.state.filters.hasOwnProperty(key) &&
                this.state.filters[key].value) {
                {
                    var value = this.state.filters[key].value

                    params[key +
                    this.state.filters[key].comparator] = value;
                }
            }
        }
        const res = await userService.getUsers(params);
        if (this.isComponentMounted) {
           // this.setState({loading: false, data: res.userBOs, totalSize: res.totalRecords});

            this.setState({
                alert: res.error,
                data: res.userBOs,
                loading: false,
                page: params.pageNumber ? params.pageNumber : this.state.page,
                sizePerPage: params.numberOfRows ?
                    params.numberOfRows :
                    this.state.sizePerPage,
                totalSize: res.totalRecords
            });

        }
    }

    handleFilterChange(e) {
        let {name, value} = e.target;

        const {filters} = this.state;
        const filterInfo = name.split('.');
        filters[filterInfo[0]][filterInfo[1]] = value;
        this.setState({filters: filters});
    }

/*
    async componentDidMount() {
        this.isComponentMounted = true;
        const params = {}
        params.numberOfRows = this.state.sizePerPage;
        params.pageNumber = this.state.page;
        const res = await userService.getUsers(params);
        if (this.isComponentMounted) {
            this.setState({loading: false, data: res.userBOs, totalSize: res.totalRecords});

        }
    }
*/

    componentWillUnmount() {
        this.isComponentMounted = false;
    }

    getTableColumns() {

        return [
            {
                dataField: 'userName',
                text: 'Login Id',
                sort: true,
                headerAlign: 'center',
                headerStyle: {
                    width: "11%"
                },
                headerClasses: 'p-1',
                classes: 'text-left p-0',
                style: {
                    'wordWrap': 'break-word'
                },
              /*  filter: textFilter({placeholder: 'Search', comparator: Comparator.EQ}),
                onFilter: (filterValue) => {
                }*/
            },
            {
                dataField: 'attUid',
                text: 'ATT UID',
                showHideSelection: true,
                headerAlign: 'center',
                headerStyle: {
                    width: "9%"
                },
                headerClasses: 'p-1',
                classes: 'text-left p-0',
                style: {
                    'wordWrap': 'break-word'
                },
                //filter: textFilter({placeholder: 'Search', comparator: Comparator.EQ}),
            },
            {
                dataField: 'enabled',
                text: 'Enabled',
                headerAlign: 'center',
                headerStyle: {
                    width: "6%",
                },
                headerClasses: 'p-1',
                classes: 'text-center p-0',
                style: {
                    'wordWrap': 'break-word'
                },
            },
            {
                dataField: 'fName',
                text: 'First Name',
                showHideSelection: true,
                headerAlign: 'center',
                headerStyle: {
                    width: "12%"
                },
                headerClasses: 'p-1',
                classes: 'text-left p-0',
                style: {
                    'wordWrap': 'break-word'
                },
            },
            {
                dataField: 'lName',
                text: 'Last Name',
                headerAlign: 'center',
                sort: true,
                onSort: (field, order) => {
                },
               // filter: textFilter({placeholder: 'Search', comparator: Comparator.EQ}),
                headerStyle: {
                    width: "16%"
                },
                headerClasses: 'p-1',
                classes: 'text-left p-0',
                style: {
                    'wordWrap': 'break-word'
                },
            },
            {
                dataField: 'addrEmail',
                text: 'Email',
                headerAlign: 'center',
                sort: true,
                headerStyle: {
                    width: "21%",
                },
                headerClasses: 'p-1',
                classes: 'text-left p-0',
                style: {
                    'wordWrap': 'break-word'
                },
                /*filter: customFilter({comparator: this.state.comparator}),
                headerEvents: {
                    onClick: (e, column, columnIndex) => {
                        return false
                        e.preventDefault()
                    }
                },
                filterRenderer: (onFilter, column) => {
                    return (<>
                        <div><select
                            key="select"
                            ref={node => this.select = node}
                            className="form-control"
                            onClick={(e) => {
                                this.setState({com: true});
                                e.preventDefault();
                                return false
                            }}
                            onChange={(e) => this.setState({comparator: e.target.value})}
                        >
                            <option value={Comparator.EQ}>Equals to</option>
                            <option value={"contains"}>Contains</option>
                            <option value={"beg"}>Begins with</option>
                        </select>
                        </div>
                        <div>
                            <input
                                className={"form-control"}
                                placeholder={"Search"}
                                onChange={(e) => onFilter({value: e.target.value, comparator: this.state.comparator})}
                            /></div>
                    </>)
                }*/
            },

            {
                dataField: 'modTime',
                text: 'Last Modified',
                /*hidden: true,*/
                showHideSelection: true,
                headerAlign: 'center',
                headerStyle: {
                    width: "15%"
                },
                headerClasses: 'p-1',
                classes: 'text-center p-0',
                style: {
                    'wordWrap': 'break-word'
                },
            },
            {
                dataField: "",
                text: "Action",
                headerAlign: 'center',
                headerStyle: {
                    width: "10%",
                },
                headerClasses: 'p-1',
                classes: 'text-center p-0',
                style: {
                    'wordWrap': 'break-word'
                },
                formatter: (cell, row, rowIndex) => <>
                    <Link
                        to={`/sys/users/details/${row.userId}`}
                        key={"details_dns_zone"}
                        className={"color-dragon-blue mr-2"}
                    >Details </Link>
                    <Link
                        to={`/sys/users/edit/${row.userId}`}
                        key={"edit_dns_zone"}
                        className={"color-dragon-blue"}
                    >Edit</Link>
                </>

            },
        ];

    }




    getAdvanceSearchDialog() {
        return <Dialog
            fullWidth={true}
            onClose={(event, reason) => {
                if (reason === 'backdropClick' || reason === 'escapeKeyDown') {
                    return false;
                }
            }}
            maxWidth="lg"
            open={this.state.showAdvanceSearch}
        >
            <DialogTitle id="form-dialog-title">DNS Users
                Search</DialogTitle>

            <DialogContent>
                <Form>
                    <Form.Group as={Row} className={'align-items-center'}>
                        <Form.Label column sm="2" className={'font-weight-bold'}>
                            Login Id
                        </Form.Label>
                        <Col sm={6}>
                            <Form.Control name={'userName.value'}
                                          value={this.state.filters.userName.value}
                                          onChange={this.handleFilterChange}
                            />
                        </Col>
                    </Form.Group>


                    <Form.Group as={Row} className={'align-items-center'}>
                        <Form.Label column sm="2" className={'font-weight-bold'}>
                           ATT UID
                        </Form.Label>
                        <Col sm={6}>
                            <Form.Control name={'attUid.value'} value={this.state.filters.attUid.value}
                                          onChange={this.handleFilterChange}
                            />
                        </Col>
                    </Form.Group>
                    <Form.Group as={Row} className={"align-items-center"}>
                        <Form.Label column sm="2" className={"font-weight-bold"}>
                            Last Name </Form.Label>
                        <Col sm={4}>
                            <Form.Control name={"lName.value"} value={this.state.filters.lName.value}
                                          onChange={this.handleFilterChange}
                            />
                        </Col>
                    </Form.Group>
                    <Form.Group as={Row} className={'align-items-center'}>
                        <Form.Label column sm="2" className={'font-weight-bold'}>
                            Email
                        </Form.Label>
                        <Col sm={2}>
                            <FormControl variant="outlined">
                                <InputLabel htmlFor="wildcard-emailAddr1-search">Email</InputLabel>
                                <Select
                                    autoWidth={true}
                                    className={'w-100'}
                                    name={'emailAddr1.comparator'}
                                    value={this.state.filters.emailAddr1.comparator}
                                    onChange={this.handleFilterChange}
                                    label="Email"
                                >
                                    {UserHelper.getEmailComparators.map(obj => (
                                        <MenuItem value={obj.value}
                                                  key={obj.value}>{obj.label}</MenuItem>
                                    ))}

                                </Select>
                            </FormControl>
                        </Col>
                        <Col sm={4}>
                            <Form.Control name={'emailAddr1.value'}
                                          value={this.state.filters.emailAddr1.value}
                                          onChange={this.handleFilterChange}
                            />
                        </Col>

                    </Form.Group>

                    <Form.Group as={Row} className={"align-items-center"}>
                        <Form.Label column sm="3" className={'font-weight-bold'}>
                            Ordered By </Form.Label>
                        <Col sm={9}>
                            <RadioGroup value={this.state.filters.order.by} name={"order.by"}
                                        onChange={this.handleFilterChange} row={true}>

                                <FormControlLabel value="userName"
                                                  control={<Radio color="primary"/>}
                                                  label="Login Id"/>
                                <FormControlLabel value="lName"
                                                  control={<Radio color="primary"/>}
                                                  label="Last Name"/>

                                <FormControlLabel value="emailAddr"
                                                  control={<Radio color="primary"/>}
                                                  label="Email Address"/>

                            </RadioGroup>
                        </Col>
                    </Form.Group>
                    <Form.Group as={Row} className={"align-items-center"}>
                        <Form.Label column sm="3" className={'font-weight-bold'}>
                            Ordered Direction </Form.Label>
                        <Col sm={9}>
                            <RadioGroup value={this.state.filters.order.dir} name={"order.dir"}
                                        onChange={this.handleFilterChange} row={true}>

                                <FormControlLabel value="asc"
                                                  control={<Radio color="primary"/>}
                                                  label="Ascending"/>
                                <FormControlLabel value="desc" control={<Radio color="primary"/>}
                                                  label="Descending"/>


                            </RadioGroup>
                        </Col>
                    </Form.Group>


                </Form>
            </DialogContent>

            <DialogActions>
                <Button onClick={async (e) => {
                    await this.loadTableData({numberOfRows: 10, pageNumber:1});
                    this.setState(
                        {showAdvanceSearch: false});
                }
                } color="primary" className={'dns-blue-button text-white'}
                >
                    Search
                </Button>
                <Button onClick={() => this.setState(
                    {showAdvanceSearch: false})}
                        color="primary" className={'dns-blue-button text-white'}>
                    Close
                </Button>
                <Button type={"reset"} onClick={() => {
                    this.setState({filters: _.cloneDeep(defaultFilters)}, () => {
                        console.log(defaultFilters, "defaultFilters");
                        console.log(this.state, "STATE");
                        this.loadTableData({numberOfRows: 10, pageNumber: 1})
                    });
                }} variant="contained"
                        className={"dns-blue-button text-white ml-2"}
                        disabled={JSON.stringify(this.state.filters) === JSON.stringify(defaultFilters)}>clear</Button>
            </DialogActions>

        </Dialog>
    }






    getPaginationOptions() {
        return {
            sizePerPage: this.state.sizePerPage,
            page: this.state.page,
            totalSize: this.state.totalSize,
            alwaysShowAllBtns: true, // Always show next and previous button
            withFirstAndLast: true, // Hide the going to First and Last page button
            firstPageText: 'First',
            prePageText: 'Back',
            nextPageText: 'Next',
            lastPageText: 'Last',
            nextPageTitle: 'First page',
            prePageTitle: 'Pre page',
            firstPageTitle: 'Next page',
            lastPageTitle: 'Last page',
            showTotal: false,
            sizePerPageList: [
                {
                    text: '10', value: 10
                }, {
                    text: '20', value: 20
                }, {
                    text: '50', value: 50
                },
            ],

            pageButtonRenderer: pageRenderer,
            sizePerPageRenderer: ({
                                      options,
                                      currSizePerPage,
                                      onSizePerPageChange
                                  }) => <SizePerPageRenderer options={options}
                                                             currSizePerPage={currSizePerPage}
                                                             onSizePerPageChange={onSizePerPageChange}/>,

            disablePageTitle: true,
        };
    }


    async handleTableChange(type, {filters, page, sortOrder, sortField, sizePerPage, totalSize}) {
        console.log(type,'type')
        console.log(filters,'filters')
        console.log(page,'page')
        console.log(sortOrder,"sortOrder")
        console.log(sortField,'sortField')
        console.log(sizePerPage,"sizePerPage")
        console.log(totalSize,"totalSize")

        let userSearchParams = {}

            userSearchParams.orderDir = sortOrder;
            userSearchParams.orderBy = UserHelper.getDataFieldToSortMap(sortField);
            if (!_.isEmpty(filters)) {

                for (const [columnField, colFilterInfo] of Object.entries(filters)) {
                    let comparator = colFilterInfo.comparator
                    let value = colFilterInfo.filterVal
                    if (_.isObject(value) && value.hasOwnProperty('comparator')) {
                        comparator = colFilterInfo.filterVal.comparator
                        value = colFilterInfo.filterVal.value
                    }
                    switch (comparator) {
                        case Comparator.EQ:
                            userSearchParams[`${UserHelper.getDataFieldToFilterMap(columnField)}Eq`] = value
                            break;
                        case Comparator.LIKE:
                            userSearchParams[`${UserHelper.getDataFieldToFilterMap(columnField)}Contains`] = value
                            break;
                        case Comparator.GT:
                            userSearchParams[`${UserHelper.getDataFieldToFilterMap(columnField)}Beg`] = value
                            break;
                        default:
                            userSearchParams[`${UserHelper.getDataFieldToFilterMap(columnField)}${Utility.ucFirst(comparator)}`] = value
                            break;
                    }


                }
            }

            userSearchParams.numberOfRows = sizePerPage;
            userSearchParams.pageNumber = page ? page:1;

       // this.setState({loading: true});
    /*    const res = await userService.getUsers(userSearchParams);
        this.setState({
            data: res.userBOs,
            loading: false,
            page: page,
            sizePerPage: sizePerPage,
            totalSize: res.totalRecords
        });*/
        await this.loadTableData(userSearchParams);

    }

    RemoteTable(p) {
        const columns = this.getTableColumns();

        return <ToolkitProvider bootstrap4={true}
                                keyField="userName"
                                data={p.data}
                                remote
                                columns={columns}
            //remote={{filter: true, sort: true}}
                                columnToggle>
            {
                (props) => (
                    <div>
                        {this.getAdvanceSearchDialog()}

                        <div className={"row mb-2"}>
                            <h5 className="font-weight-bold  text-capitalize text-left pt-3 pl-5">User List</h5>
                            <div className={"col text-right mt-2 mb-2"}>
                                <Button aria-controls="simple-menu" aria-haspopup="true"
                                        variant={"contained"} color="primary"
                                        className={'dns-blue-button text-white mr-1'}
                                        onClick={(e) => history.push('/sys/users/create')}>
                                    Insert User <AddIcon/>
                                </Button>

                                <ShowHideButton columnToggleProps={props.columnToggleProps}
                                                className={"d-inline-block"}></ShowHideButton>


                                <Button aria-controls="simple-menu"
                                        aria-haspopup="true"
                                        color="primary"
                                        className={'d-inline-block dns-blue-button mr-1 ml-1'}
                                        variant={'contained'}
                                        onClick={() => {
                                            this.setState(
                                                {showAdvanceSearch: true});
                                        }} key={'advance_search'}>Search</Button>
                                {(JSON.stringify(this.state.filters) !== JSON.stringify(defaultFilters)) &&
                                <Button type={"reset"} onClick={() => {
                                    this.setState({filters: _.cloneDeep(defaultFilters)}, () => {
                                        this.loadTableData({numberOfRows: 10, pageNumber:1})
                                    });
                                }} variant="contained"
                                        className={'d-inline-block text-white dns-blue-button ml-1 mr-1'}
                                >clear</Button>}


                            </div>
                        </div>
                        <div className={"pb-2"}> {p.alert.message && <Alert
                            severity={p.alert.type}>{p.alert.message}</Alert>}</div>
                        <div className="pl-4 pr-3">
                            <BootstrapTable bootstrap4
                                            keyField={"attUid"}
                                            remote
                                            onTableChange={p.handleTableChange}
                                            filterPosition={"top"}
                                            filter={filterFactory()}
                                            {...props.baseProps}
                                            noDataIndication="Table is Empty"
                                            pagination={paginationFactory(p.paginationOptions)}
                                            id={"user_table"}
                                            loading={true}
                                            striped
                                            hover
                                            condensed
                            />
                        </div>
                    </div>)
            }
        </ToolkitProvider>
    }

    render() {
        const paginationOptions = this.getPaginationOptions();
        return (
            <>
                <Helmet>
                    <title>List Users | Home</title>
                </Helmet>
                <Box>
                    <Container maxWidth={false} className={"px-2"}>
                        <Card>
                            <CardContent className={"px-0"}>
                                <div className={"mt-3 ml-2 mr-3 mb-3"}>
                                    {this.RemoteTable({
                                        data: this.state.data,
                                        handleTableChange: this.handleTableChange,
                                        alert: this.props.alert, paginationOptions: paginationOptions,
                                        loading: this.state.loading
                                    })}
                                </div>
                            </CardContent>
                        </Card>

                    </Container>
                </Box>
            </>

        );
    }
}


const styledSearch = withStyles(useStyles)(Search);

function mapState(state) {
    const {deleted} = state.users
    const {alert} = state
    return {deleted, alert}
}

const actionCreators = {
    alertClear: alertActions.clear,
}

const connectedUser = connect(mapState, actionCreators)(styledSearch);
export {connectedUser as Search};
