import React from "react";
import ListItem from "@material-ui/core/ListItem";
import ListItemIcon from "@material-ui/core/ListItemIcon";
import {Button, Collapse, Link, ListItemText, ListSubheader, withStyles} from "@material-ui/core";
import List from "@material-ui/core/List";
import {NavLink, withRouter} from 'react-router-dom';
import ExpandLess from '@material-ui/icons/ExpandLess';
import ExpandMore from '@material-ui/icons/ExpandMore';
import PropTypes from "prop-types";
import {connect} from "react-redux";
import {StarBorder} from "@material-ui/icons";
import {history} from "../_helpers";
import {DragonAction} from "./DragonAction";
import {isAuthorized} from "./PrivateRoute";

const useStyles = theme => ({

    navLink: {
        color: 'black',
        textDecoration: 'none',
        '&:hover': {
            textDecoration: 'none',
            color: 'black',
        },


    },
    nested: {
        paddingLeft: theme.spacing(4),
    },
})

class SideBarLink extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            open: false
        }
        this.handClick = this.handClick.bind(this);

        this.isActiveLink = this.isActiveLink.bind(this);
    }

    handClick() {
        this.setState({open: !this.state.open})
    }

    isActiveLink(routeName) {
        return this.props.location.pathname === routeName ? true : false;
    }


    render() {
        if (this.props.children && this.props.children.length > 0) {
            return (<>
                    <ListItem
                        selected={this.isActiveLink(this.props.path instanceof Function ? this.props.path() : this.props.path)}
                        button onClick={this.handClick}>
                        {this.props.icon && <ListItemIcon>
                            {this.props.icon}
                        </ListItemIcon>}
                        <ListItemText primary={this.props.label}/>

                        {this.state.open ? <ExpandLess/> : <ExpandMore/>}


                    </ListItem>

                    <Collapse in={this.state.open}>

                        {this.props.children.map((child, key) => {
                            return <List key={key} disablePadding>
                                <NavLink to={child.path} className={this.props.classes.navLink}>
                                    <ListItem component="div" button className={this.props.classes.nested}
                                              selected={this.isActiveLink(child.path instanceof Function ? child.path() : child.path)}>
                                        {child.icon && <ListItemIcon>{child.icon}
                                        </ListItemIcon>}
                                        <ListItemText primary={child.label}/>
                                    </ListItem>

                                </NavLink>
                            </List>
                        })}
                    </Collapse>
                </>

            )
        } else {
            if(!this.props.hasOwnProperty('privileges') || isAuthorized(this.props.privileges)){
                return <Link className={this.props.classes.navLink}
                             onClick={this.props.hasOwnProperty('onclick') ? this.props.onclick : (e) => {
                                 e.preventDefault();
                                 history.push(this.props.path)
                             }}
                >
                    <ListItem button selected={this.isActiveLink(this.props.path)}>
                        {this.props.icon && <ListItemIcon>
                            {this.props.icon}
                        </ListItemIcon>}
                        <ListItemText primary={this.props.label}/>
                    </ListItem>
                </Link>
            }

    return <></>;

        }
    }
}

SideBarLink.propTypes = {
    classes: PropTypes.object.isRequired
};

export default withRouter(connect()(withStyles(useStyles)(SideBarLink)));