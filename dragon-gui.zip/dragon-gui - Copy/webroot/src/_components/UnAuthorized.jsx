import React from "react";
import AttLogo from "../../assets/images/attdragon2.gif";
import SwooshImg from "../../assets/images/swoosh.gif";
import {Helmet} from "react-helmet";
import {Layout} from "./Layout";
import {Route, Switch, withRouter} from "react-router-dom";
import {User as Profile} from "../Sys/Users";
import Container from "@material-ui/core/Container";
import Paper from "@material-ui/core/Paper";
import Box from "@material-ui/core/Box";
import Typography from "@material-ui/core/Typography";
import {ErrorPage, HomeMenu} from "./NavItems";
import {AppBar, Drawer, IconButton, Link, ListItemText, Menu, MenuItem, Toolbar, withStyles} from "@material-ui/core";
import clsx from "clsx";
import MenuIcon from "@material-ui/icons/Menu";
import {Breadcrumb} from "./Breadcrumb";
import Badge from "@material-ui/core/Badge";
import HomeIcon from "@material-ui/icons/Home";
import {history} from "../_helpers";
import {AccountCircle} from "@material-ui/icons";
import PowerSettingsNewIcon from "@material-ui/icons/PowerSettingsNew";
import CssBaseline from "@material-ui/core/CssBaseline";
import Divider from "@material-ui/core/Divider";
import List from "@material-ui/core/List";
import SideBarLink from "./SideBarLink";
import PropTypes from "prop-types";
import {connect} from "react-redux";


const drawerWidth = 1;
const useStyles = theme => ({
    root: {
        display: 'flex'
    },
    menuList: {
        width: '100%',
        maxWidth: 360,
        backgroundColor: theme.palette.background.paper,
    },
    /*toolbar: {
        paddingRight: 24 // keep right padding when menu bar/drawer closed
    },*/
/*
    toolbarIcon: {
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'flex-end',
        padding: '0 8px',
        backgroundImage: `url(${AttLogo})`,
        backgroundRepeat: 'no-repeat',
        backgroundSize: '95% 95%',
        ...theme.mixins.toolbar
    },
*/

    footBar: {
        zIndex: theme.zIndex.drawer + 1,
        backgroundImage: `url(${SwooshImg})`,
        backgroundRepeat: 'no-repeat',
        backgroundSize: 'cover',
        transition: theme.transitions.create(['width', 'margin'], {
            easing: theme.transitions.easing.sharp,
            duration: theme.transitions.duration.leavingScreen
        })
    },




    appBar: {
        zIndex: theme.zIndex.drawer + 1,
        backgroundImage: `url(${SwooshImg})`,
        backgroundRepeat: 'no-repeat',
        backgroundSize: 'cover',
        transition: theme.transitions.create(['width', 'margin'], {
            easing: theme.transitions.easing.sharp,
            duration: theme.transitions.duration.leavingScreen
        })
    },

    appBarShift: {
        marginLeft: drawerWidth,
        width: `calc(100% - ${drawerWidth}px)`,
        transition: theme.transitions.create(['width', 'margin'], {
            easing: theme.transitions.easing.sharp,
            duration: theme.transitions.duration.enteringScreen
        })
    },
    menuButton: {
        marginRight: 36,
        color: 'black'

    },
    menuButtonHidden: {
        display: 'none'
    },
    title: {
        flexGrow: 1
    },

    appBarSpacer: theme.mixins.toolbar,
    content: {
        flexGrow: 1,
        minHeight: '100vh',
        position: 'relative'
    },
    container: {
        paddingTop: theme.spacing(0),
        paddingBottom: theme.spacing(5),


    },
    paper: {
        padding: theme.spacing(1),
        display: 'flex',
        overflow: 'auto',
        flexDirection: 'column'
    },
    /*   fixedHeight: {
           height: 240
       }*/
});
class UnAuthorized extends React.Component {
    constructor(props) {
        super(props)
        super(props);
        this.state = {open: true, anchorEl: null, showLogoffConfirm: false};
        this.toggleAccountDropdownMenu = this.toggleAccountDropdownMenu.bind(this);


    }

/*    toggleLeftMenu() {
        this.setState({open: !this.state.open});
    };*/

    toggleAccountDropdownMenu(event) {
        this.setState({anchorEl: this.state.anchorEl === null ? event.currentTarget : null})
    };
    getHeader() {
        const {classes} = this.props;
        return (
            <>
                <AppBar position="absolute"
                        className={clsx(classes.appBar, this.state.open &&
                            classes.appBarShift)}>

                    <Toolbar className={classes.toolbar}>

                        <IconButton
                            edge="start"
                            color="inherit"
                            aria-label="open drawer"
                            onClick={this.toggleLeftMenu}
                            className={clsx(classes.menuButton, this.state.open &&
                                classes.menuButtonHidden)}
                        >
                            <MenuIcon/>
                        </IconButton>
                        <Typography component="h1" variant="h6" color="inherit" noWrap
                                    className={classes.title}>
                            <Breadcrumb routes={this.props.menuItems}/>
                        </Typography>
                        <a href={'https://cp.s2-ia.bcs.att.com/portal/index.jsp'} target={"_blank"} className={"text-white pt-1 mr-3 font-weight-bold"} >BusinessDirect</a>

                        <IconButton color="inherit">
                            <Badge color="secondary">
                                <HomeIcon onClick={() => {
                                    history.push({pathname: '/'})
                                }}/>
                            </Badge>
                        </IconButton>
                        <IconButton
                            aria-label="account of current user"
                            aria-controls="menu-appbar"
                            aria-haspopup="true"
                            onClick={this.toggleAccountDropdownMenu}
                            color="inherit"
                        >

                            <AccountCircle/>

                        </IconButton>
                        <Menu
                            id="customized-menu"
                            anchorEl={this.state.anchorEl}
                            elevation={0}
                            getContentAnchorEl={null}
                            keepMounted
                            open={Boolean(this.state.anchorEl)}
                            onClose={this.toggleAccountDropdownMenu}
                            anchorOrigin={{
                                vertical: 'bottom',
                                horizontal: 'center',
                            }}
                            transformOrigin={{
                                vertical: 'top',
                                horizontal: 'center',
                            }}
                        >
                            <MenuItem>
                                <ListItemText onClick={() => {
                                    this.props.history.push('/profile')
                                }} primary="My Account"/>
                            </MenuItem>
                            {/*    <MenuItem> <ListItemText onClick={() => {
                                this.props.history.push('/')
                            }} primary="Logoff"/></MenuItem>*/}
                        </Menu>
                        <IconButton
                            aria-label="account of current user"
                            aria-controls="menu-appbar"
                            aria-haspopup="true"
                            onClick={() => {
                                history.push('/logout')
                            }}
                            color="inherit"
                        >
                            <PowerSettingsNewIcon/>
                        </IconButton>
                    </Toolbar>
                </AppBar>
            </>
        )

    }

/*
    getLeftMenu() {
        const {classes} = this.props;
        const open = Boolean(this.state.anchorEl);
        return (
            <>

                <div className={classes.root}>
                    <CssBaseline/>
                    <Drawer
                        variant="permanent"
                        classes={{
                            paper: clsx(classes.drawerPaper, !this.state.open &&
                                classes.drawerPaperClose)
                        }}
                        open={this.state.open}
                    >
                        <div className={classes.toolbarIcon}>
                            {/!*  <IconButton onClick={this.toggleLeftMenu}>
                                <ChevronLeftIcon/>
                            </IconButton>*!/}
                        </div>
                        <Divider/>

                        <List component="nav"
                              aria-labelledby="nested-list-subheader" className={this.props.classes.menuList}>
                            {this.props.menuItems.map((prop, key) => {
                                if (prop.label) {
                                    return <SideBarLink {...prop} key={key} location={this.props.location}/>

                                } else if (prop.divider) {
                                    return <Divider key={key}/>

                                }
                            })}
                        </List>
                    </Drawer>
                    <main className={classes.content}>
                        <div className={classes.appBarSpacer}/>
                        <div id={"body"} className={classes.container}>{this.props.children}</div>
                        {this.getFooter()}
                    </main>

                </div>


            </>
        )
    }
*/

    getFooter() {
        //  const {classes} = this.props;

        return (
            <>
                <footer className={"position-absolute bottom-0 pl-5"}
                    /*    className={clsx(classes.footBar)}*/
                >
                    <Typography>
                        <Link href="http://www.corp.att.com/terms/" className={"mr-2"}>
                            Terms and Conditions
                        </Link>
                        |
                        <Link href="http://www.corp.att.com/terms/"
                              className={"ml-2"}>
                            Privacy Policy </Link>
                        <span dangerouslySetInnerHTML={{"__html": "&copy;"}}/>
                        2010 AT&amp;T. All rights reserved.
                    </Typography>
                </footer>
            </>

        )
    }
    getMenu() {
        return ErrorPage;
    }
    render() {

        return (
            <>
                {this.getHeader()}
                <Container maxWidth={false} className={"px-2"}>
                    <Paper>
                        <Box p={20}>
                            <Typography component={"div"} variant="inherit" align={"left"}>
                                <h5><p className={"text-wrap text-center"}>
                                    User Not Authorized to Access Dragon</p></h5>
                            </Typography>
                        </Box>

                    </Paper>
                </Container>
                {this.getFooter()}

            </>
        )
    }
}


const UnAuthorizedConn = withRouter(connect()(withStyles(useStyles)(UnAuthorized)))
export {UnAuthorizedConn as UnAuthorized};

//export  {UnAuthorized};