import React from 'react';
import {Route, Redirect} from 'react-router-dom';
import {useSelector} from "react-redux";
import {store} from "../_helpers";
import PropTypes from "prop-types";
import Typography from "@material-ui/core/Typography";
import {Card} from "@material-ui/core";
import Container from "@material-ui/core/Container";

export const PrivateRoute = (({component: Component, ...rest}) => {
    const user = useSelector( (s)=> s.authentication)
   // console.log(user)
    return (
        <Route {...rest} render={props => (
            user && user.loggedIn
                ? <Component {...props} />
                : <Redirect to={{pathname: '/login', state: {from: props.location}}}/>
        )}/>
    )})
export const DragonRoute = (({component: Component, ...props}) =>{
   // return <Route path={props.path} component={Component}/>
    return <Route path={props.path}  component={() => isAuthorized(props.priv) ? Component :
      <><Card maxWidth={false} className={"px-2"}>{props.title && <h5 className={"font-weight-bold ml-5 mt-5"}>{props.title}</h5>} <div className={"mt-5 mb-5 ml-2 text-center badge-default font-italic font-weight-bolder"}>{props.unauthorizedMsg}
      </div></Card></>} exact/>
});
DragonRoute.propTypes = {
    priv: PropTypes.string.isRequired,
    path: PropTypes.string.isRequired,
    unauthorizedMsg: PropTypes.string.isRequired,
    //title: PropTypes.string.isRequired,

}
export function isAuthorized(priv){

    const state = store.getState()
console.log(state?.authentication?.user?.privileges.split(',').includes(priv),"state?.authentication?.user?.privileges.split(',').includes(priv)")
    console.log(state,"state")
    console.log(priv,"priv")

    return state?.authentication?.user?.privileges.split(',').includes(priv);
}