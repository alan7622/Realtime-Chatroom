import React from 'react';
import {Typography, Breadcrumbs} from '@material-ui/core';
import useBreadcrumbs from 'use-react-router-breadcrumbs';
import {Link} from 'react-router-dom';


const Breadcrumb = (props) => {
    const breadcrumbs = useBreadcrumbs(props.routes);

    return (
        <Breadcrumbs aria-label="breadcrumb">

            {breadcrumbs.filter(({
                                     match,
                                     breadcrumb
                                 }, index) => !['details', 'edit', 'create','rr', 'servers', 'zones', 'accounts','delg','nameServers'].includes(breadcrumb.props.children.toLowerCase())).map(({//will add breadcrumb element inside array if I do not need it in breadcrumb  and will test to see how far it will work for all test cases.
                                                                                                                                                                     match,
                                                                                                                                                                     breadcrumb
                                                                                                                                                                 }, index) => {

                    //console.log(breadcrumb)
                    //console.log(match)
                    //console.log(match.url, "match.url")
                    if (index === breadcrumbs.length - 1 || match.url === props.location.pathname) {
                        return <Typography key={match.url} color="textPrimary">{breadcrumb}</Typography>
                    } else {
                        return <Link key={match.url} to={match.url}>{breadcrumb}</Link>
                    }
                }
            )}
        </Breadcrumbs>
    );
};
export {Breadcrumb};