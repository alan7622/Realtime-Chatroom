import React from "react";
import {connect, useSelector} from "react-redux";
import {isAuthorized} from "./PrivateRoute";
import {Route, Switch, matchPath} from "react-router-dom";
class DragonAction extends React.Component {
    constructor(props) {
        super(props);
    }

    render() {
            return <Route path={this.props.path} component={() => isAuthorized(this.props.priv) ? this.props.component :
                <div>{this.props.unauthorizedMsg}</div>}/>



    }
}

/*
DragonAction.propTypes = {
    priv: PropTypes.string.isRequired,
    path: PropTypes.string.isRequired,
    unauthorizedMsg: PropTypes.string.isRequired,
}
*/

function mapState(state) {
    return {user: state.authentication.user}
}


const connectedDragonAction = connect(mapState)(DragonAction);
export {connectedDragonAction as DragonAction};