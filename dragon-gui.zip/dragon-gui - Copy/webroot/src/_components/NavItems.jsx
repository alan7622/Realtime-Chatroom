import React from 'react';
import HomeIcon from "@material-ui/icons/Home";
import DnsIcon from '@material-ui/icons/Dns';
import SupervisorAccountIcon from '@material-ui/icons/SupervisorAccount';
import {history, store} from "../_helpers";
import {RrTxt, RrTxtSearch} from "../Dns/Zones/ResourceRecords/Txt-Records";
import {RrAaaa, RrAaaaSearch} from "../Dns/Zones/ResourceRecords/Aaaa-Records";
import {RrA, RrASearch} from "../Dns/Zones/ResourceRecords/A-Records";
import {RrHinfo, RrHinfoSearch} from "../Dns/Zones/ResourceRecords/Hinfo-Records";
import {Bkp, RrMx, RrMxSearch} from "../Dns/Zones/ResourceRecords/Mx-Records";
import {RrCname, RrCnameSearch} from "../Dns/Zones/ResourceRecords/Cname-Records";
import {RrSrv, RrSrvSearch} from "../Dns/Zones/ResourceRecords/Srv-Records";
import {RrGmsFor, RrGmsForSearch} from "../Dns/Zones/ResourceRecords/Gmsfor-Records";
import {RrGmsRev, RrGmsRevSearch} from "../Dns/Zones/ResourceRecords/Gmsrev-Records";
import {RrNaptr, RrNaptrSearch} from "../Dns/Zones/ResourceRecords/Naptr-Records";
import {RrPtr, RrPtrSearch} from "../Dns/Zones/ResourceRecords/Ptr-Records";
import {RrSoa} from "../Dns/Zones/ResourceRecords/Soa-Records";
import {AttNameServers, AttNameServersSearch} from "../Dns/Zones/Servers/Att-NameServers";
import {NonAttNameServers, NonAttNameServersSearch, SlaveNameServer,} from "../Dns/Zones/Servers/Non-Att-NameServers";
import {ListAllRecords} from "../Dns/Zones/ResourceRecords/ListAll-Records";
import {NameServerGroup, NameServerGroupSearch} from "../Dns/Zones/Servers/Name-Server-Groups";
import {RrGen, RrGenSearch} from "../Dns/Zones/ResourceRecords/GENERATE-Records";

import {TransferZoneSearch, TransferZone} from "../Dns/Zones/ZoneTransfers/TransferZone";

export const HomeMenu = [
    {
        path: '/',
        label: 'Home',
        icon: <HomeIcon/>,
        breadcrumb: '',
    },
    {
        path: '/dns',
        label: 'DNS Admin',
        icon: <DnsIcon/>,
        breadcrumb: '',
    },
    {
        path: '/sys',
        label: 'SYS Admin',
        icon: <SupervisorAccountIcon/>,
        breadcrumb: '',
    },

];
export const DnsAdminMenu = [
    {
        path: '/',
        label: 'Home',
        breadcrumb: 'Home',

    },
    {
        path: '/dns',
        label: '',
        breadcrumb: 'Dns',
    },
    {
        path: '/dns/accounts',
        label: 'Accounts',
        children: [
            {
                path: '/dns/accounts/search',
                label: 'Search',
                breadcrumb: 'search',
                inset: true,
            },
            {
                path: '/dns/accounts/create',
                label: 'Create',
                breadcrumb: 'create',

            }
        ]

    },
    {
        path: '/dns/zones',
        label: 'Zones',
        breadcrumb: 'Zones',
        children: [
            {
                path: '/dns/zones/search',
                label: 'Search Zones',
                breadcrumb: 'search',
                inset: true,
            },
            {
                path: '/dns/zones/ptr',
                label: 'Find Zone/PTR-IPV6',
                breadcrumb: 'ptr',
            },
            {
                path: '/dns/zones/delegation',
                label: 'Find Zone/Delegation-IPV6',
                breadcrumb: 'delegation',
            },

        ]

    },
    /*
        {
            path: '/dns/domains',
            label: 'New Domains',
            breadcrumb: 'NewDomains',
        },
    */  //Not supporting this feature now.When user add domains in dpt it should be displayed in dragon new domains.Dpt domains used work differently in the past.After creating domain cron is run to check if that domain is regsitred within 30days and is deleted if not after 30days.
// But in current dcu we cannot support this feature since it needs ti check with outside dns servers which may not be possible. So in dargon we areremoving new domains screen for now.
    {
        path: '/dns/historylogs',
        label: 'History Logs',
        breadcrumb: 'HistoryLogs',
    }
]
export const AccountMenu = [
    ...DnsAdminMenu,
    {
        divider: true,
        path: "-"
    },
    {
        path: "/zones",
        breadcrumb: "listzone",
        icon: "",
        label: "List Zones",
        privileges: ["su,ab,ai,au,ad,zb,zi,zu,zd,ri,ru,rd", "ab,ai,au,ad,zb,zi,zu,zd,ri,ru,rd", "ab,zb,ri,ru,rd", "ab,zb,pu", "ab,zb"],

        onclick: (e) => {
            e.preventDefault()
            let pathArr = window.location.pathname.split("/")
            pathArr = pathArr.slice(2, 6)
            pathArr.push('zones/search')
            history.push("/" + pathArr.join('/'))

        }

    },
    {
        path: "/primaryZone",
        breadcrumb: "PrimaryZone",
        icon: "",
        label: "Add Primary Zone",
        privileges: ["su,ab,ai,au,ad,zb,zi,zu,zd,ri,ru,rd", "ab,ai,au,ad,zb,zi,zu,zd,ri,ru,rd"],

        onclick: (e) => {
            e.preventDefault()
            let pathArr = window.location.pathname.split("/")
            pathArr = pathArr.slice(2, 6)
            pathArr.push('create')
            pathArr.push('primaryZone')
            history.push("/" + pathArr.join('/'))
            //return("/" + pathArr.join('/'))

        }


    },
    {
        path: "/secondaryZone",
        breadcrumb: "Secondary Zone",
        icon: "",
        label: "Insert Secondary Zone",
        privileges: ["su,ab,ai,au,ad,zb,zi,zu,zd,ri,ru,rd", "ab,ai,au,ad,zb,zi,zu,zd,ri,ru,rd"],
        onclick: (e) => {
            e.preventDefault()
            let pathArr = window.location.pathname.split("/")
            pathArr = pathArr.slice(2, 6)
            pathArr.push('create')
            pathArr.push('secondaryZone')
            history.push("/" + pathArr.join('/'))
        }
    },
    {
        path: "/zones",
        breadcrumb: "BillableZones",
        icon: "",
        label: "List Billable Zones",
        privileges: ["su,ab,ai,au,ad,zb,zi,zu,zd,ri,ru,rd", "ab,ai,au,ad,zb,zi,zu,zd,ri,ru,rd"],
        onclick: (e) => {
            e.preventDefault()
            let pathArr = window.location.pathname.split("/")
            pathArr = pathArr.slice(2, 6)
            pathArr.push('zones/search/billable')
            history.push("/" + pathArr.join('/'))

        }

    },
    {
        divider: true,
        path: "-"
    },
    {
        path: "/acctDelg",
        breadcrumb: "AccountDelegations",
        icon: "",
        label: "List Delegations",
        privileges: ["su,ab,ai,au,ad,zb,zi,zu,zd,ri,ru,rd", "ab,ai,au,ad,zb,zi,zu,zd,ri,ru,rd", "ab,zb,ri,ru,rd", "ab,zb,pu", "ab,zb"],

        onclick: (e) => {
            e.preventDefault()
            let pathArr = window.location.pathname.split("/")
            pathArr = pathArr.slice(2, 6)
            pathArr.push('acctDelg')
            history.push("/" + pathArr.join('/'))

        }

    }


]
export const ZoneMenu = [
    {
        path: '/',
        label: 'Home',
        breadcrumb: 'Home',
    },
    {
        path: '/dns',
        label: '',
        breadcrumb: 'Dns',

    },
    {
        path: '/dns/accounts',
        label: 'Accounts',
        children: [
            {
                path: '/dns/accounts/search',
                label: 'Search',
                breadcrumb: 'search',
                inset: true,
            },
            {
                path: '/dns/accounts/create',
                label: 'Create',
                breadcrumb: 'create',
            }
        ]

    },
    {
        path: '/dns/zones',
        label: 'Zones',
        breadcrumb: 'Zones',
        children: [
            {
                path: '/dns/zones/search',
                label: 'Search Zones',
                breadcrumb: 'search',
                inset: true,
            },
            {
                path: '/dns/zones/ptr',
                label: 'Find Zone/PTR-IPV6',
                breadcrumb: 'ptr',
            },
            {
                path: '/dns/zones/delegation',
                label: 'Find Zone/Delegation-IPV6',
                breadcrumb: 'delegation',
            },
            {
                path: () => {
                    let pathArr = window.location.pathname.split("/")
                    pathArr = pathArr.slice(2, 7)
                    return "/" + pathArr.join('/') + "/xferzones/acl"
                },
                component: {
                    search: <TransferZoneSearch key={"xfer_search"}/>,
                    create: <TransferZone isEmptyForm={true} isEditable={true} key={"xfer_create"}/>,
                    edit: <TransferZone isEditable={true} key={"xfer_edit"}/>,
                    details: <TransferZone key={"xfer_details"}/>
                },
                name: 'acl',
                label: 'XFER  ACLS',
                breadcrumb: 'acl',
                inset: true,
            },

            /*{
                path: () => {
                    let pathArr = window.location.pathname.split("/")
                    pathArr = pathArr.slice(2, 6)
                    return "/" + pathArr.join('/') + "/xferzones/aclv4"
                },
                component: {
                    search: <XferIPv4AclSearch key={"xfer_ipv4_search"}/>,
                    create: <XferIPv4Acl isEmptyForm={true} isEditable={true} key={"xfer_ipv4_create"}/>,
                    edit: <XferIPv4Acl isEditable={true} key={"xfer_ipv4_edit"}/>,
                    details: <XferIPv4Acl key={"xfer_ipv4_details"}/>
                },
                name: 'aclv4',
                label: 'XFER IPV4 ACLS',
                breadcrumb: 'aclv4',
                inset: true,
            },
            {
                path: () => {
                    let pathArr = window.location.pathname.split("/")
                    pathArr = pathArr.slice(2, 6)
                    return "/" + pathArr.join('/') + "/xferzones/aclv6"
                },
                component: {
                    search: <XferIPv6AclSearch key={"xfer_ipv6_search"}/>,
                    create: <XferIPv6Acl isEmptyForm={true} isEditable={true} key={"xfer_ipv6_create"}/>,
                    edit: <XferIPv6Acl isEditable={true} key={"xfer_ipv6_edit"}/>,
                    details: <XferIPv6Acl key={"xfer_ipv6_details"}/>
                },
                name: 'aclv6',
                label: 'XFER IPV6 ACLS',
                breadcrumb: 'aclv6',
                inset: true,
            },*/

        ]

    },
    {
        path: "/dns/zones/rr",
        breadcrumb: "",
        icon: "",
        label: "Resource Records",
        children: [

            {
                path: () => {
                    let pathArr = window.location.pathname.split("/")
                    //pathArr = pathArr.slice(2, 6)
                    pathArr = pathArr.slice(2, 7)
                    return "/" + pathArr.join('/') + "/rr/SOA"
                },
                component: {
                    search: <RrSoa key={"rr_soa_search"}/>,
                    create: <RrSoa isEmptyForm={true} isEditable={true} key={"rr_soa_create"}/>,
                    edit: <RrSoa isEditable={true} key={"rr_soa_edit"}/>,
                    details: <RrSoa key={"rr_soa_details"}/>
                },
                name: 'SOA',
                label: 'SOA Records',
                breadcrumb: 'soa',
                inset: true,
            },

            {
                path: () => {
                    let pathArr = window.location.pathname.split("/")
                    pathArr = pathArr.slice(2, 7)
                    return "/" + pathArr.join('/') + "/rr/A"
                },
                component: {
                    search: <RrASearch key={"rr_a_search"}/>,
                    create: <RrA isEmptyForm={true} isEditable={true} key={"rr_a_create"}/>,
                    edit: <RrA isEditable={true} key={"rr_a_edit"}/>,
                    details: <RrA key={"rr_a_details"}/>
                },
                name: 'A',
                label: 'A Records',
                breadcrumb: 'RR_A',
                inset: true,


            },

            {
                path: () => {
                    let pathArr = window.location.pathname.split("/")
                    pathArr = pathArr.slice(2, 7)
                    return "/" + pathArr.join('/') + "/rr/MX"
                },
                component: {
                    search: <RrMxSearch key={"rr_mx_search"}/>,
                    create: <RrMx isEmptyForm={true} isEditable={true} key={"rr_mx_create"}/>,
                    edit: <RrMx isEditable={true} key={"rr_mx_edit"}/>,
                    details: <RrMx key={"rr_mx_details"}/>
                },
                name: 'MX',
                label: 'MX Records',
                breadcrumb: 'RR_MX',
                inset: true,

            },
            {
                path: () => {
                    let pathArr = window.location.pathname.split("/")
                    pathArr = pathArr.slice(2, 7)
                    return "/" + pathArr.join('/') + "/rr/CNAME"
                },
                component: {
                    search: <RrCnameSearch key={"rr_cname_search"}/>,
                    create: <RrCname isEmptyForm={true} isEditable={true} key={"rr_cname_create"}/>,
                    edit: <RrCname isEditable={true} key={"rr_cname_edit"}/>,
                    details: <RrCname key={"rr_cname_details"}/>
                },
                name: 'CNAME',
                label: 'CName',
                breadcrumb: 'RR_CNAME',
                inset: true,
            },
            {
                path: () => {
                    let pathArr = window.location.pathname.split("/")// ['',dragon','dns','zones','details','340','rr','PTR']
                    pathArr = pathArr.slice(2, 7)
                    return "/" + pathArr.join('/') + "/rr/PTR"
                },
                component: {
                    search: <RrPtrSearch key={"rr_ptr_search"}/>,
                    create: <RrPtr isEmptyForm={true} isEditable={true} key={"rr_ptr_create"}/>,
                    edit: <RrPtr isEditable={true} key={"rr_ptr_edit"}/>,
                    details: <RrPtr key={"rr_ptr_details"}/>
                },
                name: 'PTR',
                label: 'PTR Records',
                breadcrumb: 'RR_PTR',
                inset: true,
            },
            {
                path: () => {
                    let pathArr = window.location.pathname.split("/")// ['',dragon','dns','zones','details','340','rr','TXT']
                    pathArr = pathArr.slice(2, 7)
                    return "/" + pathArr.join('/') + "/rr/HINFO"
                },
                component: {
                    search: <RrHinfoSearch key={"rr_hinfo_search"}/>,
                    create: <RrHinfo isEmptyForm={true} isEditable={true} key={"rr_txt_create"}/>,
                    edit: <RrHinfo isEditable={true} key={"rr_hinfo_edit"}/>,
                    details: <RrHinfo key={"rr_hinfo_details"}/>
                },
                name: 'HINFO',
                label: 'HINFO Records',
                breadcrumb: 'RR_HINFO',
                inset: true,


            },
            {
                path: () => {
                    let pathArr = window.location.pathname.split("/")// ['',dragon','dns','zones','details','340','rr','TXT']
                    pathArr = pathArr.slice(2, 7) //['zones','details','340','rr','TXT']
                    return "/" + pathArr.join('/') + "/rr/TXT"
                },//  /zones/details/340/rr/TXT/rr/TXT
                component: {
                    search: <RrTxtSearch key={"rr_txt_search"}/>,
                    create: <RrTxt isEmptyForm={true} isEditable={true} key={"rr_txt_create"}/>,
                    edit: <RrTxt isEditable={true} key={"rr_txt_edit"}/>,
                    details: <RrTxt key={"rr_txt_details"}/>
                },
                name: 'TXT',
                label: 'TXT Records',
                breadcrumb: 'RR_TXT',
                inset: true,


            },
            {
                path: () => {
                    let pathArr = window.location.pathname.split("/")
                    pathArr = pathArr.slice(2, 7)
                    return "/" + pathArr.join('/') + "/rr/SRV"
                },
                component: {
                    search: <RrSrvSearch key={"rr_srv_search"}/>,
                    create: <RrSrv isEmptyForm={true} isEditable={true} key={"rr_srv_create"}/>,
                    edit: <RrSrv isEditable={true} key={"rr_srv_edit"}/>,
                    details: <RrSrv key={"rr_srv_details"}/>
                },
                name: 'SRV',
                label: 'SRV Records',
                breadcrumb: 'RR_SRV',
                inset: true,
            },
            /*
                        {
                            path: () => {
                                let pathArr = window.location.pathname.split("/")
                                pathArr = pathArr.slice(2, 6)
                                return "/" + pathArr.join('/') + "/rr/GMSFOR"
                               // return "/" + pathArr.join('/') + "/rr/GEN"


                            },
                            component: {
                                search: <RrGmsForSearch key={"rr_gmsfor_search"}/>,
                                create: <RrGmsFor isEmptyForm={true} isEditable={true} key={"rr_gmsfor_create"}/>,
                                edit: <RrGmsFor isEmptyForm={false} isEditable={true} key={"rr_gmsfor_edit"}/>,
                                details: <RrGmsFor key={"rr_gmsfor_details"}/>
                            },
                            name: 'GMSFOR',
                           // name: 'GEN',
                            label: 'GMSFOR Records',
                            breadcrumb: 'RR_GMSFOR',
                            inset: true,
                        },
            */
            /*
                        {
                            path: () => {
                                let pathArr = window.location.pathname.split("/")
                                pathArr = pathArr.slice(2, 6)
                                return "/" + pathArr.join('/') + "/rr/GMSREV"
                                //  return "/" + pathArr.join('/') + "/rr/GEN"

                            },
                            component: {
                                search: <RrGmsRevSearch key={"rr_gmsrev_search"}/>,
                                create: <RrGmsRev isEmptyForm={true} isEditable={true} key={"rr_gmsrev_create"}/>,
                                edit: <RrGmsRev isEditable={true} key={"rr_gmsrev_edit"}/>,
                                details: <RrGmsRev key={"rr_gmsrev_details"}/>
                            },
                            name: 'GMSREV',
                            // name: 'GEN',
                            label: 'GMSREV Records',
                            breadcrumb: 'RR_GMSREV',
                            inset: true,
                        },
            */



            {
                path: () => {
                    let pathArr = window.location.pathname.split("/")
                    pathArr = pathArr.slice(2, 7)
                    return "/" + pathArr.join('/') + "/rr/GEN"


                },
                component: {
                    search: <RrGenSearch key={"rr_gen_search"}/>,
                    create: <RrGen isEmptyForm={true} isEditable={true} key={"rr_gen_create"}/>,
                    edit: <RrGen isEmptyForm={false} isEditable={true} key={"rr_gen_edit"}/>,
                    details: <RrGen key={"rr_gen_details"}/>
                },
                name: 'GEN',
                label: 'GEN Records',
                breadcrumb: 'RR_GEN',
                inset: true,
            },
            {
                path: () => {
                    let pathArr = window.location.pathname.split("/")// ['',dragon','dns','zones','details','340','rr','AAAA']
                    pathArr = pathArr.slice(2, 7)
                    return "/" + pathArr.join('/') + "/rr/AAAA"
                },
                component: {
                    search: <RrAaaaSearch key={"rr_AAAA_search"}/>,
                    create: <RrAaaa isEmptyForm={true} isEditable={true} key={"rr_AAAA_insert"}/>,
                    edit: <RrAaaa isEditable={true} key={"rr_AAAA_edit"}/>,
                    details: <RrAaaa key={"rr_AAAA_details"}/>
                },
                name: 'AAAA',
                label: 'AAAA Records',
                breadcrumb: 'RR_AAAA',
                inset: true,


            },
            {
                path: () => {
                    let pathArr = window.location.pathname.split("/")
                    pathArr = pathArr.slice(2, 7)
                    return "/" + pathArr.join('/') + "/rr/NAPTR"
                },
                component: {
                    search: <RrNaptrSearch key={"rr_naptr_search"}/>,
                    create: <RrNaptr isEmptyForm={true} isEditable={true} key={"rr_naptr_create"}/>,
                    edit: <RrNaptr isEditable={true} key={"rr_naptr_edit"}/>,
                    details: <RrNaptr key={"rr_naptr_details"}/>
                },
                name: 'NAPTR',
                label: 'NAPTR Records',
                breadcrumb: 'RR_NAPTR',
                inset: true,
            },

            {
                path: () => {
                    let pathArr = window.location.pathname.split("/")
                    pathArr = pathArr.slice(2, 7)
                    return "/" + pathArr.join('/') + "/ALL"
                },
                component: {
                    details: <ListAllRecords key={"rr_list_all"}/>
                },
                name: 'LISTALL',
                label: 'List All Zone Records',
                breadcrumb: 'RR_ListAllRecords',
                inset: true,
            },
        ]

    },
    {
        path: "/dns/zones/servers",
        breadcrumb: "",
        icon: "",
        label: "Servers",
        children: [
            {
                path: () => {
                    let pathArr = window.location.pathname.split("/")
                    pathArr = pathArr.slice(2, 7)
                    return "/" + pathArr.join('/') + "/servers/ATT-NS"
                    //return "/" + pathArr.join('/') + "/ATT-NS"

                },
                component: {
                    search: <AttNameServersSearch key={"srvr_attns_search"}/>,
                    create: <AttNameServers isEmptyForm={true} isEditable={true} key={"srvr_attns_create"}/>,
                    edit: <AttNameServers isEditable={true} key={"srvr_attns_edit"}/>,
                    details: <AttNameServers key={"srvr_attns_details"}/>
                },
                name: 'ATT-NS',
                label: 'ATT Name Servers',
                breadcrumb: 'ATTNameServer',
                inset: true,
            },
            {
                path: () => {
                    let pathArr = window.location.pathname.split("/")
                    pathArr = pathArr.slice(2, 7)
                    return "/" + pathArr.join('/') + "/servers/NONATT-NS"
                },
                component: {
                    search: <NonAttNameServersSearch key={"srvr_nonattns_search"}/>,
                    create: <NonAttNameServers isEmptyForm={true} isEditable={true} key={"srvr_nonattns_create"}/>,
                    edit: <NonAttNameServers isEditable={true} key={"srvr_nonattns_edit"}/>,
                    details: <NonAttNameServers key={"srvr_nonattns_details"}/>
                },
                name: 'NONATT-NS',
                label: 'Non ATT Name Servers',
                breadcrumb: 'Non-ATTNameServer',
                inset: true,


            },
            {
                path: () => {
                    let pathArr = window.location.pathname.split("/")
                    pathArr = pathArr.slice(2, 7)
                    return "/" + pathArr.join('/') + "/servers/NONATT-NS"
                },
                component: {
                    search: <NonAttNameServersSearch key={"masterlist_search"}/>,
                    create: <SlaveNameServer isEmptyForm={true} isEditable={true} key={"msaterlist_create"}/>,
                    /* edit: <NonAttNameServers isEditable={true} key={"srvr_nonattns_edit"}/>,
                     details: <NonAttNameServers key={"srvr_nonattns_details"}/>*/
                },
                name: 'NONATT-NS',
                label: 'Masterlist Name Servers',
                breadcrumb: 'MasterlistNameServer',
                inset: true,


            },
            {
                path: () => {
                    let pathArr = window.location.pathname.split("/")
                    pathArr = pathArr.slice(2, 7)
                    return "/" + pathArr.join('/') + "/servers/SRVRGRP"
                },
                component: {
                    search: <NameServerGroupSearch key={"srvr_search"}/>,
                    create: <NameServerGroup isEmptyForm={true} isEditable={true} key={"srvr_create"}/>,
                    edit: <NameServerGroup isEditable={true} key={"srvr_edit"}/>,
                    details: <NameServerGroup key={"srvr_details"}/>
                },
                name: 'SRVRGRP',
                label: 'Name Server Groups',
                breadcrumb: 'nameservergroup',
                inset: true,
            },
        ]

    },
    /*
      {
          path: '/dns/domains',
          label: 'New Domains',
          breadcrumb: 'NewDomains',
      },
  */  //Not supporting this feature now.When user add domains in dpt it should be displayed in dragon new domains.Dpt domains used work differently in the past.After creating domain cron is run to check if that domain is regsitred within 30days and is deleted if not after 30days.
// But in current dcu we cannot support this feature since it needs ti check with outside dns servers which may not be possible. So in dargon we areremoving new domains screen for now.
    {
        path: '/dns/historylogs',
        label: 'History Logs',
        breadcrumb: 'HistoryLogs',
    },
    {
        divider: true,
        path: "-"
    },
    {
        path: "zoneDelegation",
        breadcrumb: "zoneDelegation",
        icon: "",
        label: "Delegation Under this Zone",

        onclick: (e) => {
            e.preventDefault()
            let pathArr = window.location.pathname.split("/")
            pathArr = pathArr.slice(2, 7)
            pathArr.push('zoneDelegation')
            history.push("/" + pathArr.join('/'))

        }
    },
    {
        path: "/listAll",
        breadcrumb: "ListAll",
        icon: "",
        label: "List All Records",
        onclick: (e) => {
            e.preventDefault()
            let pathArr = window.location.pathname.split("/")
            pathArr = pathArr.slice(2, 7)
            pathArr.push('ALL')
            history.push("/" + pathArr.join('/'))
        }
    },
    {
        divider: true,
        path: "-"
    },
    {
        path: "/primaryZone",
        breadcrumb: "PrimaryZone",
        icon: "",
        label: "Add Primary Zone",
        privileges: ["su,ab,ai,au,ad,zb,zi,zu,zd,ri,ru,rd", "ab,ai,au,ad,zb,zi,zu,zd,ri,ru,rd"],

        onclick: (e) => {
            e.preventDefault()
            const reduxStore = store.getState()
            history.push(`/dns/accounts/details/${reduxStore.zones.zone.accountId}/create/primaryZone`)
        },
    },
    {
        path: "/secondaryZone",
        breadcrumb: "SecondaryZone",
        icon: "",
        label: "Add Secondary Zone",
        onclick: (e) => {
            e.preventDefault()
            const reduxStore = store.getState()
            history.push(`/dns/accounts/details/${reduxStore.zones.zone.accountId}/create/secondaryZone`)
        },
        privileges: ["su,ab,ai,au,ad,zb,zi,zu,zd,ri,ru,rd", "ab,ai,au,ad,zb,zi,zu,zd,ri,ru,rd"],

    }


]
export const ZoneSuspendMenu = _.cloneDeep(ZoneMenu).filter(m => !["Resource Records", "Servers"].includes(m.label))

export const AddZoneMenu = [
    {
        path: '/',
        label: 'Home',
        breadcrumb: 'Home',
    },
    {
        path: '/dns',
        label: '',
        breadcrumb: 'Dns',
    },
    {
        path: '/dns/accounts',
        label: 'Accounts',
        children: [
            {
                path: '/dns/accounts/search',
                label: 'Search',
                breadcrumb: 'search',
                inset: true,
            },
            {
                path: '/dns/accounts/create',
                label: 'Create',
                breadcrumb: 'create',
            }
        ]

    },
    {
        path: '/dns/zones',
        label: 'Zones',
        breadcrumb: 'Zones',
        children: [
            {
                path: '/dns/zones/search',
                label: 'Search Zones',
                breadcrumb: 'search',
                inset: true,
            },
            {
                path: '/dns/zones/ptr',
                label: 'Find Zone and PTR',
                breadcrumb: 'ptr',
            },
            {
                path: '/dns/zones/delegation',
                label: 'Find Zone and Delegation',
                breadcrumb: 'delegation',
            }

        ]

    },
    /*
      {
          path: '/dns/domains',
          label: 'New Domains',
          breadcrumb: 'NewDomains',
      },
  */  //Not supporting this feature now.When user add domains in dpt it should be displayed in dragon new domains.Dpt domains used work differently in the past.After creating domain cron is run to check if that domain is regsitred within 30days and is deleted if not after 30days.
// But in current dcu we cannot support this feature since it needs ti check with outside dns servers which may not be possible. So in dargon we areremoving new domains screen for now.
    {
        path: '/dns/history',
        label: 'History Logs',
        breadcrumb: 'HistoryLogs',
    },
    {
        divider: true,
        path: "-"
    },
]
export const SysAdminMenu = [
    {
        path: '/',
        label: 'Home',
        breadcrumb: 'Home',
    },
    {
        path: '/sys',
        label: '',
        breadcrumb: 'Sysadmin',
    },
    {
        path: '/sys/users',
        label: 'Users',
        breadcrumb: 'Users',
    },
    {
        path: '/sys/accountlogs',
        label: 'AccountLogs',
        breadcrumb: 'AccountLogs',
    },
    {
        path: '/sys/historylogs',
        label: 'History Logs',
        breadcrumb: 'HistoryLogs',
    },
    {
        path: '/sys/tlds',
        label: 'Top Level Domains',
        breadcrumb: 'TopLevelDomains',
    },

];
export const AccountDropDownMenu = [
    {
        path: '/',
        label: 'Home',
        breadcrumb: 'Home',

    },
    {
        path: '/profile',
        label: 'MyAccount',
        breadcrumb: 'profile',
    },
    {
        path: '/',
        label: 'Logoff',
        breadcrumb: 'logoff',
    },

];
export const ErrorPage = [
    {
        path: '/error',
        label: 'Home',
        //icon: <HomeIcon/>,
        breadcrumb: '',
    }

];

