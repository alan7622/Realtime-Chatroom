import {Dropdown} from "react-bootstrap";
import {Button, Checkbox, FormControlLabel, Menu, MenuItem} from "@material-ui/core";
import React, {useState} from "react";
import PropTypes from "prop-types";
import filterFactory, {textFilter, customFilter, Comparator, FILTER_TYPES} from 'react-bootstrap-table2-filter';
import {Row, Col} from 'react-bootstrap';
import ArrowDropDownIcon from "@material-ui/icons/ArrowDropDown";
import clsx from "clsx";

export function ShowHideButton(props) {
    const [open, setOpen] = useState(false);
    const {columns, onColumnToggle, toggles} = props.columnToggleProps;
    return (<>
            <Button aria-controls="simple-menu" aria-haspopup="true"
                    variant="contained" color="primary"
                    onClick={(e) => setOpen(e.currentTarget)}
                    className={"dns-blue-button"}>
                Column Visibility<ArrowDropDownIcon/>
            </Button>
            <Menu
                id="simple-menu"
                anchorEl={open}
                keepMounted
                open={Boolean(open)}
                onClose={() => setOpen(null)}
            >
                {
                    columns.map(column => ({
                        ...column,
                        toggle: toggles[column.dataField]
                    })).map(column => {
                        if (column.dataField) {
                            return column.showHideSelection && <MenuItem key={column.dataField}> <FormControlLabel
                                control={
                                    <Checkbox checked={column.toggle}
                                              onChange={() => onColumnToggle(
                                                  column.dataField)}
                                              name={`showColumn${column.name}`}
                                    />
                                }
                                label={column.text}
                            /></MenuItem>;
                        }
                    })}
            </Menu>
        </>

    );
}
export function ShowHideHistoryLogButton(props) {
    const [open, setOpen] = useState(false);
    const {columns, onColumnToggle, toggles} = props.columnToggleProps;
    return (<>
            <Button aria-controls="simple-menu" aria-haspopup="true"
                    variant="contained" color="primary"
                    onClick={(e) => setOpen(e.currentTarget)}
                    className={"dns-blue-button"}>
                History Visibility<ArrowDropDownIcon/>
            </Button>
            <Menu
                id="simple-menu"
                anchorEl={open}
                keepMounted
                open={Boolean(open)}
                onClose={() => setOpen(null)}
            >
                {
                    columns.map(column => ({
                        ...column,
                        toggle: toggles[column.dataField]
                    })).map(column => {
                        if (column.dataField) {
                            return column.showHideSelection && <MenuItem key={column.dataField}> <FormControlLabel
                                control={
                                    <Checkbox checked={column.toggle}
                                              onChange={() => onColumnToggle(
                                                  column.dataField)}
                                              name={`showColumn${column.name}`}
                                    />
                                }
                                label={column.text}
                            /></MenuItem>;
                        }
                    })}
            </Menu>
        </>

    );
}


export function pageRenderer({page, active, disabled, title, onPageChange}) {
    const classes = clsx({
        active,
        disabled,
        'page-item': true
    });

    const handleClick = function (e) {
        e.preventDefault();
        onPageChange(page);
    };

    return (
        <li className={classes} title={title} key={page}>
            <a href="#" onClick={handleClick} className={clsx({
                'page-link': true,
                'dns-blue-button': active && typeof page != 'string'
            })}> {page}</a>
        </li>
    );
}


export class SizePerPageRenderer extends React.Component {
    constructor() {
        super();
        this.state = {
            openPgMenu: null
        };
    }

    render() {
        const {currSizePerPage, onSizePerPageChange, options} = this.props;
        return (<div>
            <Button aria-controls="simple-menu" aria-haspopup="true"
                    color="primary" className={'dns-blue-button'}
                    variant={'contained'}
                    onClick={(e) => this.setState({openPgMenu: e.currentTarget})}>
                {currSizePerPage}<ArrowDropDownIcon/>
            </Button>
            <Menu
                id="simple-menu"
                anchorEl={this.state.openPgMenu}
                keepMounted
                open={Boolean(this.state.openPgMenu)}
                onClose={() => this.setState({openPgMenu: null})}
            >
                {options.map(option => (
                    <MenuItem selected={currSizePerPage == option.page}
                              key={option.text}
                              onClick={() => {this.setState({openPgMenu: null})
                              onSizePerPageChange(option.page)}}
                    > {option.text}</MenuItem>))}
            </Menu>
        </div>);
    }
}


export class CustomTextFilterComponent extends React.Component {
    constructor(props) {
        super(props);
        this.filter = this.filter.bind(this);
        this.getValue = this.getValue.bind(this);
        this.onChange = this.onChange.bind(this);
        this.state = {value: '', comparator: Comparator.EQ};
    }

    onChange(e) {
       // console.log('change', e.target.value)
        this.setState({value: e.target.value});
    }

    getValue() {
        return this.state.value;
    }

    filter() {
        console.log('change', this.state)
        this.props.onFilter({
            value: this.state.value,
            comparator: this.state.comparator
        });
    }

    render() {
        return <Row xs={1} md={1}>
            <Col md={{span: 10, offset: 2}}> <select
                key="select"
                ref={node => this.select = node}
                className="form-control"
                onChange={(e) => this.setState({comparator: e.target.value})}
            >
                <option value={Comparator.EQ}>Equals</option>
                <option value={"contains"}>Contains</option>
                <option value={"end"}>Ends with</option>
            </select></Col>
        </Row>

    }
}


CustomTextFilterComponent.propTypes = {
    column: PropTypes.object.isRequired,
    onFilter: PropTypes.func.isRequired
};