#!/bin/sh
cd ../webroot
npm install
npm run build
cp  -r ../dev_stack/META-INF ./dist/
cp  -r ../dev_stack/WEB-INF ./dist/
cp ../dev_stack/index.jsp ./dist/
#cd ../dist
cd dist
/usr/java/jdk/bin/jar -cvf DragonWebApp.war *
